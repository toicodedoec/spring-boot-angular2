package ch.admin.oss.uvg.endpoint;

import java.math.BigDecimal;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.PersonDto;

/**
 * @author hha
 */
public class UvgGesellschafterDto extends AbstractOSSDto {

	private PersonDto person;
	private BigDecimal lohnsumme;

	public PersonDto getPerson() {
		return person;
	}

	public void setPerson(PersonDto person) {
		this.person = person;
	}

	public BigDecimal getLohnsumme() {
		return lohnsumme;
	}

	public void setLohnsumme(BigDecimal lohnsumme) {
		this.lohnsumme = lohnsumme;
	}

}
