/*
 * HrServiceAdapter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.hr;

import java.io.Serializable;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

/**
 * @author hha
 */
@Component
public class UPRegServiceAdapter implements IUPRegServiceAdapter {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UPRegServiceAdapter.class);

	@Autowired
	private RestTemplate restTemplate;

	@Value("${hr.notary.url}")
	private String notaryUrl;

	@Override
	public List<NotaryDto> searchNotaries(String kanton, String familienname, String vorname) {
		String url = MessageFormat.format(notaryUrl,
			kanton,
			familienname,
			vorname
		);
		return exchangeGetList(url, NotaryDto[].class);
	}

	public <T extends Serializable> List<T> exchangeGetList(String url, Class<T[]> responseClazz) {
		try {
			return Arrays.asList(restTemplate.getForObject(url, responseClazz));
		} catch (HttpClientErrorException e) {
			// Due to an external error => return an empty result.
			LOGGER.error("Error occurs when calling to URL " + url, e);
		}
		return Collections.emptyList();
	}
}
