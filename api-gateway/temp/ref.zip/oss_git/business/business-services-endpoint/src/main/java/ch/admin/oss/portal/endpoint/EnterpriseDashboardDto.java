package ch.admin.oss.portal.endpoint;

import java.util.List;

import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.organisation.endpoint.EinladungDto;
import ch.admin.oss.organisation.endpoint.ZugriffDto;

public class EnterpriseDashboardDto {
	private Long orgId;
	private OrganisationProcessesDto finishedProcesses;
	private OrganisationProcessesDto openProcesses;
	private String defaultName;
	private AdresseDto domizil;
	private List<ZugriffDto> zugrrifs;
	private List<EinladungDto> einladungs;

	public EnterpriseDashboardDto() {
		this.finishedProcesses = new OrganisationProcessesDto();
		this.openProcesses = new OrganisationProcessesDto();
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public OrganisationProcessesDto getFinishedProcesses() {
		return finishedProcesses;
	}

	public void setFinishedProcesses(OrganisationProcessesDto finishedProcesses) {
		this.finishedProcesses = finishedProcesses;
	}

	public OrganisationProcessesDto getOpenProcesses() {
		return openProcesses;
	}

	public void setOpenProcesses(OrganisationProcessesDto openProcesses) {
		this.openProcesses = openProcesses;
	}

	public String getDefaultName() {
		return defaultName;
	}

	public void setDefaultName(String defaultName) {
		this.defaultName = defaultName;
	}

	public AdresseDto getDomizil() {
		return domizil;
	}

	public void setDomizil(AdresseDto domizil) {
		this.domizil = domizil;
	}

	public List<ZugriffDto> getZugrrifs() {
		return zugrrifs;
	}

	public void setZugrrifs(List<ZugriffDto> zugrrifs) {
		this.zugrrifs = zugrrifs;
	}

	public List<EinladungDto> getEinladungs() {
		return einladungs;
	}

	public void setEinladungs(List<EinladungDto> einladungs) {
		this.einladungs = einladungs;
	}

}
