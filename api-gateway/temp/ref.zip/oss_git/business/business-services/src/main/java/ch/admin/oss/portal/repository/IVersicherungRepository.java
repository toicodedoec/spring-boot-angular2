package ch.admin.oss.portal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ch.admin.oss.domain.VersicherungEntity;

/**
 * 
 * @author hhu
 *
 */
@Repository
public interface IVersicherungRepository extends JpaRepository<VersicherungEntity, Long>{

}
