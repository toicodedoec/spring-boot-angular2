/*
 * ISwissregServiceAdapter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author hhg
 */
public interface IZefixServiceAdapter {

	ShortResponseDto searchCompanyByName(String name, RechtsformEnum rechtsform, Integer bfsNr)
		throws ZefixTooShortNameException, ZefixTooManyResultsException, ZefixBusinessException;

	DetailledResponseDto getCompanyDetailByUid(int uid, RechtsformEnum rechtsform)
		throws ZefixInvalidUIDException, ZefixBusinessException;

	DetailledResponseDto getCompanyDetailByChid(String chid, RechtsformEnum rechtsform)
		throws ZefixInvalidCHIdException, ZefixBusinessException;

	DetailledResponseDto getCompanyDetail(String uidOrChid)
		throws ZefixInvalidCHIdException, ZefixInvalidUIDException, ZefixBusinessException;
}
