/*
 * HrTemplateType
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ch.admin.oss.util.TemplateFile;

/**
 * @author hha
 */
public enum UvgTemplateType {

	BASIC(TemplateFile.get("UVG"));

	private List<TemplateFile> files;

	private UvgTemplateType(TemplateFile... files) {
		this.files = Stream.of(files)
			.map(item -> {
				item.setFileName("uvg/" + item.getFileName());
				return item;
			})
			.collect(Collectors.toList());
	}

	public List<TemplateFile> getFiles() {
		return files;
	}
	
}