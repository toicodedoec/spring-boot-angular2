/*
 * BrancheAdminDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * @author xdg
 */
public class BrancheAdminDto extends AbstractGruppeDto {

	@NotNull
	private String code;

	@NotNull
	private boolean aktiv;

	@NotNull
	private boolean suva;

	@Valid
	@NotNull
	private StandardTextDto standardText;

	public BrancheAdminDto() {}

	public boolean isAktiv() {
		return aktiv;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public boolean isSuva() {
		return suva;
	}

	public void setSuva(boolean suva) {
		this.suva = suva;
	}

	public StandardTextDto getStandardText() {
		return standardText;
	}

	public void setStandardText(StandardTextDto standardText) {
		this.standardText = standardText;
	}

}
