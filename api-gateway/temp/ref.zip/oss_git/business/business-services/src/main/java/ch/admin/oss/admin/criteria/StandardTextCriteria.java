/*
 * StandardTextCriteria
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.criteria;

import ch.admin.oss.common.enums.StandardTextTypeEnum;

/**
 * @author hha
 */
public class StandardTextCriteria extends AbstractPaginationCriteria {

	private StandardTextTypeEnum type;
	private String code;
	private String text;

	public StandardTextTypeEnum getType() {
		return type;
	}

	public void setType(StandardTextTypeEnum type) {
		this.type = type;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
