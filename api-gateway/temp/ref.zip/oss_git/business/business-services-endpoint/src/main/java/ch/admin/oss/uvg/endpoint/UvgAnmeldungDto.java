package ch.admin.oss.uvg.endpoint;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import ch.admin.oss.admin.endpoint.VersicherungDto;
import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.CommonAddress;
import ch.admin.oss.common.ProzessDto;
import ch.admin.oss.common.UvgKontaktAdresse;
import ch.admin.oss.common.enums.VersichererWunschEnum;
import ch.admin.oss.hr.endpoint.EditingState;

/**
 * @author hhu
 */
public class UvgAnmeldungDto extends AbstractOSSDto {
	private ProzessDto prozess;

	private BigDecimal angestellteHeute;
	private Date ersteAnstellung;

	private BigDecimal angestellteZukunft;
	private Date ersteAnstellungZukunft;

	private boolean angestelltePartner;
	private boolean angestellteFamilie;

	private boolean angestellteGesellschafter;
	private boolean angestellteLehrling;
	private boolean angestellteOhneLohn;
	private boolean angestellteAushilfe;

	private String partnerName;
	private BigDecimal partnerLohnsumme;
	private boolean partnerFreiwillig;

	private BigDecimal angehoerigeLohnsumme;
	private BigDecimal angehoerigeAnzahl;
	private boolean angehoerigeFreiwillig;
	private boolean uvgInhaberFreiwillig;

	@Min(0)
	@NotNull
	private BigDecimal lohnsummeFolgejahr;

	@Min(0)
	@NotNull
	private BigDecimal lohnsumme;

	@NotNull
	private CodeWertDto zahlungsmodus;
	private boolean taggeldAnBetrieb;

	private String ahvName;
	private String ahvNummer;
	private String versicherungName;
	private String versicherungNummer;

	private Integer glAnzahl;
	private BigDecimal glLohnsumme;
	private BigDecimal vrLohnsumme;
	
	private VersichererWunschEnum versichererWunsch;
	
	private String kontaktName;
	private String kontaktVorname;
	
	@Valid
	@NotNull(groups = {CommonAddress.class, UvgKontaktAdresse.class})
	private AdresseDto kontaktAdresse;

	private String bemerkungen;

	private Set<UvgGesellschafterDto> gesellschafters = new HashSet<>();

	@NotNull
	private List<VersicherungDto> versicherer = new ArrayList<>();

	private EditingState editingState;
	
	public ProzessDto getProzess() {
		return prozess;
	}

	public void setProzess(ProzessDto prozess) {
		this.prozess = prozess;
	}

	public BigDecimal getAngestellteHeute() {
		return angestellteHeute;
	}

	public void setAngestellteHeute(BigDecimal angestellteHeute) {
		this.angestellteHeute = angestellteHeute;
	}

	public Date getErsteAnstellung() {
		return ersteAnstellung;
	}

	public void setErsteAnstellung(Date ersteAnstellung) {
		this.ersteAnstellung = ersteAnstellung;
	}

	public BigDecimal getAngestellteZukunft() {
		return angestellteZukunft;
	}

	public void setAngestellteZukunft(BigDecimal angestellteZukunft) {
		this.angestellteZukunft = angestellteZukunft;
	}

	public Date getErsteAnstellungZukunft() {
		return ersteAnstellungZukunft;
	}

	public void setErsteAnstellungZukunft(Date ersteAnstellungZukunft) {
		this.ersteAnstellungZukunft = ersteAnstellungZukunft;
	}

	public boolean isAngestelltePartner() {
		return angestelltePartner;
	}

	public void setAngestelltePartner(boolean angestelltePartner) {
		this.angestelltePartner = angestelltePartner;
	}

	public boolean isAngestellteFamilie() {
		return angestellteFamilie;
	}

	public void setAngestellteFamilie(boolean angestellteFamilie) {
		this.angestellteFamilie = angestellteFamilie;
	}

	public boolean isAngestellteGesellschafter() {
		return angestellteGesellschafter;
	}

	public void setAngestellteGesellschafter(boolean angestellteGesellschafter) {
		this.angestellteGesellschafter = angestellteGesellschafter;
	}

	public boolean isAngestellteLehrling() {
		return angestellteLehrling;
	}

	public void setAngestellteLehrling(boolean angestellteLehrling) {
		this.angestellteLehrling = angestellteLehrling;
	}

	public boolean isAngestellteOhneLohn() {
		return angestellteOhneLohn;
	}

	public void setAngestellteOhneLohn(boolean angestellteOhneLohn) {
		this.angestellteOhneLohn = angestellteOhneLohn;
	}

	public boolean isAngestellteAushilfe() {
		return angestellteAushilfe;
	}

	public void setAngestellteAushilfe(boolean angestellteAushilfe) {
		this.angestellteAushilfe = angestellteAushilfe;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public BigDecimal getPartnerLohnsumme() {
		return partnerLohnsumme;
	}

	public void setPartnerLohnsumme(BigDecimal partnerLohnsumme) {
		this.partnerLohnsumme = partnerLohnsumme;
	}

	public boolean isPartnerFreiwillig() {
		return partnerFreiwillig;
	}

	public void setPartnerFreiwillig(boolean partnerFreiwillig) {
		this.partnerFreiwillig = partnerFreiwillig;
	}

	public BigDecimal getAngehoerigeLohnsumme() {
		return angehoerigeLohnsumme;
	}

	public void setAngehoerigeLohnsumme(BigDecimal angehoerigeLohnsumme) {
		this.angehoerigeLohnsumme = angehoerigeLohnsumme;
	}

	public BigDecimal getAngehoerigeAnzahl() {
		return angehoerigeAnzahl;
	}

	public void setAngehoerigeAnzahl(BigDecimal angehoerigeAnzahl) {
		this.angehoerigeAnzahl = angehoerigeAnzahl;
	}

	public boolean isAngehoerigeFreiwillig() {
		return angehoerigeFreiwillig;
	}

	public void setAngehoerigeFreiwillig(boolean angehoerigeFreiwillig) {
		this.angehoerigeFreiwillig = angehoerigeFreiwillig;
	}

	public boolean isUvgInhaberFreiwillig() {
		return uvgInhaberFreiwillig;
	}

	public void setUvgInhaberFreiwillig(boolean uvgInhaberFreiwillig) {
		this.uvgInhaberFreiwillig = uvgInhaberFreiwillig;
	}

	public String getKontaktName() {
		return kontaktName;
	}

	public void setKontaktName(String kontaktName) {
		this.kontaktName = kontaktName;
	}

	public String getKontaktVorname() {
		return kontaktVorname;
	}

	public void setKontaktVorname(String kontaktVorname) {
		this.kontaktVorname = kontaktVorname;
	}

	public AdresseDto getKontaktAdresse() {
		return kontaktAdresse;
	}

	public void setKontaktAdresse(AdresseDto kontaktAdresse) {
		this.kontaktAdresse = kontaktAdresse;
	}

	public Set<UvgGesellschafterDto> getGesellschafters() {
		return gesellschafters;
	}

	public void setGesellschafters(Set<UvgGesellschafterDto> gesellschafters) {
		this.gesellschafters = gesellschafters;
	}

	public BigDecimal getLohnsummeFolgejahr() {
		return lohnsummeFolgejahr;
	}

	public void setLohnsummeFolgejahr(BigDecimal lohnsummeFolgejahr) {
		this.lohnsummeFolgejahr = lohnsummeFolgejahr;
	}

	public BigDecimal getLohnsumme() {
		return lohnsumme;
	}

	public void setLohnsumme(BigDecimal lohnsumme) {
		this.lohnsumme = lohnsumme;
	}

	public CodeWertDto getZahlungsmodus() {
		return zahlungsmodus;
	}

	public void setZahlungsmodus(CodeWertDto zahlungsmodus) {
		this.zahlungsmodus = zahlungsmodus;
	}

	public boolean isTaggeldAnBetrieb() {
		return taggeldAnBetrieb;
	}

	public void setTaggeldAnBetrieb(boolean taggeldAnBetrieb) {
		this.taggeldAnBetrieb = taggeldAnBetrieb;
	}

	public String getAhvName() {
		return ahvName;
	}

	public void setAhvName(String ahvName) {
		this.ahvName = ahvName;
	}

	public String getAhvNummer() {
		return ahvNummer;
	}

	public void setAhvNummer(String ahvNummer) {
		this.ahvNummer = ahvNummer;
	}

	public String getVersicherungName() {
		return versicherungName;
	}

	public void setVersicherungName(String versicherungName) {
		this.versicherungName = versicherungName;
	}

	public String getVersicherungNummer() {
		return versicherungNummer;
	}

	public void setVersicherungNummer(String versicherungNummer) {
		this.versicherungNummer = versicherungNummer;
	}

	public Integer getGlAnzahl() {
		return glAnzahl;
	}

	public void setGlAnzahl(Integer glAnzahl) {
		this.glAnzahl = glAnzahl;
	}

	public BigDecimal getGlLohnsumme() {
		return glLohnsumme;
	}

	public void setGlLohnsumme(BigDecimal glLohnsumme) {
		this.glLohnsumme = glLohnsumme;
	}

	public BigDecimal getVrLohnsumme() {
		return vrLohnsumme;
	}

	public void setVrLohnsumme(BigDecimal vrLohnsumme) {
		this.vrLohnsumme = vrLohnsumme;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public VersichererWunschEnum getVersichererWunsch() {
		return versichererWunsch;
	}

	public void setVersichererWunsch(VersichererWunschEnum versichererWunsch) {
		this.versichererWunsch = versichererWunsch;
	}

	public List<VersicherungDto> getVersicherer() {
		return versicherer;
	}

	public void setVersicherer(List<VersicherungDto> versicherer) {
		this.versicherer = versicherer;
	}

	public EditingState getEditingState() {
		return editingState;
	}

	public void setEditingState(EditingState editingState) {
		this.editingState = editingState;
	}
}
