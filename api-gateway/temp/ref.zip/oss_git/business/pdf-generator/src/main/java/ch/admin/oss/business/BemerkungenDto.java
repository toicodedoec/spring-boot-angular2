/*
 * BemerkungenDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

/**
 * @author hhg
 *
 */
public class BemerkungenDto {
	
	private String anschluss;
	private Integer anschlus;
	private Boolean partnerWeb;
	private String bemerkung;
	private Boolean verhaeltnis;
	
	public BemerkungenDto(String anschluss, Boolean partnerWeb, String bemerkung, Integer anschlus, Boolean verhaeltnis) {
		this.anschluss = anschluss;
		//this.anschlus = anschlus.intValue() <= 0 ? Integer.valueOf(0) : anschlus;
		this.anschlus = anschlus;
		this.partnerWeb = partnerWeb;
		this.bemerkung = bemerkung;
		this.verhaeltnis = verhaeltnis;
	}

	public String getAnschluss() {
		return anschluss;
	}

	public Boolean getPartnerWeb() {
		return partnerWeb;
	}

	public String getBemerkung() {
		return bemerkung;
	}

	public Integer getAnschlus() {
		return anschlus;
	}

	public Boolean getVerhaeltnis() {
		return verhaeltnis;
	}
}
