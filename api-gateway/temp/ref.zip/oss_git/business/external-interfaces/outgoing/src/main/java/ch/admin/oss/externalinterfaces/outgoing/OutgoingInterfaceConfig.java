/*
 * OutgoingInterfaceConfig
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.web.client.RestTemplate;

import ch.admin.e_service.zefix._2015_06_26.CompanyDetailedInfoType;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyDetailedInfoDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixServiceAdapter;

/**
 * Centralized place to configure the proxy to all outgoing external interfaces.
 * 
 * @author phd
 */
@Configuration
@ComponentScan(basePackageClasses = OutgoingInterfaceConfig.class)
@ImportResource({
	"classpath:common-cxf-config.xml", 
	"classpath:swissregWebServiceClient-cxf-config.xml",
	"classpath:zefixWebServiceClient-cxf-config.xml"
})
public class OutgoingInterfaceConfig {

	@Bean(name = "outgoingInterfaceMapper")
	public DozerBeanMapper mapper() {
		DozerBeanMapper mapper = new DozerBeanMapper();
		mapper.addMapping(new BeanMappingBuilder() {
			@Override
			protected void configure() {
				mapping(CompanyDetailedInfoType.class, CompanyDetailedInfoDto.class,
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(ZefixServiceAdapter.COMPANY_DETAIL)
				)
				.fields("address.addressInformation", "address");
			}
		});
		return mapper;
	}

	@Bean
	public RestTemplateBuilder restTemplateBuilder() {
		return new RestTemplateBuilder();
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}

}
