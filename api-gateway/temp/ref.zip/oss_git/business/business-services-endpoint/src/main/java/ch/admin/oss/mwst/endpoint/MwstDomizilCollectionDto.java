/*
 * MwstDomizilCollectionDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.mwst.endpoint;

import java.util.ArrayList;
import java.util.List;

import ch.admin.oss.common.AdresseDto;

/**
 * @author xdg
 */
public class MwstDomizilCollectionDto {

	private List<AdresseDto> orgDomizils = new ArrayList<AdresseDto>();
	private List<AdresseDto> korrespondenz = new ArrayList<AdresseDto>();
	private List<AdresseDto> inhaber = new ArrayList<AdresseDto>();

	public MwstDomizilCollectionDto() {}

	public List<AdresseDto> getOrgDomizils() {
		return orgDomizils;
	}

	public List<AdresseDto> getKorrespondenz() {
		return korrespondenz;
	}

	public List<AdresseDto> getInhaber() {
		return inhaber;
	}

}
