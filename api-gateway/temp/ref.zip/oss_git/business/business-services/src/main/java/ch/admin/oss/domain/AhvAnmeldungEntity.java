/*
 * AhvAnmeldungEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;

import ch.admin.oss.common.enums.AhvGruendungsartEnum;
import ch.admin.oss.common.enums.AhvUebernahmeEnum;
import ch.admin.oss.common.enums.AhvVerbandszugehoerigkeitEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_AHV_ANMELDUNG")
public class AhvAnmeldungEntity extends AbstractOSSEntity implements IProzessEntity {

	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name="FK_AHV_PROZESS"))
	private ProzessEntity prozess;

	@Column(name = "VERBAND_ID")
	private Long verbandId;

	@Column(name = "VERBAND_BEITRITT_DATUM")
	private LocalDate verbandBeitrittDatum;

	@Enumerated(EnumType.STRING)
	@Column(name = "VERBAND_ZUGEHOERIGKEIT")
	private AhvVerbandszugehoerigkeitEnum verbandZugehoerigkeit;

	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "VERBAND_FAK", length = 1)
	private Boolean verbandFak;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "GRUEND_ART")
	private AhvGruendungsartEnum gruendArt;
	
	@Column(name = "GRUEND_ALTE_BEZEICHNUNG")
	private String gruendAlteBezeichnung;

	@Enumerated(EnumType.STRING)
	@Column(name = "GRUEND_UEBERNAME_ART")
	private AhvUebernahmeEnum gruendUebernameArt;
	
	@Column(name = "GRUEND_UEBERNAME_NAME")
	private String gruendUebernameName;

	@Column(name = "GRUEND_UEBERNAME_NUMMER")
	private String gruendUebernameNummer;
	
	@Column(name = "KAPITAL_EIGEN")
	private BigDecimal kapitalEigen;

	@Column(name = "KAPITAL_DARLEHEN")
	private BigDecimal kapitalDarlehen;

	@Column(name = "INVEST_WERKZEUG_KAUF")
	private BigDecimal investWerkzeugKauf;
	
	@Column(name = "INVEST_FAHRZEUG_KAUF")
	private BigDecimal investFahrzeugKauf;
	
	@Column(name = "INVEST_WAREN_INV_KAUF")
	private BigDecimal investWarenInvKauf;
	
	@Column(name = "INVEST_WEITERE_KAUF_ART")
	private String investWeitereKaufArt;
	
	@Column(name = "INVEST_WEITERE_KAUF")
	private BigDecimal investWeitereKauf;
	
	@Column(name = "INVEST_BUERO_MIETE")
	private BigDecimal investBueroMiete;
	
	@Column(name = "INVEST_LADEN_MIETE")
	private BigDecimal investLadenMiete;
	
	@Column(name = "INVEST_WERKSTATT_MIETE")
	private BigDecimal investWerkstattMiete;
	
	@Column(name = "INVEST_LAGER_MIETE")
	private BigDecimal investLagerMiete;
	
	@Column(name = "INVEST_FAHRZEUG_MIETE")
	private BigDecimal investFahrzeugMiete;
	
	@Column(name = "INVEST_WEITERE_MIETE_ART")
	private String investWeitereMieteArt;
	
	@Column(name = "INVEST_WEITERE_MIETE")
	private BigDecimal investWeitereMiete;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "RAUM_KEINE", length = 1)
	private Boolean raumKeine;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "RAUM_EIGENE", length = 1)
	private Boolean raumEigene;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "RAUM_WOHNUNG", length = 1)
	private Boolean raumWohnung;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "RAUM_KUNDE", length = 1)
	private Boolean raumKunde;
	
	@Column(name = "TAETIG_ANZ_KUNDEN")
	private Integer taetigAnzKunden;
	
	@Column(name = "TAETIG_KUNDE1")
	private String taetigKunde1;
	
	@Column(name = "TAETIG_KUNDE2")
	private String taetigKunde2;
	
	@Column(name = "TAETIG_KUNDE3")
	private String taetigKunde3;
	
	@Lob
	@Column(name = "TAETIG_ART_AUFTRAEGE")
	private String taetigArtAuftraege;
	
	@Column(name = "TAETIG_DATUM_LETZTER_AUFTRAG")
	private LocalDate taetigDatumLetzterAuftrag;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "TAETIG_AGENT", length = 1)
	private Boolean taetigAgent;
	
	@Column(name = "TAETIG_AUFTRAGGEBER")
	private String taetigAuftraggeber;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "TAETIG_GEMEINSAME_KUNDEN", length = 1)
	private Boolean taetigGemeinsameKunden;
	
	@Column(name = "ZEFIX_STATUS")
	@Enumerated(EnumType.STRING)
	private HRStatusEnum zefixStatus;

	@Column(name = "ZEFIX_COMPANY_NAME")
	private String zefixCompanyName;

	@Column(name = "ZEFIX_POLGEMEINDE")
	private String zefixPolGemeinde;

	@Column(name = "ZEFIX_CH_NR")
	private String zefixChNr;

	@Column(name = "ZEFIX_UID")
	private String zefixUid;

	@Column(name = "ZEFIX_SHAB_NR")
	private String zefixShabNr;

	@Column(name = "ZEFIX_SHAB_DATE")
	private LocalDate zefixShabDate;
	
	@Column(name = "ANGESTELLTE_VR_HONORARE")
	private BigDecimal angestellteVrHonorare;

	@Column(name = "ANGESTELLTE_GI_ANZ")
	private Integer angestellteGiAnz;

	@Column(name = "ANGESTELLTE_GI_LOHNSUMME")
	private BigDecimal angestellteGiLohnSumme;

	@Column(name = "ANGESTELLTE_GI_LOHNSEIT")
	private LocalDate angestellteGiLohnSeit;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "ANGESTELLTE_GI_HATKINDER")
	private Boolean angestellteGiHatKinder;
	
	@Column(name = "ANGESTELLTE_ANG_ANZ")
	private Integer angestellteAngAnz;
	
	@Column(name = "ANGESTELLTE_ANG_LOHNSUMME")
	private BigDecimal angestellteAngLohnSumme;
	
	@Column(name = "ANGESTELLTE_ANG_LOHNSEIT")
	private LocalDate angestellteAngLohnSeit;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "ANGESTELLTE_ANG_HATKINDER")
	private Boolean angestellteAngHatKinder;
	
	@Column(name = "ANGESTELLTE_UEB_ANZ")
	private Integer angestellteUebAnz;
	
	@Column(name = "ANGESTELLTE_UEB_LOHNSUMME")
	private BigDecimal angestellteUebLohnSumme;
	
	@Column(name = "ANGESTELLTE_UEB_LOHNSEIT")
	private LocalDate angestellteUebLohnSeit;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "ANGESTELLTE_UEB_HATKINDER")
	private Boolean angestellteUebHatKinder;
	
	@Column(name = "KONTAKT_VORNAME")
	private String kontaktVorname;
	
	@Column(name = "KONTAKT_FAMILIENNAME")
	private String kontaktFamilienname;
	
	@Column(name = "KONTAKT_TELEFON")
	private String kontaktTelefon;
	
	@Column(name = "KONTAKT_MOBILE")
	private String kontaktMobile;
	
	@Column(name = "KONTAKT_EMAIL")
	private String kontaktEmail;
	
	@Lob
	@Column(name = "KONTAKT_BEMERKUNGEN")
	private String kontaktBemerkungen;
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "ahv", cascade = CascadeType.ALL)
	private Set<AhvTeilhaberEntity> ahvTeilhabers = new HashSet<>();

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE_KONTAKT", foreignKey = @ForeignKey(name="FK_AHV_ADRESSE_KONTAKT"))
	private AdresseEntity adresseKontakt;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE_TREUHAND", foreignKey = @ForeignKey(name="FK_AHV_ADRESSE_TREUHAND"))
	private AdresseEntity adresseTreuhand;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "SONDER_PARTNER_WEB", length = 1)
	private Boolean sonderPartnerWeb;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "SONDER_VERBAND", length = 1)
	private Boolean sonderVerband;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "SONDER_BVG", length = 1)
	private Boolean sonderBvg;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "SONDER_UVG", length = 1)
	private Boolean sonderUvg;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "SONDER_KKV", length = 1)
	private Boolean sonderKkv;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "SONDER_WEITERE", length = 1)
	private Boolean sonderWeitere;

	@Column(name = "SONDER_FORMULARE")
	private Integer sonderFormulare;

	@Column(name = "SOZIALVERS_UVG")
	private String sozialversUvg;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "SOZIALVERS_BVG", length = 1)
	private Boolean sozialversBvg;
	
	@Column(name = "SOZIALVERS_BVG_NAME")
	private String sozialversBvgName;
	
	@Column(name = "SOZIALVERS_BVG_GRUND")
	private String sozialversBvgGrund;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "LOHNBUCH_PAPIER", length = 1)
	private Boolean lohnbuchPapier;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "LOHNBUCH_COMPUTER", length = 1)
	private Boolean lohnbuchComputer;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "LOHNBUCH_SUVA", length = 1)
	private Boolean lohnbuchSuva;
	
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "LOHNBUCH_TREUHAENDER", length = 1)
	private Boolean lohnbuchTreuhaender;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "ahvAnmeldung", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<AhvFilialeEntity> ahvFiliales = new HashSet<>();
	
	public AhvAnmeldungEntity() {
		prozess = new ProzessEntity(ProzessTypEnum.AHV, true);
	}
	
	public AhvAnmeldungEntity(OrganisationEntity org) {
		prozess = new ProzessEntity(ProzessTypEnum.AHV, true, org);
	}

	public Long getVerbandId() {
		return verbandId;
	}

	public void setVerbandId(Long verbandId) {
		this.verbandId = verbandId;
	}

	public LocalDate getVerbandBeitrittDatum() {
		return verbandBeitrittDatum;
	}

	public void setVerbandBeitrittDatum(LocalDate verbandBeitrittDatum) {
		this.verbandBeitrittDatum = verbandBeitrittDatum;
	}

	public AhvVerbandszugehoerigkeitEnum getVerbandZugehoerigkeit() {
		return verbandZugehoerigkeit;
	}

	public void setVerbandZugehoerigkeit(AhvVerbandszugehoerigkeitEnum verbandZugehoerigkeit) {
		this.verbandZugehoerigkeit = verbandZugehoerigkeit;
	}

	public Boolean getVerbandFak() {
		return verbandFak;
	}

	public void setVerbandFak(Boolean verbandFak) {
		this.verbandFak = verbandFak;
	}

	public AhvGruendungsartEnum getGruendArt() {
		return gruendArt;
	}

	public void setGruendArt(AhvGruendungsartEnum gruendArt) {
		this.gruendArt = gruendArt;
	}

	public AhvUebernahmeEnum getGruendUebernameArt() {
		return gruendUebernameArt;
	}

	public void setGruendUebernameArt(AhvUebernahmeEnum gruendUebernameArt) {
		this.gruendUebernameArt = gruendUebernameArt;
	}

	public String getGruendUebernameName() {
		return gruendUebernameName;
	}

	public void setGruendUebernameName(String gruendUebernameName) {
		this.gruendUebernameName = gruendUebernameName;
	}

	public String getGruendUebernameNummer() {
		return gruendUebernameNummer;
	}

	public void setGruendUebernameNummer(String gruendUebernameNummer) {
		this.gruendUebernameNummer = gruendUebernameNummer;
	}

	public BigDecimal getKapitalEigen() {
		return kapitalEigen;
	}

	public void setKapitalEigen(BigDecimal kapitalEigen) {
		this.kapitalEigen = kapitalEigen;
	}

	public BigDecimal getKapitalDarlehen() {
		return kapitalDarlehen;
	}

	public void setKapitalDarlehen(BigDecimal kapitalDarlehen) {
		this.kapitalDarlehen = kapitalDarlehen;
	}

	public BigDecimal getInvestWerkzeugKauf() {
		return investWerkzeugKauf;
	}

	public void setInvestWerkzeugKauf(BigDecimal investWerkzeugKauf) {
		this.investWerkzeugKauf = investWerkzeugKauf;
	}

	public BigDecimal getInvestFahrzeugKauf() {
		return investFahrzeugKauf;
	}

	public void setInvestFahrzeugKauf(BigDecimal investFahrzeugKauf) {
		this.investFahrzeugKauf = investFahrzeugKauf;
	}

	public BigDecimal getInvestWarenInvKauf() {
		return investWarenInvKauf;
	}

	public void setInvestWarenInvKauf(BigDecimal investWarenInvKauf) {
		this.investWarenInvKauf = investWarenInvKauf;
	}

	public String getInvestWeitereKaufArt() {
		return investWeitereKaufArt;
	}

	public void setInvestWeitereKaufArt(String investWeitereKaufArt) {
		this.investWeitereKaufArt = investWeitereKaufArt;
	}

	public BigDecimal getInvestWeitereKauf() {
		return investWeitereKauf;
	}

	public void setInvestWeitereKauf(BigDecimal investWeitereKauf) {
		this.investWeitereKauf = investWeitereKauf;
	}

	public BigDecimal getInvestBueroMiete() {
		return investBueroMiete;
	}

	public void setInvestBueroMiete(BigDecimal investBueroMiete) {
		this.investBueroMiete = investBueroMiete;
	}

	public BigDecimal getInvestLadenMiete() {
		return investLadenMiete;
	}

	public void setInvestLadenMiete(BigDecimal investLadenMiete) {
		this.investLadenMiete = investLadenMiete;
	}

	public BigDecimal getInvestWerkstattMiete() {
		return investWerkstattMiete;
	}

	public void setInvestWerkstattMiete(BigDecimal investWerkstattMiete) {
		this.investWerkstattMiete = investWerkstattMiete;
	}

	public BigDecimal getInvestLagerMiete() {
		return investLagerMiete;
	}

	public void setInvestLagerMiete(BigDecimal investLagerMiete) {
		this.investLagerMiete = investLagerMiete;
	}

	public BigDecimal getInvestFahrzeugMiete() {
		return investFahrzeugMiete;
	}

	public void setInvestFahrzeugMiete(BigDecimal investFahrzeugMiete) {
		this.investFahrzeugMiete = investFahrzeugMiete;
	}

	public String getInvestWeitereMieteArt() {
		return investWeitereMieteArt;
	}

	public void setInvestWeitereMieteArt(String investWeitereMieteArt) {
		this.investWeitereMieteArt = investWeitereMieteArt;
	}

	public BigDecimal getInvestWeitereMiete() {
		return investWeitereMiete;
	}

	public void setInvestWeitereMiete(BigDecimal investWeitereMiete) {
		this.investWeitereMiete = investWeitereMiete;
	}

	public Boolean getRaumKeine() {
		return raumKeine;
	}

	public void setRaumKeine(Boolean raumKeine) {
		this.raumKeine = raumKeine;
	}

	public Boolean getRaumEigene() {
		return raumEigene;
	}

	public void setRaumEigene(Boolean raumEigene) {
		this.raumEigene = raumEigene;
	}

	public Boolean getRaumWohnung() {
		return raumWohnung;
	}

	public void setRaumWohnung(Boolean raumWohnung) {
		this.raumWohnung = raumWohnung;
	}

	public Boolean getRaumKunde() {
		return raumKunde;
	}

	public void setRaumKunde(Boolean raumKunde) {
		this.raumKunde = raumKunde;
	}

	public Integer getTaetigAnzKunden() {
		return taetigAnzKunden;
	}

	public void setTaetigAnzKunden(Integer taetigAnzKunden) {
		this.taetigAnzKunden = taetigAnzKunden;
	}

	public String getTaetigKunde1() {
		return taetigKunde1;
	}

	public void setTaetigKunde1(String taetigKunde1) {
		this.taetigKunde1 = taetigKunde1;
	}

	public String getTaetigKunde2() {
		return taetigKunde2;
	}

	public void setTaetigKunde2(String taetigKunde2) {
		this.taetigKunde2 = taetigKunde2;
	}

	public String getTaetigKunde3() {
		return taetigKunde3;
	}

	public void setTaetigKunde3(String taetigKunde3) {
		this.taetigKunde3 = taetigKunde3;
	}

	public String getTaetigArtAuftraege() {
		return taetigArtAuftraege;
	}

	public void setTaetigArtAuftraege(String taetigArtAuftraege) {
		this.taetigArtAuftraege = taetigArtAuftraege;
	}

	public LocalDate getTaetigDatumLetzterAuftrag() {
		return taetigDatumLetzterAuftrag;
	}

	public void setTaetigDatumLetzterAuftrag(LocalDate taetigDatumLetzterAuftrag) {
		this.taetigDatumLetzterAuftrag = taetigDatumLetzterAuftrag;
	}

	public Boolean getTaetigAgent() {
		return taetigAgent;
	}

	public void setTaetigAgent(Boolean taetigAgent) {
		this.taetigAgent = taetigAgent;
	}

	public String getTaetigAuftraggeber() {
		return taetigAuftraggeber;
	}

	public void setTaetigAuftraggeber(String taetigAuftraggeber) {
		this.taetigAuftraggeber = taetigAuftraggeber;
	}

	public ProzessEntity getProzess() {
		return prozess;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	public String getGruendAlteBezeichnung() {
		return gruendAlteBezeichnung;
	}

	public void setGruendAlteBezeichnung(String gruendAlteBezeichnung) {
		this.gruendAlteBezeichnung = gruendAlteBezeichnung;
	}

	public HRStatusEnum getZefixStatus() {
		return zefixStatus;
	}

	public void setZefixStatus(HRStatusEnum zefixStatus) {
		this.zefixStatus = zefixStatus;
	}

	public String getZefixChNr() {
		return zefixChNr;
	}

	public void setZefixChNr(String zefixChNr) {
		this.zefixChNr = zefixChNr;
	}

	public String getZefixUid() {
		return zefixUid;
	}

	public void setZefixUid(String zefixUid) {
		this.zefixUid = zefixUid;
	}

	public String getZefixShabNr() {
		return zefixShabNr;
	}

	public void setZefixShabNr(String zefixShabNr) {
		this.zefixShabNr = zefixShabNr;
	}

	public LocalDate getZefixShabDate() {
		return zefixShabDate;
	}

	public void setZefixShabDate(LocalDate zefixShabDate) {
		this.zefixShabDate = zefixShabDate;
	}

	public String getZefixCompanyName() {
		return zefixCompanyName;
	}

	public void setZefixCompanyName(String zefixCompanyName) {
		this.zefixCompanyName = zefixCompanyName;
	}

	public String getZefixPolGemeinde() {
		return zefixPolGemeinde;
	}

	public void setZefixPolGemeinde(String zefixPolGemeinde) {
		this.zefixPolGemeinde = zefixPolGemeinde;
	}

	public Boolean getTaetigGemeinsameKunden() {
		return taetigGemeinsameKunden;
	}

	public void setTaetigGemeinsameKunden(Boolean taetigGemeinsameKunden) {
		this.taetigGemeinsameKunden = taetigGemeinsameKunden;
	}

	public BigDecimal getAngestellteVrHonorare() {
		return angestellteVrHonorare;
	}

	public void setAngestellteVrHonorare(BigDecimal angestellteVrHonorare) {
		this.angestellteVrHonorare = angestellteVrHonorare;
	}

	public LocalDate getAngestellteGiLohnSeit() {
		return angestellteGiLohnSeit;
	}

	public void setAngestellteGiLohnSeit(LocalDate angestellteGiLohnSeit) {
		this.angestellteGiLohnSeit = angestellteGiLohnSeit;
	}

	public Boolean getAngestellteGiHatKinder() {
		return angestellteGiHatKinder;
	}

	public void setAngestellteGiHatKinder(Boolean angestellteGiHatKinder) {
		this.angestellteGiHatKinder = angestellteGiHatKinder;
	}

	public Integer getAngestellteAngAnz() {
		return angestellteAngAnz;
	}

	public void setAngestellteAngAnz(Integer angestellteAngAnz) {
		this.angestellteAngAnz = angestellteAngAnz;
	}

	public BigDecimal getAngestellteAngLohnSumme() {
		return angestellteAngLohnSumme;
	}

	public void setAngestellteAngLohnSumme(BigDecimal angestellteAngLohnSumme) {
		this.angestellteAngLohnSumme = angestellteAngLohnSumme;
	}

	public LocalDate getAngestellteAngLohnSeit() {
		return angestellteAngLohnSeit;
	}

	public void setAngestellteAngLohnSeit(LocalDate angestellteAngLohnSeit) {
		this.angestellteAngLohnSeit = angestellteAngLohnSeit;
	}

	public Boolean getAngestellteAngHatKinder() {
		return angestellteAngHatKinder;
	}

	public void setAngestellteAngHatKinder(Boolean angestellteAngHatKinder) {
		this.angestellteAngHatKinder = angestellteAngHatKinder;
	}

	public Integer getAngestellteUebAnz() {
		return angestellteUebAnz;
	}

	public void setAngestellteUebAnz(Integer angestellteUebAnz) {
		this.angestellteUebAnz = angestellteUebAnz;
	}

	public BigDecimal getAngestellteUebLohnSumme() {
		return angestellteUebLohnSumme;
	}

	public void setAngestellteUebLohnSumme(BigDecimal angestellteUebLohnSumme) {
		this.angestellteUebLohnSumme = angestellteUebLohnSumme;
	}

	public LocalDate getAngestellteUebLohnSeit() {
		return angestellteUebLohnSeit;
	}

	public void setAngestellteUebLohnSeit(LocalDate angestellteUebLohnSeit) {
		this.angestellteUebLohnSeit = angestellteUebLohnSeit;
	}

	public Boolean getAngestellteUebHatKinder() {
		return angestellteUebHatKinder;
	}

	public void setAngestellteUebHatKinder(Boolean angestellteUebHatKinder) {
		this.angestellteUebHatKinder = angestellteUebHatKinder;
	}

	public String getKontaktVorname() {
		return kontaktVorname;
	}

	public void setKontaktVorname(String kontaktVorname) {
		this.kontaktVorname = kontaktVorname;
	}

	public String getKontaktFamilienname() {
		return kontaktFamilienname;
	}

	public void setKontaktFamilienname(String kontaktFamilienname) {
		this.kontaktFamilienname = kontaktFamilienname;
	}

	public String getKontaktTelefon() {
		return kontaktTelefon;
	}

	public void setKontaktTelefon(String kontaktTelefon) {
		this.kontaktTelefon = kontaktTelefon;
	}

	public String getKontaktMobile() {
		return kontaktMobile;
	}

	public void setKontaktMobile(String kontaktMobile) {
		this.kontaktMobile = kontaktMobile;
	}

	public String getKontaktEmail() {
		return kontaktEmail;
	}

	public void setKontaktEmail(String kontaktEmail) {
		this.kontaktEmail = kontaktEmail;
	}

	public String getKontaktBemerkungen() {
		return kontaktBemerkungen;
	}

	public void setKontaktBemerkungen(String kontaktBemerkungen) {
		this.kontaktBemerkungen = kontaktBemerkungen;
	}

	public AdresseEntity getAdresseKontakt() {
		return adresseKontakt;
	}

	public void setAdresseKontakt(AdresseEntity adresseKontakt) {
		this.adresseKontakt = adresseKontakt;
	}

	public AdresseEntity getAdresseTreuhand() {
		return adresseTreuhand;
	}

	public void setAdresseTreuhand(AdresseEntity adresseTreuhand) {
		this.adresseTreuhand = adresseTreuhand;
	}

	public Boolean getSonderPartnerWeb() {
		return sonderPartnerWeb;
	}

	public void setSonderPartnerWeb(Boolean sonderPartnerWeb) {
		this.sonderPartnerWeb = sonderPartnerWeb;
	}

	public Boolean getSonderVerband() {
		return sonderVerband;
	}

	public void setSonderVerband(Boolean sonderVerband) {
		this.sonderVerband = sonderVerband;
	}

	public Boolean getSonderBvg() {
		return sonderBvg;
	}

	public void setSonderBvg(Boolean sonderBvg) {
		this.sonderBvg = sonderBvg;
	}

	public Boolean getSonderUvg() {
		return sonderUvg;
	}

	public void setSonderUvg(Boolean sonderUvg) {
		this.sonderUvg = sonderUvg;
	}

	public Boolean getSonderKkv() {
		return sonderKkv;
	}

	public void setSonderKkv(Boolean sonderKkv) {
		this.sonderKkv = sonderKkv;
	}

	public Boolean getSonderWeitere() {
		return sonderWeitere;
	}

	public void setSonderWeitere(Boolean sonderWeitere) {
		this.sonderWeitere = sonderWeitere;
	}

	public Set<AhvFilialeEntity> getAhvFiliales() {
		return ahvFiliales;
	}

	public void setAhvFiliales(Set<AhvFilialeEntity> ahvFiliales) {
		this.ahvFiliales = ahvFiliales;
	}

	public Set<AhvTeilhaberEntity> getAhvTeilhabers() {
		return ahvTeilhabers;
	}

	public void setAhvTeilhabers(Set<AhvTeilhaberEntity> ahvTeilhabers) {
		this.ahvTeilhabers = ahvTeilhabers;
	}

	public String getSozialversUvg() {
		return sozialversUvg;
	}

	public void setSozialversUvg(String sozialversUvg) {
		this.sozialversUvg = sozialversUvg;
	}

	public Boolean getSozialversBvg() {
		return sozialversBvg;
	}

	public void setSozialversBvg(Boolean sozialversBvg) {
		this.sozialversBvg = sozialversBvg;
	}

	public String getSozialversBvgName() {
		return sozialversBvgName;
	}

	public void setSozialversBvgName(String sozialversBvgName) {
		this.sozialversBvgName = sozialversBvgName;
	}

	public String getSozialversBvgGrund() {
		return sozialversBvgGrund;
	}

	public void setSozialversBvgGrund(String sozialversBvgGrund) {
		this.sozialversBvgGrund = sozialversBvgGrund;
	}

	public Boolean getLohnbuchPapier() {
		return lohnbuchPapier;
	}

	public void setLohnbuchPapier(Boolean lohnbuchPapier) {
		this.lohnbuchPapier = lohnbuchPapier;
	}

	public Boolean getLohnbuchComputer() {
		return lohnbuchComputer;
	}

	public void setLohnbuchComputer(Boolean lohnbuchComputer) {
		this.lohnbuchComputer = lohnbuchComputer;
	}

	public Boolean getLohnbuchSuva() {
		return lohnbuchSuva;
	}

	public void setLohnbuchSuva(Boolean lohnbuchSuva) {
		this.lohnbuchSuva = lohnbuchSuva;
	}

	public Boolean getLohnbuchTreuhaender() {
		return lohnbuchTreuhaender;
	}

	public void setLohnbuchTreuhaender(Boolean lohnbuchTreuhaender) {
		this.lohnbuchTreuhaender = lohnbuchTreuhaender;
	}

	public Integer getSonderFormulare() {
		return sonderFormulare;
	}

	public void setSonderFormulare(Integer sonderFormulare) {
		this.sonderFormulare = sonderFormulare;
	}

	public Integer getAngestellteGiAnz() {
		return angestellteGiAnz;
	}

	public void setAngestellteGiAnz(Integer angestellteGiAnz) {
		this.angestellteGiAnz = angestellteGiAnz;
	}

	public BigDecimal getAngestellteGiLohnSumme() {
		return angestellteGiLohnSumme;
	}

	public void setAngestellteGiLohnSumme(BigDecimal angestellteGiLohnSumme) {
		this.angestellteGiLohnSumme = angestellteGiLohnSumme;
	}
}
