/*
 * UserInvitationDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.endpoint;

import java.util.Date;

import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.AccessLevelEnum;

/**
 * @author tdm
 *
 */
public class UserInvitationDto {
	
	@NotNull
	private Long id;
	@NotNull
	private int version;
	@NotNull
	private long orgId;
	private String eid;
	private String orgName;
	@NotNull
	private AccessLevelEnum zugriffsstufe;
	@NotNull
	private Date ausgestellt;
	@NotNull
	private Date ablauf;

	public UserInvitationDto() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public AccessLevelEnum getZugriffsstufe() {
		return zugriffsstufe;
	}

	public void setZugriffsstufe(AccessLevelEnum zugriffsstufe) {
		this.zugriffsstufe = zugriffsstufe;
	}

	public Date getAusgestellt() {
		return ausgestellt;
	}

	public void setAusgestellt(Date ausgestellt) {
		this.ausgestellt = ausgestellt;
	}

	public Date getAblauf() {
		return ablauf;
	}

	public void setAblauf(Date ablauf) {
		this.ablauf = ablauf;
	}
	
}
