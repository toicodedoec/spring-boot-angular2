/*
 * PdfAhvAnmeldungDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.time.LocalDate;

/**
 * @author hhg
 *
 */
public class BetriebDto {

	private String legalForm;
	private String companyName;
	private String industries;
	private String companyObject;
	private LocalDate dateStartBusiness;
	private String uvg;
	private String verband;
	private String vak;
	private LocalDate seit;
	private AddressDto mainAddr;
	private String hrStatus;
	private String chNr;
	private String shabNr;
	private LocalDate shabDatum;
	private String shabPage;
	private String shabId;
	
	public String getLegalForm() {
		return legalForm;
	}
	
	public void setLegalForm(String legalForm) {
		this.legalForm = legalForm;
	}
	
	public String getCompanyName() {
		return companyName;
	}
	
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getIndustries() {
		return industries;
	}
	
	public void setIndustries(String industries) {
		this.industries = industries;
	}
	
	public String getCompanyObject() {
		return companyObject;
	}
	
	public void setCompanyObject(String companyObject) {
		this.companyObject = companyObject;
	}
	
	public LocalDate getDateStartBusiness() {
		return dateStartBusiness;
	}
	
	public void setDateStartBusiness(LocalDate dateStartBusiness) {
		this.dateStartBusiness = dateStartBusiness;
	}
	
	public String getUvg() {
		return uvg;
	}
	
	public void setUvg(String uvg) {
		this.uvg = uvg;
	}
	
	public String getVerband() {
		return verband;
	}
	
	public void setVerband(String verband) {
		this.verband = verband;
	}

	public String getVak() {
		return vak;
	}

	public void setVak(String vak) {
		this.vak = vak;
	}

	public AddressDto getMainAddr() {
		return mainAddr;
	}
	
	public void setMainAddr(AddressDto mainAddr) {
		this.mainAddr = mainAddr;
	}

	public LocalDate getSeit() {
		return seit;
	}

	public void setSeit(LocalDate seit) {
		this.seit = seit;
	}

	public String getHrStatus() {
		return hrStatus;
	}

	public void setHrStatus(String hrStatus) {
		this.hrStatus = hrStatus;
	}

	public String getChNr() {
		return chNr;
	}

	public void setChNr(String chNr) {
		this.chNr = chNr;
	}

	public String getShabNr() {
		return shabNr;
	}

	public void setShabNr(String shabNr) {
		this.shabNr = shabNr;
	}

	public LocalDate getShabDatum() {
		return shabDatum;
	}

	public void setShabDatum(LocalDate shabDatum) {
		this.shabDatum = shabDatum;
	}

	public String getShabPage() {
		return shabPage;
	}

	public void setShabPage(String shabPage) {
		this.shabPage = shabPage;
	}

	public String getShabId() {
		return shabId;
	}

	public void setShabId(String shabId) {
		this.shabId = shabId;
	}
}
