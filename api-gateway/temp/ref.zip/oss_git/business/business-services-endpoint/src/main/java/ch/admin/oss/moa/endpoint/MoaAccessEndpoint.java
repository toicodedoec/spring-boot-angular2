package ch.admin.oss.moa.endpoint;

import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.admin.oss.common.AbstractOSSEndpoint;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.MwstAnmeldungEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.mwst.endpoint.MwstMoaIdDto;
import ch.admin.oss.mwst.service.IMWSTService;
import ch.admin.oss.util.OSSConstants;

/**
 * 
 * @author hhu
 *
 */
@CrossOrigin("*")
@RestController
@RequestMapping(MoaAccessEndpoint.MOA_URL)
public class MoaAccessEndpoint extends AbstractOSSEndpoint {

	public static final String MOA_URL = "/public/moa";

	public static final String GET_MOA_USER_DATA = "getMoaUserData";
	
	public static final String GET_MOA_USER_DATA_URL = MOA_URL + "/" + GET_MOA_USER_DATA;

	public static final String PUT_MOA_USER_DATA = "putMoaUserData";

	public static final String PUT_MOA_USER_DATA_URL = MOA_URL + "/" + PUT_MOA_USER_DATA;
	
	public static final String MOA_JUMP_BACK = "jumpBackUrl";

	public static final String MOA_JUMP_BACK_URL = MOA_URL + "/" + MOA_JUMP_BACK;

	@Autowired
	private IMWSTService mwstService;
	
	@Autowired
	private RestTemplate restTemplate;
	
	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern(OSSConstants.MOA_DATE_FORMAT);

	@RequestMapping(value = GET_MOA_USER_DATA + "/{uuid}", method = RequestMethod.GET, produces = "text/javascript")
	public String getMoaUserData(@PathVariable String uuid, @RequestParam String callback) throws JsonProcessingException {
		MwstMoaIdDto moaIds = MwstMoaIdDto.decode(uuid);
		MwstMoaUserDataDto dto = mapMwstMoaUserDataDto(mwstService.getOrganisation(moaIds.getOrgId()));
		ObjectMapper mapper = new ObjectMapper();	
		return callback + "(" + mapper.writeValueAsString(dto) + ")";
	}
	
	@RequestMapping(value = PUT_MOA_USER_DATA, method = RequestMethod.POST)
	public void putMoaUserData(@RequestBody MoaDataDto dto) {
		MwstMoaIdDto moaIds = MwstMoaIdDto.decode(dto.getUuid());
		MwstAnmeldungEntity entity = mwstService.getMwstAnmeldungFromMOA(moaIds.getOrgId());
		entity.getProzess().setPdf(downloadFile(dto.getAnmeldungPdfUrl()));
		entity.setPdf1(downloadFile(dto.getPdf1Url()));
		entity.setPdf2(downloadFile(dto.getPdf2Url()));
		entity.setPdf3(downloadFile(dto.getPdf3Url()));
		entity.setPdf4(downloadFile(dto.getPdf4Url()));
		mwstService.signProcessFromMOA(moaIds.getUserId(), entity);
	}
	// SECOOSS-525 : MWST process leaving MOA goes to user dashboard
	@RequestMapping(value = MOA_JUMP_BACK + "/{uuid}", method = RequestMethod.GET, produces = "text/html")
	public String moaJumpBackUrl(@PathVariable String uuid) throws JsonProcessingException {
		MwstMoaIdDto moaIds = MwstMoaIdDto.decode(uuid);
		MwstAnmeldungEntity entity = mwstService.getMwstAnmeldungFromMOA(moaIds.getOrgId());
		String script = null;
		String callBack = "<html>";
		callBack += "<head>";
		callBack += "<script type=\"text/javascript\">";
		
		if (entity.getProzess().getStatus() == ProzessStatusEnum.GESENDET) {
			script = "window.parent.location.assign(\"" + getFrontendRootUrl() + "/#/mwst/MWST/" 
				+ moaIds.getOrgId() + "/MWSTAbschluss\");";
		} else {
			script = "window.parent.location.assign(\"" + getFrontendRootUrl() + "/#/dashboard\");";
		}
		callBack += script;
		callBack += "</script>";
		callBack += "</head>";
		callBack += "</html>";
		
		return callBack;
	}

	private byte[] downloadFile(String url) {
		if (url == null) {
			return null;
		}
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_PDF));
		ResponseEntity<byte[]> response = restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<byte[]>(headers), byte[].class);
		return response.getBody();
	}
	
	private MwstMoaUserDataDto mapMwstMoaUserDataDto(OrganisationEntity organisation) {
		MwstMoaUserDataDto dto = new MwstMoaUserDataDto();
		dto.setChId(organisation.getChNr());
		dto.setUid(organisation.getUid());
		if(organisation.getShabDatum() != null) {
			dto.setCommercialRegisterEntryDate(organisation.getShabDatum().atStartOfDay().format(formatter));
		}		
		dto.setUidStreet(organisation.getDomizil().getStrasse());

		dto.setAddress(mapMwstMoaUserDataAddressDto(organisation.getDomizil()));
		// mapping name only for address of MoaUserData
		dto.getAddress().setName(organisation.defaultName());

		if (organisation.getRechtsform() == RechtsformEnum.EINZELFIRMA) {
			dto.setAddressPrivate(mapMwstMoaUserDataAddressDto(organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).iterator().next().getPerson().getWohnadresse()));
		}
		dto.setUidRegistered(StringUtils.isEmpty(dto.getUid()) ? false : true);
		dto.setHrRegistered(organisation.getHrStatus() == HRStatusEnum.REGISTERED ? true : false);
		dto.setLegalForm(new MwstMoaUserDataLegalFormDto(organisation.getRechtsform()));
		dto.setCommunityNumber(String.valueOf(organisation.getDomizil().getBfsNr()));

		if (organisation.getRechtsform() == RechtsformEnum.KOLLGES
				|| organisation.getRechtsform() == RechtsformEnum.KOMMGES) {
			boolean leading = true;
			for(GeschaftsrolleEntity ges : organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)) {
				dto.getCorporators().add(mapMwstMoaUserDataCorporatorDto(ges.getPerson(), leading));
				leading = false;
			}
			if (organisation.getKommGes() != null && organisation.getKommGes().getKommFirmas().size() > 0) {
				organisation.getKommGes().getKommFirmas().stream()
						.forEach(kom -> dto.getCorporators().add(mapMwstMoaUserDataCorporatorDto(kom)));
			}

		}
		dto.setFinancialYearEnd(organisation.getGeschaeftsjahrEnd().atStartOfDay().format(formatter));
		dto.setStart(organisation.getEroeffnungsDatum().atStartOfDay().format(formatter));
		if(organisation.getRechtsform() == RechtsformEnum.EINZELFIRMA) {
			dto.setOwner(mapMwstMoaUserDataContactDto(organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).iterator().next()));
		}		
		dto.setOwnerAddressSameAsFirmAddress(organisation.getRechtsform() != RechtsformEnum.EINZELFIRMA ? false
				: compareOwnerInfoAdresses(
						organisation.getDomizil(), organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).iterator().next().getPerson().getWohnadresse()));
		return dto;
	}

	private boolean compareOwnerInfoAdresses(AdresseEntity companyAdresse, AdresseEntity ownerAdresse) {
		if (companyAdresse.getBfsNr() == ownerAdresse.getBfsNr()
				&& StringUtils.equalsIgnoreCase(companyAdresse.getEmail(), ownerAdresse.getEmail())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getEmpfaenger(), ownerAdresse.getEmpfaenger())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getFax(), ownerAdresse.getFax())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getHausnummer(), ownerAdresse.getHausnummer())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getKanton(), ownerAdresse.getKanton())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getLand().getCode(), ownerAdresse.getLand().getCode())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getPlz(), ownerAdresse.getPlz())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getPolGemeinde(), ownerAdresse.getPolGemeinde())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getPostfach(), ownerAdresse.getPostfach())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getPostfachOrt(), ownerAdresse.getPostfachOrt())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getPostfachPlz(), ownerAdresse.getPostfachPlz())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getStrasse(), ownerAdresse.getStrasse())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getTelefon(), ownerAdresse.getTelefon())
				&& StringUtils.equalsIgnoreCase(companyAdresse.getZusatz(), ownerAdresse.getZusatz())) {
			return true;
		}
		return false;
	}
	
	private MwstMoaUserDataContactDto mapMwstMoaUserDataContactDto(GeschaftsrolleEntity ges) {
		MwstMoaUserDataContactDto dto = new MwstMoaUserDataContactDto();
		dto.setPerson(mapMwstMoaUserDataCorporatorPersonDto(ges.getPerson()));
		dto.setAddress(mapMwstMoaUserDataCorporatorAddressDto(ges.getPerson().getWohnadresse(), null));
		return dto;
	}
	
	private MwstMoaUserDataAddressDto mapMwstMoaUserDataAddressDto(AdresseEntity adresse) {
		MwstMoaUserDataAddressDto dto = new MwstMoaUserDataAddressDto();
		dto.setStreet(adresse.getStrasse());
		dto.setBuildingNum(adresse.getHausnummer());
		dto.setCountry(getLandIso2Code(adresse.getLand()));
		dto.setLocation(mapMwstMoaUserDataAddressLocationDto(adresse));
		dto.setPhone(adresse.getTelefon());
		dto.setFax(adresse.getFax());
		dto.setMobile(adresse.getMobile());
		dto.setMail(adresse.getEmail());		
		dto.setPoBox(adresse.getPostfach());
		dto.setCo(adresse.getZusatz());
		
		return dto;
	}
	
	private String getLandIso2Code(CodeWertEntity adresse) {
		return applicationService.getLand(adresse).getIso2().name();
	}
	
	private MwstMoaUserDataAddressLocationDto mapMwstMoaUserDataAddressLocationDto(AdresseEntity adresse) {
		MwstMoaUserDataAddressLocationDto dto = new MwstMoaUserDataAddressLocationDto();
		dto.setZip(adresse.getPlz());
		dto.setPlace(adresse.getOrt());
		dto.setCanton(adresse.getKanton());
		dto.setCommunityNumber(String.valueOf(adresse.getBfsNr()));
		return dto;
	}
	
	private MwstMoaUserDataCorporatorDto mapMwstMoaUserDataCorporatorDto(PersonEntity personEntity, boolean leading) {
		MwstMoaUserDataCorporatorDto dto = new MwstMoaUserDataCorporatorDto();
		dto.setPersonType(OSSConstants.MOA_CORPORATOR_NATURAL_PERSON); //natural person
		dto.setAddress(mapMwstMoaUserDataCorporatorAddressDto(personEntity.getWohnadresse(), null));		
		dto.setPerson(mapMwstMoaUserDataCorporatorPersonDto(personEntity));
		dto.setLeading(leading);
		return dto;
	}
	
	private MwstMoaUserDataCorporatorDto mapMwstMoaUserDataCorporatorDto(KommFirmaEntity kom) {
		MwstMoaUserDataCorporatorDto dto = new MwstMoaUserDataCorporatorDto();
		dto.setPersonType(OSSConstants.MOA_CORPORATOR_LEGAL_PERSON); //natural person
		dto.setAddress(mapMwstMoaUserDataCorporatorAddressDto(kom.getDomizil(), kom));
		dto.setPerson(new MwstMoaUserDataCorporatorPersonDto(1, null));	// title =1, nationality = ISO2 kommfirma.domizil.land
		dto.setLeading(false);
		return dto;
	}
	
	private MwstMoaUserDataCorporatorAddressDto mapMwstMoaUserDataCorporatorAddressDto(AdresseEntity adresse, KommFirmaEntity legalPartner) {
		MwstMoaUserDataCorporatorAddressDto dto = new MwstMoaUserDataCorporatorAddressDto();
		// SECOOSS-521 : MWST process, limited partnership, legal person, company name missing
		if (legalPartner != null) {
			dto.setName(legalPartner.getName());
		}
		dto.setStreet(adresse.getStrasse());
		dto.setBuildingNum(adresse.getHausnummer());
		dto.setCountry(getLandIso2Code(adresse.getLand()));
		dto.setLocation(mapMwstMoaUserDataAddressLocationDto(adresse));
		dto.setPhone(adresse.getTelefon());
		dto.setFax(adresse.getFax());
		dto.setMobile(adresse.getMobile());
		dto.setMail(adresse.getEmail());		
		dto.setPoBox(adresse.getPostfach());
		dto.setCo(adresse.getZusatz());
		return dto;
	}
	
	private MwstMoaUserDataCorporatorPersonDto mapMwstMoaUserDataCorporatorPersonDto(PersonEntity person) {
		MwstMoaUserDataCorporatorPersonDto dto = new MwstMoaUserDataCorporatorPersonDto();
		if(person.getAnrede() == null) {
			dto.setTitle(0);
		} else {
			dto.setTitle(StringUtils.equalsIgnoreCase(person.getAnrede().getCode(), OSSConstants.ANDERE_MR_CODE) ? 1 : 2);
		}
		
		// SECOOSS-524 : MWST process wrong citizenship
		CodeWertEntity firstNationality = person.getNationalitaetens().iterator().next();
		dto.setNationality(getLandIso2Code(firstNationality));
		dto.setLastName(person.getFamilienname());
		dto.setFirstName(person.getVorname());
		dto.setBirthday(person.getGeburtsdatum().atStartOfDay().format(formatter));
		dto.setSocialSecurityNum(person.getAhvNummer());
		dto.setHomeTown(StringUtils.join(
				person.getHeimatortes().stream().map(item -> item.getPolGemeinde()).collect(Collectors.toList()), 
				OSSConstants.MOA_HOMETOWN_SEPARATED));
		return dto;
	}
}
