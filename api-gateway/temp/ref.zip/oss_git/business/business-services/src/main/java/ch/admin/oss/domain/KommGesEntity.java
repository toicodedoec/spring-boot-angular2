/*
 * KommGesEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 * @author coh
 *
 */
@Entity
@Table(name = "T_KOMMGES")
public class KommGesEntity extends AbstractOSSEntity {

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name="FK_KOMMGES_ORGANISATION"))
	private OrganisationEntity organisation;
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "kommges", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<KommFirmaEntity> kommFirmas = new HashSet<>();

	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public Set<KommFirmaEntity> getKommFirmas() {
		return kommFirmas;
	}

	public void setKommFirmas(Set<KommFirmaEntity> kommFirmas) {
		this.kommFirmas = kommFirmas;
	}
}
