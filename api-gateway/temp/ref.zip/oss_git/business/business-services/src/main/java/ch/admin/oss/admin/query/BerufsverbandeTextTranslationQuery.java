/*
 * BerufsverbandeQueryCriteria
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.query;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.admin.criteria.BerufsverbandeCriteria;
import ch.admin.oss.common.enums.AktivFilterEnum;
import ch.admin.oss.domain.QStandardTextEntity;
import ch.admin.oss.domain.QTextTranslationEntity;
import ch.admin.oss.domain.QVerbandEntity;
import ch.admin.oss.domain.VerbandEntity;

/**
 * @author tdm
 */
public class BerufsverbandeTextTranslationQuery
	extends AbstractTextTranslationQuery<BerufsverbandeCriteria, VerbandEntity> {

	@Override
	public JPAQuery<VerbandEntity> buildQuery(BerufsverbandeCriteria criteria, EntityManager em) {
		JPAQuery<VerbandEntity> query = new JPAQuery<VerbandEntity>(em)
			.from(QVerbandEntity.verbandEntity)
			.leftJoin(QVerbandEntity.verbandEntity.standardText, QStandardTextEntity.standardTextEntity)
			.join(QStandardTextEntity.standardTextEntity.translations, QTextTranslationEntity.textTranslationEntity)
			.orderBy(QVerbandEntity.verbandEntity.id.asc())
			.distinct();

		if (StringUtils.isNotBlank(criteria.getText())) {
			query.where(QTextTranslationEntity.textTranslationEntity.text
				.containsIgnoreCase(StringUtils.trim(criteria.getText())));
		}

		if (criteria.getStatus() == AktivFilterEnum.Unaktiv) {
			query.where(QVerbandEntity.verbandEntity.aktiv.eq(false));
		}

		if (criteria.getStatus() == AktivFilterEnum.Aktiv) {
			query.where(QVerbandEntity.verbandEntity.aktiv.eq(true));
		}

		return query;
	}
}
