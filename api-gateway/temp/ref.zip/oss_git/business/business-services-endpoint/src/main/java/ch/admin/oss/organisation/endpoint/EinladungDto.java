/*
 * Eindalung
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import java.util.Date;

import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.AccessLevelEnum;

/**
 * @author tdm
 */
public class EinladungDto {
	private Long id;
	private int version;
	@NotNull
	private long orgId;
	@NotNull
	private String email;
	@NotNull
	private AccessLevelEnum zugriffsstufe;
	private Date zugriffVon;
	private Date zugriffBis;
	private Date ausgestellt;

	public EinladungDto() {}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public AccessLevelEnum getZugriffsstufe() {
		return zugriffsstufe;
	}

	public void setZugriffsstufe(AccessLevelEnum zugriffsstufe) {
		this.zugriffsstufe = zugriffsstufe;
	}

	public Date getZugriffVon() {
		return zugriffVon;
	}

	public void setZugriffVon(Date zugriffVon) {
		this.zugriffVon = zugriffVon;
	}

	public Date getZugriffBis() {
		return zugriffBis;
	}

	public void setZugriffBis(Date zugriffBis) {
		this.zugriffBis = zugriffBis;
	}

	public Date getAusgestellt() {
		return ausgestellt;
	}

	public void setAusgestellt(Date ausgestellt) {
		this.ausgestellt = ausgestellt;
	}

}
