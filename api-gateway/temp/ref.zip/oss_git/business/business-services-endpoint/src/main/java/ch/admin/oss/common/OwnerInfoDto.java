/*
 * OwnerInfoDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import ch.admin.oss.common.enums.PersonTypeEnum;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author xdg
 */
public class OwnerInfoDto<T extends AbstractPersonRoleDto> {

	private PersonTypeEnum type;

	private long sourceId;
	private T role;
	private RechtsformEnum rechtsform;
	private String residence;

	private PersonTypeEnum accessFrom;
	private ProzessDto prozess;
	
	private boolean accessFromOutSideSummary;

	public PersonTypeEnum getType() {
		return type;
	}

	public void setType(PersonTypeEnum type) {
		this.type = type;
	}

	public long getSourceId() {
		return sourceId;
	}

	public void setSourceId(long sourceId) {
		this.sourceId = sourceId;
	}

	public T getRole() {
		return role;
	}

	public void setRole(T role) {
		this.role = role;
	}

	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}

	public String getResidence() {
		return residence;
	}

	public void setResidence(String residence) {
		this.residence = residence;
	}

	public PersonTypeEnum getAccessFrom() {
		return accessFrom;
	}

	public void setAccessFrom(PersonTypeEnum accessFrom) {
		this.accessFrom = accessFrom;
	}

	public ProzessDto getProzess() {
		return prozess;
	}

	public void setProzess(ProzessDto prozess) {
		this.prozess = prozess;
	}

	public boolean isAccessFromOutSideSummary() {
		return accessFromOutSideSummary;
	}

	public void setAccessFromOutSideSummary(boolean accessFromOutSideSummary) {
		this.accessFromOutSideSummary = accessFromOutSideSummary;
	}

}
