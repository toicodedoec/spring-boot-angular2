/*
 * FlowHistoryItemEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 * @author coh
 */
@Entity
@Table(name = "T_FLOW_HISTORY_ITEM")
public class FlowHistoryItemEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_FLOW_HISTORY", foreignKey = @ForeignKey(name = "FK_HISTORY_HISTORY_ITEM"))
	private FlowHistoryEntity flowHistory;

	@Column(name = "NAME")
	private String name;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "flowHistoryItem", cascade = CascadeType.ALL)
	private Set<FlowHistoryItemDataEntity> data = new HashSet<>();

	@Column(name = "\"INDEX\"")
	private int index;

	public FlowHistoryItemEntity() {}

	public FlowHistoryItemEntity(String name, Set<FlowHistoryItemDataEntity> data) {
		this.name = name;
		this.data = data;
		for (FlowHistoryItemDataEntity itemData : data) {
			itemData.setFlowHistoryItem(this);
		}
	}

	public void setFlowHistory(FlowHistoryEntity flowHistory) {
		this.flowHistory = flowHistory;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public int getIndex() {
		return index;
	}

	public Set<FlowHistoryItemDataEntity> getData() {
		return data;
	}
}
