/*
 * EhePartnerInDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.time.LocalDate;

/**
 * @author hhu
 */
public class EhePartnerInDto {
	private String anrede;
	private String titel;
	private String familienname;
	private String vorname;
	private String vornamenliste;
	private LocalDate geburtsdatum;
	private String ahvNummer;
	private String partnerArbeitetMit;
	private String einkommen;

	public String getAnrede() {
		return anrede;
	}

	public void setAnrede(String anrede) {
		this.anrede = anrede;
	}

	public String getTitel() {
		return titel;
	}

	public void setTitel(String titel) {
		this.titel = titel;
	}

	public String getFamilienname() {
		return familienname;
	}

	public void setFamilienname(String familienname) {
		this.familienname = familienname;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getVornamenliste() {
		return vornamenliste;
	}

	public void setVornamenliste(String vornamenliste) {
		this.vornamenliste = vornamenliste;
	}

	public LocalDate getGeburtsdatum() {
		return geburtsdatum;
	}

	public void setGeburtsdatum(LocalDate geburtsdatum) {
		this.geburtsdatum = geburtsdatum;
	}

	public String getAhvNummer() {
		return ahvNummer;
	}

	public void setAhvNummer(String ahvNummer) {
		this.ahvNummer = ahvNummer;
	}

	public String getPartnerArbeitetMit() {
		return partnerArbeitetMit;
	}

	public void setPartnerArbeitetMit(String partnerArbeitetMit) {
		this.partnerArbeitetMit = partnerArbeitetMit;
	}

	public String getEinkommen() {
		return einkommen;
	}

	public void setEinkommen(String einkommen) {
		this.einkommen = einkommen;
	}

}
