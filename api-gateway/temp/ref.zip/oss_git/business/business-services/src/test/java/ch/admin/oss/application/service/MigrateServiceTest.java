package ch.admin.oss.application.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.business.AbstractOSSTest;
import ch.admin.oss.common.enums.AhvGruendungsartEnum;
import ch.admin.oss.common.enums.AhvMitarbeitEnum;
import ch.admin.oss.common.enums.AhvNamenEnum;
import ch.admin.oss.common.enums.AhvVerbandszugehoerigkeitEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.KontotypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.common.enums.ZahlungszweckEnum;
import ch.admin.oss.domain.AhvAnmeldungEntity;
import ch.admin.oss.domain.AhvTeilhaberEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrAnmeldungEntity;
import ch.admin.oss.domain.HrGruenderEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.KontoEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.QAhvAnmeldungEntity;
import ch.admin.oss.domain.QHrAnmeldungEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QStartBizDataEntity;
import ch.admin.oss.domain.QUvgAnmeldungEntity;
import ch.admin.oss.domain.StartBizDataEntity;
import ch.admin.oss.domain.UvgAnmeldungEntity;
import ch.admin.oss.util.JpaUtil;
import ch.admin.oss.util.OSSConstants;

/**
 * @author hhu
 */
@ActiveProfiles("unittest")
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Transactional
public class MigrateServiceTest extends AbstractOSSTest {
	
	private static final DateTimeFormatter DATE_STARTBIZ_FORMATTER = new DateTimeFormatterBuilder()
			.appendPattern("yyyy-MM-dd")
			.toFormatter();

	private static final String FUNKTION_PRAESIDENT_CODE = "PRAESIDENT";

	private static final String LAND_DEU_CODE = "8207";

	private static final String ZEICHNUNG_SIG_CODE = "SIG";

	private static final String LAND_CHE_CODE = "8100";

	@PersistenceContext
	private EntityManager em;

	@Autowired
	private IMigrationService migrationSerivce;

	@Autowired
	protected JpaUtil jpaUtil;

	@Test
	public void testMigrateStartbizBaseData() {
		initDataMigration();
		OrganisationEntity org = new JPAQuery<OrganisationEntity>(em)
				.from(QOrganisationEntity.organisationEntity)
				.where(QOrganisationEntity.organisationEntity.namens.any().bezeichnung.eq("TEST ELCA KollGes"))
				.fetchOne();
		
		Assert.assertEquals(org.getRechtsform(), RechtsformEnum.KOLLGES);
		Assert.assertEquals(org.defaultName(), "TEST ELCA KollGes");
		Assert.assertEquals(org.getZweck(), "Test");
		
		Assert.assertEquals(org.getEroeffnungsDatum(), LocalDate.parse("1900-01-01", DATE_STARTBIZ_FORMATTER));
		Assert.assertEquals(org.getErstrechnungsDatum(), LocalDate.parse("1900-01-01", DATE_STARTBIZ_FORMATTER));
		Assert.assertEquals(org.getErstauftragsDatum(), LocalDate.parse("2016-12-01", DATE_STARTBIZ_FORMATTER));
		Assert.assertEquals(org.getGeschaeftsjahrStart(), LocalDate.parse("1970-01-01", DATE_STARTBIZ_FORMATTER));
		Assert.assertEquals(org.getGeschaeftsjahrEnd(), LocalDate.parse("1970-12-31", DATE_STARTBIZ_FORMATTER));

		Assert.assertEquals(org.getBranches().size(), 1);
		Assert.assertEquals(org.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).size(), 2);

		for (GeschaftsrolleEntity ges : org.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)) {
			Assert.assertEquals(ges.isComplete(), true);
			Assert.assertEquals(ges.getZeichnung().getCode(), ZEICHNUNG_SIG_CODE);
			Assert.assertEquals(ges.getHaftungCHF(), new BigDecimal(-1));
			Assert.assertEquals(ges.isNurHauptsitz(), false);
			Assert.assertEquals(ges.getEinlage(), null);
		}

		Assert.assertEquals(org.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream()
				.filter(g -> g.getPerson().getFamilienname().equals("Nachname1")
						&& g.getPerson().getVorname().equals("Vorname"))
				.count(), 1);

		OrganisationEntity orgKommG = new JPAQuery<OrganisationEntity>(em)
				.from(QOrganisationEntity.organisationEntity)				
				.where(QOrganisationEntity.organisationEntity.namens.any().bezeichnung.eq("TEST KOMMG"))
				.fetchOne();

		Assert.assertEquals(orgKommG.getRechtsform(), RechtsformEnum.KOMMGES);
		Assert.assertEquals(orgKommG.getBranches().size(), 3);
		Assert.assertEquals(orgKommG.getGeschaeftsrollens(GeschaeftsrolleTypEnum.SIGNATORY).size(), 2);
		Assert.assertEquals(orgKommG.getGeschaeftsstellens().size(), 1);
		Assert.assertEquals(orgKommG.getKommGes().getKommFirmas().size(), 2);
		
		KommFirmaEntity kommFirma = orgKommG.getKommGes().getKommFirmas().stream()
		.filter(kom -> StringUtils.equals(kom.getHrNummer(), "107921752")).findFirst().get();		
		
		Assert.assertEquals(kommFirma.getName(), "Sohard AG");
		Assert.assertEquals(kommFirma.getHaftung(), new BigDecimal(1234567));
		Assert.assertEquals(kommFirma.getEinlage().getCode(), "BAR");
		Assert.assertTrue(kommFirma.isComplete());
		Assert.assertEquals(kommFirma.getRechtsformCH(), RechtsformEnum.AG);
		
		Assert.assertEquals(kommFirma.getDomizil().getStrasse(), "Galgenfeldweg");
		Assert.assertEquals(kommFirma.getDomizil().getHausnummer(), "18");
		Assert.assertEquals(kommFirma.getDomizil().getPlz(), "3006");
		Assert.assertEquals(kommFirma.getDomizil().getBfsNr(), 351);
		Assert.assertEquals(kommFirma.getDomizil().getOrt(), "Bern");
		Assert.assertEquals(kommFirma.getDomizil().getPolGemeinde(), "Bern");
		Assert.assertEquals(kommFirma.getDomizil().getKanton(), "BE");
		

		Assert.assertEquals(orgKommG.getDomizil().getEmpfaenger(), "ZUSTELL TEST KOMMG");
		Assert.assertEquals(orgKommG.getDomizil().getEmail(), "david.keimer@elca.ch");
		Assert.assertEquals(orgKommG.getDomizil().getKanton(), "BE");
		Assert.assertEquals(orgKommG.getDomizil().getStrasse(), "STRASSE");
		Assert.assertEquals(orgKommG.getDomizil().getPolGemeinde(), "Bern");
		Assert.assertEquals(orgKommG.getDomizil().getLand().getCode(), LAND_CHE_CODE);
		Assert.assertEquals(orgKommG.isBaseDataComplete(), true);
	}

	private List<StartBizDataEntity> initDataMigration() {
		List<StartBizDataEntity> entities = new JPAQuery<StartBizDataEntity>(em)
				.from(QStartBizDataEntity.startBizDataEntity).fetch();

		entities.stream().forEach(ent -> {
			try {
				migrationSerivce.migrateStartBizDataToEasyGov(ent);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		em.flush();
		em.clear();
		return entities;
	}

	@Test
	public void testMigrateStartbizAhv() {
		initDataMigration();

		Long id = new JPAQuery<Long>(em).from(QOrganisationEntity.organisationEntity)				
				.where(QOrganisationEntity.organisationEntity.namens.any().bezeichnung.eq("TEST ELCA KollGes"))
				.select(QOrganisationEntity.organisationEntity.id).fetchOne();

		AhvAnmeldungEntity entity = new JPAQuery<AhvAnmeldungEntity>(em).from(QAhvAnmeldungEntity.ahvAnmeldungEntity)
				.where(QAhvAnmeldungEntity.ahvAnmeldungEntity.prozess.organisation.id.eq(id)).fetchOne();
		
		Assert.assertEquals(entity.getZefixStatus(), HRStatusEnum.PENDING);
		Assert.assertEquals(entity.getGruendArt(), AhvGruendungsartEnum.NEU);
		Assert.assertEquals(entity.getVerbandFak(), true);
		Assert.assertEquals(entity.getVerbandZugehoerigkeit(), AhvVerbandszugehoerigkeitEnum.NEIN);
		Assert.assertEquals(entity.getLohnbuchPapier(), false);
		Assert.assertEquals(entity.getLohnbuchComputer(), false);
		Assert.assertEquals(entity.getLohnbuchSuva(), true);
		Assert.assertEquals(entity.getLohnbuchTreuhaender(), false);
		Assert.assertEquals(entity.getSozialversBvg(), false);
		Assert.assertEquals(entity.getSozialversBvgGrund(), "Test");
		Assert.assertEquals(entity.getSonderPartnerWeb(), true);
		Assert.assertEquals(entity.getSonderVerband(), false);
		Assert.assertEquals(entity.getSonderBvg(), false);
		Assert.assertEquals(entity.getSonderUvg(), false);
		Assert.assertEquals(entity.getSonderKkv(), false);
		Assert.assertEquals(entity.getSonderWeitere(), false);
		Assert.assertEquals(entity.getSonderFormulare(), Integer.valueOf(0));
		Assert.assertEquals(entity.getKontaktBemerkungen(), "Testanmeldung ELCA Informatik AG, bitte nicht bearbeiten, sondern an david.keimer@elca.ch weiterleiten");
		Assert.assertEquals(entity.getKontaktFamilienname(), "David");
		Assert.assertEquals(entity.getKontaktVorname(), "Keimer");
		Assert.assertEquals(entity.getKapitalEigen(), new BigDecimal(100000));
		Assert.assertEquals(entity.getKapitalDarlehen(), new BigDecimal(1));
		
		Assert.assertEquals(entity.getInvestWerkzeugKauf(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestFahrzeugKauf(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestWarenInvKauf(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestWeitereKauf(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestWeitereKaufArt(), "anderes");
		Assert.assertEquals(entity.getInvestBueroMiete(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestLadenMiete(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestWerkstattMiete(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestLagerMiete(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestFahrzeugMiete(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestWeitereMiete(), new BigDecimal(1));
		Assert.assertEquals(entity.getInvestWeitereMieteArt(), "anderes");
		
		Assert.assertEquals(entity.getRaumKeine(), false);
		Assert.assertEquals(entity.getRaumEigene(), true);
		Assert.assertEquals(entity.getRaumKunde(), false);
		Assert.assertEquals(entity.getRaumWohnung(), false);
		
		Assert.assertEquals(entity.getTaetigAnzKunden(), Integer.valueOf(1));
		Assert.assertEquals(entity.getTaetigGemeinsameKunden(), false);
		
		Assert.assertEquals(entity.getAhvTeilhabers().size(), 2);
		
		AhvTeilhaberEntity teilhaber = entity.getAhvTeilhabers().stream()
				.filter(teil -> teil.getPerson().getVorname().equals("Vorname") && teil.getPerson().getFamilienname().equals("Nachname1"))
				.findFirst().get();
		Assert.assertEquals(teilhaber.getBisherHatKinder(), false);
		
		Assert.assertEquals(teilhaber.getMitarbeit(), AhvMitarbeitEnum.HAUPTERWERB);
		Assert.assertEquals(teilhaber.getMitarbeitRolle(), "Chef");
		Assert.assertEquals(teilhaber.getEinkommenEinkommen(), new BigDecimal(100000));
		Assert.assertEquals(teilhaber.getEinkommenRechnung(), true);
		Assert.assertEquals(teilhaber.getEinkommenLohn(), true);
		
		Assert.assertEquals(teilhaber.getLastenUnkosten(), true);
		Assert.assertEquals(teilhaber.getLastenUnterhalt(), false);
		Assert.assertEquals(teilhaber.getLastenGarantie(), false);
		Assert.assertEquals(teilhaber.getLastenMaterial(), false);
		Assert.assertEquals(teilhaber.getLastenVerluste(), false);
		Assert.assertEquals(teilhaber.getLastenLohnanspruch(), false);
		Assert.assertEquals(teilhaber.getLastenRisiko(), "Risiko");
		
		Assert.assertEquals(teilhaber.getAoaWeisung(), false);
		Assert.assertEquals(teilhaber.getAoaKonkurrenzverbot(), false);
		Assert.assertEquals(teilhaber.getAoaPersoenlich(), false);
		Assert.assertEquals(teilhaber.getAoaName(), AhvNamenEnum.EIGENER);
		Assert.assertEquals(teilhaber.getAoaBriefpapier(), true);
		Assert.assertEquals(teilhaber.getAoaWerbung(), false);
		Assert.assertEquals(teilhaber.getAoaOfferten(), false);
		Assert.assertEquals(teilhaber.getAoaRechnungen(), false);
		
		Assert.assertTrue(teilhaber.getComplete());
		
	}

	@Test
	public void testMigrateStartbizUvg() {
		initDataMigration();

		Long id = new JPAQuery<Long>(em).from(QOrganisationEntity.organisationEntity)				
				.where(QOrganisationEntity.organisationEntity.namens.any().bezeichnung
						.eq("Restaurant zum/zur (Sonne,Kreuz,Bären,...), Achim Rosenkranz"))
				.select(QOrganisationEntity.organisationEntity.id).fetchOne();

		UvgAnmeldungEntity entity = new JPAQuery<UvgAnmeldungEntity>(em).from(QUvgAnmeldungEntity.uvgAnmeldungEntity)
				.where(QUvgAnmeldungEntity.uvgAnmeldungEntity.prozess.organisation.id.eq(id)).fetchOne();

		Assert.assertEquals(entity.getAngestellteHeute(), new BigDecimal(1));
		Assert.assertEquals(entity.getErsteAnstellung(), LocalDate.parse("2015-07-15", DATE_STARTBIZ_FORMATTER));
		Assert.assertEquals(entity.getAngestellteZukunft(), new BigDecimal(0));
		Assert.assertEquals(entity.getErsteAnstellungZukunft(), LocalDate.parse("2017-07-16", DATE_STARTBIZ_FORMATTER));
		Assert.assertFalse(entity.isAngestelltePartner());
		Assert.assertFalse(entity.isAngestellteFamilie());
		Assert.assertFalse(entity.isAngestellteLehrling());
		Assert.assertFalse(entity.isAngestellteOhneLohn());
		Assert.assertFalse(entity.isAngestellteAushilfe());
		Assert.assertFalse(entity.isAngestellteAushilfe());
		Assert.assertFalse(entity.isAngestellteGesellschafter());
		Assert.assertTrue(entity.isUvgInhaberFreiwillig());
		Assert.assertEquals(entity.getLohnsumme(), new BigDecimal(11110));
		Assert.assertEquals(entity.getLohnsummeFolgejahr(), new BigDecimal(22220));
		Assert.assertEquals(entity.getZahlungsmodus().getCode().toLowerCase(), "semester");
		Assert.assertFalse(entity.isTaggeldAnBetrieb());
		Assert.assertEquals(entity.getAhvName(), "Ihre AHV-Ausgleichskasse, falls vorhanden");
		Assert.assertEquals(entity.getAhvNummer(), "werwer");
		Assert.assertEquals(entity.getVersicherungName(),
				"Ihre Versicherung bzw. Krankenkasse, falls eine Krankentaggeldversicherung besteht");
		Assert.assertEquals(entity.getVersicherungNummer(),
				"Ihre Mitgliedernummer / Policen-Nummer (bzw. jene des Unternehmens)");
		Assert.assertEquals(entity.getBemerkungen(), "test");
		Assert.assertEquals(entity.getKontaktName(), "Rosenkranz");
		Assert.assertEquals(entity.getKontaktVorname(), "Achim");
		Assert.assertEquals(entity.isPartnerFreiwillig(), false);
		Assert.assertEquals(entity.getAngehoerigeAnzahl(), new BigDecimal(0));
		Assert.assertEquals(entity.isAngehoerigeFreiwillig(), false);
		Assert.assertEquals(entity.getVersicherer().iterator().next().getId(), Long.valueOf(24));

	}

	@Test
	public void testMigrateStartbizHr() {
		initDataMigration();

		Long id = new JPAQuery<Long>(em).from(QOrganisationEntity.organisationEntity)				
				.where(QOrganisationEntity.organisationEntity.namens.any().bezeichnung.eq("Trallala AG"))
				.select(QOrganisationEntity.organisationEntity.id).fetchOne();

		HrAnmeldungEntity entity = new JPAQuery<HrAnmeldungEntity>(em).from(QHrAnmeldungEntity.hrAnmeldungEntity)
				.where(QHrAnmeldungEntity.hrAnmeldungEntity.prozess.organisation.id.eq(id)).fetchOne();

		Assert.assertFalse(entity.getElektronisch());
		Assert.assertTrue(entity.isBargruendung());
		Assert.assertEquals(entity.getBemerkungen(), "asdasdsadas");
		Assert.assertEquals(entity.getNotarAnrede().getCode(), OSSConstants.ANDERE_MRS_CODE);
		Assert.assertEquals(entity.getNotarVorname(), "Vorname");
		Assert.assertEquals(entity.getNotarName(), "Name Firma");
		Assert.assertEquals(entity.getNotarPostadresse(), "Adresse");
		Assert.assertEquals(entity.getNotarTelefon(), "1231312");		
		Assert.assertEquals(entity.getNotarEmail(), "coh@elca.vn");
		Assert.assertEquals(entity.getAktienkapital(), Integer.valueOf(1000000000));
		Assert.assertEquals(entity.getLiberierungsumfang(), Integer.valueOf(200000000));
		Assert.assertEquals(entity.getNamensaktien(), Integer.valueOf(1));
		Assert.assertEquals(entity.getInhaberaktien(), Integer.valueOf(0));
		Assert.assertEquals(entity.getGruenders().size(), 1);
		HrGruenderEntity gruender = entity.getGruenders().iterator().next();
		Assert.assertEquals(gruender.getFunktion().getCode(), FUNKTION_PRAESIDENT_CODE);
		Assert.assertEquals(gruender.getZeichnung().getCode(), ZEICHNUNG_SIG_CODE);
		Assert.assertTrue(gruender.isComplete());
		Assert.assertEquals(gruender.getAnzInhaberaktien(), Integer.valueOf(0));
		Assert.assertEquals(gruender.getAnzNamensaktien(), Integer.valueOf(1));
		Assert.assertEquals(gruender.getNurHauptsitz(), false);
		
		id = new JPAQuery<Long>(em).from(QOrganisationEntity.organisationEntity)				
				.where(QOrganisationEntity.organisationEntity.namens.any().bezeichnung.eq("David Keimer Testing GmbH 5"))
				.select(QOrganisationEntity.organisationEntity.id).fetchOne();

		entity = new JPAQuery<HrAnmeldungEntity>(em).from(QHrAnmeldungEntity.hrAnmeldungEntity)
				.where(QHrAnmeldungEntity.hrAnmeldungEntity.prozess.organisation.id.eq(id)).fetchOne();
		
		Assert.assertEquals(entity.getProzess().getOrganisation().getRechtsform(), RechtsformEnum.GMBH);
		Assert.assertEquals(entity.getStammanteile(), Integer.valueOf(1));
		Assert.assertEquals(entity.getStammkapital(), Integer.valueOf(100000));
		Assert.assertEquals(entity.getGruenders().iterator().next().getAnzStammanteile(), Integer.valueOf(1));
	}

	@Test
	public void testMigrateStartbizKonto() {
		initDataMigration();
		OrganisationEntity org = new JPAQuery<OrganisationEntity>(em).from(QOrganisationEntity.organisationEntity)				
				.where(QOrganisationEntity.organisationEntity.namens.any().bezeichnung
						.eq("APPLETREE Asset Management SA"))
				.fetchOne();

		Assert.assertEquals(org.getRechtsform(), RechtsformEnum.AG);
		Assert.assertEquals(org.getKontens().size(), 3);
		Assert.assertEquals(org.getKontens().stream().filter(ko -> ko.getTyp().equals(KontotypEnum.POST)).count(), 2);
		KontoEntity konto = org.getKontens().stream().filter(ko -> ko.getTyp().equals(KontotypEnum.BANK)).findFirst()
				.get();
		Assert.assertEquals(konto.getInhaber(), "David Keimer");
		Assert.assertEquals(konto.getBankname(), "Bankname");
		Assert.assertEquals(konto.getPlz(), "12345");
		Assert.assertEquals(konto.getOrt(), "Berlin");
		Assert.assertEquals(konto.getBankleitzahl(), "BIC");
		Assert.assertEquals(konto.getKontonummer(), "1234");
		Assert.assertEquals(konto.getZweck(), ZahlungszweckEnum.UVG);
		Assert.assertEquals(konto.getLand(), LAND_DEU_CODE);
	}
}
