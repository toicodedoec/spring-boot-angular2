/*
 * AbstractProzessEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.hr.service.IHRService;
import ch.admin.oss.organisation.service.IOrganisationService;
import ch.admin.oss.util.IMailUtil;

/**
 * Abstract end point for EasyGov process.
 * 
 * @author coh
 *
 * @param <T> : Represent for the access checking result.
 * @param <D> : Represent for process dto.
 */
public abstract class AbstractProzessEndpoint<D> extends AbstractOSSEndpoint {
	
	@Autowired
	protected IMailUtil mailUtil;

	@Autowired
	protected IOrganisationService organisationService;
	
	@Autowired
	protected IHRService hrService;
	
	/**
	 * Check if the corresponding process can be access or not.
	 * 
	 * @param orgId: 
	 * @return
	 */
	@GetMapping(value = "/access/prozess/{orgId}")
	public final ProcessAccessStatus canAccessProcess(@PathVariable long orgId) {
		ProzessStatusEnum processStatus = getProcessStatus(orgId);
		if(processStatus == ProzessStatusEnum.GESCHLOSSEN || processStatus == ProzessStatusEnum.GESENDET) {
			return ProcessAccessStatus.OK;
		}
		OrganisationEntity organisation = getOrganisation(orgId);
		if (isProcessDoneExternal(organisation.getPflichtenabklaerungen())) {
			return ProcessAccessStatus.KO_DONE_EXTERNAL;
		}
		if (!organisation.isBaseDataComplete()) {
			return ProcessAccessStatus.KO_EDC_NOT_COMPLETED;
		}
		return additionConditionsAccessProcess(organisation);
	}

	/**
	 * If Rechtsform = (AG || GMBH) 
	 * then HR Process must be completed and data must be imported from zefix
	 * @param organisation
	 * @return
	 */
	public ProcessAccessStatus additionConditionsAccessProcess(OrganisationEntity organisation) {
		if ((organisation.getRechtsform() == RechtsformEnum.AG || organisation.getRechtsform() == RechtsformEnum.GMBH)
			&& !skipCheckHrStatus()
			&& !isHrDoneExternal(organisation.getPflichtenabklaerungen())) {
			if(!isDataImportedFromZefix(organisation) || !hrService.isHrProcessCompleted(organisation.getId())) {
				return ProcessAccessStatus.KO_HR_NOT_COMPLETED;
			}
		}
		return ProcessAccessStatus.OK;
	}

	private boolean isHrDoneExternal(PflichtenabklaerungenEntity pflich) {
		return pflich != null && pflich.isAnmeldungHR();
	}
	
	private boolean isDataImportedFromZefix(OrganisationEntity org) {
		return org.getHrStatus() == HRStatusEnum.REGISTERED && org.getZefixImportDate() != null;
	}

	protected OrganisationEntity getOrganisation(long orgId) {
		return organisationService.getOrganisation(orgId,
			QOrganisationEntity.organisationEntity.pflichtenabklaerungen);
	}
	
	protected boolean skipCheckHrStatus() {
		return false;
	}

	protected abstract boolean isProcessDoneExternal(PflichtenabklaerungenEntity pflich);
	
	protected abstract ProzessStatusEnum getProcessStatus(long orgId);

	/**
	 * Get the data of the corresponding process. 
	 * 
	 * @param orgId
	 * @return
	 */
	@RequestMapping(value = "/prozess/{orgId}", method = RequestMethod.GET)
	public abstract D getProcessByOrgId(@PathVariable long orgId);
	
	/**
	 * Save or update process dto without turn on the validation at service layer when 
	 * it is happen somewhere in between the process. The service validation just turn on at the very last step
	 * of the process when all data of the process had been entered. Please see {@link #saveOrUpdateWithValidation(Object)}. 
	 * 
	 * @param dto : dto to be updated.
	 * 
	 * @return
	 */
	@RequestMapping(method = RequestMethod.PUT)
	public abstract ResponseEntity<?> update(@RequestBody D dto);

	/**
	 * Complete dto and turn on the validation at service layer this happen at the very last step
	 * of the process when all data of the process had been entered. 
	 * 
	 * @param dto : dto to be updated.
	 * 
	 * @return
	 */
	@RequestMapping(value = "complete", method = RequestMethod.PUT)
	public abstract ResponseEntity<?> complete(@RequestBody D dto);

	/**
	 * Lock the process of an organisation. 
	 * 
	 * @param orgId: organisation ID.
	 */
	@RequestMapping(value = "lock/{orgId}", method = RequestMethod.PUT)
	public abstract ResponseEntity<?> lock(@PathVariable long orgId);

	/**
	 * Sign the process of an organisation. 
	 * 
	 * @param orgId: organisation ID.
	 */
	@RequestMapping(value = "sign/{orgId}", method = RequestMethod.PUT)
	public abstract ResponseEntity<?> sign(@PathVariable long orgId);
	
	/**
	 * Re lock the process after sign. 
	 * 
	 * @param orgId: organisation ID.
	 */
	@RequestMapping(value = "relock/{orgId}", method = RequestMethod.PUT)
	public abstract ResponseEntity<?> relock(@PathVariable long orgId);
	
	@RequestMapping(value = "interrupt", method = RequestMethod.PUT)
	public abstract ResponseEntity<?> interrupt(@RequestBody D dto);
}