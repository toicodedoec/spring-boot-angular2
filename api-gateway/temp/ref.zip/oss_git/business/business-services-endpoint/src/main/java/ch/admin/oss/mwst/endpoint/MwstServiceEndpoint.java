/*
 * MwstServiceEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.mwst.endpoint;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.validation.Valid;
import javax.validation.groups.Default;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import ch.admin.oss.ahv.service.IAhvService;
import ch.admin.oss.common.AbstractProzessEndpoint;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.CommonAddress;
import ch.admin.oss.common.ExceptionHandlingController;
import ch.admin.oss.common.ProcessAccessStatus;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.QuarSemEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.MwstAbmeldungEntity;
import ch.admin.oss.domain.MwstAdressaenderungEntity;
import ch.admin.oss.domain.MwstAnmeldungEntity;
import ch.admin.oss.domain.MwstEintrBestEntity;
import ch.admin.oss.domain.MwstFristverlangerungEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.enums.SupportedFileTypeDownload;
import ch.admin.oss.hr.service.IHRService;
import ch.admin.oss.moa.endpoint.MoaAccessEndpoint;
import ch.admin.oss.mwst.service.IMWSTService;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.uvg.service.IUVGService;

/**
 * @author hhu
 */
@CrossOrigin
@RestController
@RequestMapping("/private/ext/mwst")
public class MwstServiceEndpoint extends AbstractProzessEndpoint<MwstAnmeldungDto> {

	private static final int NUM_OF_YEARS = 6;

	private static final int START_DAY_OF_MONTH = 1;

	private static final int START_MONTH_OF_BUSINESS_YEAR = 7;

	public static final String SESSION_MOA_CONFIG = "moaConfigs";

	private static final String GESCHAEFSROLLE_FUNKTION_INHABER = "INHABER";

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MwstServiceEndpoint.class);
	
	@Value("${oss.mwst.fristverlangerung.url.de}")
	private String mwstfristverlangerungUrlDE;
	
	@Value("${oss.mwst.fristverlangerung.url.fr}")
	private String mwstfristverlangerungUrlFR;
	
	@Value("${oss.mwst.fristverlangerung.url.it}")
	private String mwstfristverlangerungUrlIT;

	@Value("${mwst.moa.url}")
	private String mwstMoaUrl;
	
	@Value("${mwst.moa.callback.simulate.enabled}")
	private boolean mwstMoaCallbackSimulate;
	
	@Value("${mwst.moa.callback.simulate.url}")
	private String mwstMoaCallbackSimulateUrl;
	
	@Autowired
	private IUVGService uvgService;
	
	@Autowired
	private IHRService hrService;
	
	@Autowired
	private IAhvService ahvService;
	
	@Autowired
	private IMWSTService mwstService;
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	protected boolean isProcessDoneExternal(PflichtenabklaerungenEntity pflich) {
		return pflich != null && pflich.isAnmeldungMWST();
	}
	
	@Override
	public ProcessAccessStatus additionConditionsAccessProcess(OrganisationEntity organisation) {
		switch (organisation.getPflichtenabklaerungen().getAnmeldungMWSTBefund()) {
		case MWST_FREIWILLIG_EXTERN_DATUM:
		case MWST_ZWINGEND_EXTERN_DATUM:
			return ProcessAccessStatus.KO_MWST_START_BUSINESS_DATE_EXPIRED;
		default:
			break;
		}
		return super.additionConditionsAccessProcess(organisation);
	}

	@Override
	public MwstAnmeldungDto getProcessByOrgId(@PathVariable long orgId) {
		MwstAnmeldungEntity entity = mwstService.getByOrganisationId(orgId);
		MwstAnmeldungDto dto = mapper.map(entity, MwstAnmeldungDto.class);
		dto.getProzess().getOrganisation().setAccessFromOutsideFlow(true);
		dto.setCanAccessPdf1(entity.getPdf1() != null);
		dto.setCanAccessPdf2(entity.getPdf2() != null);
		dto.setCanAccessPdf3(entity.getPdf3() != null);
		dto.setCanAccessPdf4(entity.getPdf4() != null);
		return dto;
	}

	@Override
	public ResponseEntity<?> update(@RequestBody MwstAnmeldungDto dto) {
		MwstAnmeldungEntity entity = mwstService.getByOrganisationId(dto.getProzess().getOrganisation().getId());
		mapper.map(dto, entity);	
		return ResponseEntity.ok(mapper.map(mwstService.updateProcess(entity), MwstAnmeldungDto.class));
	}
	
	@Override
	public ResponseEntity<?> interrupt(@RequestBody MwstAnmeldungDto dto) {
		MwstAnmeldungEntity entity = mwstService.getByOrganisationId(dto.getProzess().getOrganisation().getId());
		mapper.map(dto, entity);	
		return ResponseEntity.ok(mapper.map(mwstService.updateProcess(entity), MwstAnmeldungDto.class));
	}

	@Override
	public ResponseEntity<?> complete(@RequestBody MwstAnmeldungDto dto) {
		throw new UnsupportedOperationException("This operation process is not supported !");
	}

	@Override
	public ResponseEntity<?> lock(@PathVariable long orgId) {
		throw new UnsupportedOperationException("This operation process is not supported !");
	}

	@Override
	public ResponseEntity<?> sign(@PathVariable long orgId) {
		throw new UnsupportedOperationException("This operation process is not supported !");
	}

	@Override
	public ResponseEntity<?> relock(@PathVariable long orgId) {
		throw new UnsupportedOperationException("This operation process is not supported !");
	}
	
	/**
	 * This function will post data to external service and receive a html page.
	 * 
	 * <p>According SECOOSS-287: We will parse html page to get response</p>
	 * 
	 * @param dto {@link MwstFristverlangerungDto}
	 * @return
	 */
	@PutMapping("firstverlangerung")
	public ResponseEntity<?> mwstFirstverlangerung(@RequestBody @Valid MwstFristverlangerungDto dto) {
		try{
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.MULTIPART_FORM_DATA);
			MultiValueMap<String, String> body = buildRequestBodyMwstFristverlangerung(dto);
			HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(body, headers);
			
			SupportedLanguage lang = SecurityUtil.currentUser().getLanguagePreference();
			String postURL = null;
			switch (lang) {
				case DE:
				case EN:
					postURL = mwstfristverlangerungUrlDE;
					break;
				case FR:
					postURL = mwstfristverlangerungUrlFR;
					break;
				case IT:
					postURL = mwstfristverlangerungUrlIT;
					break;
				default:
					break;
			}
			
			ResponseEntity<String> response = restTemplate.postForEntity(postURL, request, String.class);
			String responseString = response.getBody();
			
			if(response.getStatusCode() != HttpStatus.OK) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
						.body(ExceptionHandlingController.errorFor(MwstServiceEndpoint.class.getSimpleName()));
			}
			
			//Fail
			if(StringUtils.contains(responseString, OSSConstants.MWST_FRIST_SERVICE_ERROR_DE) 
					|| StringUtils.contains(responseString, OSSConstants.MWST_FRIST_SERVICE_ERROR_FR)
					|| StringUtils.contains(responseString, OSSConstants.MWST_FRIST_SERVICE_ERROR_IT)) {
				responseString = StringUtils.substringBetween(responseString, "</h1><b>", "<span");
				String[] errors = StringUtils.substringsBetween(responseString, "<br>", "</b>");
				responseString = StringUtils.join(errors, "<br>");
				return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
						.body(ExceptionHandlingController.errorFor(StringUtils.replace(responseString, "<b><br>", "")));
			}
			
			//Duplicated
			if(StringUtils.contains(responseString, OSSConstants.MWST_FRIST_SERVICE_DUPLICATED_DE)) {
				responseString = StringUtils.substringBetween(responseString, OSSConstants.MWST_FRIST_SERVICE_DUPLICATED_DE, "<span");
				responseString = StringUtils.replace(responseString, "<br><br>", "<br>");
				responseString = StringUtils.replace(responseString, "<BR>", "");
				responseString = OSSConstants.MWST_FRIST_SERVICE_DUPLICATED_DE.concat(responseString);
				return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
						.body(ExceptionHandlingController.errorFor(responseString));
			}
			
			//Success
			if(StringUtils.contains(responseString, OSSConstants.MWST_FRIST_SERVICE_SUCCESS_DE)) {
				MwstFristverlangerungEntity entity = new MwstFristverlangerungEntity();
				mapper.map(dto, entity);
				return ResponseEntity.ok(mapper.map(mwstService.createMwstFirstverlangerung(entity, dto.getProzess().getOrganisation().getId()), MwstFristverlangerungDto.class));
			}
			
			//Not contains expected string
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionHandlingController.errorFor(MwstServiceEndpoint.class.getSimpleName()));
		} catch (RestClientException rce) {
			LOGGER.error("Something went wrong when request to external service mwst frist", rce);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(ExceptionHandlingController.errorFor(MwstServiceEndpoint.class.getSimpleName()));
		}
	}
	
	@RequestMapping(value = "prozess/firstverlangerung", method = RequestMethod.GET)
	public MwstFristverlangerungDto getProzessFirstverlangerung(@RequestParam(name="prozessId") Long prozessId, @RequestParam(name="orgId") Long orgId) {
		MwstFristverlangerungEntity entity = mwstService.getMwstFristverlangerung(prozessId, orgId);
		MwstFristverlangerungDto dto = mapper.map(entity, MwstFristverlangerungDto.class);
		dto.setOptions(getFristverlangerungOptionValue(null));
		return dto;
	}
	
	@RequestMapping(value = "prozess/firstverlangerungOption", method = RequestMethod.GET)
	public List<MwstFristverlangerungOptionDto> getFristverlangerungOptionValue(@RequestParam(required = false, name = "language") SupportedLanguage language) {	
		SupportedLanguage lang = language != null ? language : SecurityUtil.currentUser().getLanguagePreference();
		List<MwstFristverlangerungOptionDto> result = new ArrayList<>();
		
		switch (lang) {
			case DE:
			case FR:
			case IT:
				MwstFristverlangerungPeriod option = buildFristverlangerungOptionValue(lang);
				result.add(new MwstFristverlangerungOptionDto(StringEscapeUtils.unescapeHtml4(option.getEmptyText()), 
					option.getEmptyVal()));
				result.add(new MwstFristverlangerungOptionDto(StringEscapeUtils.unescapeHtml4(option.getPeriode1()), 
					option.getPeriode1()));
				result.add(new MwstFristverlangerungOptionDto(StringEscapeUtils.unescapeHtml4(option.getPeriode2()), 
					option.getPeriode2()));
				result.add(new MwstFristverlangerungOptionDto(StringEscapeUtils.unescapeHtml4(option.getPeriode3()), 
					option.getPeriode3()));
				break;
			case EN:
				MwstFristverlangerungPeriod text = buildFristverlangerungOptionValue(lang);
				MwstFristverlangerungPeriod value = buildFristverlangerungOptionValue(SupportedLanguage.DE);
				result.add(new MwstFristverlangerungOptionDto(StringEscapeUtils.unescapeHtml4(text.getEmptyText()), 
					value.getEmptyVal()));
				result.add(new MwstFristverlangerungOptionDto(StringEscapeUtils.unescapeHtml4(text.getPeriode1()), 
					value.getPeriode1()));
				result.add(new MwstFristverlangerungOptionDto(StringEscapeUtils.unescapeHtml4(text.getPeriode2()), 
					value.getPeriode2()));
				result.add(new MwstFristverlangerungOptionDto(StringEscapeUtils.unescapeHtml4(text.getPeriode3()), 
					value.getPeriode3()));
				break;
			default:
				throw new IllegalArgumentException("Unsupported build Fristverlangerung option value for " + lang);
		}
		
		return result;
	}
	
	// According to the algorithm mention in https://projectportal.elca.ch/jira/browse/SECOOSS-287
	private MwstFristverlangerungPeriod buildFristverlangerungOptionValue(SupportedLanguage lang) {
		int currYear = LocalDate.now().getYear();
		int nextYear = currYear + 1;
		int prevYear = currYear - 1;
		
		DateFormat formatter = new SimpleDateFormat("Mdd");
		int currentDay = Integer.valueOf(formatter.format(new Date()));
		
		String q1 = null;
		String q2 = null;
		String q3 = null;
		String q4 = null;
		String s1 = null;
		String s2 = null;
		String emptyText = null;
		String emptyVal = null;
		
		switch (lang) {
			case DE:
				emptyText = "  *** Abrechnungsperiode ? ***";
				emptyVal = "leer";
				q1 = "1. Quartal %d &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Fristerstreckung bis 31.08.%d)";
				q2 = "2. Quartal %d &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Fristerstreckung bis 30.11.%d)";
				q3 = "3. Quartal %d &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Fristerstreckung bis 28.02.%d)";
				q4 = "4. Quartal %d &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Fristerstreckung bis 31.05.%d)";
				s1 = "1. Semester %d (Fristerstreckung bis 30.11.%d)";
				s2 = "2. Semester %d (Fristerstreckung bis 31.05.%d)";
				break;
			case FR:
				emptyText = "  *** Période de décompte ? ***";
				emptyVal = "leer";
				q1 = "1. Trimestre %d &nbsp; (prorogation du délai jusqu‘au 31.08.%d)";
				q2 = "2. Trimestre %d &nbsp; (prorogation du délai jusqu‘au 30.11.%d)";
				q3 = "3. Trimestre %d &nbsp; (prorogation du délai jusqu‘au 28.02.%d)";
				q4 = "4. Trimestre %d &nbsp; (prorogation du délai jusqu‘au 31.05.%d)";
				s1 = "1. Semestre %d (prorogation du délai jusqu‘au 30.11.%d)";
				s2 = "2. Semestre %d (prorogation du délai jusqu‘au 31.05.%d)";
				break;
			case IT:
				emptyText = "  *** Periodo di rendiconto ? ***";
				emptyVal = "leer";
				q1 = "1. Trimestre %d&nbsp; (proroga del termine fino al 31.08.%d)";
				q2 = "2. Trimestre %d&nbsp; (proroga del termine fino al 30.11.%d)";
				q3 = "3. Trimestre %d&nbsp; (proroga del termine fino al 28.02.%d)";
				q4 = "4. Trimestre %d&nbsp; (proroga del termine fino al 31.05.%d)";
				s1 = "1. Semestre %d (proroga del termine fino al 30.11.%d)";
				s2 = "2. Semestre %d (proroga del termine fino al 31.05.%d)";
				break;
			case EN:
				emptyText = "  *** Abrechnungsperiode ? ***";
				emptyVal = "leer";
				q1 = "1st quarter %d &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(extension of time until 31.08.%d)";
				q2 = "2nd quarter %d &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(extension of time until 30.11.%d)";
				q3 = "3rd quarter %d &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(extension of time until 28.02.%d)";
				q4 = "4th quarter %d &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(extension of time until 31.05.%d)";
				s1 = "1st semester %d (extension of time until 30.11.%d)";
				s2 = "2nd semester %d (extension of time until 31.05.%d)";
				break;
			default:
				throw new IllegalArgumentException("Build option for lang " + lang + " is not supported.");
		}
		
		// Select the string pattern && put in the correct years, depending on the current day
		if (currentDay > 100 && currentDay < 230) {
			return new MwstFristverlangerungPeriod(emptyText, emptyVal, String.format(q3, prevYear, currYear), 
				String.format(q4, prevYear, currYear), String.format(s2, prevYear, currYear));
		} else if (currentDay > 300 && currentDay < 311) {
			return new MwstFristverlangerungPeriod(emptyText, emptyVal, String.format(q4, prevYear, currYear),
				String.format(s2, prevYear, currYear), null);
		} else if (currentDay > 310 && currentDay < 532) {
			return new MwstFristverlangerungPeriod(emptyText, emptyVal, String.format(q4, prevYear, currYear),
				String.format(q1, currYear, currYear), String.format(s2, prevYear, currYear));
		} else if (currentDay > 600 && currentDay < 610) {
			return new MwstFristverlangerungPeriod(emptyText, emptyVal, String.format(q1, currYear, currYear),
				null, null);
		} else if (currentDay > 609 && currentDay < 832) { 
			return new MwstFristverlangerungPeriod(emptyText, emptyVal, String.format(q1, currYear, currYear),
				String.format(q2, currYear, currYear), String.format(s1, currYear, currYear));
		} else if (currentDay > 900 && currentDay < 910) {
			return new MwstFristverlangerungPeriod(emptyText, emptyVal, String.format(q2, currYear, currYear),
				String.format(s1, currYear, currYear), null);
		} else if (currentDay > 909 && currentDay < 1131) {
			return new MwstFristverlangerungPeriod(emptyText, emptyVal, String.format(q2, prevYear, currYear),
				String.format(q3, currYear, nextYear), String.format(s1, currYear, currYear));
		} else if (currentDay > 1200 && currentDay < 1211) {
			return new MwstFristverlangerungPeriod(emptyText, emptyVal, String.format(q3, currYear, nextYear),
				null, null);
		} else if (currentDay > 1210 && currentDay < 1232) {
			return new MwstFristverlangerungPeriod(emptyText, emptyVal, String.format(q3, currYear, nextYear),
				String.format(q4, currYear, nextYear), String.format(s2, currYear, nextYear));
		}
		throw new IllegalArgumentException("currentday (" + currentDay +") is out of range to build value for selection box");
	}
	
	private MultiValueMap<String, String> buildRequestBodyMwstFristverlangerung(MwstFristverlangerungDto dto) {
		MultiValueMap<String, String> body = new LinkedMultiValueMap<String, String>();
		body.add("nr_1", dto.getNr1());
		body.add("nr_2", dto.getNr2());
		body.add("nr_3", dto.getNr3());
		body.add("quarsem", QuarSemEnum.getEnumValue(dto.getQuarSem(), SecurityUtil.currentUser().getLanguagePreference()));
		body.add("name", dto.getName());
		body.add("frist", dto.getFrist());
		body.add("ort", dto.getOrt());
		body.add("tel", dto.getKontakt());
		body.add("email", dto.getEmail());
		return body;
	}
	
	@RequestMapping(value = "mwstAdressaenderungRef", method = RequestMethod.GET)
	public ResponseEntity<?> getMwstMitteilungDomizils(@RequestParam long orgId) {
		
		OrganisationEntity entity = organisationService.getDomizilOfAllPersons(orgId);
		
		MwstDomizilCollectionDto result = new MwstDomizilCollectionDto();
		
		if (entity.getDomizil() != null && entity.getDomizil().getLand() != null
			&& OSSConstants.SWISS_CODE_WERT.equals(entity.getDomizil().getLand().getCode())) {
			result.getOrgDomizils().add(mapper.map(entity.getDomizil(), AdresseDto.class));
		}
		// get Person address
		if (entity.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC) != null) {
			entity.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream().forEach(r -> {
				if (GESCHAEFSROLLE_FUNKTION_INHABER.equals(r.getFunktion().getCode())
					&& OSSConstants.SWISS_CODE_WERT.equals(r.getPerson().getWohnadresse().getLand().getCode())) {
					result.getInhaber().add(mapper.map(r.getPerson().getWohnadresse(), AdresseDto.class));
				}
			});
		}

		result.getKorrespondenz().addAll(getKorrespondenzAdresse(orgId, entity.getDomizil()));
		
		MwstAdressaenderungDto dto = new MwstAdressaenderungDto(entity.getRechtsform());
		dto.setRefDomizilData(result);
		
		return ResponseEntity.ok(dto);
	}

	private List<AdresseDto> getKorrespondenzAdresse(long orgId, AdresseEntity domizil) {
		List<AdresseDto> result = new ArrayList<AdresseDto>();

		if (domizil != null && domizil.getLand() != null
			&& OSSConstants.SWISS_CODE_WERT.equals(domizil.getLand().getCode())) {
			result.add(mapper.map(domizil, AdresseDto.class));
		}
		// get AhvAnmeldung
		result.addAll(convertToAdresseDtoList(ahvService.getAhvAdresseKontaktByOrgId(orgId)));
		// get HrAnmeldung
		result.addAll(convertToAdresseDtoList(hrService.getHrAdresseKorrespondenzByOrgId(orgId)));
		// get UvgAnmeldung
		result.addAll(convertToAdresseDtoList(uvgService.getUvgKontaktAdresseByOrgId(orgId)));
		// get MwstAdressaenderung
		result.addAll(convertToAdresseDtoList(mwstService.getMwstAdressaenderungAdresseKorrespondenzByOrgId(orgId)));
		// get MwstEintrBest
		result.addAll(convertToAdresseDtoList(mwstService.getMwstEintrBestAdresseByOrgId(orgId)));

		return result;
	}

	private List<AdresseDto> convertToAdresseDtoList(List<AdresseEntity> entities) {
		if (entities != null && entities.size() > 0) {
			return entities.stream().map(a -> mapper.map(a, AdresseDto.class))
				.collect(Collectors.toList());
		}
		return Arrays.asList();
	}
	
	@PutMapping("mwstAdressaenderung")
	public ResponseEntity<?> mwstAdressaenderung(@RequestBody
		@Validated({CommonAddress.class, Default.class}) MwstAdressaenderungDto dto) {
		if (dto.getRechtsForm() == RechtsformEnum.EINZELFIRMA) {
			if (dto.getAdresseOwner() == null) {
				return ResponseEntity
					.status(HttpStatus.PRECONDITION_FAILED)
					.body(ExceptionHandlingController.errorFor("The owner address is required."));
			}
			if (dto.getAdresseOwner().getStrasse() == null
				|| dto.getAdresseOwner().getPlz() == null
				|| dto.getAdresseOwner().getOrt() == null) {
				return ResponseEntity
					.status(HttpStatus.PRECONDITION_FAILED)
					.body(ExceptionHandlingController.errorFor("For the owner address: strasse, plz and ort are required."));
			}
		}

		MwstAdressaenderungEntity entity = new MwstAdressaenderungEntity();
		mapper.map(dto, entity);

		// set default land
		CodeWertEntity swissCodeWert = getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT);
		entity.getAdresseBisher().setLand(swissCodeWert);
		entity.getAdresseNeu().setLand(swissCodeWert);
		if (entity.getAdresseKorrespondenz() != null) {
			entity.getAdresseKorrespondenz().setLand(swissCodeWert);
		}
		if (entity.getAdresseOwner() != null) {
			entity.getAdresseOwner().setLand(swissCodeWert);
		}
		
		return ResponseEntity
			.ok(mapper.map(mwstService.createMwstAdressaenderung(entity, dto.getProzess().getOrganisation().getId()),
				MwstAdressaenderungDto.class));
	}

	@RequestMapping(value = "prozess/mwstAdressaenderung", method = RequestMethod.GET)
	public ResponseEntity<?> mwstAdressaenderung(@RequestParam Long prozessId, @RequestParam Long orgId) {
		MwstAdressaenderungEntity entity = mwstService.getMwstAdressaenderungByProzessId(prozessId, orgId);
		return entity != null ? ResponseEntity.ok(mapper.map(entity, MwstAdressaenderungDto.class))
			: ResponseEntity.ok(new MwstAdressaenderungDto());
	}
		
	@RequestMapping(value = "mwstAbmeldungRef", method = RequestMethod.GET)
	public ResponseEntity<?> getMwstAbmeldungDomizils(@RequestParam long orgId) {
		MwstAbmeldungDto dto = new MwstAbmeldungDto();
		
		AdresseEntity entity = organisationService.getOrgDomizil(orgId);
		if (entity != null) {
			dto.setOrgDomizil(mapper.map(entity, AdresseDto.class));
		}
		
		dto.setBegrundung(applicationService.getCodeWerts(Arrays.asList(KategorieEnum.MWST_ABMELD_GRUND))
			.get(KategorieEnum.MWST_ABMELD_GRUND).stream().map(c -> mapper.map(c, CodeWertDto.class))
			.collect(Collectors.toList()));
		
		return ResponseEntity.ok(dto);
	}

	@PutMapping("mwstAbmeldung")
	public ResponseEntity<?> mwstAbmeldung(@RequestBody
		@Validated({CommonAddress.class, MwstAbmeldungAddress.class, Default.class})
		MwstAbmeldungDto dto) {
		MwstAbmeldungEntity entity = new MwstAbmeldungEntity();
		mapper.map(dto, entity);

		// set default land
		entity.getAdresse().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
		
		return ResponseEntity
			.ok(mapper.map(mwstService.createMwstAbmeldung(entity, dto.getProzess().getOrganisation().getId()),
				MwstAbmeldungDto.class));
	}

	@RequestMapping(value = "prozess/mwstAbmeldung", method = RequestMethod.GET)
	public ResponseEntity<?> mwstAbmeldung(@RequestParam Long prozessId, @RequestParam Long orgId) {
		MwstAbmeldungDto dto = new MwstAbmeldungDto();
		MwstAbmeldungEntity entity = mwstService.getMwstAbmeldungByProzessId(prozessId, orgId);
		if (entity != null) {
			dto = mapper.map(entity, MwstAbmeldungDto.class);
			dto.setBegrundung(applicationService.getCodeWerts(Arrays.asList(KategorieEnum.MWST_ABMELD_GRUND))
				.get(KategorieEnum.MWST_ABMELD_GRUND).stream().map(c -> mapper.map(c, CodeWertDto.class))
				.collect(Collectors.toList()));
			return ResponseEntity.ok(dto);
		}
		return ResponseEntity.ok(new MwstAbmeldungDto());
	}
	
	@SuppressWarnings({"rawtypes"})
	@RequestMapping(value = "/download/anmeldungPdf/{orgId}", method = RequestMethod.GET)
	public ResponseEntity downloadAnmeldungPdf(@PathVariable long orgId) {
		byte[] pdf = mwstService.getByOrganisationId(orgId).getProzess().getPdf();
		return download(pdf, "mwstAnmeldung.pdf", SupportedFileTypeDownload.PDF);
	}
	
	@SuppressWarnings({"rawtypes"})
	@RequestMapping(value = "/download/pdf1/{orgId}", method = RequestMethod.GET)
	public ResponseEntity downloadPdf1(@PathVariable long orgId) {
		byte[] pdf = mwstService.getByOrganisationId(orgId).getPdf1();
		return download(pdf, "mwstPdf1.pdf", SupportedFileTypeDownload.PDF);
	}
	
	@SuppressWarnings({"rawtypes"})
	@RequestMapping(value = "/download/pdf2/{orgId}", method = RequestMethod.GET)
	public ResponseEntity downloadPdf2(@PathVariable long orgId) {
		byte[] pdf = mwstService.getByOrganisationId(orgId).getPdf2();
		return download(pdf, "mwstPdf2.pdf", SupportedFileTypeDownload.PDF);
	}
	
	@SuppressWarnings({"rawtypes"})
	@RequestMapping(value = "/download/pdf3/{orgId}", method = RequestMethod.GET)
	public ResponseEntity downloadPdf3(@PathVariable long orgId) {
		byte[] pdf = mwstService.getByOrganisationId(orgId).getPdf3();
		return download(pdf, "mwstPdf3.pdf", SupportedFileTypeDownload.PDF);
	}
	
	@SuppressWarnings({"rawtypes"})
	@RequestMapping(value = "/download/pdf4/{orgId}", method = RequestMethod.GET)
	public ResponseEntity downloadPdf4(@PathVariable long orgId) {
		byte[] pdf = mwstService.getByOrganisationId(orgId).getPdf4();
		return download(pdf, "mwstPdf4.pdf", SupportedFileTypeDownload.PDF);
	}
	
	@RequestMapping(value = "mwstEintrBestRef", method = RequestMethod.GET)
	public ResponseEntity<?> getMwstEintrBestDomizils(@RequestParam long orgId) {
		MwstDomizilCollectionDto dom = new MwstDomizilCollectionDto();

		AdresseEntity entity = organisationService.getOrgDomizil(orgId);
		if (entity != null) {
			dom.getOrgDomizils().add(mapper.map(entity, AdresseDto.class));
		}

		dom.getKorrespondenz().addAll(getKorrespondenzAdresse(orgId, entity));

		MwstEintrBestDto dto = new MwstEintrBestDto();
		
		dto.setRefDomizilData(dom);
				
		int currentYear = LocalDate.now().getYear();
		dto.setJahren((LocalDate.now().isBefore(LocalDate.of(currentYear, START_MONTH_OF_BUSINESS_YEAR, START_DAY_OF_MONTH)))
			? IntStream.range(0, NUM_OF_YEARS).map(index -> currentYear - (index + 1)).boxed().collect(Collectors.toList())
			: IntStream.range(0, NUM_OF_YEARS).map(index -> currentYear - index).boxed().collect(Collectors.toList()));

		return ResponseEntity.ok(dto);
	}

	@PutMapping("mwstEintrBest")
	public ResponseEntity<?> mwstEintrBest(@RequestBody
		@Validated({CommonAddress.class, MwstEintrBestAddress.class, Default.class})
		MwstEintrBestDto dto) {
		MwstEintrBestEntity entity = new MwstEintrBestEntity();
		mapper.map(dto, entity);

		// set default land
		CodeWertEntity swissCodeWert = getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT);
		entity.getAdresse().setLand(swissCodeWert);
		entity.getZustellAdresse().setLand(swissCodeWert);
		
		return ResponseEntity
			.ok(mapper.map(mwstService.createMwstEintrBest(entity, dto.getProzess().getOrganisation().getId()),
				MwstEintrBestDto.class));
	}

	@RequestMapping(value = "prozess/mwstEintrBest", method = RequestMethod.GET)
	public ResponseEntity<?> mwstEintrBest(@RequestParam Long prozessId, @RequestParam Long orgId) {
		MwstEintrBestEntity entity = mwstService.getMwstEintrBestByProzessId(prozessId, orgId);
		return entity != null ? ResponseEntity.ok(mapper.map(entity, MwstEintrBestDto.class))
			: ResponseEntity.ok(new MwstEintrBestDto());
	}

	@RequestMapping(value = "moaConfig", method = RequestMethod.GET)
	public MwstMoaConfigDto getMoaConfig(@RequestParam Long orgId) {
		String uuid = new MwstMoaIdDto(orgId, SecurityUtil.currentUser().getUserId()).encode();
		String serviceRootUrl = mwstMoaCallbackSimulate ? mwstMoaCallbackSimulateUrl : getServiceRootUrl() ;
		MwstMoaConfigDto moaConfig = new MwstMoaConfigDto(
			uuid,
			getMwstMoaUrl(),
			serviceRootUrl + MoaAccessEndpoint.MOA_JUMP_BACK_URL + "/" + uuid,
			serviceRootUrl + MoaAccessEndpoint.GET_MOA_USER_DATA_URL,
			serviceRootUrl + MoaAccessEndpoint.PUT_MOA_USER_DATA_URL
		);
		return moaConfig;
	}

	private String getMwstMoaUrl() {
		String language = SecurityUtil.currentUser().getLanguagePreference().name().toLowerCase();
		return StringUtils.replace(mwstMoaUrl, "{language}", language);
	}
	
	private class MwstFristverlangerungPeriod {
		private final String periode1;
		private final String periode2;
		private final String periode3;
		private final String emptyText;
		private final String emptyVal;
		
		public MwstFristverlangerungPeriod(String emptyText, String emptyVal, String periode1, String periode2, String periode3) {
			super();
			this.emptyText = emptyText;
			this.emptyVal = emptyVal;
			this.periode1 = periode1;
			this.periode2 = periode2;
			this.periode3 = periode3;
		}

		public String getEmptyText() {
			return emptyText;
		}

		public String getEmptyVal() {
			return emptyVal;
		}

		public String getPeriode1() {
			return periode1;
		}

		public String getPeriode2() {
			return periode2;
		}

		public String getPeriode3() {
			return periode3;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected ProzessStatusEnum getProcessStatus(long orgId) {
		return mwstService.getProcessStatusByOrgId(orgId);
	}	
}
