/*
 * GenerateDataTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.performance;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.ClassRule;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized.Parameters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.context.ApplicationContextException;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestContextManager;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;
import org.springframework.transaction.TransactionStatus;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.ahv.service.IAhvService;
import ch.admin.oss.business.AbstractOSSManualTransactionalTest;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.AccessLevelEnum;
import ch.admin.oss.common.enums.AccessStatusEnum;
import ch.admin.oss.common.enums.AnmeldungAHVBefundEnum;
import ch.admin.oss.common.enums.AnmeldungHRBefundEnum;
import ch.admin.oss.common.enums.AnmeldungMWSTBefundEnum;
import ch.admin.oss.common.enums.AnmeldungUVGBefundEnum;
import ch.admin.oss.common.enums.EinlageEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.FirmennameEntity;
import ch.admin.oss.domain.GeschaeftsstelleEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.KommGesEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.QUserEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.organisation.service.IOrganisationService;
import ch.admin.oss.performance.process.ProcessGeneratorFactory;
import ch.admin.oss.portal.service.IPortalService;

/**
 * @author hha
 */
@Ignore
@ActiveProfiles(CommonConstants.PROFILE_TEST_PERFORMANCE_DATA)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@RunWith(Parallelized.class)
public class GenerateDataTest extends AbstractOSSManualTransactionalTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(GenerateDataTest.class);

	private static final int ID_RANGE = 100_000;

	// Number of organisation should be committed in each transaction.
	private static final int DATA_BULK_SIZE = 200;

	// The ID to generate data.
	private static final int DATA_FROM = 1;
	// For each type of form.
	private static final int DATA_MAX = 100_000;

	@ClassRule
	public static final SpringClassRule SPRING_CLASS_RULE = new SpringClassRule();
	@Rule
	public final SpringMethodRule springMethodRule = new SpringMethodRule();

	@Autowired
	private IOrganisationService organisationService;
	@Autowired
	private IPortalService portalService;
	@Autowired
	private IAhvService ahvService;

	@Autowired
	private ProcessGeneratorFactory processGeneratorFactory;
	@Autowired
	private DataHelper dataHelper;

	private static long getFromId(RechtsformEnum form) {
		switch (form) {
			case AG:
				return ID_RANGE * 0; // 0
			case GMBH:
				return ID_RANGE * 1; // 100.000
			case EINZELFIRMA:
				return ID_RANGE * 2; // 200.000
			case KOLLGES:
				return ID_RANGE * 3;
			case KOMMGES:
				return ID_RANGE * 4;
			default:
				return ID_RANGE * 8;
		}
	}

	@Parameters
	public static Collection<Object[]> getParameters() {
		List<Object[]> parameters = new ArrayList<Object[]>();
		for (RechtsformEnum rechtsform : RechtsformEnum.values()) {
			long rangeId = getFromId(rechtsform);
			final Range range = new Range(DATA_BULK_SIZE, rangeId + DATA_MAX, rangeId + DATA_FROM);
			while (range.next()) {
				parameters.add(new Object[] {
					new OrganisationConfig(range.from, range.to, rechtsform)
				});
			}
		}
		return parameters;
	}

	private OrganisationConfig config;

	public GenerateDataTest(OrganisationConfig config) {
		this.config = config;
	}

	@Before
	public void setupTest() {
		try {
			new TestContextManager(getClass()).prepareTestInstance(this);
		} catch (Exception e) {
			throw new ApplicationContextException("Application context failed to start", e);
		}
	}

	@Test
	public void generateData() throws Exception {
		LOGGER.warn("BEGIN === Generate data FROM " + config.from + " TO " + config.to);

		UserEntity fromUser = new JPAQuery<UserEntity>(em)
			.from(QUserEntity.userEntity)
			.where(QUserEntity.userEntity.familienname.eq(USER_FAMILY_NAME))
			.where(QUserEntity.userEntity.vorname.goe(getKey(config.from)))
			.where(QUserEntity.userEntity.vorname.loe(getKey(config.to)))
			.orderBy(QUserEntity.userEntity.eid.desc())
			.fetchFirst();
		long from = fromUser != null ? Integer.parseInt(fromUser.getVorname()) : config.from;
		if (from >= config.to) {
			return;
		}

		execute(new Consumer<TransactionStatus>() {
			@Override
			public void accept(TransactionStatus status) {
				for (long i = from; i <= config.to; i++) {
					String key = getKey(i);
					login(key);
					OrganisationEntity organisation = createOrganisation(key, config.rechtsform);

					for (GeschaeftsstelleEntity item : new ArrayList<>(organisation.getGeschaeftsstellens())) {
						ahvService.createAhvFiliale(item);
					}
					for (GeschaftsrolleEntity item : organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)) {
						ahvService.createAhvTeilhaber(item);
					}

					for (ProzessTypEnum prozessTyp : ProzessTypEnum.values()) {
						organisation = processGeneratorFactory.generate(organisation, prozessTyp);
					}

					// Distribute users
					long rangeIdFrom = getFromId(config.rechtsform) + 1;
					long rangeIdTo = rangeIdFrom + ID_RANGE;
					if (!(rangeIdFrom <= i && i <= rangeIdTo)) {
						continue;
					}
					// We have 5 types of form.

					// We need 30.000 orgs with 3 users
					// ==> Distribute for each form 6000
					// From ??1_001 => ??7_000

					// We need 70.000 orgs with 2 users
					// ==> Distribute for each form 14.000
					// From ?10_001 => ?24_000

					long orgWith3UsersFrom = rangeIdFrom + 1_000; // 1 + 1000 = 1001
					long orgWith3Users = orgWith3UsersFrom + 6_000 - 1; // 1001 + 6000 - 1 = 7000 (1001 -> 7000 = 6000 orgs)

					long orgWith2UsersFrom = rangeIdFrom + 10_000; // 1 + 10000 = 10001
					long orgWith2Users = orgWith2UsersFrom + 14_000 - 1; // 10001 + 14000 - 1 = 24000 (10001 -> 24000 = 14000 orgs)

					if (orgWith3UsersFrom <= i && i <= orgWith3Users) {
						// Divide users to group of 3
						// i = 1001 => (2) => assign 1002, 1003
						// i = 1002 => (0) => assign 1001, 1003
						// i = 1003 => (1) => assign 1001, 1002

						// i = 1004 => (2) => assign 1005, 1006
						// i = 1005 => (0) => assign 1004, 1006
						// i = 1006 => (1) => assign 1004, 1005

						if (i % 3 == 2) {
							assignUsers(organisation, i + 1, i + 2);
						} else if (i % 3 == 0) {
							assignUsers(organisation, i - 1, i + 1);
						} else if (i % 3 == 1) {
							assignUsers(organisation, i - 1, i - 2);
						}
					} else if (orgWith2UsersFrom <= i && i <= orgWith2Users) {
						// Divide users to group of 2
						// i = 10_001 => (1) => assign 10_002
						// i = 10_002 => (0) => assign 10_001
						// i = 10_003 => (1) => assign 10_004
						// i = 10_004 => (0) => assign 10_003

						if (i % 2 == 1) {
							assignUsers(organisation, i + 1);
						} else if (i % 2 == 0) {
							assignUsers(organisation, i - 1);
						}
					}
				}
			}
		});
		LOGGER.warn("END === Generate data FROM " + config.from + " TO " + config.to);
	}

	private void assignUsers(OrganisationEntity organisation, long... userIds) {
		for (long id : userIds) {
			ZugriffEntity item = new ZugriffEntity();
			item.setOrganisation(organisation);
			item.setAccessLevel(AccessLevelEnum.FULL);
			item.setFromDate(LocalDate.now());
			item.setStatus(AccessStatusEnum.GRANTED);
			item.setUser(findOrCreateUser(getKey(id)));
			organisation.getZugrrifs().add(item);
		}
	}

	private String getKey(long value) {
		return StringUtils.leftPad(String.valueOf(value), 6, "0");
	}
	
	private String getShortName(RechtsformEnum form) {
		switch (form) {
			case EINZELFIRMA:
				return "EF";
			case AG:
				return "AG";
			case GMBH:
				return "GMBH";
			case KOLLGES:
				return "KOLL";
			case KOMMGES:
				return "KOMM";
			default:
				return form.name();
		}
	}

	@SuppressWarnings("deprecation")
	private OrganisationEntity createOrganisation(String key, RechtsformEnum rechtsform) {
		OrganisationEntity organisation = organisationService
			.createOrganisationFromScratch("PERF " + getShortName(rechtsform) + " C" + key + "", false);
		addUserAuthorizedCompany(organisation.defaultName(), organisation);

		// Assign COD
		PflichtenabklaerungenEntity pflichtenabklaerungen = createCOD(rechtsform);
		pflichtenabklaerungen.setOrganisation(organisation);
		organisation.setPflichtenabklaerungen(pflichtenabklaerungen);

		organisation = organisationService.confirmRechsform(organisation);

		// Other information
		organisation.setDomizil(dataHelper.createAddress());
		organisation.setZweck("Performance test data " + rechtsform + " - " + key);
		organisation.setBemerkungen("Created by user U" + key);
		organisation.setBeschreibung("This organisation is generated automatically");
		organisation.setRechtsform(rechtsform);
		organisation.setEroeffnungsDatum(LocalDate.now());
		organisation.setErstrechnungsDatum(LocalDate.now());
		organisation.setErstauftragsDatum(LocalDate.now());
		organisation.setGeschaeftsjahrStart(LocalDate.now());
		organisation.setGeschaeftsjahrEnd(LocalDate.now().plusYears(5));

		organisation.setHrStatus(HRStatusEnum.NONE);
		for (SupportedLanguage language : SupportedLanguage.values()) {
			addCompanyName(organisation, language);
		}

		switch (rechtsform) {
			case AG:
			case GMBH:
			case EINZELFIRMA:
				// 1 Owner
				organisation.getGeschaeftsrollens()
					.add(dataHelper.createOwnerPerson(organisation, GeschaeftsrolleTypEnum.EDC));
				break;
			case KOMMGES:
			case KOLLGES:
				// 2 Owner
				organisation.getGeschaeftsrollens()
					.add(dataHelper.createOwnerPerson(organisation, GeschaeftsrolleTypEnum.EDC));
				organisation.getGeschaeftsrollens()
					.add(dataHelper.createOwnerPerson(organisation, GeschaeftsrolleTypEnum.EDC));
				break;
		}

		organisation.getGeschaeftsstellens().add(createOffice(organisation));
		organisation.getGeschaeftsstellens().add(createOffice(organisation));

		organisation.getBranches().addAll(cacheService.getBranches().subList(0, 3));

		// TODO [HHA] Einladungs, Zefix
		organisation.setBaseDataComplete(true);

		if (rechtsform == RechtsformEnum.KOMMGES) {
			organisation.setKommGes(createKommGes(organisation));
		}

		return organisationService.updateOrganisation(organisation);
	}

	private KommGesEntity createKommGes(OrganisationEntity organisation) {
		KommGesEntity kommGes = new KommGesEntity();
		kommGes.setOrganisation(organisation);
		kommGes.getKommFirmas().add(createKomfirma(kommGes));
		kommGes.getKommFirmas().add(createKomfirma(kommGes));
		return kommGes;
	}

	private KommFirmaEntity createKomfirma(KommGesEntity kommGes) {
		KommFirmaEntity kommFirma = new KommFirmaEntity();
		kommFirma.setKommges(kommGes);
		kommFirma.setDomizil(dataHelper.createAddress());
		kommFirma.setHaftung(BigDecimal.valueOf(1500d));
		kommFirma.setEinlage(dataHelper.getCodeWert(KategorieEnum.EINLAGE, EinlageEnum.BAR.name()));
		kommFirma.setRechtsformCH(kommGes.getOrganisation().getPflichtenabklaerungen().getRechtsform());
		kommFirma.setRechtsformAusland("Test Rechform");
		kommFirma.setName("Dummy Name");
		kommFirma.setHrNummer("999.99.999.999");
		kommFirma.setComplete(true);
		return kommFirma;
	}

	private GeschaeftsstelleEntity createOffice(OrganisationEntity organisation) {
		GeschaeftsstelleEntity office = new GeschaeftsstelleEntity();
		office.setOrganisation(organisation);
		office.setAnzAngestellte(1500);
		office.setAdresse(dataHelper.createAddress());
		return office;
	}

	private void addCompanyName(OrganisationEntity organisation, SupportedLanguage language) {
		FirmennameEntity defaultName = organisation.getNamens()
			.stream()
			.filter(name -> name.isDefault())
			.findFirst().get();
		if (defaultName.getSprache().getCode().equalsIgnoreCase(language.toString())) {
			return;
		}

		FirmennameEntity name = new FirmennameEntity();
		name.setSprache(applicationService.getCodeWerts(KategorieEnum.SPRACHE)
			.stream()
			.filter(item -> item.getCode().equalsIgnoreCase(language.name()))
			.findFirst().get()
			);
		name.setBezeichnung(defaultName.getBezeichnung() + " " + language);
		name.setOrganisation(organisation);

		organisation.getNamens().add(name);
	}

	private PflichtenabklaerungenEntity createCOD(RechtsformEnum rechtsform) {
		PflichtenabklaerungenEntity cod = new PflichtenabklaerungenEntity();
		
		cod.setRechtsform(rechtsform);
		cod.setEroeffnungsdatum(LocalDate.now());
		
		cod.setAngestellte(100);
		cod.setHandel(false);
		cod.getBranches().addAll(cacheService.getBranches().subList(0, 3));
		// cod.setDatum(LocalDateTime.now());

		// TODO [HHA] Flow history
		cod.setLocked(true);
		cod.setCompleted(true);

		if (rechtsform == RechtsformEnum.EINZELFIRMA) {
			cod.setBeruf(cacheService.getBerufs().get(0));
		}

		cod.setAnmeldungAHVBefund(AnmeldungAHVBefundEnum.AHV_ZWINGEND);
		cod.setAnmeldungMWSTBefund(AnmeldungMWSTBefundEnum.MWST_FREIWILLIG);
		cod.setAnmeldungHRBefund(AnmeldungHRBefundEnum.HR_ZWINGEND);
		cod.setAnmeldungUVGBefund(AnmeldungUVGBefundEnum.UVG_FREIWILLIG_EF_KEINE_ANG_PRIVAT);

		return portalService.save(cod);
	}

	private static class Range {
	
		private long max;
		private long size;
	
		private long from;
		private long to;
	
		public Range(long size, long max, long init) {
			this.max = max;
			this.size = size;
	
			// Initialise value
			this.to = init - 1;
		}
	
		public boolean next() {
			this.from = this.to + 1;
			this.to = this.from + this.size - 1;
			
			if (this.to > this.max) {
				this.to = this.max;
			}
	
			return hasNext();
		}
	
		private boolean hasNext() {
			return this.from <= this.max;
		}
	
		@Override
		public String toString() {
			return "From " + from + " To " + to;
		}
	}

	private static class OrganisationConfig {

		private long from;
		private long to;
		private RechtsformEnum rechtsform;
		
		public OrganisationConfig(long from, long to, RechtsformEnum rechtsform) {
			this.from = from;
			this.to = to;
			this.rechtsform = rechtsform;
		}

	}
	
}
