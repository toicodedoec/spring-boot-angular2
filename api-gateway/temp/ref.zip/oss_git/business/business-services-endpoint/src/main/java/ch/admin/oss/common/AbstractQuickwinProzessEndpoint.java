/*
 * AbstractQuickwinProzessEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author hhg
 *
 */
public abstract class AbstractQuickwinProzessEndpoint<T> extends AbstractOSSEndpoint {

	/**
	 * Return the process data.
	 * @param id Process ID
	 * @param orgId Organisation ID which the process belongs to.
	 * @return Process DTO
	 */
	@GetMapping
	public abstract ResponseEntity<T> getProzess(@RequestParam Long prozessId, @RequestParam Long orgId);

	/**
	 * Update the process data.
	 * @param dto Process DTO
	 * @return Process DTO
	 */
	@PutMapping("update")
	public abstract ResponseEntity<T> updateProzess(@RequestBody T dto);

	/**
	 * Update the process and mark as completed.
	 * @param dto Process DTO
	 * @return Process DTO
	 */
	@PutMapping("complete")
	public abstract ResponseEntity<T> completeProzess(@RequestBody T dto);

	/**
	 * Handle lock the process.
	 * @param id Process ID
	 * @param orgId Organisation ID which the process belongs to.
	 * @return Process DTO
	 */
	@GetMapping("lock")
	public abstract ResponseEntity<T> lockProzess(@RequestParam Long id, @RequestParam Integer version, @RequestParam Long orgId);

	/**
	 * Handle relock the process.
	 * @param id Process ID
	 * @param orgId Organisation ID which the process belongs to.
	 * @return Process DTO
	 */
	@GetMapping("relock")
	public abstract ResponseEntity<T> relockProzess(@RequestParam Long id, @RequestParam Integer version, @RequestParam Long orgId);

	/**
	 * Handle sign the process.
	 * @param id Process ID
	 * @param orgId Organisation ID which the process belongs to.
	 * @return Process DTO
	 */
	@GetMapping("sign")
	public abstract ResponseEntity<T> signProzess(@RequestParam Long id, @RequestParam Integer version, @RequestParam Long orgId);
	
	/**
	 * Handle interrupt the process.
	 * @param dto Process DTO
	 * @return Process DTO
	 */
	@PutMapping("interrupt")
	public abstract ResponseEntity<T> interruptProzess(@RequestBody T dto);
}
