/*
 * OSSCustomObjectMapper
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;

import ch.admin.oss.util.OSSConstants;

/**
 * @author coh
 *
 */
// we don't serialise json *mappers*
@SuppressWarnings("serial")
public class OSSCustomObjectMapper extends ObjectMapper {

    /**
     * Default constructor.
     */
    public OSSCustomObjectMapper() {
        setDateFormat(new SimpleDateFormat(OSSConstants.DATE_FORMAT));
        registerModule(new OSSCustomModule());
    }

    /**
     * Customize module for OSS.
     */
    public class OSSCustomModule extends SimpleModule {
        /**
         * Default constructor.
         */
        public OSSCustomModule() {
            super("OSSCustomModule", Version.unknownVersion());
            addDeserializer(Date.class, new OSSCustomDateDeserializer());
            
            addSerializer(Enum.class, new OSSEnumSerializer());
            addDeserializer(Enum.class, new OSSEnumDeserializer());
        }
    }
}
