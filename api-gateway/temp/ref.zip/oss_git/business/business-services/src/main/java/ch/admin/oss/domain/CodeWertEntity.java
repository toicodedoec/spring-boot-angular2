/*
 * CodeWertEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.querydsl.core.annotations.QueryProjection;

import ch.admin.oss.common.enums.KategorieEnum;

/**
 *  
 * @author coh
 */
@Entity
@Table(name = "T_CODE_WERT")
public class CodeWertEntity extends AbstractOSSEntity {

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_STANDARD_TEXT", foreignKey = @ForeignKey(name="FK_CODE_WERT_TEXT"))
	private StandardTextEntity standardText;
	
	@Column(name = "KATEGORIE")
	@Enumerated(EnumType.STRING)
	private KategorieEnum kategorie;
	
	@Column(name = "CODE")
	private String code;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PARENT", foreignKey = @ForeignKey(name = "FK_CODE_WERT_CODE_WERT"))
	private CodeWertEntity parent;
	
	@Column(name = "AKTIV", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean aktiv;
	
	@Column(name = "POS")
	private int pos;
	
	public CodeWertEntity() {
		
	}
	
	@QueryProjection
	public CodeWertEntity(Long id) {
		setId(id);
	}

	public CodeWertEntity(KategorieEnum kategorie, String code, boolean aktiv,
			int pos) {
		super();
		this.kategorie = kategorie;
		this.code = code;
		this.aktiv = aktiv;
		this.pos = pos;
	}

	public StandardTextEntity getStandardText() {
		return standardText;
	}

	public KategorieEnum getKategorie() {
		return kategorie;
	}

	public String getCode() {
		return code;
	}

	public CodeWertEntity getParent() {
		return parent;
	}

	public boolean isAktiv() {
		return aktiv;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public void setStandardText(StandardTextEntity standardText) {
		this.standardText = standardText;
	}
	
	
}
