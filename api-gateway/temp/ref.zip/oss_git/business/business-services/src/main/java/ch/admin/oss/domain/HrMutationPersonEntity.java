/*
 * HrMutationPerson
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.HrMutationPersonTypeOfChangeEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonEnum;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_HR_MUTATION_PERSON")
public class HrMutationPersonEntity extends AbstractOSSEntity {

	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "TYPE_OF_CHANGE")
	private HrMutationPersonTypeOfChangeEnum typeOfChange;
	
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "TYPE_OF_PERSON")
	private HrMutationTypeOfPersonEnum typeOfPerson;
	
	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "LN_HR_MUTATION", foreignKey = @ForeignKey(name="FK_HR_PERSON_HR_MUTATION"))
	private HrMutationEntity hrMutation;
	
	// Contains the updated personal information.
	// If a known person is modified, then newLegalPerson is a copy of (not a reference to) the known person.
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_NEW_PERSON", foreignKey = @ForeignKey(name="FK_HR_M_NEW_PERSON"))
	private GeschaftsrolleEntity newNaturalPerson;
	
	// Contains the updated information of a legal person
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_NEW_LEGAL_PERSON", foreignKey = @ForeignKey(name="FK_HR_M_NEW_LEGAL_PERSON"))
	private KommFirmaEntity newLegalPerson;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name = "LN_EXIST_PERSON", foreignKey = @ForeignKey(name="FK_HR_M_EXIST_PERSON"))
	private GeschaftsrolleEntity existingNaturalPerson;
	
	// Contains the updated information of a legal person
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.MERGE)
	@JoinColumn(name = "LN_EXIST_LEGAL_PERSON", foreignKey = @ForeignKey(name="FK_HR_M_EXIST_LEGAL_PERSON"))
	private KommFirmaEntity existingLegalPeson;

	// previous family name of a natural person
	@Column(name = "PREV_FAMILY_NAME")
	private String prevFamilyName;
	
	// previous given name of a natural person
	@Column(name = "PREV_GIVEN_NAME")
	private String prevGivenName;
	
	// previous birthday of a natural person
	@Column(name = "PREV_BIRTHDAY")
	private LocalDate prevBirthday;
	
	// previous company name of a legal person
	@Column(name = "PREV_COMPANY_NAME")
	private String prevCompanyName;
	
	// previous legal form of a legal person
	@Column(name = "PREV_LEGAL_FORM")
	private String prevLegalForm;
	
	// previous domicile city of a legal person
	@Column(name = "PREV_CITY")
	private String prevCity;

	public HrMutationPersonTypeOfChangeEnum getTypeOfChange() {
		return typeOfChange;
	}

	public void setTypeOfChange(HrMutationPersonTypeOfChangeEnum typeOfChange) {
		this.typeOfChange = typeOfChange;
	}

	public HrMutationTypeOfPersonEnum getTypeOfPerson() {
		return typeOfPerson;
	}

	public void setTypeOfPerson(HrMutationTypeOfPersonEnum typeOfPerson) {
		this.typeOfPerson = typeOfPerson;
	}

	public HrMutationEntity getHrMutation() {
		return hrMutation;
	}

	public void setHrMutation(HrMutationEntity hrMutation) {
		this.hrMutation = hrMutation;
	}

	public GeschaftsrolleEntity getNewNaturalPerson() {
		return newNaturalPerson;
	}

	public void setNewNaturalPerson(GeschaftsrolleEntity newNaturalPerson) {
		this.newNaturalPerson = newNaturalPerson;
	}

	public KommFirmaEntity getNewLegalPerson() {
		return newLegalPerson;
	}

	public void setNewLegalPerson(KommFirmaEntity newLegalPerson) {
		this.newLegalPerson = newLegalPerson;
	}

	public GeschaftsrolleEntity getExistingNaturalPerson() {
		return existingNaturalPerson;
	}

	public void setExistingNaturalPerson(GeschaftsrolleEntity existingNaturalPerson) {
		this.existingNaturalPerson = existingNaturalPerson;
	}

	public KommFirmaEntity getExistingLegalPeson() {
		return existingLegalPeson;
	}

	public void setExistingLegalPeson(KommFirmaEntity existingLegalPeson) {
		this.existingLegalPeson = existingLegalPeson;
	}

	public String getPrevFamilyName() {
		return prevFamilyName;
	}

	public void setPrevFamilyName(String prevFamilyName) {
		this.prevFamilyName = prevFamilyName;
	}

	public String getPrevGivenName() {
		return prevGivenName;
	}

	public void setPrevGivenName(String prevGivenName) {
		this.prevGivenName = prevGivenName;
	}

	public LocalDate getPrevBirthday() {
		return prevBirthday;
	}

	public void setPrevBirthday(LocalDate prevBirthday) {
		this.prevBirthday = prevBirthday;
	}

	public String getPrevCompanyName() {
		return prevCompanyName;
	}

	public void setPrevCompanyName(String prevCompanyName) {
		this.prevCompanyName = prevCompanyName;
	}

	public String getPrevLegalForm() {
		return prevLegalForm;
	}

	public void setPrevLegalForm(String prevLegalForm) {
		this.prevLegalForm = prevLegalForm;
	}

	public String getPrevCity() {
		return prevCity;
	}

	public void setPrevCity(String prevCity) {
		this.prevCity = prevCity;
	}
}
