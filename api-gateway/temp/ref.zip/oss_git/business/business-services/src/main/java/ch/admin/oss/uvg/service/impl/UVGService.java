/*
 * UVGService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.uvg.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aspose.words.Document;
import com.aspose.words.NodeType;
import com.aspose.words.SaveFormat;
import com.querydsl.core.types.dsl.PathInits;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.e_service.xmlns.startbiz_uvg._1.Adresse;
import ch.admin.e_service.xmlns.startbiz_uvg._1.AufenthaltEnum;
import ch.admin.e_service.xmlns.startbiz_uvg._1.Auslaender;
import ch.admin.e_service.xmlns.startbiz_uvg._1.Bank;
import ch.admin.e_service.xmlns.startbiz_uvg._1.Buergerort;
import ch.admin.e_service.xmlns.startbiz_uvg._1.CountryEnum;
import ch.admin.e_service.xmlns.startbiz_uvg._1.Geschaeftsstelle;
import ch.admin.e_service.xmlns.startbiz_uvg._1.HRStatusEnum;
import ch.admin.e_service.xmlns.startbiz_uvg._1.KantonEnum;
import ch.admin.e_service.xmlns.startbiz_uvg._1.Nationalitaet;
import ch.admin.e_service.xmlns.startbiz_uvg._1.NationalitaetEnum;
import ch.admin.e_service.xmlns.startbiz_uvg._1.ObjectFactory;
import ch.admin.e_service.xmlns.startbiz_uvg._1.Organisation;
import ch.admin.e_service.xmlns.startbiz_uvg._1.Person;
import ch.admin.e_service.xmlns.startbiz_uvg._1.Post;
import ch.admin.e_service.xmlns.startbiz_uvg._1.Schweizer;
import ch.admin.e_service.xmlns.startbiz_uvg._1.UVGAngaben;
import ch.admin.e_service.xmlns.startbiz_uvg._1.UVGGesellschafter;
import ch.admin.e_service.xmlns.startbiz_uvg._1.UVGZahlungsmodusEnum;
import ch.admin.oss.business.CompanyDto;
import ch.admin.oss.business.FirmennameDto;
import ch.admin.oss.business.GeschaeftsstelleDto;
import ch.admin.oss.business.GeschaftsrolleDto;
import ch.admin.oss.business.KontoDto;
import ch.admin.oss.business.UvgDto;
import ch.admin.oss.business.UvgGesellschafterDto;
import ch.admin.oss.business.UvgTemplateType;
import ch.admin.oss.common.AbstractProcessService;
import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.OssTechnicalException;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.enums.AnredeEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.GeschlechtEnum;
import ch.admin.oss.common.enums.ISO3Enum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.KontotypEnum;
import ch.admin.oss.common.enums.NatTypEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.common.enums.VersichererWunschEnum;
import ch.admin.oss.common.enums.ZahlungszweckEnum;
import ch.admin.oss.common.enums.ZivilstandEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.FirmennameEntity;
import ch.admin.oss.domain.GeschaeftsstelleEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.KontoEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QCodeWertEntity;
import ch.admin.oss.domain.QGeschaftsrolleEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QPersonEntity;
import ch.admin.oss.domain.QProzessEntity;
import ch.admin.oss.domain.QStatuswechselEntity;
import ch.admin.oss.domain.QUvgAnmeldungEntity;
import ch.admin.oss.domain.StatuswechselEntity;
import ch.admin.oss.domain.UvgAnmeldungEntity;
import ch.admin.oss.domain.VersicherungEntity;
import ch.admin.oss.enums.SupportedFileTypeDownload;
import ch.admin.oss.enums.UvgEmailTemplateType;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.IDocumentMergeCallback;
import ch.admin.oss.util.MailMessage;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OSSDateUtil;
import ch.admin.oss.util.OssAsposeUtil;
import ch.admin.oss.util.TemplateDto;
import ch.admin.oss.util.ZipUtil;
import ch.admin.oss.uvg.repository.IUvgAnmeldungRepository;
import ch.admin.oss.uvg.service.IUVGService;
import ch.ech.xmlns.ech_0090._1.Envelope;

/**
 * @author hha
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class UVGService extends AbstractProcessService<UvgAnmeldungEntity> implements IUVGService, InitializingBean {
	
	private static final String FILENAME_UVG_PDF = "uvg.pdf";
	private static final String FILENAME_UVG_XML = "uvg.xml";
	private static final String UVG_LANGUAGE_SAPARATOR = ",";
	
	@Value("${oss.uvg.email.bcc.to.datenversand}")
	private boolean bccToDatenversand;
	@Value("${suva.sedex.outbox}")
	private String sedexFolder;
	@Value("${suva.sedex.message.type}")
	private String sedexMessageType;
	@Value("${suva.sedex.address.easygov}")
	private String sedexSender;
	@Value("${suva.sedex.address.suva}")
	private String sedexReceiver;
	
	private static final QOrganisationEntity QORGANISATION = new QOrganisationEntity(
		QUvgAnmeldungEntity.uvgAnmeldungEntity.prozess.organisation.getMetadata(), PathInits.DIRECT);

	@Autowired
	private IUvgAnmeldungRepository uvgAnmeldungRepository;
	
	// TODO [COH / S9] Should consider introduce only 1 single JAXBContext for OSS across the project.
	private JAXBContext jaxbContext;

	@Override
	public UvgAnmeldungEntity createProcess(OrganisationEntity organisation) {
		UvgAnmeldungEntity entity = new UvgAnmeldungEntity();
		entity.getProzess().setOrganisation(organisation);
		if (organisation.getPflichtenabklaerungen().isAnmeldungUVG()) {
			entity.getProzess().setStatus(ProzessStatusEnum.EXTERN);
		}
		recordProcessStatusChange(entity.getProzess());
		return uvgAnmeldungRepository.save(entity);
	}

	@Override
	public UvgAnmeldungEntity getByOrganisationId(long orgId) {
		UvgAnmeldungEntity uvgAnmeldung = new JPAQuery<UvgAnmeldungEntity>(em)
				.from(QUvgAnmeldungEntity.uvgAnmeldungEntity)
				.where(QUvgAnmeldungEntity.uvgAnmeldungEntity.prozess.organisation.id.eq(orgId))
				.fetchOne();
		if (uvgAnmeldung == null) {
			return null;
		}
		jpaUtil.initialize(uvgAnmeldung,
			QUvgAnmeldungEntity.uvgAnmeldungEntity.gesellschafters.any().person,
			QUvgAnmeldungEntity.uvgAnmeldungEntity.zahlungsmodus,
			QUvgAnmeldungEntity.uvgAnmeldungEntity.kontaktAdresse,
			QUvgAnmeldungEntity.uvgAnmeldungEntity.zahlungsmodus,
			QUvgAnmeldungEntity.uvgAnmeldungEntity.zahlungsmodus.standardText.translations,
			QUvgAnmeldungEntity.uvgAnmeldungEntity.versicherer.any().standardText.translations,
			QUvgAnmeldungEntity.uvgAnmeldungEntity.prozess.statuswechsels,
			QUvgAnmeldungEntity.uvgAnmeldungEntity.prozess.flowHistory.items.any().data,
			QUvgAnmeldungEntity.uvgAnmeldungEntity.prozess.statuswechsels,
			QORGANISATION.domizil,
			QORGANISATION.geschaeftsrollens.any().person,
			QORGANISATION.geschaeftsrollens.any().person.geschlecht,
			QORGANISATION.geschaeftsrollens.any().haftung,
			QORGANISATION.geschaeftsstellens.any().adresse,
			QORGANISATION.kontens,
			QORGANISATION.branches,
			QORGANISATION.branches.any().standardText.translations,
			QORGANISATION.namens.any().sprache.standardText.translations,
			QORGANISATION.flowHistory.items.any().data
		);
		
		if(uvgAnmeldung.getKontaktAdresse() != null) {
			jpaUtil.initialize(uvgAnmeldung.getKontaktAdresse().getLand(), 
				QCodeWertEntity.codeWertEntity.standardText.translations);
		}

		if (uvgAnmeldung.getProzess().getOrganisation().getRechtsform() == RechtsformEnum.KOMMGES) {
			jpaUtil.initialize(uvgAnmeldung, 
				QORGANISATION.kommGes.kommFirmas.any().domizil,
				QORGANISATION.kommGes.kommFirmas.any().einlage.standardText.translations
			);
		}

		QPersonEntity qPerson = QPersonEntity.personEntity;
		// This is special case where we need to initial the whole geschaeftsrollens.
		uvgAnmeldung.getProzess().getOrganisation().getGeschaeftsrollens().stream().forEach(item -> {
			jpaUtil.initialize(item,
				QGeschaftsrolleEntity.geschaftsrolleEntity.haftung.standardText.translations,
				QGeschaftsrolleEntity.geschaftsrolleEntity.funktion.standardText.translations,
				QGeschaftsrolleEntity.geschaftsrolleEntity.zeichnung.standardText.translations
			);
			initPersonData(item.getPerson(), qPerson);
		});

		return uvgAnmeldung;
	}

	private void initPersonData(PersonEntity personEntity, QPersonEntity qPerson) {
		jpaUtil.initialize(personEntity, 
			qPerson.wohnadresse.land,
			qPerson.heimatortes,
			qPerson.auslaenderAusweis.standardText.translations,
			qPerson.anrede.standardText.translations,
			qPerson.zivilstand.standardText.translations,
			qPerson.nationalitaetens.any().standardText.translations
		);
		
		jpaUtil.initialize(personEntity.getWohnadresse().getLand(), QCodeWertEntity.codeWertEntity.standardText.translations);
	}

	@Override
	public UvgAnmeldungEntity updateProcess(UvgAnmeldungEntity entity) {
		processUpdated(entity.getProzess());
		return uvgAnmeldungRepository.save(entity);
	}

	@Override
	public UvgAnmeldungEntity completeProcess(UvgAnmeldungEntity entity) {
		processCompleted(entity);
		return uvgAnmeldungRepository.save(entity);
	}

	@Override
	public UvgAnmeldungEntity lockProcess(UvgAnmeldungEntity entity) {
		processLocked(entity, true);
		if (isSuva(entity)) {
			sendEmail(entity, entity.getVersicherer().stream().findFirst().orElse(null));
		} else {
			entity.getVersicherer().forEach(item -> sendEmail(entity, item));
		}
		return signProcess(entity);
	}

	private boolean isSuva(UvgAnmeldungEntity entity) {
		return entity.getProzess().getOrganisation().getBranches().stream().anyMatch(branche -> branche.isSuva());
	}

	@Override
	public UvgAnmeldungEntity signProcess(UvgAnmeldungEntity entity) {
		processSigned(entity.getProzess());
		return uvgAnmeldungRepository.save(entity);
	}

	@Override
	public UvgAnmeldungEntity relockProcess(UvgAnmeldungEntity entity) {
		throw new UnsupportedOperationException("Relock UVG process is not supported.");
	}

	@Override
	public void markProcessExternal(ProzessEntity prozess, boolean external) {
		processExternIntern(prozess, external);
	}

	@Override
	public List<AdresseEntity> getUvgKontaktAdresseByOrgId(long orgId) {
		return new JPAQuery<UvgAnmeldungEntity>(em)
			.from(QUvgAnmeldungEntity.uvgAnmeldungEntity)
			.join(QUvgAnmeldungEntity.uvgAnmeldungEntity.kontaktAdresse).fetchJoin()
			.where(QUvgAnmeldungEntity.uvgAnmeldungEntity.prozess.organisation.id.eq(orgId)
				.and(QUvgAnmeldungEntity.uvgAnmeldungEntity.kontaktAdresse.land.code.eq(OSSConstants.SWISS_CODE_WERT)))
			.fetch()
			.stream()
			.map(a -> a.getKontaktAdresse())
			.collect(Collectors.toList());		
	}
	
	@Override
	public FileDto downloadDocument(long orgId) {
		return new FileDto("uvg.pdf", SupportedFileTypeDownload.PDF, getDocument(orgId));
	}

	@Override
	public byte[] generateDocument(UvgAnmeldungEntity entity, boolean draft) {
		return this.generateDocument(entity, draft, SecurityUtil.currentUser().getLanguagePreference());
	}

	private byte[] generateDocument(UvgAnmeldungEntity entity, boolean draft, SupportedLanguage language) {
		UvgTemplateType templateType = UvgTemplateType.BASIC;
		UvgDto dto = convertEntityToDocumentDto(entity, language, templateType);
		TemplateDto<UvgDto> templateDto = new TemplateDto<>(dto, templateType.getFiles(), SaveFormat.PDF, language.name());
		if (draft) {
			templateDto.setWatermark(applicationService.getTranslation("gui_labels.hr.document.watermark", language));
		}
		return OssAsposeUtil.generateDocument(templateDto, new DocumentMergeCallback(entity));
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		jaxbContext = JAXBContext.newInstance(Organisation.class, Envelope.class);
	}

	private UvgDto convertEntityToDocumentDto(UvgAnmeldungEntity entity, SupportedLanguage language, UvgTemplateType template) {
		UvgDto dto = new UvgDto();

		ProzessEntity prozess = entity.getProzess();
		OrganisationEntity organisationEntity = prozess.getOrganisation();
		RechtsformEnum rechtsform = organisationEntity.getRechtsform();

		dto.setSuvaResponsible(isSuva(entity));
		dto.setAnmeldung(dto.isSuvaResponsible() || entity.getVersichererWunsch() == VersichererWunschEnum.CONTRACT);

		// Organisation
		CompanyDto organisation = new CompanyDto();
		dto.setOrg(organisation);
		organisation.setRechtsform(applicationService.getTranslation(organisationEntity.getRechtsform(), language));
		organisation.setRechtsformType(organisationEntity.getRechtsform().name());
		organisation.setChNr(OssNumberFormatUtil.formatChid(organisationEntity.getChNr()));
		organisation.setUid(OssNumberFormatUtil.formatUidNonCHE(organisationEntity.getUid()));
		organisation.setZweck(organisationEntity.getZweck());
		organisation.setEroeffnungsdatum(organisationEntity.getEroeffnungsDatum());
		
		AtomicInteger geschaeftsstelleCounter = new AtomicInteger(1);
		organisation.setGeschaeftsstellens(organisationEntity.getGeschaeftsstellens().stream()
			.map(item -> {
				GeschaeftsstelleDto geschaeftsstelleDto = new GeschaeftsstelleDto();
				geschaeftsstelleDto.setIndex(geschaeftsstelleCounter.getAndIncrement());
				geschaeftsstelleDto.setAdr(convertAddressToDocumentDto(item.getAdresse(), language));
				return geschaeftsstelleDto;
			})
			.collect(Collectors.toList()));

		organisation.setCombinedBranch(StringUtils.join(organisationEntity.getBranches().stream()
			.map(item -> item.getStandardText().textTranslation(language))
			.toArray(size -> new String[size]), ", "));

		organisationEntity.getNamens().stream().filter(item -> item.isDefault())
			.forEach(item -> {
				FirmennameDto firmenname = new FirmennameDto();
				organisation.setDefaultFirmenname(firmenname);
				firmenname.setBezeichnung(item.getBezeichnung());
				firmenname.setSprache(getCodeText(item.getSprache(), language));
				organisation.setName(firmenname.getBezeichnung());
			});

		// UVG
		if (StringUtils.isNotEmpty(organisationEntity.getChNr())) {
			dto.setHrEintragDone(applicationService.getTranslation("enums.JaNeinEnum.JA", language));
		} else {
			ProzessStatusEnum hrProzessStatus = getHrProzessStatus(organisationEntity.getId());
			if (hrProzessStatus == ProzessStatusEnum.GESENDET || hrProzessStatus == ProzessStatusEnum.GESCHLOSSEN) {
				dto.setHrEintragDone(applicationService.getTranslation("gui_labels.uvg.angemeldet", language));
			} else {
				dto.setHrEintragDone(applicationService.getTranslation("enums.JaNeinEnum.NEIN", language));
			}
		}
		
		dto.setKontaktName(entity.getKontaktName());
		dto.setKontaktVorname(entity.getKontaktVorname());
		dto.setKontaktAdresse(convertAddressToDocumentDto(entity.getKontaktAdresse(), language));

		if (rechtsform == RechtsformEnum.EINZELFIRMA) {
			GeschaftsrolleEntity founderEntity = organisationEntity
				.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream().findFirst().get();
			dto.setOwner(convertNaturalPersonToDocumentDto(new GeschaftsrolleDto(), language, founderEntity).setUvg(dto));
		}
		dto.setUvgInhaberFreiwillig(entity.isUvgInhaberFreiwillig());
		
		dto.setPartnerName(entity.getPartnerName());
		dto.setPartnerLohnsumme(entity.getPartnerLohnsumme());
		dto.setPartnerFreiwillig(entity.isPartnerFreiwillig());

		dto.setAngehoerigeLohnsumme(entity.getAngehoerigeLohnsumme());
		dto.setAngehoerigeAnzahl(entity.getAngehoerigeAnzahl());
		dto.setAngehoerigeFreiwillig(entity.isAngehoerigeFreiwillig());

		dto.setAngestellteLehrling(entity.isAngestellteLehrling());
		dto.setAngestellteOhneLohn(entity.isAngestellteOhneLohn());
		dto.setAngestellteAushilfe(entity.isAngestellteAushilfe());
		dto.setAngestellteGesellschafter(entity.isAngestellteGesellschafter());

		dto.setShowGesellschafter(entity.isAngestellteGesellschafter()
			&& (rechtsform == RechtsformEnum.KOLLGES || rechtsform == RechtsformEnum.KOMMGES));
		
		dto.setLohnsumme(entity.getLohnsumme());
		dto.setLohnsummeFolgejahr(entity.getLohnsummeFolgejahr());
		dto.setShowLohnsummeGeschaftsleitung(entity.isAngestellteGesellschafter()
			&& (rechtsform == RechtsformEnum.AG || rechtsform == RechtsformEnum.GMBH));
		dto.setShowVerwaltungsratshonorare(entity.isAngestellteGesellschafter()
			&& (rechtsform == RechtsformEnum.AG || rechtsform == RechtsformEnum.GMBH)
			&& entity.getVrLohnsumme() != null
			&& entity.getVrLohnsumme().compareTo(BigDecimal.ZERO) > 0);

		dto.setGlAnzahl(entity.getGlAnzahl());
		dto.setGlLohnsumme(entity.getGlLohnsumme());
		dto.setVrLohnsumme(entity.getVrLohnsumme());

		AtomicInteger gesellschafterCounter = new AtomicInteger();
		dto.setGesellschafters(entity.getGesellschafters().stream()
			.map(item -> {
				UvgGesellschafterDto gesellschafterDto = new UvgGesellschafterDto();
				gesellschafterDto.setIndex(gesellschafterCounter.incrementAndGet());
				GeschaftsrolleDto person = new GeschaftsrolleDto();
				person.setVorname(item.getPerson().getVorname());
				person.setFamilienname(item.getPerson().getFamilienname());
				gesellschafterDto.setPerson(person);
				gesellschafterDto.setLohnsumme(item.getLohnsumme());
				return gesellschafterDto;
			})
			.collect(Collectors.toList())
		);
		
		dto.setZahlungsmodus(entity.getZahlungsmodus() != null ? entity.getZahlungsmodus().getCode() : null);
		
		dto.setAhvName(entity.getAhvName());
		dto.setAhvNummer(entity.getAhvNummer());
		dto.setVersicherungName(entity.getVersicherungName());
		dto.setVersicherungNummer(entity.getVersicherungNummer());
		dto.setBemerkungen(entity.getBemerkungen());
		dto.setAngestellteHeute(entity.getAngestellteHeute());

		dto.setErsteAnstellung(entity.getErsteAnstellung());
		dto.setAngestellteZukunft(entity.getAngestellteZukunft());
		dto.setErsteAnstellungZukunft(entity.getErsteAnstellungZukunft());
		
		organisationEntity.getKontens().stream()
			.filter(item -> item.getZweck() == ZahlungszweckEnum.UVG)
			.findFirst()
			.ifPresent(item -> {
				KontoDto konto = new KontoDto();
				dto.setKonto(konto);
				
				konto.setTyp(item.getTyp().name());
				konto.setInhaber(item.getInhaber());
				konto.setOrt(item.getOrt());
				konto.setZweck(item.getZweck().name());
				konto.setKontonummer(item.getKontonummer());
				konto.setBankname(item.getBankname());
				konto.setPlz(item.getPlz());
				if(item.getLand() != null) {
					CodeWertEntity land = applicationService.getCodeWerts(KategorieEnum.LAND)
							.stream()
							.filter(cw -> cw.getCode().equals(item.getLand()))
							.findFirst().get();
					konto.setLand(land.getStandardText().getTranslations().stream().filter(text -> text.getLanguage() == language).findFirst().get().getText());
				}
				konto.setBankleitzahl(item.getBankleitzahl());
				konto.setPc(item.getPc());
			});

		StatuswechselEntity gescholssenStatus = new JPAQuery<StatuswechselEntity>(em)
			.from(QStatuswechselEntity.statuswechselEntity)
			.where(QStatuswechselEntity.statuswechselEntity.prozess.id.eq(prozess.getId())
				.and(QStatuswechselEntity.statuswechselEntity.status.eq(ProzessStatusEnum.GESCHLOSSEN)))
			.orderBy(QStatuswechselEntity.statuswechselEntity.id.desc())
			.fetchFirst();
		if (gescholssenStatus != null) {
			dto.setUvgDate(gescholssenStatus.getZeitstempel());
		}

		return dto;
	}
	
	private Organisation convertToOrganisationXMLDto(UvgAnmeldungEntity entity) {
		Organisation organisation = new Organisation();
		
		OrganisationEntity organisationEntity = entity.getProzess().getOrganisation();
		RechtsformEnum rechtsform = organisationEntity.getRechtsform();
		switch (rechtsform) {
			case AG:
				organisation.setRechtsform(ch.admin.e_service.xmlns.startbiz_uvg._1.RechtsformEnum.AG);
				break;
			case EINZELFIRMA:
				organisation.setRechtsform(ch.admin.e_service.xmlns.startbiz_uvg._1.RechtsformEnum.EF);
				break;
			case GMBH:
				organisation.setRechtsform(ch.admin.e_service.xmlns.startbiz_uvg._1.RechtsformEnum.GMBH);
				break;
			case KOLLGES:
				organisation.setRechtsform(ch.admin.e_service.xmlns.startbiz_uvg._1.RechtsformEnum.KOLGES);
				break;
			case KOMMGES:
				organisation.setRechtsform(ch.admin.e_service.xmlns.startbiz_uvg._1.RechtsformEnum.KOMGES);
				break;
			default:
				throw new IllegalArgumentException("Unknown rechtform : " + rechtsform);
		}
		
		organisation.setName(getCompanyDefaultName(entity));
		organisation.setZweck(organisationEntity.getZweck());
		organisation.setBranche(organisationEntity.getBranches().stream()
			.map(item -> item.getStandardText().textTranslation(SupportedLanguage.DE))
			.collect(Collectors.joining(", "))
		);
		
		if (rechtsform == RechtsformEnum.EINZELFIRMA) {
			organisation.setInhaber(
				convertToPersonXMLDto(organisationEntity.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream().findFirst().get())
				);
		}
		organisation.setAdresse(convertToAddressXMLDto(entity.getKontaktAdresse(), null));
		
		KontoEntity konto = organisationEntity.getKontens().stream()
			.filter(item -> item.getZweck() == ZahlungszweckEnum.UVG)
			.findFirst()
			.orElse(null);
		if (konto != null) {
			if (konto.getTyp() == KontotypEnum.BANK) {
				organisation.setBank(convertToBankXMLDto(konto));
			} else if (konto.getTyp() == KontotypEnum.POST) {
				organisation.setPost(convertToPostXMLDto(konto));
			}
		}
		organisation.setUvgAngaben(convertToUVGXMLDto(entity));
		if (organisationEntity.getHrStatus() == ch.admin.oss.common.enums.HRStatusEnum.PENDING) {
			organisation.setHrStatus(HRStatusEnum.PENDENT);
		} else if (organisationEntity.getHrStatus() == ch.admin.oss.common.enums.HRStatusEnum.REGISTERED) {
			organisation.setHrStatus(HRStatusEnum.EINGETRAGEN);
		} else {
			organisation.setHrStatus(HRStatusEnum.KEIN);
		}
		organisation.setChnr(OssNumberFormatUtil.formatChid(organisationEntity.getChNr()));
		organisation.setUid(organisationEntity.getUid());
		
		organisationEntity.getGeschaeftsstellens().stream()
			.map(item -> convertToGeschaeftsstelleXMLDto(item, entity.getKontaktAdresse().getEmpfaenger()))
			.forEach(item -> organisation.getGeschaeftsstelle().add(item));		
		return organisation;
	}
	
	private Geschaeftsstelle convertToGeschaeftsstelleXMLDto(GeschaeftsstelleEntity entity, String empfaenger) {
		if (entity == null) {
			return null;
		}
		Geschaeftsstelle geschaeftsstelle = new Geschaeftsstelle();
		geschaeftsstelle.setAdresse(convertToAddressXMLDto(entity.getAdresse(), empfaenger));
		geschaeftsstelle.setEintragInHR(entity.isInHR());
		geschaeftsstelle.setAngestellte(entity.getAnzAngestellte());
		return geschaeftsstelle;
	}

	private UVGAngaben convertToUVGXMLDto(UvgAnmeldungEntity entity) {
		if (entity == null) {
			return null;
		}
		UVGAngaben uvg = new UVGAngaben();
		uvg.setAngestellteHeute(getIntValie(entity.getAngestellteHeute()));
		uvg.setErsteAnstellung(OSSDateUtil.convertToXMLDate(entity.getErsteAnstellung()));
		uvg.setAngestellteZukunft(getIntValie(entity.getAngestellteZukunft()));
		uvg.setErsteAnstellungZukunft(OSSDateUtil.convertToXMLDate(entity.getErsteAnstellungZukunft()));
		uvg.setAngestPartner(entity.isAngestelltePartner());
		uvg.setAngestFamilie(entity.isAngestellteFamilie());
		uvg.setAngestLehrling(entity.isAngestellteLehrling());
		uvg.setAngestOhneLohn(entity.isAngestellteOhneLohn());
		uvg.setAngestAushilfe(entity.isAngestellteAushilfe());
		uvg.setAngestGesellschafter(entity.isAngestellteGesellschafter());
		uvg.setUvgInhaberFreiwillig(entity.isUvgInhaberFreiwillig());
		uvg.setLohnsumme(entity.getLohnsumme());
		uvg.setLohnsummeFolgejahr(entity.getLohnsummeFolgejahr());
		uvg.setZahlungsmodus(UVGZahlungsmodusEnum.fromValue(entity.getZahlungsmodus().getCode().toLowerCase()));
		uvg.setTaggeldAnBetrieb(entity.isTaggeldAnBetrieb());
		uvg.setAhvName(entity.getAhvName());
		uvg.setAhvNummer(entity.getAhvNummer());
		uvg.setVersicherungName(entity.getVersicherungName());
		uvg.setVersicherungNummer(entity.getVersicherungNummer());
		uvg.setBemerkungen(entity.getBemerkungen());
		uvg.setKontaktFamilienname(entity.getKontaktName());
		uvg.setKontaktVorname(entity.getKontaktVorname());
		uvg.setPartnerName(entity.getPartnerName());
		uvg.setPartnerLohnsumme(entity.getPartnerLohnsumme());
		uvg.setPartnerFreiwillig(entity.isPartnerFreiwillig());
		uvg.setSonstigeAngehoerigeLohnsumme(entity.getAngehoerigeLohnsumme());
		uvg.setSonstigeAngehoerigeAnzahl(getIntValie(entity.getAngehoerigeAnzahl()));
		uvg.setSonstigeAngehoerigeFreiwillig(entity.isAngehoerigeFreiwillig());
		uvg.setGlAnzahl(entity.getGlAnzahl());
		uvg.setGlLohnsumme(entity.getGlLohnsumme());
		uvg.setVrLohnsumme(entity.getVrLohnsumme());
		entity.getGesellschafters().stream()
			.map(item -> {
				UVGGesellschafter geschaeftsstelle = new UVGGesellschafter();
				geschaeftsstelle.setName(item.getPerson().getVorname() + " " + item.getPerson().getFamilienname());
				geschaeftsstelle.setLohnsumme(item.getLohnsumme());
				return geschaeftsstelle;
			})
			.forEach(item -> uvg.getGesellschafter().add(item));
		return uvg;
	}

	private int getIntValie(BigDecimal value) {
		return value != null ? value.intValue() : 0;
	}

	private Post convertToPostXMLDto(KontoEntity konto) {
		if (konto == null) {
			return null;
		}
		Post post = new Post();
		post.setInhaber(konto.getInhaber());
		post.setKonto(konto.getKontonummer());
		post.setOrt(konto.getOrt());
		return post;
	}

	private Bank convertToBankXMLDto(KontoEntity konto) {
		if (konto == null) {
			return null;
		}
		Bank bank = new Bank();
		bank.setBankleitzahl(konto.getBankleitzahl());
		bank.setInhaber(konto.getInhaber());
		bank.setKonto(konto.getKontonummer());
		ISO3Enum iso3 = cacheService.getLands().get(konto.getLand()).getIso3();
		bank.setLand(CountryEnum.fromValue(iso3 == null ? "Undefined" : iso3.name()));
		bank.setName(konto.getBankname());
		bank.setOrt(konto.getOrt());
		bank.setPc(konto.getPc());
		bank.setPlz(konto.getPlz());
		return bank;
	}

	private Adresse convertToAddressXMLDto(AdresseEntity entity, String empfaenger) {
		if (entity == null) {
			return null;
		}
		Adresse adresse = new Adresse();
		adresse.setEmpfaenger(empfaenger == null ? entity.getEmpfaenger() : empfaenger);
		adresse.setStrasse(entity.getStrasse());
		adresse.setHausNummer(entity.getHausnummer());
		adresse.setZusatz(entity.getZusatz());
		adresse.setPostfach(entity.getPostfach());
		adresse.setPlz(entity.getPlz());
		adresse.setOrt(entity.getOrt());
		adresse.setTelefon(entity.getTelefon());
		adresse.setMobile(entity.getMobile());
		adresse.setEmail(entity.getEmail());
		return adresse;
	}
	
	private Person convertToPersonXMLDto(GeschaftsrolleEntity entity) {
		if (entity == null) {
			return null;
		}
		Person person = new Person();
		
		PersonEntity personEntity = entity.getPerson();
		if (GeschlechtEnum.FEMALE.getCode().equals(personEntity.getGeschlecht().getCode())) {
			person.setGeschlecht(ch.admin.e_service.xmlns.startbiz_uvg._1.GeschlechtEnum.F);
		} else if (GeschlechtEnum.MALE.getCode().equals(personEntity.getGeschlecht().getCode())) {
			person.setGeschlecht(ch.admin.e_service.xmlns.startbiz_uvg._1.GeschlechtEnum.M);
		}
		
		if (AnredeEnum.MR.getCode().equals(personEntity.getAnrede().getCode())) {
			person.setAnrede(ch.admin.e_service.xmlns.startbiz_uvg._1.AnredeEnum.HERR);
		} else if (AnredeEnum.MRS.getCode().equals(personEntity.getAnrede().getCode())) {
			person.setAnrede(ch.admin.e_service.xmlns.startbiz_uvg._1.AnredeEnum.FRAU);
		} else {
			person.setAnrede(ch.admin.e_service.xmlns.startbiz_uvg._1.AnredeEnum.UNDEFINED);
		}

		person.setTitel(personEntity.getTitel());
		person.setFamilienname(personEntity.getFamilienname());
		person.setFamiliennameLedig(personEntity.getLedigname());
		person.setVorname(personEntity.getVorname());
		person.setRufname(personEntity.getRufname());
		person.setVornamenListe(personEntity.getVornamenliste());
		person.setGebDatum(OSSDateUtil.convertToXMLDate(personEntity.getGeburtsdatum()));

		if (ZivilstandEnum.LEDIG.getCode().equals(personEntity.getZivilstand().getCode())) {
			person.setZivilstand(ch.admin.e_service.xmlns.startbiz_uvg._1.ZivilstandEnum.LEDIG);
		} else if (ZivilstandEnum.VERHEIRATET.getCode().equals(personEntity.getZivilstand().getCode())) {
			person.setZivilstand(ch.admin.e_service.xmlns.startbiz_uvg._1.ZivilstandEnum.VERHEIRATET);
		} else if (ZivilstandEnum.VERWITWET.getCode().equals(personEntity.getZivilstand().getCode())) {
			person.setZivilstand(ch.admin.e_service.xmlns.startbiz_uvg._1.ZivilstandEnum.VERWITWET);
		} else if (ZivilstandEnum.GESCHIEDEN.getCode().equals(personEntity.getZivilstand().getCode())) {
			person.setZivilstand(ch.admin.e_service.xmlns.startbiz_uvg._1.ZivilstandEnum.GESCHIEDEN);
		} else if (ZivilstandEnum.GETRENNT.getCode().equals(personEntity.getZivilstand().getCode())) {
			person.setZivilstand(ch.admin.e_service.xmlns.startbiz_uvg._1.ZivilstandEnum.GETRENNT);
		} else if (ZivilstandEnum.PARTNERSCHAFT.getCode().equals(personEntity.getZivilstand().getCode())) {
			person.setZivilstand(ch.admin.e_service.xmlns.startbiz_uvg._1.ZivilstandEnum.PARTNERSCHAFT);
		} else if (ZivilstandEnum.AUFGELOEST.getCode().equals(personEntity.getZivilstand().getCode())) {
			person.setZivilstand(ch.admin.e_service.xmlns.startbiz_uvg._1.ZivilstandEnum.AUFGELOEST);
		}

		person.setNationalitaet(convertToNationalitaetXMLDto(personEntity));
		person.setAhvnummer(personEntity.getAhvNummer());

		return person;
	}
	
	private Nationalitaet convertToNationalitaetXMLDto(PersonEntity entity) {
		if (entity == null) {
			return null;
		}
		Nationalitaet nationalitaet = new Nationalitaet();
		
		switch (entity.getNatType()) {
			case CH:
				nationalitaet.setArt(NationalitaetEnum.CH);
				break;
			case CH_PLUS:
				nationalitaet.setArt(NationalitaetEnum.CH_PLUS);
				break;
			case NON_CH:
				nationalitaet.setArt(NationalitaetEnum.NON_CH);
				break;
		}

		entity.getNationalitaetens().stream()
			.map(item -> {
				return cacheService.getLands().get(item.getCode()).getIso3();
			})
			.forEach(item -> nationalitaet.getZugehoerigkeit().add(CountryEnum.fromValue(item.name())));

		if (entity.getNatType() == NatTypEnum.NON_CH) {
			Auslaender auslaender = new Auslaender();
			nationalitaet.setAuslaender(auslaender);
			// SECOOSS-270 - [UVG] Finish with SUVA - According to attachment RE OSS UVG XML mapping.msg
			if (entity.getWohnadresse().getLand().getCode() == OSSConstants.SWISS_CODE_WERT) {
				auslaender.setEinreiseDatum(OSSDateUtil.convertToXMLDate(entity.getEinreisedatum()));
				auslaender.setAufenthalt(AufenthaltEnum.fromValue(entity.getAuslaenderAusweis().getCode()));
			}		
		} else {
			Schweizer schweizer = new Schweizer();
			nationalitaet.setSchweizer(schweizer);

			entity.getHeimatortes().stream()
				.map(item -> {
					Buergerort buergerort = new Buergerort();
					buergerort.setBfsnr((short) item.getBfsnr());
					buergerort.setOrt(item.getOrt());
					buergerort.setPolGemeinde(item.getPolGemeinde());
					try {
						buergerort.setKanton(KantonEnum.fromValue(item.getKanton()));
					} catch (IllegalArgumentException e) {
						buergerort.setKanton(KantonEnum.UNDEFINED);
					}
					return buergerort;
				})
				.forEach(item -> schweizer.getHeimatort().add(item));
		}
	
		return nationalitaet;
	}

	private void sendEmail(UvgAnmeldungEntity entity, VersicherungEntity versicherung) {
		MailMessage message = new MailMessage();

		boolean isSuva = isSuva(entity);
		SupportedLanguage language = detectSendingTemplateLanguage(entity, !isSuva ? versicherung.getSprache() : null);
		UvgEmailTemplateType template;
		
		String subject;
		if (isSuva) {
			template = UvgEmailTemplateType.SUVA;
			subject = applicationService.getTranslation("gui_labels.uvg.email.subject.suva", language);
		} else if (entity.getVersichererWunsch() == VersichererWunschEnum.OFFER) {
			template = UvgEmailTemplateType.OFFER;
			subject = applicationService.getTranslation("gui_labels.uvg.email.subject.offer", language);
		} else {
			template = UvgEmailTemplateType.CONTRACT;
			subject = applicationService.getTranslation("gui_labels.uvg.email.subject.contract", language);
		}

		message.setSubject(subject);
		message.setFrom(helpdeskEmail);
		message.setTo(SecurityUtil.currentUser().getEmail());
		message.setTemplateName(template.getFilePath(language));

		message.getTemplateModel().put("datenversandEmail", StringUtils.EMPTY);
		if (versicherung != null) {
			if (bccToDatenversand) {
				message.setBcc(versicherung.getEmailDatenversand());
			} else {
				message.getTemplateModel().put("datenversandEmail", versicherung.getEmailDatenversand());
			}
		}
		message.getAttachmentDatas().put(FILENAME_UVG_PDF, generateDocument(entity, false, language));

		message.getTemplateModel().put("insuranceName",
			versicherung != null ? versicherung.getStandardText().textTranslation(language) : StringUtils.EMPTY);
		message.getTemplateModel().put("companyName", getCompanyDefaultName(entity));

		if (isSuva) {
			try {
				ObjectFactory uvgFactory = new ObjectFactory();
				JAXBElement<Organisation> xmlValue = uvgFactory.createExport(convertToOrganisationXMLDto(entity));
				message.getAttachmentDatas().put(FILENAME_UVG_XML, generateXMLFile(xmlValue).toByteArray());
			} catch (JAXBException e) {
				throw new OssTechnicalException("Error during marshaling UVG entity to Organisation data.", e);
			}

			processSedexInformation(entity,
				message.getAttachmentDatas().get(FILENAME_UVG_PDF),
				message.getAttachmentDatas().get(FILENAME_UVG_XML)
			);
		}
		mailUtil.send(message);
	}

	private void processSedexInformation(UvgAnmeldungEntity entity, byte[] pdfData, byte[] xmlData) {
		String messageID = java.util.UUID.randomUUID().toString();
		String accountName = StringUtils.replacePattern(getCompanyDefaultName(entity), "[^A-Za-z0-9]", StringUtils.EMPTY);
		String encodedAccountName = Base64.getEncoder().encodeToString(accountName.getBytes());
		
		Map<String, byte[]> dataMap = new HashMap<>(2);
		dataMap.put(encodedAccountName + ".pdf", pdfData);
		dataMap.put(encodedAccountName + ".xml", xmlData);
		
		ZipUtil.createZipFile(Paths.get(sedexFolder, "data_" + messageID + ".zip").toFile(), dataMap);
		
		try {
			FileUtils.writeByteArrayToFile(Paths.get(sedexFolder, "envl_" + messageID + ".xml").toFile(), 
				generateXMLFile(createEnvelopFile(entity, messageID)).toByteArray());
		} catch (IOException e) {
			throw new OssTechnicalException("Error during writing Envelop data.", e);
		} catch (JAXBException e) {
			throw new OssTechnicalException("Error during marshaling Envelop data.", e);
		}
		
	}
	
	private ByteArrayOutputStream generateXMLFile(Object message) throws JAXBException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		marshaller.marshal(message, baos);
		return baos;
	}

	private Envelope createEnvelopFile(UvgAnmeldungEntity entity, String msgId) {
		Envelope envelope = new Envelope();
		envelope.setMessageId(msgId);
		envelope.setMessageType(sedexMessageType);
		envelope.setMessageClass((byte) 0);
		envelope.setSenderId(sedexSender);
		envelope.setRecipientId(sedexReceiver);
		envelope.setEventDate(OSSDateUtil.getCurrentXMLDate().toString());
		envelope.setMessageDate(envelope.getEventDate());
		return envelope;
	}

	private String getCompanyDefaultName(UvgAnmeldungEntity entity) {
		FirmennameEntity firmennameEntity = entity.getProzess().getOrganisation().getNamens().stream()
			.filter(item -> item.isDefault()).findFirst().get();
		String companyName = firmennameEntity.getBezeichnung();
		return companyName;
	}

	private SupportedLanguage detectSendingTemplateLanguage(UvgAnmeldungEntity entity, String supportLanguages) {
		if (isSuva(entity) || StringUtils.isBlank(supportLanguages)) {
			return SecurityUtil.currentUser().getLanguagePreference();
		}
		return getSupportedLanguage(supportLanguages, UVG_LANGUAGE_SAPARATOR);
	}
	
	private static class DocumentMergeCallback implements IDocumentMergeCallback<UvgDto> {
		
		private UvgAnmeldungEntity uvgEntity;
		
		public DocumentMergeCallback(UvgAnmeldungEntity uvgEntity) {
			this.uvgEntity = uvgEntity;
		}

		@Override
		public void apply(Document doc, UvgDto data) throws Exception {
			RechtsformEnum rechtsform = uvgEntity.getProzess().getOrganisation().getRechtsform();
			if (rechtsform != RechtsformEnum.EINZELFIRMA) {
				OssAsposeUtil.removeEmptyBlock(doc, "owner_p", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "table_owner", NodeType.TABLE);
			}
			if (!uvgEntity.isAngestelltePartner()) {
				OssAsposeUtil.removeEmptyBlock(doc, "partner_p", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "table_partner", NodeType.TABLE);
			}
			if (!uvgEntity.isAngestellteFamilie()) {
				OssAsposeUtil.removeEmptyBlock(doc, "family_p", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "table_family", NodeType.TABLE);
			}

			boolean isBank = data.getKonto() != null && data.getKonto().getTyp() == KontotypEnum.BANK.name();
			boolean isPost = data.getKonto() != null && data.getKonto().getTyp() == KontotypEnum.POST.name();
			if (!isBank) {
				OssAsposeUtil.removeEmptyBlock(doc, "konto_bank_1", NodeType.ROW);
				OssAsposeUtil.removeEmptyBlock(doc, "konto_bank_2", NodeType.ROW);
				OssAsposeUtil.removeEmptyBlock(doc, "konto_bank_3", NodeType.ROW);
			}
			if (!isPost) {
				OssAsposeUtil.removeEmptyBlock(doc, "konto_post", NodeType.ROW);
			}
			if (!data.isShowGesellschafter()) {
				OssAsposeUtil.removeEmptyBlock(doc, "table_gesellschafter", NodeType.TABLE);
			}
			doc.getRange().getBookmarks().clear();
		}
	}

	@Override
	protected ProzessTypEnum getProcessType() {
		return ProzessTypEnum.UVG;
	}

	@Override
	public UvgAnmeldungEntity updateProcess(long orgId, UvgAnmeldungEntity entity) {
		throw new UnsupportedOperationException("Not use in UVG process");
	}
	
	private ProzessStatusEnum getHrProzessStatus(long orgId){
		return new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.organisation.id.eq(orgId)
				.and(QProzessEntity.prozessEntity.typ.eq(ProzessTypEnum.HR)))
			.select(QProzessEntity.prozessEntity.status)
			.fetchOne();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ProzessStatusEnum getProcessStatusByOrgId(long orgId) {
		return getProcessStatus(orgId);
	}
}
