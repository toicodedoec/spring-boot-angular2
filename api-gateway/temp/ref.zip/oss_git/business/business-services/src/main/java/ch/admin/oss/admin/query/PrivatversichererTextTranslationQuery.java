package ch.admin.oss.admin.query;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.admin.criteria.PrivatversichererCriteria;
import ch.admin.oss.common.enums.AktivFilterEnum;
import ch.admin.oss.domain.QStandardTextEntity;
import ch.admin.oss.domain.QTextTranslationEntity;
import ch.admin.oss.domain.QVersicherungEntity;
import ch.admin.oss.domain.VersicherungEntity;

public class PrivatversichererTextTranslationQuery extends AbstractTextTranslationQuery<PrivatversichererCriteria, VersicherungEntity> {
	
	@Override
	public JPAQuery<VersicherungEntity> buildQuery(PrivatversichererCriteria criteria, EntityManager em) {
		JPAQuery<VersicherungEntity> query = new JPAQuery<VersicherungEntity>(em)
			.from(QVersicherungEntity.versicherungEntity)
			.leftJoin(QVersicherungEntity.versicherungEntity.standardText, QStandardTextEntity.standardTextEntity)
			.join(QStandardTextEntity.standardTextEntity.translations, QTextTranslationEntity.textTranslationEntity)
			.orderBy(QVersicherungEntity.versicherungEntity.id.asc())
			.distinct();
		
		if (criteria.getStatus() == AktivFilterEnum.Unaktiv) {
			query.where(QVersicherungEntity.versicherungEntity.aktiv.eq(false));
		} else if (criteria.getStatus() == AktivFilterEnum.Aktiv) {
			query.where(QVersicherungEntity.versicherungEntity.aktiv.eq(true));
		}

		if (StringUtils.isNotBlank(criteria.getName())) {
			query.where(QTextTranslationEntity.textTranslationEntity.text.containsIgnoreCase(criteria.getName()));
		}
		
		return query;
	}
}
