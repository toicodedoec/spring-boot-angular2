package ch.admin.oss.common.dto;

import java.util.ArrayList;
import java.util.List;

public class ExistingOrgSearchResultDto {
	private List<ExistingOrgInfoDto> orgs;

	private Long totalCount;

	private Long pageSize;

	private Long pageNumber;

	public ExistingOrgSearchResultDto() {
		orgs = new ArrayList<ExistingOrgInfoDto>();
	}

	public List<ExistingOrgInfoDto> getOrgs() {
		return orgs;
	}

	public void setOrgs(List<ExistingOrgInfoDto> orgs) {
		this.orgs = orgs;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public Long getPageSize() {
		return pageSize;
	}

	public void setPageSize(Long pageSize) {
		this.pageSize = pageSize;
	}

	public Long getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Long pageNumber) {
		this.pageNumber = pageNumber;
	}

}
