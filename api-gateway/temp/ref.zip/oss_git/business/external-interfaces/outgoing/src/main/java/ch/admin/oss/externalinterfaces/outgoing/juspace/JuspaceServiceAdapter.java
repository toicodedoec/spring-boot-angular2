/*
 * JuspaceServiceAdapter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.juspace;

import java.io.StringWriter;
import java.util.UUID;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.joda.time.DateTime;
import org.opensaml.Configuration;
import org.opensaml.common.SAMLVersion;
import org.opensaml.saml2.core.Assertion;
import org.opensaml.saml2.core.Attribute;
import org.opensaml.saml2.core.AttributeStatement;
import org.opensaml.saml2.core.AttributeValue;
import org.opensaml.saml2.core.Audience;
import org.opensaml.saml2.core.AudienceRestriction;
import org.opensaml.saml2.core.AuthnContext;
import org.opensaml.saml2.core.AuthnContextClassRef;
import org.opensaml.saml2.core.AuthnStatement;
import org.opensaml.saml2.core.Conditions;
import org.opensaml.saml2.core.Issuer;
import org.opensaml.saml2.core.NameID;
import org.opensaml.saml2.core.NameIDType;
import org.opensaml.saml2.core.Response;
import org.opensaml.saml2.core.Status;
import org.opensaml.saml2.core.StatusCode;
import org.opensaml.saml2.core.Subject;
import org.opensaml.saml2.core.SubjectConfirmation;
import org.opensaml.saml2.core.SubjectConfirmationData;
import org.opensaml.saml2.core.impl.ResponseMarshaller;
import org.opensaml.xml.XMLObjectBuilder;
import org.opensaml.xml.XMLObjectBuilderFactory;
import org.opensaml.xml.io.MarshallingException;
import org.opensaml.xml.schema.XSAny;
import org.opensaml.xml.signature.Signature;
import org.opensaml.xml.util.Base64;
import org.opensaml.xml.util.XMLHelper;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Element;

import ch.admin.oss.common.OssTechnicalException;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.AuthenticationTypeEnum;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.CrDataContainerType;

/**
 * @author hhg
 *
 */
@Component
public class JuspaceServiceAdapter implements InitializingBean {
	
	@Value("${juspace.url}")
	private String juspaceUrl;
	
	@Value("${juspace.issuer}")
	private String juspaceIssuer;
	
	private JAXBContext jaxbContext;
	
	public String getJuspaceURL() {
		return juspaceUrl;
	}
	
	public String createSAMLResponse(CrDataContainerType payload) {
		XMLObjectBuilderFactory builderFactory = Configuration.getBuilderFactory();

		Response response = (Response) builderFactory
			.getBuilder(Response.DEFAULT_ELEMENT_NAME)
			.buildObject(Response.DEFAULT_ELEMENT_NAME);
		response.setID(UUID.randomUUID().toString());
		response.setVersion(SAMLVersion.VERSION_20);
		response.setIssueInstant(new DateTime());

		Issuer issuerResponse = createIssuer(builderFactory);
		response.setIssuer(issuerResponse);

		Status status = createStatusResponse(builderFactory);
		response.setStatus(status);

		Assertion assertion = createAssertion(builderFactory, payload);
		response.getAssertions().add(assertion);

		Signature signature = createSignature(builderFactory);
		response.setSignature(signature);

		try {
			Element element = new ResponseMarshaller().marshall(response);
			String samlString = XMLHelper.nodeToString(element);
			return new String(Base64.encodeBytes(samlString.getBytes()));
		} catch (MarshallingException e) {
			throw new OssTechnicalException("An technical error while marshalling the SAML response", e);
		}
	}

	private Signature createSignature(XMLObjectBuilderFactory builderFactory) {
		Signature signature = (Signature) builderFactory
			.getBuilder(Signature.DEFAULT_ELEMENT_NAME)
			.buildObject(Signature.DEFAULT_ELEMENT_NAME);
		// TODO [HHG, S9]: Check with DKE for the signature !!!
		return signature;
	}

	private Assertion createAssertion(XMLObjectBuilderFactory builderFactory, CrDataContainerType payload) {
		Assertion assertion = (Assertion) builderFactory
			.getBuilder(Assertion.DEFAULT_ELEMENT_NAME)
			.buildObject(Assertion.DEFAULT_ELEMENT_NAME);
		assertion.setID(UUID.randomUUID().toString());
		assertion.setIssueInstant(new DateTime());
		assertion.setVersion(SAMLVersion.VERSION_20);

		Issuer issuer = createIssuer(builderFactory);
		assertion.setIssuer(issuer);

		Subject subject = createSubject(builderFactory, payload);
		assertion.setSubject(subject);

		Conditions conditions = createConditions(builderFactory, assertion.getIssueInstant());
		assertion.setConditions(conditions);

		AuthnStatement authnStatement = createAuthnStatement(builderFactory, assertion.getIssueInstant());
		assertion.getAuthnStatements().add(authnStatement);
		
		AttributeStatement attributeStatement = createAttributeStatement(builderFactory, payload);
		assertion.getAttributeStatements().add(attributeStatement);

		return assertion;
	}

	@SuppressWarnings("unchecked")
	private AttributeStatement createAttributeStatement(XMLObjectBuilderFactory builderFactory, CrDataContainerType payload) {
		Attribute attribute = (Attribute) builderFactory
			.getBuilder(Attribute.DEFAULT_ELEMENT_NAME)
			.buildObject(Attribute.DEFAULT_ELEMENT_NAME);
		attribute.setName("payload");
		attribute.setFriendlyName("payload");
		attribute.setNameFormat(Attribute.URI_REFERENCE);
		
		XMLObjectBuilder<XSAny> builderAttributeValue = builderFactory.getBuilder(XSAny.TYPE_NAME);
		XSAny attributeValue = builderAttributeValue.buildObject(AttributeValue.DEFAULT_ELEMENT_NAME);
		attributeValue.setTextContent(marshalPayload(payload));
		attribute.getAttributeValues().add(attributeValue);
		
		AttributeStatement attributeStatement = (AttributeStatement) builderFactory
			.getBuilder(AttributeStatement.DEFAULT_ELEMENT_NAME)
			.buildObject(AttributeStatement.DEFAULT_ELEMENT_NAME);
		attributeStatement.getAttributes().add(attribute);
		return attributeStatement;
	}
	
	private String marshalPayload(CrDataContainerType payload) {
		try {
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			StringWriter sw = new StringWriter(); 
			jaxbMarshaller.marshal(payload, sw);
			return sw.toString();
		} catch (JAXBException e) {
			throw new OssTechnicalException("An error occurs when converting SAML payload to XML", e);
		}
	}
	
	private AuthnStatement createAuthnStatement(XMLObjectBuilderFactory builderFactory, DateTime issueInstant) {
		AuthnContextClassRef authnContextClassRef = (AuthnContextClassRef) builderFactory
			.getBuilder(AuthnContextClassRef.DEFAULT_ELEMENT_NAME)
			.buildObject(AuthnContextClassRef.DEFAULT_ELEMENT_NAME);
		authnContextClassRef.setAuthnContextClassRef(AuthnContext.PPT_AUTHN_CTX);
		
		AuthnContext authnContext = (AuthnContext) builderFactory
			.getBuilder(AuthnContext.DEFAULT_ELEMENT_NAME)
			.buildObject(AuthnContext.DEFAULT_ELEMENT_NAME);
		authnContext.setAuthnContextClassRef(authnContextClassRef);
		
		AuthnStatement authnStat = (AuthnStatement) builderFactory
			.getBuilder(AuthnStatement.DEFAULT_ELEMENT_NAME)
			.buildObject(AuthnStatement.DEFAULT_ELEMENT_NAME);
		authnStat.setAuthnInstant(issueInstant);
		authnStat.setAuthnContext(authnContext);
		return authnStat;
	}

	private Conditions createConditions(XMLObjectBuilderFactory builderFactory, DateTime issueInstant) {
		Audience audience = (Audience) builderFactory
			.getBuilder(Audience.DEFAULT_ELEMENT_NAME)
			.buildObject(Audience.DEFAULT_ELEMENT_NAME);
		audience.setAudienceURI(juspaceUrl);
		
		AudienceRestriction audienceRestric = (AudienceRestriction) builderFactory
			.getBuilder(AudienceRestriction.DEFAULT_ELEMENT_NAME)
			.buildObject(AudienceRestriction.DEFAULT_ELEMENT_NAME);
		audienceRestric.getAudiences().add(audience);
		
		Conditions conditions = (Conditions) builderFactory
			.getBuilder(Conditions.DEFAULT_ELEMENT_NAME)
			.buildObject(Conditions.DEFAULT_ELEMENT_NAME);
		conditions.setNotBefore(issueInstant.minusSeconds(5));
		conditions.setNotOnOrAfter(issueInstant.plusSeconds(500));
		conditions.getAudienceRestrictions().add(audienceRestric);
		return conditions;
	}

	private Subject createSubject(XMLObjectBuilderFactory builderFactory, CrDataContainerType payload) {
		Subject subject = (Subject) builderFactory
			.getBuilder(Subject.DEFAULT_ELEMENT_NAME)
			.buildObject(Subject.DEFAULT_ELEMENT_NAME);

		String loginValue = payload.getCrHeader().getIdentification().getAuthenticatonAttribute();
		AuthenticationTypeEnum loginType = payload.getCrHeader().getIdentification().getLoginType();
		switch (loginType) {
			case USERNAME_PASSWORD:
				subject.setNameID(createNameID(builderFactory, NameIDType.EMAIL, loginValue));
				break;
			case SUISSE_ID:
				subject.setNameID(createNameID(builderFactory, NameIDType.UNSPECIFIED, loginValue));
				break;
			default:
				throw new OssTechnicalException("Not support authentication method " + loginType);
		}

		SubjectConfirmation subjectConfirmation = createSubjectConfirmation(builderFactory);
		subject.getSubjectConfirmations().add(subjectConfirmation);
		return subject;
	}

	private SubjectConfirmation createSubjectConfirmation(XMLObjectBuilderFactory builderFactory) {
		SubjectConfirmationData subjectConfirmData = (SubjectConfirmationData) builderFactory
			.getBuilder(SubjectConfirmationData.DEFAULT_ELEMENT_NAME)
			.buildObject(SubjectConfirmationData.DEFAULT_ELEMENT_NAME);
		subjectConfirmData.setRecipient(juspaceUrl);

		SubjectConfirmation subjectConfirm = (SubjectConfirmation) builderFactory
			.getBuilder(SubjectConfirmation.DEFAULT_ELEMENT_NAME)
			.buildObject(SubjectConfirmation.DEFAULT_ELEMENT_NAME);
		subjectConfirm.setMethod(SubjectConfirmation.METHOD_BEARER);
		subjectConfirm.setSubjectConfirmationData(subjectConfirmData);
		return subjectConfirm;
	}

	private NameID createNameID(XMLObjectBuilderFactory builderFactory, String identifier, String value) {
		NameID nameId = (NameID) builderFactory
			.getBuilder(NameID.DEFAULT_ELEMENT_NAME)
			.buildObject(NameID.DEFAULT_ELEMENT_NAME);
		nameId.setValue(value);
		nameId.setFormat(identifier);
		return nameId;
	}

	private Status createStatusResponse(XMLObjectBuilderFactory builderFactory) {
		StatusCode statusCode = (StatusCode) builderFactory
			.getBuilder(StatusCode.DEFAULT_ELEMENT_NAME)
			.buildObject(StatusCode.DEFAULT_ELEMENT_NAME);
		statusCode.setValue(StatusCode.SUCCESS_URI);
		Status status = (Status) builderFactory
			.getBuilder(Status.DEFAULT_ELEMENT_NAME)
			.buildObject(Status.DEFAULT_ELEMENT_NAME);
		status.setStatusCode(statusCode);
		return status;
	}

	private Issuer createIssuer(XMLObjectBuilderFactory builderFactory) {
		Issuer issuer = (Issuer) builderFactory
			.getBuilder(Issuer.DEFAULT_ELEMENT_NAME)
			.buildObject(Issuer.DEFAULT_ELEMENT_NAME);
		issuer.setValue(juspaceIssuer);
		issuer.setFormat(NameIDType.ENTITY);
		return issuer;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		jaxbContext = JAXBContext.newInstance(CrDataContainerType.class);
	}
}
