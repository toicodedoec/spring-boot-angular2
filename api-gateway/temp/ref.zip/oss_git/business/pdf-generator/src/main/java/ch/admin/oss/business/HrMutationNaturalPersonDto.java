/*
 * HrMutationNaturalPersonDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.time.LocalDate;

/**
 * @author coh
 */
public class HrMutationNaturalPersonDto extends AbstractNaturalPersonDto {

	private HrMutationPDFDto hrMutation;
	
	private String prevFamilyName;
	private String prevGivenName;
	private LocalDate prevBirthday;
	private String einlage;
	
	public HrMutationPDFDto getHrMutation() {
		return hrMutation;
	}
	public void setHrMutation(HrMutationPDFDto hrMutation) {
		this.hrMutation = hrMutation;
	}
	public String getPrevFamilyName() {
		return prevFamilyName;
	}
	public void setPrevFamilyName(String prevFamilyName) {
		this.prevFamilyName = prevFamilyName;
	}
	public String getPrevGivenName() {
		return prevGivenName;
	}
	public void setPrevGivenName(String prevGivenName) {
		this.prevGivenName = prevGivenName;
	}
	public LocalDate getPrevBirthday() {
		return prevBirthday;
	}
	public void setPrevBirthday(LocalDate prevBirthday) {
		this.prevBirthday = prevBirthday;
	}
	public String getEinlage() {
		return einlage;
	}
	public void setEinlage(String einlage) {
		this.einlage = einlage;
	}
}
