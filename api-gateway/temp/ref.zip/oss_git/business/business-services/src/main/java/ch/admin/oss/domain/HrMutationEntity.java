/*
 * HrMutation
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;

import ch.admin.oss.common.enums.ProzessTypEnum;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_HR_MUTATION")
public class HrMutationEntity extends AbstractOSSEntity implements IProzessEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name="FK_HR_MUTATION_PROZESS"))
	private ProzessEntity prozess;
	
	// details about the persons which need to be added/updated/deleted in the commercial register
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hrMutation", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<HrMutationPersonEntity> persons = new HashSet<>();
	
	// user has chosen to modify the company name
	@Column(name = "TASK_NAME", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean taskName = false;
	
	// user has chosen to modify the domicile address
	@Column(name = "TASK_ADDRESS", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean taskAddress = false;
	
	// user has chosen to modify the company purpose
	@Column(name = "TASK_PURPOSE", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean taskPurpose = false;
	
	// user has chosen to modify persons
	@Column(name = "TASK_PERSONS", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean taskPersons = false;
	
	// user has chosen to declare the dissolution of the partnership (KollG/KommG)
	@Column(name = "TASK_DISSOLUTION", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean taskDissolution = false;
	
	// user has chosen to modify the seat of the revision body (AG/GMBH)
	@Column(name = "TASK_REVISION", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean taskRevision = false;
	
	// user has chosen to order register excerpts
	@Column(name = "TASK_EXCERPTS", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean taskExcerpts = false;

	// NULL, if the user hasn't pulled company data from ZEFIX yet
	@Column(name = "ZEFIX_UPDATE_DATE")
	private LocalDateTime zefixUpdateDate;
	
	// old company name from ZEFIX or from Organization#DefaultFirmenname
	@Column(name = "OLD_COMPANY_NAME")
	private String oldCompanyName;
	
	@Column(name = "NEW_COMPANY_NAME")
	private String newCompanyName;

	// old company purpose; from ZEFIX or from Organization#Zweck
	@Lob
	@Column(name = "OLD_PURPOSE")
	private String oldPurpose;
	
	@Lob
	@Column(name = "NEW_PURPOSE")
	private String newPurpose;
	
	// old company address from ZEFIX or a copied reference of Organization#Domizil
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_OLD_DOMICILE", foreignKey = @ForeignKey(name="FK_HR_M_OLD_DOMICILE"))
	private AdresseEntity oldDomicile;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_NEW_DOMICILE", foreignKey = @ForeignKey(name="FK_HR_M_NEW_DOMICILE"))
	private AdresseEntity newDomicile;
	
	// delivery address for excerpts
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_EXCERPTS_D_ADDRESS", foreignKey = @ForeignKey(name="FK_HR_M_D_ADDRESS"))
	private AdresseEntity excerptsDeliveryAddress;
	
	// billing address for excerpts
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_EXCERPTS_B_ADDRESS", foreignKey = @ForeignKey(name="FK_HR_M_B_ADDRESS"))
	private AdresseEntity excerptsBillingAddress;
		
	// number of notarized excerpts ordered
	@Column(name = "EXCERPTS_NUM", nullable = false)
	private int excerptsNum = 0;
	
	// number of preliminary notarized excerpts ordered
	@Column(name = "EXCERPTS_NUM_PRELIM", nullable = false)
	private int excerptsNumPrelim = 0;
	
	// given name of the leaving partner
	@Column(name = "DISSLEAVING_PARTNER_GIVENNAME")
	private String dissLeavingPartnerGivenName;
	
	// family name of the leaving partner
	@Column(name = "DISSLEAVING_PARTNER_FAMILYNAME")
	private String dissLeavingPartnerFamilyName;
	
	// birthday of the leaving partner
	@Column(name = "DISSLEAVING_PARTNER_BIRTHDAY")
	private LocalDate dissLeavingPartnerBirthday;
	
	// new owner of the remaining single proprietorship
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_DISS_NEW_OWNER", foreignKey = @ForeignKey(name="FK_HR_M_DISS_NEW_OWNER"))
	private GeschaftsrolleEntity dissNewOwner;

	// new name of the company
	@Column(name = "DISS_NEW_COMPANY_NAME")
	private String dissNewCompanyName;
	
	// company name of revision body
	@Column(name = "REV_COMPANY_NAME")
	private String revCompanyName;
	
	// previous seat of the revision body: BFS-Nr
	@Column(name = "REV_PREVIOUS_SEAT_BFSNR")
	private Integer revPreviousSeatBfsNr;
	
	// previous seat of the revision body: City (Ort)
	@Column(name = "REV_PREVIOUS_SEAT_CITY")
	private String revPreviousSeatCity;
	
	// previous seat of the revision body: Political community (Gemeinde)
	@Column(name = "REV_PREVIOUS_SEAT_POLCOMMUNITY")
	private String revPreviousSeatPolCommunity;
	
	// previous seat of the revision body: Canton (Kanton)
	@Column(name = "REV_PREVIOUS_SEAT_CANTON")
	private String revPreviousSeatCanton;
	
	// new seat of the revision body: BFS-Nr
	@Column(name = "REV_NEW_SEAT_BFSNR")
	private Integer revNewSeatBfsNr;
	
	// new seat of the revision body: City (Ort)
	@Column(name = "REV_NEW_SEAT_CITY")
	private String revNewSeatCity;
	
	// new seat of the revision body: Political community (Gemeinde)
	@Column(name = "REV_NEW_SEAT_POLCOMMUNITY")
	private String revNewSeatPolCommunity;
	
	// new seat of the revision body: Canton (Kanton)
	@Column(name = "REV_NEW_SEAT_CANTON")
	private String revNewSeatCanton;
	
	public HrMutationEntity() {
		prozess = new ProzessEntity(ProzessTypEnum.HR_MUTATION, true);
	}
	
	public HrMutationEntity(OrganisationEntity org) {
		prozess = new ProzessEntity(ProzessTypEnum.HR_MUTATION, true, org);
	}
	
	public Set<HrMutationPersonEntity> getPersons() {
		return persons;
	}

	public void setPersons(Set<HrMutationPersonEntity> persons) {
		this.persons = persons;
	}

	public boolean isTaskName() {
		return taskName;
	}

	public void setTaskName(boolean taskName) {
		this.taskName = taskName;
	}

	public boolean isTaskAddress() {
		return taskAddress;
	}

	public void setTaskAddress(boolean taskAddress) {
		this.taskAddress = taskAddress;
	}

	public boolean isTaskPurpose() {
		return taskPurpose;
	}

	public void setTaskPurpose(boolean taskPurpose) {
		this.taskPurpose = taskPurpose;
	}

	public boolean isTaskPersons() {
		return taskPersons;
	}

	public void setTaskPersons(boolean taskPersons) {
		this.taskPersons = taskPersons;
	}

	public boolean isTaskDissolution() {
		return taskDissolution;
	}

	public void setTaskDissolution(boolean taskDissolution) {
		this.taskDissolution = taskDissolution;
	}

	public boolean isTaskRevision() {
		return taskRevision;
	}

	public void setTaskRevision(boolean taskRevision) {
		this.taskRevision = taskRevision;
	}

	public boolean isTaskExcerpts() {
		return taskExcerpts;
	}

	public void setTaskExcerpts(boolean taskExcerpts) {
		this.taskExcerpts = taskExcerpts;
	}

	public LocalDateTime getZefixUpdateDate() {
		return zefixUpdateDate;
	}

	public void setZefixUpdateDate(LocalDateTime zefixUpdateDate) {
		this.zefixUpdateDate = zefixUpdateDate;
	}

	public String getOldCompanyName() {
		return oldCompanyName;
	}

	public void setOldCompanyName(String oldCompanyName) {
		this.oldCompanyName = oldCompanyName;
	}

	public String getNewCompanyName() {
		return newCompanyName;
	}

	public void setNewCompanyName(String newCompanyName) {
		this.newCompanyName = newCompanyName;
	}

	public String getOldPurpose() {
		return oldPurpose;
	}

	public void setOldPurpose(String oldPurpose) {
		this.oldPurpose = oldPurpose;
	}

	public String getNewPurpose() {
		return newPurpose;
	}

	public void setNewPurpose(String newPurpose) {
		this.newPurpose = newPurpose;
	}

	public AdresseEntity getOldDomicile() {
		return oldDomicile;
	}

	public void setOldDomicile(AdresseEntity oldDomicile) {
		this.oldDomicile = oldDomicile;
	}

	public AdresseEntity getNewDomicile() {
		return newDomicile;
	}

	public void setNewDomicile(AdresseEntity newDomicile) {
		this.newDomicile = newDomicile;
	}

	public AdresseEntity getExcerptsDeliveryAddress() {
		return excerptsDeliveryAddress;
	}

	public void setExcerptsDeliveryAddress(AdresseEntity excerptsDeliveryAddress) {
		this.excerptsDeliveryAddress = excerptsDeliveryAddress;
	}

	public AdresseEntity getExcerptsBillingAddress() {
		return excerptsBillingAddress;
	}

	public void setExcerptsBillingAddress(AdresseEntity excerptsBillingAddress) {
		this.excerptsBillingAddress = excerptsBillingAddress;
	}

	public int getExcerptsNum() {
		return excerptsNum;
	}

	public void setExcerptsNum(int excerptsNum) {
		this.excerptsNum = excerptsNum;
	}

	public int getExcerptsNumPrelim() {
		return excerptsNumPrelim;
	}

	public void setExcerptsNumPrelim(int excerptsNumPrelim) {
		this.excerptsNumPrelim = excerptsNumPrelim;
	}

	public String getDissLeavingPartnerGivenName() {
		return dissLeavingPartnerGivenName;
	}

	public void setDissLeavingPartnerGivenName(String dissLeavingPartnerGivenName) {
		this.dissLeavingPartnerGivenName = dissLeavingPartnerGivenName;
	}

	public String getDissLeavingPartnerFamilyName() {
		return dissLeavingPartnerFamilyName;
	}

	public void setDissLeavingPartnerFamilyName(String dissLeavingPartnerFamilyName) {
		this.dissLeavingPartnerFamilyName = dissLeavingPartnerFamilyName;
	}

	public LocalDate getDissLeavingPartnerBirthday() {
		return dissLeavingPartnerBirthday;
	}

	public void setDissLeavingPartnerBirthday(LocalDate dissLeavingPartnerBirthday) {
		this.dissLeavingPartnerBirthday = dissLeavingPartnerBirthday;
	}

	public GeschaftsrolleEntity getDissNewOwner() {
		return dissNewOwner;
	}

	public void setDissNewOwner(GeschaftsrolleEntity dissNewOwner) {
		this.dissNewOwner = dissNewOwner;
	}

	public String getDissNewCompanyName() {
		return dissNewCompanyName;
	}

	public void setDissNewCompanyName(String dissNewCompanyName) {
		this.dissNewCompanyName = dissNewCompanyName;
	}

	public String getRevCompanyName() {
		return revCompanyName;
	}

	public void setRevCompanyName(String revCompanyName) {
		this.revCompanyName = revCompanyName;
	}

	public Integer getRevPreviousSeatBfsNr() {
		return revPreviousSeatBfsNr;
	}

	public void setRevPreviousSeatBfsNr(Integer revPreviousSeatBfsNr) {
		this.revPreviousSeatBfsNr = revPreviousSeatBfsNr;
	}

	public String getRevPreviousSeatCity() {
		return revPreviousSeatCity;
	}

	public void setRevPreviousSeatCity(String revPreviousSeatCity) {
		this.revPreviousSeatCity = revPreviousSeatCity;
	}

	public String getRevPreviousSeatPolCommunity() {
		return revPreviousSeatPolCommunity;
	}

	public void setRevPreviousSeatPolCommunity(String revPreviousSeatPolCommunity) {
		this.revPreviousSeatPolCommunity = revPreviousSeatPolCommunity;
	}

	public String getRevPreviousSeatCanton() {
		return revPreviousSeatCanton;
	}

	public void setRevPreviousSeatCanton(String revPreviousSeatCanton) {
		this.revPreviousSeatCanton = revPreviousSeatCanton;
	}

	public Integer getRevNewSeatBfsNr() {
		return revNewSeatBfsNr;
	}

	public void setRevNewSeatBfsNr(Integer revNewSeatBfsNr) {
		this.revNewSeatBfsNr = revNewSeatBfsNr;
	}

	public String getRevNewSeatCity() {
		return revNewSeatCity;
	}

	public void setRevNewSeatCity(String revNewSeatCity) {
		this.revNewSeatCity = revNewSeatCity;
	}

	public String getRevNewSeatPolCommunity() {
		return revNewSeatPolCommunity;
	}

	public void setRevNewSeatPolCommunity(String revNewSeatPolCommunity) {
		this.revNewSeatPolCommunity = revNewSeatPolCommunity;
	}

	public String getRevNewSeatCanton() {
		return revNewSeatCanton;
	}

	public void setRevNewSeatCanton(String revNewSeatCanton) {
		this.revNewSeatCanton = revNewSeatCanton;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	@Override
	public ProzessEntity getProzess() {
		return prozess;
	}
}
