/*
 * MigrationService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.application.service.impl;

import java.io.StringReader;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.common.jaxb.JAXBUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.ahv.repository.IAhvAnmeldungRepository;
import ch.admin.oss.ahv.repository.IAhvFilialeRepository;
import ch.admin.oss.ahv.repository.IAhvTeilhaberRepository;
import ch.admin.oss.ahv.repository.IKontoRepository;
import ch.admin.oss.application.repository.IFlowHistoryRepository;
import ch.admin.oss.application.repository.IStartBizDataRepository;
import ch.admin.oss.application.service.IMigrationService;
import ch.admin.oss.common.AbstractOSSService;
import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.OssTechnicalException;
import ch.admin.oss.common.enums.AccessLevelEnum;
import ch.admin.oss.common.enums.AccessStatusEnum;
import ch.admin.oss.common.enums.AhvGruendungsartEnum;
import ch.admin.oss.common.enums.AhvMitarbeitEnum;
import ch.admin.oss.common.enums.AhvNamenEnum;
import ch.admin.oss.common.enums.AhvUebernahmeEnum;
import ch.admin.oss.common.enums.AhvVerbandszugehoerigkeitEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.KontotypEnum;
import ch.admin.oss.common.enums.NatTypEnum;
import ch.admin.oss.common.enums.OrganisationCreationTypeEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.VersichererWunschEnum;
import ch.admin.oss.common.enums.ZahlungszweckEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.AhvAnmeldungEntity;
import ch.admin.oss.domain.AhvFilialeEntity;
import ch.admin.oss.domain.AhvTeilhaberEntity;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.FirmennameEntity;
import ch.admin.oss.domain.FlowHistoryEntity;
import ch.admin.oss.domain.GeschaeftsstelleEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrAnmeldungEntity;
import ch.admin.oss.domain.HrGruenderEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.KommGesEntity;
import ch.admin.oss.domain.KontoEntity;
import ch.admin.oss.domain.LandEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PersonHeimatortEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QCHOrtEntity;
import ch.admin.oss.domain.StartBizDataEntity;
import ch.admin.oss.domain.StatuswechselEntity;
import ch.admin.oss.domain.TextTranslationEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.UvgAnmeldungEntity;
import ch.admin.oss.domain.UvgGesellschafterEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.exception.BfsNrNotFoundException;
import ch.admin.oss.hr.repository.IHrAnmeldungRepository;
import ch.admin.oss.hr.repository.IHrGruenderRepository;
import ch.admin.oss.organisation.repository.IAdresseRepository;
import ch.admin.oss.organisation.repository.IGeschaeftsstelleRepository;
import ch.admin.oss.organisation.repository.IGeschaftsrolleRepository;
import ch.admin.oss.organisation.repository.IKommFirmaRepository;
import ch.admin.oss.organisation.repository.IKommGesRepository;
import ch.admin.oss.organisation.repository.IOrganisationRepository;
import ch.admin.oss.organisation.repository.IPersonHeimatortRepository;
import ch.admin.oss.organisation.repository.IPersonRepository;
import ch.admin.oss.organisation.repository.IPflichtenabklaerungenRepository;
import ch.admin.oss.portal.repository.IProzessRepository;
import ch.admin.oss.portal.repository.IUserRepository;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.DataUtil;
import ch.admin.oss.util.NumberUtil;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OSSDateUtil;
import ch.admin.oss.uvg.repository.IUvgAnmeldungRepository;
import ch.admin.oss.uvg.repository.IUvgGesellschafterRepository;
import generated.Abklaerung;
import generated.AdressRef;
import generated.AdressZweckEnum;
import generated.Adresse;
import generated.Ahv;
import generated.AhvAngestellteLohn;
import generated.AhvArbOrgAuftritt;
import generated.AhvBisher;
import generated.AhvEF;
import generated.AhvEinkommen;
import generated.AhvInvestitionen;
import generated.AhvKG;
import generated.AhvKapital;
import generated.AhvLasten;
import generated.AhvMitarbeit;
import generated.AhvPG;
import generated.AhvPGTeilhaberdaten;
import generated.AhvPartner;
import generated.AhvRaeumlichkeiten;
import generated.AhvTaetigkeit;
import generated.AngestelltenEnum;
import generated.AnredeEnum;
import generated.Bank;
import generated.Buergerort;
import generated.CountryEnum;
import generated.EinlageArtEnum;
import generated.Funktion;
import generated.Geschaeftsstelle;
import generated.GeschlechtEnum;
import generated.GruenderAGType;
import generated.GruenderGmbHType;
import generated.GruenderType;
import generated.HrAnmeldungAG;
import generated.HrAnmeldungGmbH;
import generated.HrAnmeldungKg;
import generated.KomFirma;
import generated.Kommanditgesellschaft.KomFirmen;
import generated.NameValuePair;
import generated.NationalitaetEnum;
import generated.Organisation;
import generated.Person;
import generated.Post;
import generated.RechtsformEnum;
import generated.RestriktionEnum;
import generated.UVGAngaben;
import generated.UVGGesellschafter;
import generated.UVGZahlungsmodusEnum;
import generated.UmsatzKategorienEnum;
import generated.Userdata;
import generated.VersicherungsauswahlEnum;
import generated.ZivilstandEnum;

/**
 * @author hhg
 *
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class MigrationService extends AbstractOSSService implements IMigrationService, InitializingBean {

	@Autowired
	private IAdresseRepository adresseRepo;

	@Autowired
	private IPersonRepository personRepo;

	@Autowired
	private IOrganisationRepository orgRepo;

	@Autowired
	private IKommGesRepository kommgesRepo;

	@Autowired
	private IKommFirmaRepository kommFirmaRepo;

	@Autowired
	private IPersonHeimatortRepository heimatortRepo;

	@Autowired
	private IGeschaftsrolleRepository geschaftsolleRepo;
	
	@Autowired
	private IGeschaeftsstelleRepository geschaeftsstelleRepo;

	@Autowired
	private IPflichtenabklaerungenRepository pflichRepository;
	
	@Autowired
	private IHrAnmeldungRepository hrRepository;
	
	@Autowired
	private IHrGruenderRepository hrGruenderRepository;

	@Autowired
	private IUvgAnmeldungRepository uvgAnmeldungRepo;

	@Autowired
	private IUvgGesellschafterRepository uvgGesellschafterRepo;
	
	@Autowired
	private IAhvAnmeldungRepository ahvAnmeldungRepo;
	
	@Autowired
	private IAhvFilialeRepository ahvFilialeRepo;
	
	@Autowired
	private IAhvTeilhaberRepository ahvTeilhaberRepo;
	
	@Autowired
	private IProzessRepository processRepo;
	
	@Autowired
	private IKontoRepository kontoRepo;
	
	@Autowired
	private IStartBizDataRepository startBizRepo;
	
	@Autowired
	private IFlowHistoryRepository flowHistoryRepo;
	
	@Autowired
	private IUserRepository userRepo;
	
	private JAXBContext jaxbContext;
	
	private static final String STARTBIZ_DATE_FORMAT = "yyyy-MM-dd";
	private static final String STARTBIZ_DATE_SAPARATOR = " ";

	private static final DateTimeFormatter DATE_STARTBIZ_FORMATTER = new DateTimeFormatterBuilder()
			.appendPattern(STARTBIZ_DATE_FORMAT)
			.toFormatter();

	/**
	 * DateTimeFormatter for yyyy.MM.dd
	 */
	private static final DateTimeFormatter PROZESS_STARTBIZ_FORMATTER = new DateTimeFormatterBuilder()
			.appendPattern("yyyy.MM.dd")
		.toFormatter();

	private static final String UVGINTERVALL_SEMESTER_CODE = "Semester";
	private static final String UVGINTERVALL_QUARTAL_CODE = "Quartal";
	private static final String UVGINTERVALL_JAHR_CODE = "Jahr";

	private static final String ZIVILSTAND_AUFGELOEST_CODE = "7";
	private static final String ZIVILSTAND_PARTNERSCHAFT_CODE = "6";
	private static final String ZIVILSTAND_GETRENNT_CODE = "5";
	private static final String ZIVILSTAND_GESCHIEDEN_CODE = "4";
	private static final String ZIVILSTAND_VERWITWET_CODE = "3";
	private static final String ZIVILSTAND_VERHEIRATET_CODE = "2";
	private static final String ZIVILSTAND_LEDIG_CODE = "1";

	private static final String HR_DECL_VARIABLE_KEY = "STATE:HR_DECL_SELF";
	private static final String AHV_DECL_VARIABLE_KEY = "STATE:HR_DECL_SELF";
	private static final String MWST_DECL_VARIABLE_KEY = "STATE:HR_DECL_SELF";
	private static final String UVG_DECL_VARIABLE_KEY = "STATE:HR_DECL_SELF";
	private static final String DECMOD_LOCKED_VARIABLE_KEY = "STATE:DECMOD_LOCKED";
	private static final String DECMOD_COMPLETED_VARIABLE_KEY = "STATE:DECMOD_COMPLETED";

	private static final String LAST_DOSSIER_UPDATE_VARIABLE_KEY = "Sys:LAST_DOSSIER_UPDATE";
	private static final String HR_TRANSLATE_VARIABLE_KEY = "Sys:HRtranslate";
	private static final String HR_RANZAHL_NORM_VARIABLE_KEY = "Sys:HRanzahlNorm";
	private static final String HR_RANZAHL_VOR_VARIABLE_KEY = "Sys:HRanzahlVor";

	private static final String HR_DATE_VARIABLE_KEY = "STATE:HR_DATE";
	private static final String AHV_DATE_VARIABLE_KEY = "STATE:AHV_DATE";
	private static final String UVG_DATE_VARIABLE_KEY = "STATE:UVG_DATE";
	
	private static final String EINLAGE_SACH_CODE = "SACH";
	private static final String EINLAGE_BAR_CODE = "BAR";

	private static final String HAFTUNG_UNBESCHRAENKT_CODE = "UNBESCHRAENKT";
	private static final String HAFTUNG_BESCHRAENKT_CODE = "BESCHRAENKT";
	
	private static final LocalDateTime EPOCH_DATE = LocalDateTime.ofInstant(Instant.ofEpochMilli(0l), ZoneId.systemDefault());
	
	private LocalDate fomartDateLastUpdateDossier(String date) {
		if(date == null) {
			return null;
		}
		return LocalDate.parse(StringUtils.split(date, STARTBIZ_DATE_SAPARATOR)[0], DATE_STARTBIZ_FORMATTER);
	}

	private LocalDateTime convertProcessDate(String startBizProzessDate) {
		if(startBizProzessDate == null) {
			return null;
		}
		return LocalDate.parse(startBizProzessDate, PROZESS_STARTBIZ_FORMATTER).atStartOfDay();
	}

	@Override
	public ZugriffEntity migrateStartBizDataToEasyGov(StartBizDataEntity startBizData) {

		Userdata userdata = convertToUserData(startBizData.getData());
		
		Map<String, AdresseEntity> adresseMap = migrateStartBizDataToAddress(userdata);

		Map<String, PersonEntity> personMap = migrateStartBizDataToPerson(userdata, adresseMap);

		OrganisationEntity organisation = migrateStartBizDataToOrganisation(startBizData.getId(), userdata, adresseMap, personMap);
		
		migrateStartBizDataToPflichtenabklaerungen(userdata, organisation);

		Map<String, GeschaeftsstelleEntity> geschaeftsstelleMap = migrateStartBizDataToGeschaeftsstelle(userdata, organisation, adresseMap);

		migrateStartBizDataToKonto(userdata, organisation);
		
		migrateStartBizDataToUvg(userdata, adresseMap, personMap, organisation);

		migrateStartBizDataToAhv(userdata, adresseMap, personMap, geschaeftsstelleMap, organisation);

		migrateStartBizDataToHrAnmeldung(userdata, personMap, organisation);
	
		startBizData.setOrganisation(organisation);
		startBizRepo.save(startBizData);
		
		ZugriffEntity zugriff = new ZugriffEntity();
		zugriff.setUser(userRepo.findOne(SecurityUtil.currentUser().getUserId()));
		zugriff.setAccessLevel(AccessLevelEnum.FULL);
		zugriff.setOrganisation(organisation);
		zugriff.setStatus(AccessStatusEnum.GRANTED);
		zugriff.setFromDate(LocalDate.now());
		organisation.getZugrrifs().add(zugriff);
		
		return zugriff;
	}
	
	private void migrateStartBizDataToKonto(Userdata userdata, OrganisationEntity organisation) {
		for(Bank b : getStartBizOrgData(userdata).getBank()) {
			KontoEntity ent = new KontoEntity();
			ent.setTyp(KontotypEnum.BANK);
			ent.setInhaber(b.getInhaber());
			ent.setBankname(b.getName());
			ent.setPlz(b.getPlz());
			ent.setOrt(b.getOrt());
			if(b.getLand() != null) {
				CodeWertEntity land = findLandByIsoCode3(b.getLand().name());
				ent.setLand(land == null ? null : land.getCode());
			}
			ent.setBankleitzahl(b.getBankleitzahl());
			ent.setKontonummer(b.getKonto());
			ent.setPc(b.getPc());
			ent.setZweck(convertToZahlungszweck(b.getZweck()));
			ent.setOrganisation(organisation);
			organisation.getKontens().add(ent);
			kontoRepo.save(ent);
		}
				
		for(Post p: getStartBizOrgData(userdata).getPost()) {
			KontoEntity ent = new KontoEntity();
			ent.setTyp(KontotypEnum.POST);
			ent.setInhaber(p.getInhaber());
			ent.setOrt(p.getOrt());
			ent.setKontonummer(p.getKonto());
			ent.setZweck(convertToZahlungszweck(p.getZweck()));
			ent.setOrganisation(organisation);
			organisation.getKontens().add(ent);
			kontoRepo.save(ent);
		}
	}

	private ZahlungszweckEnum convertToZahlungszweck(generated.ZahlungszweckEnum zweck) {
		if(zweck == null) {
			return null;
		}
		switch(zweck) {
		case AHV:
			return ZahlungszweckEnum.AHV;
		case HR:
			return ZahlungszweckEnum.HR;
		case MWST:
			return ZahlungszweckEnum.MWST;
		case UVG:
			return ZahlungszweckEnum.UVG;
		default:
			throw new IllegalArgumentException("Unkown generated.ZahlungszweckEnum : " + zweck);		
		}
	}

	private void migrateStartBizDataToHrAnmeldung(Userdata userdata, Map<String, PersonEntity> personMap, OrganisationEntity org) {
		switch(userdata.getDossier().getRechtsform()) {
			case AG:
				HrAnmeldungAG hrAg = userdata.getDossier().getAktiengesellschaft().getHr();
				if (hrAg != null) {
					HrAnmeldungEntity hr = initialzeHrAnmeldung(hrAg, userdata, org);
					hr.setAktienkapital(NumberUtil.getIntegerValue(hrAg.getAktienKapital()));
					hr.setLiberierungsumfang(NumberUtil.getIntegerValue(hrAg.getLiberierungsUmfang()));
					hr.setNamensaktien(NumberUtil.getIntegerValue(hrAg.getAnzahlNamensaktien()));
					hr.setInhaberaktien(NumberUtil.getIntegerValue(hrAg.getAnzahlInhaberaktien()));
					hr = hrRepository.save(hr);
					for (GruenderAGType gruender : hrAg.getGruender()) {
						HrGruenderEntity hrGruender = initializeHrGruender(personMap, hr, gruender);
						hrGruender.setAnzInhaberaktien(NumberUtil.getIntegerValue(gruender.getAnzInhaberaktien()));
						hrGruender.setAnzNamensaktien(NumberUtil.getIntegerValue(gruender.getAnzNamensaktien()));
						hrGruenderRepository.save(hrGruender);
					}
				} else {
					createNewHrProcess(org);
				}
				break;
			case GMBH:
				HrAnmeldungGmbH hrGmbh = userdata.getDossier().getGmbh().getHr();
				if (hrGmbh != null) {
					HrAnmeldungEntity hr = initialzeHrAnmeldung(hrGmbh, userdata, org);
					hr.setStammanteile(NumberUtil.getIntegerValue(hrGmbh.getAnzahlStammanteile()));
					hr.setStammkapital(NumberUtil.getIntegerValue(hrGmbh.getStammKapital()));
					hr = hrRepository.save(hr);
					for (GruenderGmbHType gruender : hrGmbh.getGruender()) {
						HrGruenderEntity hrGruender = initializeHrGruender(personMap, hr, gruender);
						hrGruender.setAnzStammanteile(NumberUtil.getIntegerValue(gruender.getAnzStammanteile()));
						hrGruenderRepository.save(hrGruender);
					}
				} else {
					createNewHrProcess(org);
				}
				break;
			case EF:
			case KOLGES:
			case KOMGES:
				createNewHrProcess(org);
				break;
			default:
				throw new IllegalArgumentException("Unknown RechtsformEnum: " + userdata.getDossier().getRechtsform());
		}
	}

	private void createNewHrProcess(OrganisationEntity org) {
		HrAnmeldungEntity hr = new HrAnmeldungEntity(org);
		ProzessEntity prozess = hr.getProzess();
		prozess.getStatuswechsels().add(initializeProcessStatus(prozess, LocalDateTime.now()));
		hrRepository.save(hr);
	}

	private void createNewAhvProcess(OrganisationEntity org) {
		AhvAnmeldungEntity ahv = new AhvAnmeldungEntity(org);
		ProzessEntity prozess = ahv.getProzess();
		prozess.getStatuswechsels().add(initializeProcessStatus(prozess, LocalDateTime.now()));
		ahvAnmeldungRepo.save(ahv);
	}

	private void createNewUvgProcess(OrganisationEntity org) {
		UvgAnmeldungEntity uvg = new UvgAnmeldungEntity(org);
		ProzessEntity prozess = uvg.getProzess();
		prozess.getStatuswechsels().add(initializeProcessStatus(prozess, LocalDateTime.now()));
		uvgAnmeldungRepo.save(uvg);
	}

	private HrGruenderEntity initializeHrGruender(Map<String, PersonEntity> personMap, HrAnmeldungEntity hr,
		GruenderType gruender) {
		HrGruenderEntity hrGruender = new HrGruenderEntity();
		hrGruender.setHrAnmeldung(hr);
		hrGruender.setPerson(personMap.get(getPersonStartBizRef(gruender.getRef())));
		hrGruender.setFunktion(findCodeWertByCategoryAndCode(KategorieEnum.FUNKTION, gruender.getBezeichnung().name()));
		hrGruender.setZeichnung(findCodeWertByCategoryAndCode(KategorieEnum.ZEICHNUNG, gruender.getZb().name()));
		hrGruender.setNurHauptsitz(gruender.getRestriktion() == RestriktionEnum.BESCHRAENKT_AUF_HAUPTSITZ);
		hrGruender.setComplete(gruender.isDatacomplete());
		return hrGruender;
	}

	private HrAnmeldungEntity initialzeHrAnmeldung(HrAnmeldungKg startBizHrData, Userdata userdata, OrganisationEntity org) {
		ProzessEntity prozess = initializeProcess(userdata, org, ProzessTypEnum.HR, HR_DATE_VARIABLE_KEY);

		HrAnmeldungEntity hr = new HrAnmeldungEntity();
		hr.setProzess(prozess);
		hr.setElektronisch(startBizHrData.isElektronischeGruendung());
		hr.setBargruendung(startBizHrData.isBargruendung());
		hr.setFinanzBemerkungen(startBizHrData.getFinanzBemerkungen());
		if (startBizHrData.getNotar() != null) {
			hr.setBemerkungen(startBizHrData.getNotarBemerkungen());
			hr.setNotarAnrede(findAdrede(startBizHrData.getNotar().getAnrede()));
			hr.setNotarTitel(startBizHrData.getNotar().getTitel());
			hr.setNotarName(startBizHrData.getNotar().getFamilienname());
			hr.setNotarVorname(startBizHrData.getNotar().getVorname());
			hr.setNotarPostadresse(startBizHrData.getNotar().getPostadresse());
			hr.setNotarFunktion(startBizHrData.getNotar().getFunktion());
			hr.setNotarTelefon(startBizHrData.getNotar().getTelefon());			
			hr.setNotarEmail(startBizHrData.getNotar().getEmail());
			hr.setNotarFax(startBizHrData.getNotar().getFax());
			hr.setNotarUpRegUUID(startBizHrData.getNotar().getUpRegUUID());
			hr.setNotarKanton(startBizHrData.getNotar().getKanton());
		}
		hr.setTranslate(getBooleanValue(userdata.getDossier().getVar(), HR_TRANSLATE_VARIABLE_KEY));
		hr.setAuszuege(getIntegerValue(userdata.getDossier().getVar(), HR_RANZAHL_NORM_VARIABLE_KEY));
		hr.setAuszuegeVor(getIntegerValue(userdata.getDossier().getVar(), HR_RANZAHL_VOR_VARIABLE_KEY));
		return hr;
	}

	private void migrateStartBizDataToAhv(Userdata userdata, Map<String, AdresseEntity> adresseMap,
		Map<String, PersonEntity> personMap, Map<String, GeschaeftsstelleEntity> geschaeftsstelleMap, OrganisationEntity org) {
		Ahv ahv = getStartBizAhvData(userdata);
		if(ahv != null) {
			AhvAnmeldungEntity ahvAnmeldung = migrateToAhvAnmeldung(userdata, adresseMap, personMap, org, ahv);
			List<AhvTeilhaberEntity> ahvTeilhabers = migrateToAhvTeilhaber(userdata, personMap, ahvAnmeldung, org, ahv);
			if (CollectionUtils.isNotEmpty(ahvTeilhabers)) {
				ahvAnmeldung.getAhvTeilhabers().addAll(ahvTeilhabers);
			}
			List<AhvFilialeEntity> ahvFiliales = migrateToAhvFiliale(geschaeftsstelleMap, ahvAnmeldung, ahv);
			if (CollectionUtils.isNotEmpty(ahvFiliales)) {
				ahvAnmeldung.getAhvFiliales().addAll(ahvFiliales);
			}
		} else {
			createNewAhvProcess(org);
		}
	}

	private List<AhvFilialeEntity> migrateToAhvFiliale(Map<String, GeschaeftsstelleEntity> geschaeftsstelleMap, AhvAnmeldungEntity ahvAnmeldung, Ahv ahv) {
		List<AhvFilialeEntity> entities = new ArrayList<>();
		ahv.getFilialen().stream().forEach(fil -> {
			if (fil.getAdrref() != null) {
				String idRef = ((Adresse)fil.getAdrref()).getId();
				if (idRef != null) {
					GeschaeftsstelleEntity geschaeftsstelle = geschaeftsstelleMap.get(idRef);
					if (geschaeftsstelle != null) {
						AhvFilialeEntity ent = new AhvFilialeEntity();
						ent.setAngestellte(Long.valueOf(fil.getAngestellte()));
						ent.setLohnSumme(fil.getLohnSumme());
						ent.setSeit(OSSDateUtil.toLocalDate(fil.getSeit()));
						ent.setGeschaeftsstelle(geschaeftsstelle);
						ent.setAhvAnmeldung(ahvAnmeldung);
						entities.add(ahvFilialeRepo.save(ent));
					}
				}
			}
		});
		return entities;
	}

	private List<AhvTeilhaberEntity> migrateToAhvTeilhaber(Userdata userdata, Map<String, PersonEntity> personMap,
		AhvAnmeldungEntity ahvAnmeldung, OrganisationEntity org, Ahv ahv) {
		switch(userdata.getDossier().getRechtsform()) {
			case EF:
				return Arrays.asList(migrateAhvTeilhaberEF((AhvEF) ahv, personMap, ahvAnmeldung, org));
			case KOLGES:
				AhvPG ahvKol = (AhvPG) ahv;
				return migrateAhvTeilhaberKollAndKomm(ahvKol.getTeilhaber(), personMap, ahvAnmeldung);
			case KOMGES:
				AhvPG ahvKomm = (AhvPG) ahv;
				return migrateAhvTeilhaberKollAndKomm(ahvKomm.getTeilhaber(), personMap, ahvAnmeldung);
			case AG:
			case GMBH:
				return null;
			default:
				throw new IllegalArgumentException("Unknown generated.RechtsformEnum " + userdata.getDossier().getRechtsform());
		}
	}

	private AhvTeilhaberEntity migrateAhvTeilhaberEF(AhvEF ef, Map<String, PersonEntity> personMap,
			AhvAnmeldungEntity ahv, OrganisationEntity org) {
		AhvTeilhaberEntity ent = new AhvTeilhaberEntity();
		ent.setAhv(ahv);

		if(ef.getBisher() != null) {
			migrateAhvBisher(ef.getBisher(), ent);
		}
		
		if(ef.getMitarbeit() != null) {
			migrateAhvMitarbeit(ef.getMitarbeit(), ent);
		}
		
		if(ef.getEinkommen() != null) {
			migrateAhvEinkommenGeneral(ef.getEinkommen(), ent);
			ent.setEinkommenProvision(ef.getEinkommen().isProvision());
		}
		
		if(ef.getLasten() != null) {
			migrateAhvLastenGeneral(ef.getLasten(), ent);
		}
		
		if(ef.getArbOrgAuftritt() != null) {
			migrateAhvAoaGenernal(ef.getArbOrgAuftritt(), ent);
			ent.setAoaRabatte(ef.getArbOrgAuftritt().isRabatte());
			ent.setAoaKundendienst(ef.getArbOrgAuftritt().isKundendienst());
		}
		
		if(ef.getPartner() != null) {
			migrateAhvPartner(ef.getPartner(), personMap, ent);
		}
		Optional<GeschaftsrolleEntity> person = org.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream().findFirst();
		if(person.isPresent()) {
			ent.setPerson(person.get().getPerson());
		}
		
		return ahvTeilhaberRepo.save(ent);
	}

	private void migrateAhvPartner(AhvPartner ahvPartner, Map<String, PersonEntity> personMap, AhvTeilhaberEntity ent) {
		if(ahvPartner.getPerson() != null) {
			ent.setPartner(personMap.get(ahvPartner.getPerson().getId()));
		}
		if(ahvPartner.getLohn() != null) {
			ent.setPartnerLohnSumme(ahvPartner.getLohn().getLohnsumme());
			ent.setPartnerLohnSeit(OSSDateUtil.toLocalDate(ahvPartner.getLohn().getSeit()));
			ent.setPartnerHatKinder(ahvPartner.getLohn().isHatKinder());
		}
		
		ent.setPartnerArbeitetMit(ahvPartner.isArbeitetMit());
		ent.setPartnerEinkommenUeber(ahvPartner.isEinkommenUeber());
	}

	private void migrateAhvAoaGenernal(AhvArbOrgAuftritt ahvEFArbOrgAuftritt, AhvTeilhaberEntity ent) {
		ent.setAoaWeisung(ahvEFArbOrgAuftritt.isWeisungen());
		ent.setAoaKonkurrenzverbot(ahvEFArbOrgAuftritt.isKonkurrenzverbot());
		ent.setAoaPersoenlich(ahvEFArbOrgAuftritt.isPersoenlich());
		ent.setAoaName(convertToAhvNamen(ahvEFArbOrgAuftritt.getName()));
		ent.setAoaBriefpapier(ahvEFArbOrgAuftritt.isBriefpapier());
		ent.setAoaWerbung(ahvEFArbOrgAuftritt.isWerbung());
		ent.setAoaOfferten(ahvEFArbOrgAuftritt.isOfferten());
		ent.setAoaRechnungen(ahvEFArbOrgAuftritt.isRechnungen());
	}

	private void migrateAhvLastenGeneral(AhvLasten ahvLasten, AhvTeilhaberEntity ent) {
		ent.setLastenUnkosten(ahvLasten.isUnkosten());
		ent.setLastenUnterhalt(ahvLasten.isUnterhaltskosten());
		ent.setLastenGarantie(ahvLasten.isGarantiearbeiten());
		ent.setLastenMaterial(ahvLasten.isMaterial());
		ent.setLastenRisiko(ahvLasten.getRisiko());
	}

	private void migrateAhvEinkommenGeneral(AhvEinkommen ahvEFEinkommen, AhvTeilhaberEntity ent) {
		ent.setEinkommenEinkommen(ahvEFEinkommen.getEinkommen());
		ent.setEinkommenRechnung(ahvEFEinkommen.isRechnungen());
		ent.setEinkommenLohn(ahvEFEinkommen.isLohn());
	}

	private void migrateAhvMitarbeit(AhvMitarbeit ahvMitarbeit, AhvTeilhaberEntity ent) {
		ent.setMitarbeit(convertToMitarbeit(ahvMitarbeit.getMitarbeit()));
		ent.setMitarbeitRolle(ahvMitarbeit.getRolle());
		ent.setMitarbeitBezeichnung(ahvMitarbeit.getBezeichnung());
		
		if(ahvMitarbeit.getAdresse() != null) {
			ent.setMitarbeitName(ahvMitarbeit.getAdresse().getName());
			ent.setMitarbeitStrasse(ahvMitarbeit.getAdresse().getStrasse());
			ent.setMitarbeitPlzOrt(ahvMitarbeit.getAdresse().getPlzOrt());
		}
		
		ent.setMitarbeitStaaten(ahvMitarbeit.getStaaten());
	}

	private void migrateAhvBisher(AhvBisher ahvBisher, AhvTeilhaberEntity ent) {
		CodeWertEntity bisherBeitragAls = findCodeWertByCategoryAndCode(KategorieEnum.AHV_BEITRAG_ALS, ahvBisher.getBeitraegeAls().value());
		if(bisherBeitragAls != null) {
			ent.setBisherBeitragAls(bisherBeitragAls.getId());
		}
		ent.setBisherEinkommen(ahvBisher.getEinkommen());
		ent.setBisherAk(ahvBisher.getAusgleichskasse());
		ent.setBisherVon(OSSDateUtil.toLocalDate(ahvBisher.getVon()));
		ent.setBisherBis(OSSDateUtil.toLocalDate(ahvBisher.getBis()));
		if (ahvBisher.getVerbandsAK().isMitglied()) {
			ent.setBisherVerbandAkId(ahvBisher.getVerbandsAK().getReferenz());
		}
		if (ahvBisher.getBerufsverband().isMitglied()) {
			ent.setBisherBerufVerbandId(ahvBisher.getBerufsverband().getReferenz());
		}
		ent.setBisherHatKinder(ahvBisher.isHatKinder());
	}

	private AhvNamenEnum convertToAhvNamen(generated.AhvNamenEnum name) {
		if(name == null) {
			return null;
		}
		switch(name) {
			case AUFTRAGGEBER:
				return AhvNamenEnum.AUFTRAGGEBER;
			case EIGENER:
				return AhvNamenEnum.EIGENER;
			case GESELLSCHAFT:
				return AhvNamenEnum.GESELLSCHAFT;
			default:
				throw new IllegalArgumentException("Unknown generated.AhvNamenEnum" + name);
		}
	}

	private AhvMitarbeitEnum convertToMitarbeit(generated.AhvMitarbeitEnum mitarbeit) {
		if(mitarbeit == null) {
			return null;
		}
		switch(mitarbeit) {
			case HAUPTERWERB:
				return AhvMitarbeitEnum.HAUPTERWERB;
			case NEBENERWERB:
				return AhvMitarbeitEnum.NEBENERWERB;
			default:
				throw new IllegalArgumentException("Unknown generated.AhvMitarbeitEnum" + mitarbeit);
		}
	}

	private List<AhvTeilhaberEntity> migrateAhvTeilhaberKollAndKomm(List<AhvPGTeilhaberdaten> teilhabers,
			Map<String, PersonEntity> personMap, AhvAnmeldungEntity ahv) {
		if(CollectionUtils.isEmpty(teilhabers)) {
			return Collections.emptyList();
		}
		
		List<AhvTeilhaberEntity> entities = new ArrayList<>();
		for(AhvPGTeilhaberdaten teilhaber : teilhabers) {
			AhvTeilhaberEntity ent = new AhvTeilhaberEntity();
			if(teilhaber.getBisher() != null) {
				migrateAhvBisher(teilhaber.getBisher(), ent);
			}
			if(teilhaber.getMitarbeit() != null) {
				migrateAhvMitarbeit(teilhaber.getMitarbeit(), ent);
			}
			if(teilhaber.getEinkommen() != null) {
				migrateAhvEinkommenGeneral(teilhaber.getEinkommen(), ent);
				ent.setEinkommenAnteilAmGewinn(teilhaber.getEinkommen().getAnteilAmGewinn());
				ent.setEinkommenAnteilAmVerlust(teilhaber.getEinkommen().getAnteilAmVerlust());
			}
			if(teilhaber.getLasten() != null) {
				migrateAhvLastenGeneral(teilhaber.getLasten(), ent);
				ent.setLastenInkassorisiko(teilhaber.getLasten().isInkassorisiko());
				ent.setLastenVerluste(teilhaber.getLasten().isVerluste());
				ent.setLastenLohnanspruch(teilhaber.getLasten().isLohnanspruch());
			}
			if(teilhaber.getArbOrgAuftritt() != null) {
				migrateAhvAoaGenernal(teilhaber.getArbOrgAuftritt(), ent);
			}
			if(teilhaber.getPartner() != null) {
				migrateAhvPartner(teilhaber.getPartner(), personMap, ent);
			}
			ent.setComplete(teilhaber.isDatacomplete());
			ent.setPerson(personMap.get(getPersonStartBizRef(teilhaber.getRef())));
			ent.setAhv(ahv);
			entities.add(ent);
		}
		return ahvTeilhaberRepo.save(entities);
	}

	private AhvAnmeldungEntity migrateToAhvAnmeldung(Userdata userdata, Map<String, AdresseEntity> adresseMap,
			Map<String, PersonEntity> personMap, OrganisationEntity org, Ahv ahv) {
		AhvAnmeldungEntity result = migrateGeneralAhv(ahv, userdata, adresseMap, org);
		switch (userdata.getDossier().getRechtsform()) {
			case EF:
				migrateAhvEF(result, (AhvEF) ahv);
				break;
			case AG:
				migrateAhvKG(result, (AhvKG) ahv);
				break;
			case GMBH:
				migrateAhvKG(result, (AhvKG) ahv);
				break;
			case KOLGES:
				migrateAhvPG(result, (AhvPG) ahv);
				break;
			case KOMGES:
				migrateAhvPG(result, (AhvPG) ahv);
				break;
			default:
				throw new IllegalArgumentException("Unknown generated.RechtsformEnum " + userdata.getDossier().getRechtsform());
		}
		return ahvAnmeldungRepo.save(result);
	}
	
	private AhvAnmeldungEntity migrateGeneralAhv(Ahv data, Userdata userdata, Map<String, AdresseEntity> adresseMap, OrganisationEntity org) {
		ProzessEntity prozess = initializeProcess(userdata, org, ProzessTypEnum.AHV, AHV_DATE_VARIABLE_KEY);
		
		AhvAnmeldungEntity ent = new AhvAnmeldungEntity();
		ent.setProzess(prozess);
		if (data.getZefixDaten() != null) {
			ent.setZefixStatus(convertToHRStatus(data.getZefixDaten().getStatus()));
			ent.setZefixChNr(data.getZefixDaten().getChNummer());
			ent.setZefixShabNr(data.getZefixDaten().getShabNummer());
			ent.setZefixShabDate(OSSDateUtil.toLocalDate(data.getZefixDaten().getShabDate()));
		}

		if (data.getGruendung() != null) {
			ent.setGruendArt(convertToAhvGruendungsart(data.getGruendung().getArt()));
			ent.setGruendAlteBezeichnung(data.getGruendung().getAlteBezeichnung());

			if (data.getGruendung().getUebernahme() != null) {
				ent.setGruendUebernameArt(
						convertToAhvUebername(data.getGruendung().getUebernahme().getUebernahmeArt()));
				ent.setGruendUebernameNummer(data.getGruendung().getUebernahme().getNummer());
				ent.setGruendUebernameName(data.getGruendung().getUebernahme().getName());
			}
		}

		if (data.getVerband() != null) {
			ent.setVerbandZugehoerigkeit(
					convertToAhvVerbandszugehoerigkeit(data.getVerband().getVerbandszugehoerigkeit()));
			ent.setVerbandBeitrittDatum(OSSDateUtil.toLocalDate(data.getVerband().getBeitritt()));
			ent.setVerbandFak(data.getVerband().isFak());
			ent.setVerbandId(data.getVerband().getPkVerband());
		}

		if (data.getLohnbuch() != null) {
			ent.setLohnbuchPapier(data.getLohnbuch().isPapier());
			ent.setLohnbuchComputer(data.getLohnbuch().isComputer());
			ent.setLohnbuchSuva(data.getLohnbuch().isSuva());
			ent.setLohnbuchTreuhaender(data.getLohnbuch().isTreuhaender());
		}

		if (data.getSozialvers() != null) {
			ent.setSozialversBvg(data.getSozialvers().isBvgAngeschlossen());
			ent.setSozialversBvgGrund(data.getSozialvers().getBvgBegruendung());
			ent.setSozialversBvgName(data.getSozialvers().getBvgVersicherung());
			ent.setSozialversUvg(data.getSozialvers().getUvgVersicherung());
		}

		if (data.getSonderfragen() != null) {
			ent.setSonderPartnerWeb(data.getSonderfragen().isPartnerWeb());
			ent.setSonderVerband(data.getSonderfragen().isVerband());
			ent.setSonderBvg(data.getSonderfragen().isBvg());
			ent.setSonderUvg(data.getSonderfragen().isUvg());
			ent.setSonderKkv(data.getSonderfragen().isKkv());
			ent.setSonderWeitere(data.getSonderfragen().isWeitere());
			ent.setSonderFormulare(data.getSonderfragen().getAntragsformulare());
		}

		ent.setKontaktBemerkungen(data.getBemerkungen());
		ent.setKontaktVorname(data.getKontaktVorname());
		ent.setKontaktFamilienname(data.getKontaktFamilienname());
		
		Optional<AdressRef> adresse = getAdressRef(userdata).stream()
				.filter(a -> a.getZweck() == AdressZweckEnum.KONTAKT_AHV).findFirst();
		if(adresse.isPresent()) {
			ent.setAdresseKontakt(adresseMap.get(getAdresseStartBizRef(adresse.get())));
		}		
		
		Optional<AdressRef> adresseTreuhand = getAdressRef(userdata).stream()
				.filter(a -> a.getZweck() == AdressZweckEnum.TREUHAND_AHV).findFirst();
		if(adresseTreuhand.isPresent()) {
			ent.setAdresseTreuhand(adresseMap.get(getAdresseStartBizRef(adresseTreuhand.get())));
		}		
		
		//TODO [HHG / S9]: mapping for ahv adresse Rechnung.
//		Optional<AdressRef> adresseRechnung = getAdressRef(userdata).stream()
//				.filter(a -> a.getZweck() == AdressZweckEnum.RECHN_AHV).findFirst();
//		if(adresseRechnung.isPresent()) {
//			ent.setAdresseRechnung(adresseMap.get(getAdresseStartBizRef(adresseRechnung.get())));
//		}		

		return ent;
	}

	private String getAdresseStartBizRef(AdressRef adressRef) {
		if(adressRef == null) {
			return null;
		}
		return ((Adresse)adressRef.getRef()).getId();
	}
	
	private void migrateAhvEF(AhvAnmeldungEntity ent, AhvEF ahvEf) {
		if(ahvEf.getKapital() != null) {
			migrateAhvKapital(ent, ahvEf.getKapital());
		}
		
		if(ahvEf.getInvestitionen() != null) {
			migrateAhvInvestotionen(ent, ahvEf.getInvestitionen());
		}
		
		if(ahvEf.getRaeumlichkeiten() != null) {
			migrateAhvRaeumlichkeiten(ent, ahvEf.getRaeumlichkeiten());
		}
		
		if(ahvEf.getTaetigkeit() != null) {
			migrateAhvTaetigkeit(ent, ahvEf.getTaetigkeit());
			ent.setTaetigAgent(ahvEf.getTaetigkeit().isAgent());
			ent.setTaetigAuftraggeber(ahvEf.getTaetigkeit().getAuftraggeber());
		}
		
		if(ahvEf.getAngestellte() != null) {
			migrateAhvAngestelle(ent, ahvEf.getAngestellte());
		}
		
	}
	
	private void migrateAhvPG(AhvAnmeldungEntity ent, AhvPG ahvPG) {
		if(ahvPG.getKapital() != null) {
			migrateAhvKapital(ent, ahvPG.getKapital());
		}
		
		if(ahvPG.getInvestitionen() != null) {
			migrateAhvInvestotionen(ent, ahvPG.getInvestitionen());
		}
		
		if(ahvPG.getRaeumlichkeiten() != null) {
			migrateAhvRaeumlichkeiten(ent, ahvPG.getRaeumlichkeiten());
		}
		
		if(ahvPG.getTaetigkeit() != null) {
			migrateAhvTaetigkeit(ent, ahvPG.getTaetigkeit());
			ent.setTaetigGemeinsameKunden(ahvPG.getTaetigkeit().isGemeinsameKunden());
		}
		
		if(ahvPG.getAngestellte() != null) {
			migrateAhvAngestelle(ent, ahvPG.getAngestellte());
		}
	}

	private void migrateAhvKG(AhvAnmeldungEntity ent, AhvKG ahvKG) {
		if(ahvKG.getAngestellte() != null) {
			ent.setAngestellteGiAnz(ahvKG.getAngestellte().getAnzGl());
			if(ahvKG.getAngestellte().getLohnGl() != null) {
				ent.setAngestellteGiLohnSumme(ahvKG.getAngestellte().getLohnGl().getLohnsumme());
				ent.setAngestellteGiLohnSeit(OSSDateUtil.toLocalDate(ahvKG.getAngestellte().getLohnGl().getSeit()));
				ent.setAngestellteGiHatKinder(ahvKG.getAngestellte().getLohnGl().isHatKinder());
			}
			ent.setAngestellteVrHonorare(ahvKG.getAngestellte().getVrHonorare());
			
			if(ahvKG.getAngestellte().getLohnUebrige() != null) {
				ent.setAngestellteUebLohnSumme(ahvKG.getAngestellte().getLohnUebrige().getLohnsumme());
				ent.setAngestellteAngLohnSeit(OSSDateUtil.toLocalDate(ahvKG.getAngestellte().getLohnUebrige().getSeit()));
				ent.setAngestellteUebHatKinder(ahvKG.getAngestellte().getLohnUebrige().isHatKinder());
			}
			
		}
	}

	private void migrateAhvAngestelle(AhvAnmeldungEntity ent, AhvAngestellteLohn angestellte) {
		ent.setAngestellteAngAnz(angestellte.getAnzAngehoerige());
		if(angestellte.getLohnAngehoerige() != null) {
			ent.setAngestellteAngLohnSumme(angestellte.getLohnAngehoerige().getLohnsumme());
			ent.setAngestellteAngLohnSeit(OSSDateUtil.toLocalDate(angestellte.getLohnAngehoerige().getSeit()));
			ent.setAngestellteAngHatKinder(angestellte.getLohnAngehoerige().isHatKinder());			
		}
		ent.setAngestellteUebAnz(angestellte.getAnzUebrige());
		
		if(angestellte.getLohnUebrige() != null) {
			ent.setAngestellteAngLohnSumme(angestellte.getLohnUebrige().getLohnsumme());
			ent.setAngestellteUebLohnSeit(OSSDateUtil.toLocalDate(angestellte.getLohnUebrige().getSeit()));
			ent.setAngestellteUebHatKinder(angestellte.getLohnUebrige().isHatKinder());
		}
	}

	private void migrateAhvTaetigkeit(AhvAnmeldungEntity ent, AhvTaetigkeit taetigkeit) {
		ent.setTaetigAnzKunden(taetigkeit.getAnzKunden());
		ent.setTaetigArtAuftraege(taetigkeit.getArtAuftraege());
		ent.setTaetigDatumLetzterAuftrag(OSSDateUtil.toLocalDate(taetigkeit.getDatumLetzterAuftrag()));
		ent.setTaetigKunde1(taetigkeit.getKunde1());
		ent.setTaetigKunde2(taetigkeit.getKunde2());
		ent.setTaetigKunde3(taetigkeit.getKunde3());
	}

	private void migrateAhvRaeumlichkeiten(AhvAnmeldungEntity ent, AhvRaeumlichkeiten raeumlichkeiten) {
		ent.setRaumKeine(raeumlichkeiten.isKeine());
		ent.setRaumEigene(raeumlichkeiten.isEigene());
		ent.setRaumKunde(raeumlichkeiten.isKunde());
		ent.setRaumWohnung(raeumlichkeiten.isWohnung());
	}

	private void migrateAhvInvestotionen(AhvAnmeldungEntity ent, AhvInvestitionen investitionen) {
		ent.setInvestWerkzeugKauf(investitionen.getWerkzeugKauf());
		ent.setInvestFahrzeugKauf(investitionen.getFahrzeugKauf());
		ent.setInvestWarenInvKauf(investitionen.getWareninventarKauf());
		ent.setInvestWeitereKauf(investitionen.getWeitereKauf());
		ent.setInvestWeitereKaufArt(investitionen.getWeitereKaufArt());
		ent.setInvestBueroMiete(investitionen.getBueroMiete());
		ent.setInvestLadenMiete(investitionen.getLadenMiete());
		ent.setInvestWerkstattMiete(investitionen.getWerkstattMiete());
		ent.setInvestLagerMiete(investitionen.getLagerMiete());
		ent.setInvestFahrzeugMiete(investitionen.getFahrzeugMiete());
		ent.setInvestWeitereMiete(investitionen.getWeitereMiete());
		ent.setInvestWeitereMieteArt(investitionen.getWeitereMieteArt());
	}

	private void migrateAhvKapital(AhvAnmeldungEntity ent, AhvKapital kapital) {
		ent.setKapitalEigen(kapital.getEigenkapital());
		ent.setKapitalDarlehen(kapital.getDarlehen());		
	}
	
	private AhvVerbandszugehoerigkeitEnum convertToAhvVerbandszugehoerigkeit(generated.AhvVerbandszugehoerigkeitEnum verbandszugehoerigkeit) {
		if(verbandszugehoerigkeit == null) {
			return null;
		}
		switch(verbandszugehoerigkeit) {
		case BALD:
			return AhvVerbandszugehoerigkeitEnum.BALD;
		case JA:
			return AhvVerbandszugehoerigkeitEnum.JA;
		case NEIN:
			return AhvVerbandszugehoerigkeitEnum.NEIN;
		case NEIN_IN_KEINEM_DER_AUFGEFUEHRTEN:
			return AhvVerbandszugehoerigkeitEnum.NEIN_IN_KEINEM_DER_AUFGEFUEHRTEN;
		default:
			throw new IllegalArgumentException("Unknown AhvVerbandszugehoerigkeitEnum: " + verbandszugehoerigkeit);
		}
	}

	private AhvUebernahmeEnum convertToAhvUebername(generated.AhvUebernahmeEnum uebernahmeArt) {
		if(uebernahmeArt == null) {
			return null;
		}
		switch(uebernahmeArt) {
		case KAUF:
			return AhvUebernahmeEnum.KAUF;
		case MIETE:
			return AhvUebernahmeEnum.MIETE;
		case PACHT:
			return AhvUebernahmeEnum.PACHT;
		default:
			throw new IllegalArgumentException("Unknown generated.AhvUebernahmeEnum " + uebernahmeArt);
		}
		
	}

	private AhvGruendungsartEnum convertToAhvGruendungsart(generated.AhvGruendungsartEnum art) {
		if(art == null) {
			return null;
		}
		switch(art) {
		case NEU:
			return AhvGruendungsartEnum.NEU;
		case UEBERNAHME:
			return AhvGruendungsartEnum.UBERNAHME;
		case UMWANDLUNG:
			return AhvGruendungsartEnum.UMWANDLUNG;
		default:
			throw new IllegalArgumentException("Unknown generated.AhvGruendungsartEnum " + art);
		}
		
	}

	private Ahv getStartBizAhvData(Userdata userdata) {
		if(userdata == null) {
			return null;
		}
		switch(userdata.getDossier().getRechtsform()) {
		case AG:
			return userdata.getDossier().getAktiengesellschaft().getAhv();
		case EF:
			return userdata.getDossier().getEinzelfirma().getAhv();
		case GMBH:
			return userdata.getDossier().getGmbh().getAhv();
		case KOLGES:
			return userdata.getDossier().getKollektivgesellschaft().getAhv();
		case KOMGES:
			return userdata.getDossier().getKommanditgesellschaft().getAhv();
		default:
			throw new IllegalArgumentException("Unknown generated.RechtsformEnum " + userdata.getDossier().getRechtsform());
		}
	}

	private void migrateStartBizDataToUvg(Userdata userdata, Map<String, AdresseEntity> adresseMap,
			Map<String, PersonEntity> personMap, OrganisationEntity org) {
		UVGAngaben uvgAngaben = getStartBizOrgData(userdata).getUvgAngaben();
		if (uvgAngaben != null) {
			UvgAnmeldungEntity uvg = migrateToUvgAnmeldung(userdata, adresseMap, org, uvgAngaben);
			migrateToUVGGesellschafter(uvgAngaben, uvg, personMap);
		} else {
			createNewUvgProcess(org);
		}
	}

	private List<UvgGesellschafterEntity> migrateToUVGGesellschafter(UVGAngaben uvgAngaben, UvgAnmeldungEntity uvg,
			Map<String, PersonEntity> personMap) {
		List<UvgGesellschafterEntity> result = new ArrayList<>();
		for (UVGGesellschafter gesellschafter : uvgAngaben.getGesellschafter()) {
			UvgGesellschafterEntity ent = new UvgGesellschafterEntity();
			ent.setLohnsumme(gesellschafter.getLohnsumme());
			ent.setPerson(personMap.entrySet().stream()
					.filter(entry -> getNamePerson(entry.getValue()).equals(gesellschafter.getName())).findFirst().get()
					.getValue());
			ent.setUvgAnmeldung(uvg);
			result.add(uvgGesellschafterRepo.save(ent));
		}
		return result;
	}

	private String getNamePerson(PersonEntity person) {
		return person.getVorname() + " " + person.getFamilienname();
	}

	private List<AdressRef> getAdressRef(Userdata userdata) {
		return getStartBizOrgData(userdata).getAdresse();
	}

	private UvgAnmeldungEntity migrateToUvgAnmeldung(Userdata userdata, Map<String, AdresseEntity> adresseMap,
		OrganisationEntity org, UVGAngaben uvgAngaben) {
		ProzessEntity process = initializeProcess(userdata, org, ProzessTypEnum.UVG, UVG_DATE_VARIABLE_KEY);
		UvgAnmeldungEntity ent = new UvgAnmeldungEntity();
		ent.setProzess(process);
		ent.setAngestellteHeute(new BigDecimal(uvgAngaben.getAngestellteHeute()));
		ent.setErsteAnstellung(OSSDateUtil.toLocalDate(uvgAngaben.getErsteAnstellung()));
		ent.setErsteAnstellungZukunft(OSSDateUtil.toLocalDate(uvgAngaben.getErsteAnstellungZukunft()));
		ent.setAngestellteZukunft(new BigDecimal(uvgAngaben.getAngestellteZukunft()));
		ent.setAngestelltePartner(uvgAngaben.isAngestPartner());
		ent.setAngestellteFamilie(uvgAngaben.isAngestFamilie());
		ent.setAngestellteLehrling(uvgAngaben.isAngestLehrling());
		ent.setAngestellteOhneLohn(uvgAngaben.isAngestOhneLohn());
		ent.setAngestellteAushilfe(uvgAngaben.isAngestAushilfe());
		ent.setAngestellteGesellschafter(uvgAngaben.isAngestGesellschafter());
		ent.setUvgInhaberFreiwillig(uvgAngaben.isUvgInhaberFreiwillig());
		ent.setLohnsumme(uvgAngaben.getLohnsumme());
		ent.setLohnsummeFolgejahr(uvgAngaben.getLohnsummeFolgejahr());
		ent.setZahlungsmodus(findZahlungsmodus(uvgAngaben.getZahlungsmodus()));
		ent.setTaggeldAnBetrieb(uvgAngaben.isTaggeldAnBetrieb());
		ent.setAhvName(uvgAngaben.getAhvName());
		ent.setAhvNummer(uvgAngaben.getAhvNummer());
		ent.setVersicherungName(uvgAngaben.getVersicherungName());
		ent.setVersicherungNummer(uvgAngaben.getVersicherungNummer());
		ent.setBemerkungen(uvgAngaben.getBemerkungen());
		ent.setKontaktName(uvgAngaben.getKontaktFamilienname());
		ent.setKontaktVorname(uvgAngaben.getKontaktVorname());
		Optional<AdressRef> adresse = getAdressRef(userdata).stream()
				.filter(a -> a.getZweck() == AdressZweckEnum.UVG_KORRESPONDENZ).findFirst();
		if(adresse.isPresent()) {
			ent.setKontaktAdresse(adresseMap.get(getAdresseStartBizRef(adresse.get())));
		}		
		ent.setPartnerName(uvgAngaben.getPartnerName());
		ent.setPartnerLohnsumme(uvgAngaben.getPartnerLohnsumme());
		ent.setPartnerFreiwillig(uvgAngaben.isPartnerFreiwillig());
		ent.setAngehoerigeLohnsumme(uvgAngaben.getSonstigeAngehoerigeLohnsumme());
		ent.setAngehoerigeAnzahl(new BigDecimal(uvgAngaben.getSonstigeAngehoerigeAnzahl()));
		ent.setAngehoerigeFreiwillig(uvgAngaben.isSonstigeAngehoerigeFreiwillig());
		ent.setGlAnzahl(uvgAngaben.getGlAnzahl());
		ent.setGlLohnsumme(uvgAngaben.getGlLohnsumme());
		ent.setVrLohnsumme(uvgAngaben.getVrLohnsumme());
		if (uvgAngaben.getVersicherer() != null) {
			ent.setVersichererWunsch(convertToVersichererWunschEnum(uvgAngaben.getVersicherer().getWunsch()));

			uvgAngaben.getVersicherer().getVersicherungsId().stream().forEach(id -> {
				ent.getVersicherer().add(
						cacheService.getVersicherungs().stream().filter(v -> v.getId().equals(id)).findFirst().get());
			});
		}
		return uvgAnmeldungRepo.save(ent);
	}

	private ProzessEntity initializeProcess(Userdata userdata, OrganisationEntity org, ProzessTypEnum typ, String keyDate) {
		ProzessEntity prozess = new ProzessEntity();
		prozess.setOrganisation(org);
		prozess.setBearbdatum(convertProcessDate(getValue(userdata.getDossier().getVar(), keyDate)));
		prozess.setLocked(true);
		prozess.setCompleted(true);
		prozess.setStartDatum(EPOCH_DATE);
		prozess.setStatus(ProzessStatusEnum.GESENDET);
		prozess.setTyp(typ);
		prozess.setUid(DataUtil.getUID(prozess.getStartDatum()));
		prozess.setFlowHistory(new FlowHistoryEntity());
		prozess.getStatuswechsels().add(initializeProcessStatus(prozess, EPOCH_DATE));
		return processRepo.save(prozess);
	}

	private StatuswechselEntity initializeProcessStatus(ProzessEntity prozess, LocalDateTime date) {
		StatuswechselEntity statuswechsel = new StatuswechselEntity();
		statuswechsel.setProzess(prozess);
		statuswechsel.setStatus(prozess.getStatus());
		statuswechsel.setZeitstempel(date);
		statuswechsel.setUser(new UserEntity(SecurityUtil.currentUser().getUserId()));
		return statuswechsel;
	}

	private VersichererWunschEnum convertToVersichererWunschEnum(VersicherungsauswahlEnum wunsch) {
		if (wunsch == null) {
			return null;
		}
		switch (wunsch) {
		case ANMELDUNG:
			return VersichererWunschEnum.CONTRACT;
		case OFFERTE:
			return VersichererWunschEnum.OFFER;
		default:
			throw new IllegalArgumentException("Unknown generated.VersicherungsauswahlEnum " + wunsch);
		}
	}

	private CodeWertEntity findZahlungsmodus(UVGZahlungsmodusEnum zahlungsmodus) {
		if (zahlungsmodus == null) {
			return null;
		}
		switch (zahlungsmodus) {
		case JAHR:
			return findCodeWertByCategoryAndCode(KategorieEnum.UVGINTERVALL, UVGINTERVALL_JAHR_CODE);
		case QUARTAL:
			return findCodeWertByCategoryAndCode(KategorieEnum.UVGINTERVALL, UVGINTERVALL_QUARTAL_CODE);
		case SEMESTER:
			return findCodeWertByCategoryAndCode(KategorieEnum.UVGINTERVALL, UVGINTERVALL_SEMESTER_CODE);
		default:
			throw new IllegalArgumentException("Unknown generated.UVGZahlungsmodusEnum " + zahlungsmodus);
		}

	}

	@SuppressWarnings("deprecation")
	private OrganisationEntity migrateStartBizDataToOrganisation(Long startBizEntId, Userdata userdata,
			Map<String, AdresseEntity> adresseMap, Map<String, PersonEntity> personMap) {
		Organisation startBizOrg = getStartBizOrgData(userdata);
		OrganisationEntity org = new OrganisationEntity();
		org.setCreationType(OrganisationCreationTypeEnum.STARTBIZ);
		org.setRechtsform(convertToRechtsform(userdata.getDossier().getRechtsform()));
		org.setZweck(startBizOrg.getZweck());
		org.getBranches().addAll(findBranchesByNames(startBizOrg.getBranche()));
		org.setBeschreibung(startBizOrg.getBeschreibung());
		org.setBemerkungen(startBizOrg.getBemerkungen());
		org.setEroeffnungsDatum(OSSDateUtil.toLocalDate(startBizOrg.getEroeffnung()));
		org.setErstrechnungsDatum(OSSDateUtil.toLocalDate(startBizOrg.getErstrechnung()));
		org.setErstauftragsDatum(OSSDateUtil.toLocalDate(startBizOrg.getErstauftrag()));
		org.setGeschaeftsjahrStart(OSSDateUtil.toLocalDate(startBizOrg.getGeschJahrStart()));
		org.setGeschaeftsjahrEnd(OSSDateUtil.toLocalDate(startBizOrg.getGeschJahrEnde()));
		org.setZefixImportDate(
				fomartDateLastUpdateDossier(getValue(userdata.getDossier().getVar(), LAST_DOSSIER_UPDATE_VARIABLE_KEY)));

		// TODO [COH / S9] to consider grouping logic create flow history
		FlowHistoryEntity fhe = new FlowHistoryEntity();
		flowHistoryRepo.save(fhe);
		org.setFlowHistory(fhe);
		
		Optional<AdressRef> domizil = startBizOrg.getAdresse().stream()
				.filter(a -> a.getZweck() == AdressZweckEnum.DOMIZIL).findFirst();
		if (domizil.isPresent()) {
			AdresseEntity startbizDomizil = adresseMap.get(getAdresseStartBizRef(domizil.get()));
			org.setDomizil(isValidBfsNr(startbizDomizil.getBfsNr()) ? startbizDomizil
				: updateDomizilInfo(startBizEntId, startbizDomizil));
		}
		if (startBizOrg.getHreintrag() != null) {
			org.setHrStatus(convertToHRStatus(startBizOrg.getHreintrag().getStatus()));
			org.setChNr(startBizOrg.getHreintrag().getChnr());
			org.setShabDatum(OSSDateUtil.toLocalDate(startBizOrg.getHreintrag().getShabDatum()));
			org.setShabNr(startBizOrg.getHreintrag().getShabNummer());
			org.setShabId(startBizOrg.getHreintrag().getShabId());
			org.setUid(OssNumberFormatUtil.reFormatUid(startBizOrg.getHreintrag().getUid()));
		}

		migrateStartBizDataToFirmenname(userdata, startBizOrg, org);

		org = orgRepo.save(org);
		
		RechtsformEnum rechtsform = userdata.getDossier().getRechtsform();

		if (rechtsform == RechtsformEnum.KOMGES
				&& CollectionUtils.isNotEmpty(userdata.getDossier().getKommanditgesellschaft().getKomFirmen())) {
			migrateStartBizDataToKommGes(userdata, adresseMap, org);
		}

		if (CollectionUtils.isNotEmpty(startBizOrg.getFunktion())) {
			Iterator<Funktion> functionIterator = startBizOrg.getFunktion().iterator();
			org.getGeschaeftsrollens().add(migrateStartBizDataToGeschaftsrolle(personMap, org, rechtsform,
				functionIterator.next(), GeschaeftsrolleTypEnum.EDC));
			while (functionIterator.hasNext()) {
				org.getGeschaeftsrollens().add(migrateStartBizDataToGeschaftsrolle(personMap, org, rechtsform,
					functionIterator.next(), GeschaeftsrolleTypEnum.SIGNATORY));
			}
		}
		
		//TODO [HHU/S9] How to identify organisation data is complete
		Optional<GeschaftsrolleEntity> gesNonComplete = org.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream().filter(ges -> ges.isComplete() == false).findFirst();
		if(gesNonComplete.isPresent()) {
			org.setBaseDataComplete(false);
		} else {
			org.setBaseDataComplete(true);
		}

		return org;
	}
	
	private boolean isValidBfsNr(int bfsNr) {
		return new JPAQuery<CHOrtEntity>(em)
			.from(QCHOrtEntity.cHOrtEntity)
			.where(QCHOrtEntity.cHOrtEntity.bfsnr.eq(bfsNr))
			.fetchCount() > 0;
	}

	private AdresseEntity updateDomizilInfo(Long startBizEntId, AdresseEntity startbizDomizil) {
		List<CHOrtEntity> results = new JPAQuery<CHOrtEntity>(em).from(QCHOrtEntity.cHOrtEntity)
			.where(QCHOrtEntity.cHOrtEntity.ort.containsIgnoreCase(startbizDomizil.getOrt())
				.and(QCHOrtEntity.cHOrtEntity.kanton.containsIgnoreCase(startbizDomizil.getKanton())))
			.fetch();
		if (results.size() == 1) {
			startbizDomizil.setBfsNr(results.get(0).getBfsnr());
			startbizDomizil.setPolGemeinde(results.get(0).getPolGemeinde());
			return startbizDomizil;
		} else {
			throw new BfsNrNotFoundException(String.format(
				"StartBiz import error for record #[%d]: BFS Nr %d is outdated. No unique record found for %s / %s",
				startBizEntId, startbizDomizil.getBfsNr(), startbizDomizil.getOrt(), startbizDomizil.getKanton()));
		}
	}

	private void migrateStartBizDataToFirmenname(Userdata userdata, Organisation startBizOrg, OrganisationEntity org) {
		if (StringUtils.isNotBlank(startBizOrg.getName())) {
			FirmennameEntity mainName = new FirmennameEntity();
			mainName.setDefault(true);
			mainName.setOrganisation(org);
			mainName.setBezeichnung(startBizOrg.getName());
			mainName.setSprache(findCodeWertByCategoryAndCode(KategorieEnum.SPRACHE, "de"));
			org.getNamens().add(mainName);
		}
		// TODO [HHG, S9]: check with DKE how to migrate Firmenname when the name is blank !!!
		// TODO [HHG, S9]: check with DKE the impact when we change column 'Sprache' to nullable !!!
//		for (Fremdbezeichner frem : startBizOrg.getFremdBezeichner()) {
//			FirmennameEntity otherName = new FirmennameEntity();
//			otherName.setDefault(false);
//			otherName.setOrganisation(org);
//			otherName.setBezeichnung(frem.getBezeichnung());
//			otherName.setSprache(findCodeWertByCategoryAndCode(KategorieEnum.SPRACHE, frem.getSprache()));
//			firmennameRepo.save(otherName);
//		}
	}

	private Map<String, GeschaeftsstelleEntity> migrateStartBizDataToGeschaeftsstelle(Userdata userdata, OrganisationEntity organisation,
			Map<String, AdresseEntity> adresseMap) {
		Map<String, GeschaeftsstelleEntity> geschaeftsstelleMap = new HashMap<>();
		Organisation startBizOrg = getStartBizOrgData(userdata);
		if (startBizOrg == null || CollectionUtils.isEmpty(startBizOrg.getGeschaeftsstelle())) {
			return geschaeftsstelleMap;
		}
		
		for(Geschaeftsstelle ges : startBizOrg.getGeschaeftsstelle()) {
			GeschaeftsstelleEntity ent = new GeschaeftsstelleEntity();
			ent.setAnzAngestellte(ges.getAngestellte());
			ent.setInHR(ges.isEintragInHR());
			ent.setOrganisation(organisation);			
			ent.setAdresse(adresseMap.get(((Adresse)ges.getAdrref()).getId()));
			geschaeftsstelleMap.put(((Adresse)ges.getAdrref()).getId(), geschaeftsstelleRepo.save(ent));
		}
		
		return geschaeftsstelleMap;
	}

	private GeschaftsrolleEntity migrateStartBizDataToGeschaftsrolle(Map<String, PersonEntity> personMap, OrganisationEntity org,
			RechtsformEnum rechtsform, Funktion function, GeschaeftsrolleTypEnum typ) {
		GeschaftsrolleEntity geschaftrollen = new GeschaftsrolleEntity();
		geschaftrollen.setZeichnung(findCodeWertByCategoryAndCode(KategorieEnum.ZEICHNUNG, function.getZb().name()));
		geschaftrollen
				.setFunktion(findCodeWertByCategoryAndCode(KategorieEnum.FUNKTION, function.getBezeichnung().name()));
		geschaftrollen.setHaftungCHF(function.getHaftung());
		if (new BigDecimal(-1).equals(geschaftrollen.getHaftungCHF())) {
			geschaftrollen.setHaftung(findCodeWertByCategoryAndCode(KategorieEnum.HAFTUNG, HAFTUNG_UNBESCHRAENKT_CODE));
		} else {
			geschaftrollen.setHaftung(findCodeWertByCategoryAndCode(KategorieEnum.HAFTUNG, HAFTUNG_BESCHRAENKT_CODE));
		}
		geschaftrollen.setEinlage(convertStartBizEinlageArtEnum(function.getEinlage()));
		geschaftrollen.setNurHauptsitz(function.getRestriktion() == RestriktionEnum.BESCHRAENKT_AUF_HAUPTSITZ);
		switch (rechtsform) {
			case AG:
			case GMBH:
				geschaftrollen.setTyp(typ);
				break;
			case EF:
				switch (function.getBezeichnung()) {
					case INHABER:
						geschaftrollen.setTyp(GeschaeftsrolleTypEnum.EDC);
						break;
					case GESCHAEFTSFUEHRER:
					case ZEICHNUNGSBERECHTIGTER:
						geschaftrollen.setTyp(GeschaeftsrolleTypEnum.SIGNATORY);
						break;
					default:
						throw new IllegalArgumentException("Unknown FunktionEnum: " + function.getBezeichnung());
				}
				break;
			case KOLGES:
			case KOMGES:
				switch (function.getBezeichnung()) {
					case GESELLSCHAFTER:
						geschaftrollen.setTyp(GeschaeftsrolleTypEnum.EDC);
						break;
					case GESCHAEFTSFUEHRER:
					case ZEICHNUNGSBERECHTIGTER:
						geschaftrollen.setTyp(GeschaeftsrolleTypEnum.SIGNATORY);
						break;
					default:
						throw new IllegalArgumentException("Unknown FunktionEnum: " + function.getBezeichnung());
				}
				break;
			default:
				throw new IllegalArgumentException("Unknown RechtsformEnum: " + rechtsform);
		}
		geschaftrollen.setComplete(function.isDatacomplete());
		geschaftrollen.setPerson(personMap.get(getPersonStartBizRef(function.getRef())));
		geschaftrollen.setOrganisation(org);
		return geschaftsolleRepo.save(geschaftrollen);
	}

	private String getPersonStartBizRef(Object references) {
		if(references == null) {
			return null;
		}
		return ((Person) references).getId();
	}

	private CodeWertEntity convertStartBizEinlageArtEnum(EinlageArtEnum einlage) {
		switch (einlage) {
		case ASSET:
			return findCodeWertByCategoryAndCode(KategorieEnum.EINLAGE, EINLAGE_SACH_CODE);
		case CASH:
			return findCodeWertByCategoryAndCode(KategorieEnum.EINLAGE, EINLAGE_BAR_CODE);
		case NONE:
			return null;
		default:
			throw new IllegalArgumentException("Unknown EinlageArtEnum: " + einlage);
		}
	}

	private void migrateStartBizDataToKommGes(Userdata userdata, Map<String, AdresseEntity> adresseMap,
			OrganisationEntity org) {
		KommGesEntity kommges = new KommGesEntity();
		kommges.setOrganisation(org);
		kommges = kommgesRepo.save(kommges);
		for (KomFirmen k : userdata.getDossier().getKommanditgesellschaft().getKomFirmen()) {
			KommFirmaEntity kommFirma = convertToKommFirma(k, adresseMap);
			kommFirma.setKommges(kommges);
			kommFirmaRepo.save(kommFirma);
		}
	}

	private KommFirmaEntity convertToKommFirma(KomFirmen komFirmen, Map<String, AdresseEntity> adresseMap) {
		KommFirmaEntity ent = new KommFirmaEntity();
		KomFirma kom = komFirmen.getAuslKomFirma();		
		if (komFirmen.getChKomFirma() != null) {
			kom = komFirmen.getChKomFirma();
			ent.setHrNummer(OssNumberFormatUtil.reFormatUid(komFirmen.getChKomFirma().getHrNummer()));
			ent.setRechtsformCH(convertToRechtsform(komFirmen.getChKomFirma().getRechtsform()));
		} else {
			ent.setRechtsformAusland(komFirmen.getAuslKomFirma().getRechtsform());
		}		
		ent.setName(kom.getFirma());
		ent.setHaftung(kom.getHaftung());
		ent.setEinlage(findEinlage(kom.getEinlage()));
		ent.setDomizil(adresseMap.get(getAdresseStartBizRef(kom.getDomizil())));
		ent.setComplete(kom.isDatacomplete());		
		return ent;
	}

	private CodeWertEntity findEinlage(EinlageArtEnum startBizAinlage) {
		switch (startBizAinlage) {
		case ASSET:
			return findCodeWertByCategoryAndCode(KategorieEnum.EINLAGE, EINLAGE_SACH_CODE);
		case CASH:
			return findCodeWertByCategoryAndCode(KategorieEnum.EINLAGE, EINLAGE_BAR_CODE);
		case NONE:
			return null;
		default:
			throw new IllegalArgumentException("Unknown EinlageArtEnum: " + startBizAinlage);
		}
	}

	private HRStatusEnum convertToHRStatus(generated.HRStatusEnum startBizHRStatus) {
		switch (startBizHRStatus) {
		case EINGETRAGEN:
			return HRStatusEnum.REGISTERED;
		case PENDENT:
			return HRStatusEnum.PENDING;
		case KEIN:
			return HRStatusEnum.NONE;
		default:
			throw new IllegalArgumentException("Unknown HrStatusEnum: " + startBizHRStatus);
		}
	}

	private generated.Organisation getStartBizOrgData(Userdata userdata) {
		switch (userdata.getDossier().getRechtsform()) {
		case EF:
			return userdata.getDossier().getEinzelfirma();
		case AG:
			return userdata.getDossier().getAktiengesellschaft();
		case GMBH:
			return userdata.getDossier().getGmbh();
		case KOLGES:
			return userdata.getDossier().getKollektivgesellschaft();
		case KOMGES:
			return userdata.getDossier().getKommanditgesellschaft();
		default:
			throw new IllegalArgumentException("Unknown RechtsformEnum: " + userdata.getDossier().getRechtsform());
		}
	}

	private PflichtenabklaerungenEntity migrateStartBizDataToPflichtenabklaerungen(Userdata data, OrganisationEntity org) {
		if (data.getDossier().getAbklaerung() == null) {
			return null;
		}
		Abklaerung abk = data.getDossier().getAbklaerung();
		PflichtenabklaerungenEntity pflich = new PflichtenabklaerungenEntity();
		pflich.setOrganisation(org);
		pflich.setRechtsform(convertToRechtsform(data.getDossier().getRechtsform()));
		// TODO [HHG / S9] Comment out this line to skip the dozer error temporarily
		// pflich.setDatum(OSSDateUtil.toLocalDateTime(abk.getDatum()));
		pflich.setEroeffnungsdatum(OSSDateUtil.toLocalDate(abk.getBeginnTaetigkeit()));
		pflich.setUmsatz100k(abk.getUmsatzkategorie() == UmsatzKategorienEnum.CAT_OVER_100K);
		if (abk.getBerufsbezeichnung() != null) {
			pflich.setBerufText(abk.getBerufsbezeichnung().getValue());
			pflich.setBeruf(findBeruf(abk.getBerufsbezeichnung().getCode()));
		}
		pflich.getBranches().addAll(findBranchesByCodes(abk.getBranche()));
		pflich.setHandel(abk.isHandel());
		pflich.setAngestellte(abk.getAngestellte());
		pflich.setNurVollzeit(abk.getAngestelltenTyp() == AngestelltenEnum.NUR_VOLLZEIT);
		pflich.setAnmeldungHR(getBooleanValue(data.getDossier().getVar(), HR_DECL_VARIABLE_KEY));
		pflich.setAnmeldungAHV(getBooleanValue(data.getDossier().getVar(), AHV_DECL_VARIABLE_KEY));
		pflich.setAnmeldungMWST(getBooleanValue(data.getDossier().getVar(), MWST_DECL_VARIABLE_KEY));
		pflich.setAnmeldungUVG(getBooleanValue(data.getDossier().getVar(), UVG_DECL_VARIABLE_KEY));
		pflich.setLocked(getBooleanValue(data.getDossier().getVar(), DECMOD_LOCKED_VARIABLE_KEY));
		pflich.setCompleted(getBooleanValue(data.getDossier().getVar(), DECMOD_COMPLETED_VARIABLE_KEY));
		return pflichRepository.save(pflich);
	}

	private BerufEntity findBeruf(int code) {
		Optional<BerufEntity> beruf = cacheService.getBerufs().stream()
				.filter(b -> b.getCode().equals(String.valueOf(code))).findFirst();
		if (beruf.isPresent()) {
			return beruf.get();
		}
		return null;
	}

	private String getValue(List<NameValuePair> vars, String key) {
		Optional<NameValuePair> nameValuePair = vars.stream().filter(v -> v.getName().equals(key)).findFirst();
		if (nameValuePair.isPresent()) {
			return nameValuePair.get().getValue();
		}
		return null;
	}

	private Boolean getBooleanValue(List<NameValuePair> vars, String key) {
		return Boolean.valueOf(getValue(vars, key));
	}
	
	private Integer getIntegerValue(List<NameValuePair> vars, String key) {
		String value = getValue(vars, key);
		if(value != null) {
			return Integer.valueOf(value);
		}
		return null;
	}

	private ch.admin.oss.common.enums.RechtsformEnum convertToRechtsform(generated.RechtsformEnum startBizRechtsform) {
		switch (startBizRechtsform) {
		case AG:
			return ch.admin.oss.common.enums.RechtsformEnum.AG;
		case GMBH:
			return ch.admin.oss.common.enums.RechtsformEnum.GMBH;
		case EF:
			return ch.admin.oss.common.enums.RechtsformEnum.EINZELFIRMA;
		case KOLGES:
			return ch.admin.oss.common.enums.RechtsformEnum.KOLLGES;
		case KOMGES:
			return ch.admin.oss.common.enums.RechtsformEnum.KOMMGES;
		default:
			throw new OssTechnicalException("Unknown RechtsformEnum " + startBizRechtsform);
		}
	}

	private Map<String, AdresseEntity> migrateStartBizDataToAddress(Userdata userdata) {
		return userdata.getDossier().getAdresse().stream().collect(
				Collectors.toMap(key -> key.getId(), value -> adresseRepo.save(convertToAdresseEntity(value))));
	}

	private Map<String, PersonEntity> migrateStartBizDataToPerson(Userdata userdata,
			Map<String, AdresseEntity> adresseMap) {
		Map<String, PersonEntity> personMap = new HashMap<>();
		for (Person person : userdata.getDossier().getPerson()) {
			PersonEntity personEntity = personRepo.save(convertToPersonEntity(person, adresseMap));
			personMap.put(person.getId(), personEntity);
			if (person.getNationalitaet().getSchweizer() != null
					&& CollectionUtils.isNotEmpty(person.getNationalitaet().getSchweizer().getHeimatort())) {
				List<PersonHeimatortEntity> personHeimatorts = convertToPersonHeimatortEntity(
						person.getNationalitaet().getSchweizer().getHeimatort());
				personHeimatorts.stream().forEach(h -> h.setPerson(personEntity));
				heimatortRepo.save(personHeimatorts);
			}
		}
		return personMap;
	}

	private CodeWertEntity findCodeWertByCategoryAndCode(KategorieEnum kategorie, String code) {
		Optional<CodeWertEntity> codewert = applicationService.getCodeWerts(kategorie).stream()
				.filter(c -> StringUtils.equalsIgnoreCase(c.getCode(), code)).findFirst();
		if (codewert.isPresent()) {
			return codewert.get();
		}
		return null;
	}

	private List<BrancheEntity> findBranchesByNames(String startBizBranche) {
		if (startBizBranche == null) {
			return Collections.emptyList();
		}
		String[] branches = StringUtils.split(startBizBranche, ";");		
		for(int i = 0; i < branches.length; i ++) {
			branches[i] = StringUtils.trimToEmpty(branches[i]);
		}
		return cacheService.getBranches().stream().filter(b -> {
			for (TextTranslationEntity translation : b.getStandardText().getTranslations()) {
				if (ArrayUtils.contains(branches, translation.getText())) {
					return true;
				}
			}
			return false;
		}).collect(Collectors.toList());
	}

	private List<BrancheEntity> findBranchesByCodes(List<Integer> startBizBranchCodes) {
		if (startBizBranchCodes == null) {
			return Collections.emptyList();
		}

		return cacheService.getBranches().stream()
				.filter(b -> startBizBranchCodes.contains(Integer.valueOf(b.getCode()))).collect(Collectors.toList());
	}

	private CodeWertEntity findGeschlecht(GeschlechtEnum startBizGeschlecht) {
		switch (startBizGeschlecht) {
		case M:
			return findCodeWertByCategoryAndCode(KategorieEnum.GESCHLECHT, OSSConstants.GESCHLECHT_MR_CODE);
		case F:
			return findCodeWertByCategoryAndCode(KategorieEnum.GESCHLECHT, OSSConstants.GESCHLECHT_MRS_CODE);
		default:
			throw new OssTechnicalException("Unknown GeschlechtEnum " + startBizGeschlecht);
		}
	}

	private CodeWertEntity findZivilstand(ZivilstandEnum startBizZivilstand) {
		switch (startBizZivilstand) {
		case LEDIG:
			return findCodeWertByCategoryAndCode(KategorieEnum.ZIVILSTAND, ZIVILSTAND_LEDIG_CODE);
		case VERHEIRATET:
			return findCodeWertByCategoryAndCode(KategorieEnum.ZIVILSTAND, ZIVILSTAND_VERHEIRATET_CODE);
		case VERWITWET:
			return findCodeWertByCategoryAndCode(KategorieEnum.ZIVILSTAND, ZIVILSTAND_VERWITWET_CODE);
		case GESCHIEDEN:
			return findCodeWertByCategoryAndCode(KategorieEnum.ZIVILSTAND, ZIVILSTAND_GESCHIEDEN_CODE);
		case GETRENNT:
			return findCodeWertByCategoryAndCode(KategorieEnum.ZIVILSTAND, ZIVILSTAND_GETRENNT_CODE);
		case PARTNERSCHAFT:
			return findCodeWertByCategoryAndCode(KategorieEnum.ZIVILSTAND, ZIVILSTAND_PARTNERSCHAFT_CODE);
		case AUFGELOEST:
			return findCodeWertByCategoryAndCode(KategorieEnum.ZIVILSTAND, ZIVILSTAND_AUFGELOEST_CODE);
		default:
			throw new OssTechnicalException("Unknown ZivilstandEnum " + startBizZivilstand);
		}
	}

	private NatTypEnum findNatTyp(NationalitaetEnum startBizNatTyp) {
		switch (startBizNatTyp) {
		case CH:
			return NatTypEnum.CH;
		case CH_PLUS:
			return NatTypEnum.CH_PLUS;
		case NON_CH:
			return NatTypEnum.NON_CH;
		default:
			throw new OssTechnicalException("Unknown NationalitaetEnum " + startBizNatTyp);
		}
	}

	private CodeWertEntity findAdrede(AnredeEnum startBizAnrede) {
		if(startBizAnrede == null) {
			return null;
		}
		switch (startBizAnrede) {
		case FRAU:
			return findCodeWertByCategoryAndCode(KategorieEnum.ANREDE, OSSConstants.ANDERE_MRS_CODE);
		case HERR:
			return findCodeWertByCategoryAndCode(KategorieEnum.ANREDE, OSSConstants.ANDERE_MR_CODE);
		case UNDEFINED:
			return null;
		default:
			throw new IllegalArgumentException("Unknown AnredeEnum: " + startBizAnrede);
		}
	}

	private List<PersonHeimatortEntity> convertToPersonHeimatortEntity(List<Buergerort> startBizBuergerorts) {
		return startBizBuergerorts.stream().map(b -> convertToPersonHeimatortEntity(b)).collect(Collectors.toList());
	}

	private PersonHeimatortEntity convertToPersonHeimatortEntity(Buergerort startBizBuergerort) {
		PersonHeimatortEntity ent = new PersonHeimatortEntity();
		ent.setOrt(startBizBuergerort.getOrt());
		ent.setPolGemeinde(startBizBuergerort.getPolGemeinde());
		ent.setBfsnr(startBizBuergerort.getBfsnr());
		ent.setKanton(startBizBuergerort.getKanton().name());
		return ent;
	}

	private List<CodeWertEntity> findCountry(List<CountryEnum> countries) {
		if (CollectionUtils.isEmpty(countries)) {
			return null;
		}
		return countries.stream().map(c -> findLandByIsoCode3(c.name())).collect(Collectors.toList());
	}

	private PersonEntity convertToPersonEntity(Person person, Map<String, AdresseEntity> adresseMap) {
		PersonEntity ent = new PersonEntity();
		ent.setGeschlecht(findGeschlecht(person.getGeschlecht()));
		ent.setAnrede(findAdrede(person.getAnrede()));
		ent.setZivilstand(findZivilstand(person.getZivilstand()));
		ent.setTitel(person.getTitel());
		ent.setFamilienname(person.getFamilienname());
		ent.setLedigname(person.getFamiliennameLedig());
		ent.setVorname(person.getVorname());
		ent.setRufname(person.getRufname());
		ent.setVornamenliste(person.getVornamenListe());
		ent.setGeburtsdatum(OSSDateUtil.toLocalDate(person.getGebDatum()));
		ent.setWohnadresse(adresseMap.get(getAdresseStartBizRef(person.getWohnadresse())));
		ent.setAhvNummer(person.getAhvnummer());
		ent.setSteuernUSA(person.isSteuerplichtigUSA());
		ent.setNatType(findNatTyp(person.getNationalitaet().getArt()));
		if (person.getNationalitaet().getAuslaender() != null) {
			ent.setEinreisedatum(OSSDateUtil.toLocalDate(person.getNationalitaet().getAuslaender().getEinreiseDatum()));
			if (person.getNationalitaet().getAuslaender().getAufenthalt() != null) {
				ent.setAuslaenderAusweis(findCodeWertByCategoryAndCode(KategorieEnum.AUSLAUSWEIS,
						person.getNationalitaet().getAuslaender().getAufenthalt().name()));
			}
		}
		ent.getNationalitaetens().addAll(findCountry(person.getNationalitaet().getZugehoerigkeit()));
		return ent;
	}

	private AdresseEntity convertToAdresseEntity(Adresse adresse) {
		if (adresse == null) {
			return null;
		}
		AdresseEntity entity = new AdresseEntity();
		entity.setEmpfaenger(adresse.getEmpfaenger());
		entity.setStrasse(adresse.getStrasse());
		entity.setHausnummer(adresse.getHausNummer());
		entity.setZusatz(adresse.getZusatz());
		entity.setPlz(adresse.getPlz());
		entity.setOrt(adresse.getOrt());
		entity.setBfsNr(adresse.getBfsnr());
		entity.setPolGemeinde(adresse.getPolGemeinde());
		entity.setKanton(adresse.getKanton().name());
		entity.setTelefon(adresse.getTelefon());
		entity.setMobile(adresse.getMobile());
		entity.setFax(adresse.getFax());
		entity.setPostfach(adresse.getPostfach());
		entity.setPostfachOrt(adresse.getPostfachOrt());
		entity.setPostfachPlz(adresse.getPostfachPLZ());
		entity.setEmail(adresse.getEmail());
		if (adresse.getLand() != CountryEnum.UNDEFINED) {
			entity.setLand(findLandByIsoCode3(adresse.getLand().name()));
		}
		return entity;
	}

	private CodeWertEntity findLandByIsoCode3(String iso3) {
		Optional<LandEntity> land = cacheService.getLands().values().stream()
				.filter(l -> l.getIso3() != null && l.getIso3().name().equalsIgnoreCase(iso3)).findFirst();
		if (!land.isPresent()) {
			return null;
		}

		Optional<CodeWertEntity> codewert = applicationService.getCodeWerts(KategorieEnum.LAND).stream()
				.filter(c -> c.getCode().equals(land.get().getBfscode())).findFirst();
		if (codewert.isPresent()) {
			return codewert.get();
		}
		return null;
	}

	private Userdata convertToUserData(String xml) {
		try {
			JAXBElement<Userdata> element = JAXBUtils.unmarshall(jaxbContext,
					XMLInputFactory.newInstance().createXMLStreamReader(new StringReader(xml)), Userdata.class);
			return element.getValue();
		} catch (JAXBException | XMLStreamException | FactoryConfigurationError e) {
			throw new OssTechnicalException("An error occurs when converting XML string to Userdata.class", e);
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		jaxbContext = JAXBContext.newInstance(Userdata.class);
	}

}
