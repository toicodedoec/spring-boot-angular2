package ch.admin.oss.portal.endpoint;

import java.util.ArrayList;
import java.util.List;

public class DashboardDto extends AbstractPaginationDashboardDto {
	private List<OrganisationShortInfoDto> organisations;

	public DashboardDto() {
		this.organisations = new ArrayList<>();
	}

	public List<OrganisationShortInfoDto> getOrganisations() {
		return organisations;
	}

	public void setOrganisations(List<OrganisationShortInfoDto> organisations) {
		this.organisations = organisations;
	}
}
