/*
 * StandardTextEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;

import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.StandardTextTypeEnum;

/**
 * @author coh
 */
@Entity
@Table(name = "T_STANDARD_TEXT", 
	uniqueConstraints = {
		@UniqueConstraint(name = "UK_STANDARD_TEXT_CODE", columnNames = {"CODE"})
	})
public class StandardTextEntity extends AbstractOSSEntity {

	@Column(name = "CODE")
	private String code;

	@Column(name = "RICH_TEXT", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean richText;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "standardText", cascade = CascadeType.ALL)
	private Set<TextTranslationEntity> translations = new HashSet<>();
	
	public StandardTextEntity() {
	}

	public StandardTextEntity(boolean richText, Set<TextTranslationEntity> translations) {
		super();
		this.richText = richText;
		this.translations = translations;
	}
	
	/**
	 * @param text
	 * @param language
	 * @param standardEntity
	 * @return
	 */
	public void addTextTranslation(String text, SupportedLanguage language) {
		TextTranslationEntity translation = new TextTranslationEntity();
		translation.setText(text);
		translation.setLanguage(language);
		translation.setStandardText(this);
		this.getTranslations().add(translation);
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public boolean isRichText() {
		return richText;
	}

	public void setRichText(boolean richText) {
		this.richText = richText;
	}

	public void setTranslations(Set<TextTranslationEntity> translations) {
		this.translations = translations;
	}

	public Set<TextTranslationEntity> getTranslations() {
		return translations;
	}

	public StandardTextTypeEnum getType() {
		return richText ? StandardTextTypeEnum.RICH : StandardTextTypeEnum.SIMPLE;
	}
	
	public String textTranslation(SupportedLanguage language) {
		Optional<TextTranslationEntity> textTranslation = getTranslations()
			.stream().filter(t -> t.getLanguage() == language)
			.findFirst();
		if (textTranslation.isPresent()) {
			return textTranslation.get().getText();
		}
		return null;
	}
}
