package ch.admin.oss;

import org.springframework.boot.SpringApplication;

public class BusinessServiceEndpointApplication {
	public static void main(String[] args) {
		SpringApplication.run(BusinessServiceEndpointConfig.class, args);
	}
}
