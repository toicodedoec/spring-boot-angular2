package ch.admin.oss.common.dto;

import ch.admin.oss.enums.SignResultEnum;

public class DigitalSignatureDto {
	private String digitalSignees;
	private SignResultEnum signResult;
	
	public DigitalSignatureDto() {		
		this.signResult = SignResultEnum.NORMAL;
	}

	public DigitalSignatureDto(SignResultEnum signResult) {		
		this.signResult = signResult;
	}

	public String getDigitalSignees() {
		return digitalSignees;
	}

	public void setDigitalSignees(String digitalSignees) {
		this.digitalSignees = digitalSignees;
	}

	public SignResultEnum getSignResult() {
		return signResult;
	}

	public void setSignResult(SignResultEnum signResult) {
		this.signResult = signResult;
	}

}
