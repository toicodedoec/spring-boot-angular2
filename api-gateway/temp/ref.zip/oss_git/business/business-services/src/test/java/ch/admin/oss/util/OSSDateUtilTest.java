/*
 * OSSDateUtilTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author hhg
 *
 */
public class OSSDateUtilTest {
	
	@Test
	public void testFormat() {
		Assert.assertNull(OSSDateUtil.format(null));
		
		Calendar calendar = Calendar.getInstance();
		calendar.set(2016, 10-1, 25);
		Assert.assertEquals("25.10.2016", OSSDateUtil.format(calendar.getTime()));
	}

	@Test
	public void testConvertToLocalDate() {
		Date date = null;
		LocalDate localDate = null;
		
		localDate = OSSDateUtil.toLocalDate(date);
		Assert.assertNull(localDate);
		
		Calendar calendar = Calendar.getInstance();
		calendar.set(2016, 10-1, 25);
		date = calendar.getTime();
		localDate = OSSDateUtil.toLocalDate(date);
		Assert.assertNotNull(localDate);
		Assert.assertEquals("25.10.2016", localDate.format(OSSConstants.LOCAL_DATE_FORMATTER));
	}
	
	@Test
	public void testConvertToDate() {
		Date date = null;
		LocalDate localDate = null;;
		
		date = OSSDateUtil.toDate(localDate);
		Assert.assertNull(date);
		
		localDate = LocalDate.of(2016, 10, 25);
		date = OSSDateUtil.toDate(localDate);
		Assert.assertNotNull(date);
		Assert.assertEquals("25.10.2016", OSSDateUtil.format(date));
	}
}
