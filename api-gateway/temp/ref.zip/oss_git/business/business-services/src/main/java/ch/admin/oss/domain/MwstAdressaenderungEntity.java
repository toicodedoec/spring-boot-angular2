/*
 * MwstAdressaenderungEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.ProzessTypEnum;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_MWST_ADRESSAENDERUNG")
public class MwstAdressaenderungEntity extends AbstractOSSEntity {

	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name="FK_MWST_ADRESS_PROZESS"))
	private ProzessEntity prozess;
	
	/**
	 * Company UID
	 */
	@NotNull
	@Column(name = "MWSTNR")
	private String mwstNr;
	
	/**
	 * Current company name
	 */
	@NotNull
	@Column(name = "NAME_BISHER")
	private String nameBisher;
	
	/**
	 * Current company address
	 */
	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE_BISHER", foreignKey = @ForeignKey(name="FK_MWST_ADRESSE_BISHER"))
	private AdresseEntity adresseBisher;
	
	/**
	 * The date when the new address becomes valid
	 */
	@NotNull
	@Column(name = "GUELTIGAB")
	private LocalDate gueltigAb;
	
	/**
	 * Company new name
	 */
	@NotNull
	@Column(name = "NAME_NEU")
	private String nameNeu;
	
	/**
	 * Company new address
	 */
	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE_NEU", foreignKey = @ForeignKey(name="FK_MWST_ADRESSE_NEU"))
	private AdresseEntity adresseNeu;
	
	/**
	 * Address of the contact person
	 */
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE_KORRESPONDENZ", foreignKey = @ForeignKey(name="FK_MWST_ADRESSE_KOR"))
	private AdresseEntity adresseKorrespondenz;
	
	/**
	 * Name of the owner (only for Einzelfirma)
	 */
	@Column(name = "NAME_OWNER")
	private String nameOwner;

	/**
	 * Address of the owner (only for Einzelfirma)
	 */
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE_OWNER", foreignKey = @ForeignKey(name="FK_MWST_ADRESSE_OWNER"))
	private AdresseEntity adresseOwner;
	
	public MwstAdressaenderungEntity() {
		prozess = new ProzessEntity(ProzessTypEnum.MWST_ADRESSAENDERUNG, false);
	}

	public ProzessEntity getProzess() {
		return prozess;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	public String getMwstNr() {
		return mwstNr;
	}

	public void setMwstNr(String mwstNr) {
		this.mwstNr = mwstNr;
	}

	public String getNameBisher() {
		return nameBisher;
	}

	public void setNameBisher(String nameBisher) {
		this.nameBisher = nameBisher;
	}

	public AdresseEntity getAdresseBisher() {
		return adresseBisher;
	}

	public void setAdresseBisher(AdresseEntity adresseBisher) {
		this.adresseBisher = adresseBisher;
	}

	public LocalDate getGueltigAb() {
		return gueltigAb;
	}

	public void setGueltigAb(LocalDate gueltigAb) {
		this.gueltigAb = gueltigAb;
	}

	public String getNameNeu() {
		return nameNeu;
	}

	public void setNameNeu(String nameNeu) {
		this.nameNeu = nameNeu;
	}

	public AdresseEntity getAdresseNeu() {
		return adresseNeu;
	}

	public void setAdresseNeu(AdresseEntity adresseNeu) {
		this.adresseNeu = adresseNeu;
	}

	public AdresseEntity getAdresseKorrespondenz() {
		return adresseKorrespondenz;
	}

	public void setAdresseKorrespondenz(AdresseEntity adresseKorrespondenz) {
		this.adresseKorrespondenz = adresseKorrespondenz;
	}

	public String getNameOwner() {
		return nameOwner;
	}

	public void setNameOwner(String nameOwner) {
		this.nameOwner = nameOwner;
	}

	public AdresseEntity getAdresseOwner() {
		return adresseOwner;
	}

	public void setAdresseOwner(AdresseEntity adresseOwner) {
		this.adresseOwner = adresseOwner;
	}
}
