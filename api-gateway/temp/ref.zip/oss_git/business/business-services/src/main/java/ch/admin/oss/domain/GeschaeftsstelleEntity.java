/*
 * GeschaeftsstelleEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;

/**
 *  
 * @author coh
 */
@Audited
@Entity
@Table(name = "T_GESCHAEFTSSTELLE")
public class GeschaeftsstelleEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name="FK_GESCHAEFTSSTELLE_ORGA"))
	private OrganisationEntity organisation;
	
	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE", foreignKey = @ForeignKey(name="FK_GESCHAEFTSSTELLE_ADRESSE"))
	private AdresseEntity adresse;
	
	@Column(name = "IN_HR", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean inHR;
	
	@Column(name = "ANZ_ANGESTELLTE")
	private int anzAngestellte;

	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public AdresseEntity getAdresse() {
		return adresse;
	}

	public void setAdresse(AdresseEntity adresse) {
		this.adresse = adresse;
	}

	public boolean isInHR() {
		return inHR;
	}

	public void setInHR(boolean inHR) {
		this.inHR = inHR;
	}

	public int getAnzAngestellte() {
		return anzAngestellte;
	}

	public void setAnzAngestellte(int anzAngestellte) {
		this.anzAngestellte = anzAngestellte;
	}
}
