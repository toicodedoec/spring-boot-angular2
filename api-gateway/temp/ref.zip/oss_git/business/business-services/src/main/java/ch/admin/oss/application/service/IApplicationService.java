/*
 * IApplicationService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.application.service;

import java.util.List;
import java.util.Map;

import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.FlowHistoryEntity;
import ch.admin.oss.domain.HrAmtEntity;
import ch.admin.oss.domain.LandEntity;

/**
 * API for common functions.
 * 
 * @author xdg
 */
public interface IApplicationService {

	Map<KategorieEnum, List<CodeWertEntity>> getCodeWerts(List<KategorieEnum> kategories);
	
	List<CodeWertEntity> getCodeWerts(KategorieEnum kategorie);
	
	CodeWertEntity getCodeWert(Long id);
	
	List<BrancheEntity> getBranches(List<Long> ids);
	
	BerufEntity getBeruf(Long id);

	List<CHOrtEntity> getCHOrts(List<Long> ids);
	
	List<String> getKantons();

	FlowHistoryEntity saveFlowHistory(FlowHistoryEntity entity);

	FlowHistoryEntity getFlowHistory(Long id);
	
	String getTranslation(String code);

	String getTranslation(String code, SupportedLanguage lang);
	
	Map<String, String> getTranslation(List<String> codes, SupportedLanguage lang);

	String getTranslation(String code, String[] params, Object[] values);
	
	String getTranslation(String code, String[] params, Object[] values, SupportedLanguage lang);

	String getTranslation(Enum<?> value);

	String getTranslation(Enum<?> value, SupportedLanguage lang);

	HrAmtEntity getHrAmtByDomizilBfsnr(int bfsNr);
	
	HrAmtEntity getChHrAmt();
	
	long countAllOrgs();
	
	long countAllUsers();
	
	long countOrgsInLastYear();
	
	long countUsersInLastYear();
	
	AusgleichskasseEntity findDefaultAusleichskasseInKanton(String kanton, String ort, String plz);

	LandEntity getLand(CodeWertEntity country);
}
