package ch.admin.oss.moa.endpoint;

public class MwstMoaUserDataAddressDto {

	private String street;

	private String buildingNum;

	private String streetAddOn;

	private String country;

	private String name;

	private MwstMoaUserDataAddressLocationDto location;

	private String phone;

	private String fax;

	private String mobile;

	private String mail;

	private String url;

	private String poBox;

	private String co;

	public MwstMoaUserDataAddressDto() {
		streetAddOn = null;
		name = null;
		url = null;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getBuildingNum() {
		return buildingNum;
	}

	public void setBuildingNum(String buildingNum) {
		this.buildingNum = buildingNum;
	}

	public String getStreetAddOn() {
		return streetAddOn;
	}

	public void setStreetAddOn(String streetAddOn) {
		this.streetAddOn = streetAddOn;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public MwstMoaUserDataAddressLocationDto getLocation() {
		return location;
	}

	public void setLocation(MwstMoaUserDataAddressLocationDto location) {
		this.location = location;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getPoBox() {
		return poBox;
	}

	public void setPoBox(String poBox) {
		this.poBox = poBox;
	}

	public String getCo() {
		return co;
	}

	public void setCo(String co) {
		this.co = co;
	}

}
