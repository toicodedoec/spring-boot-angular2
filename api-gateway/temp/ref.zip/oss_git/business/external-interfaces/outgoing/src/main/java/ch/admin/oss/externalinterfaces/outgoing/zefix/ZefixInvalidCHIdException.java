/*
 * ZefixInvalidCHIdException
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

/**
 * This exception is thrown when getting company detail by CHId via Zefix webservice 
 * and Zefix returned an error code which represents the CHId is invalid format.
 * 
 * @author hhg
 *
 */
public class ZefixInvalidCHIdException extends Exception {

	private static final long serialVersionUID = -5136568613540025506L;

	public ZefixInvalidCHIdException(String string) {
		super(string);
	}
}
