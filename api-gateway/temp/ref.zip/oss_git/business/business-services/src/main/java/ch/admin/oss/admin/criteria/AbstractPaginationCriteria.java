/*
 * FunktionRecheDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.criteria;

import com.querydsl.jpa.impl.JPAQuery;

/**
 * @author hha
 */
public class AbstractPaginationCriteria {

	private int offset;
	private int limit;

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public <E> JPAQuery<E> applyPaginationToQuery(JPAQuery<E> query) {
		int offset = this.offset * limit;
		return query.offset(offset).limit(limit); 
	}
}
