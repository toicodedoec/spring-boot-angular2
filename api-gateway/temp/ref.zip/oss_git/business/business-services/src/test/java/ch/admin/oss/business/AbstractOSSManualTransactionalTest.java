/*
 * AbstractOSSTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.application.service.ICacheService;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.FunktionEnum;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.QUserEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.portal.repository.IUserRepository;
import ch.admin.oss.security.AuthorizedOrganisation;
import ch.admin.oss.security.AuthorizedPermission;
import ch.admin.oss.security.OssRole;
import ch.admin.oss.security.OssUser;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSDateUtil;

/**
 * @author coh
 *
 */
public class AbstractOSSManualTransactionalTest {
	
	protected static final String USER_FAMILY_NAME = "PERF USER";

	@Autowired
	private PlatformTransactionManager transactionManager;

	@PersistenceContext
	protected EntityManager em;

	@Autowired
	protected ICacheService cacheService;
	@Autowired
	protected IApplicationService applicationService;
	@Autowired
	protected IUserRepository userRepo;

	protected void login(String key) {
		UserEntity user = findOrCreateUser(key);

		OssUser ossUser = new OssUser(user.getId(), user.getEid(),
			Arrays.asList(OssRole.values()).stream().map(role -> new SimpleGrantedAuthority(role.name())).collect(Collectors.toList()),
			SupportedLanguage.EN,
			new HashSet<>(),
			new HashSet<>(Arrays.asList(FunktionEnum.values())),
			user.getEmail(),
			false,
			user.getVorname(),
			user.getFamilienname()
		);

		SecurityContextHolder.getContext()
			.setAuthentication(new PreAuthenticatedAuthenticationToken(ossUser, "N/A", ossUser.getAuthorities()));
	}

	protected UserEntity findOrCreateUser(String key) {
		String userId = "U" + key;
		UserEntity user = userRepo.findOne(QUserEntity.userEntity.eid.eq(userId));
		if (user == null) {
			user = new UserEntity();
			user.setEid(userId);
			user.setEmail("hha@elca.vn");
			user.setFamilienname(USER_FAMILY_NAME);
			user.setVorname(key);
			user.setLanguage(SupportedLanguage.EN);
			user.setCreatedTimeStamp(LocalDateTime.now());
			user = userRepo.saveAndFlush(user);
		}
		return user;
	}

	protected void execute(Consumer<TransactionStatus> consumer) {
		TransactionTemplate transactionTemplate = new TransactionTemplate(
			transactionManager, new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW)
		);
		transactionTemplate.execute(new TransactionCallback<Void>() {
			@Override
			public Void doInTransaction(TransactionStatus status) {
				consumer.accept(status);
				return null;
			}
		});
	}

	public void addUserAuthorizedCompany(String defaultOrgName, OrganisationEntity organisationEntity) {
		OssUser user = SecurityUtil.currentUser();
		ZugriffEntity zugriff = organisationEntity.getZugrrifs().iterator().next();
		user.addAuthorizedCompany(
			new AuthorizedOrganisation(zugriff.getUser().getEid(), 
					zugriff.getOrganisation().getId(),
					organisationEntity.getDomizil().getId(),
					defaultOrgName,
				new AuthorizedPermission(zugriff.getAccessLevel(), zugriff.getStatus(),
					OSSDateUtil.toDate(zugriff.getFromDate()),
					OSSDateUtil.toDate(zugriff.getToDate()))));
		SecurityUtil.updateCurrentUser(user);
	}

}
