/*
 * OSSDateUtilTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author hhg
 */
public class NumberUtilTest {

	@Test
	public void testNumberOfDecimals() {
		Assert.assertTrue(NumberUtil.hasAsMostNumberOfDecimal(155.000, 2));
		Assert.assertTrue(NumberUtil.hasAsMostNumberOfDecimal(214.01, 2));
		Assert.assertTrue(NumberUtil.hasAsMostNumberOfDecimal(142.10, 2));
		Assert.assertTrue(NumberUtil.hasAsMostNumberOfDecimal(341.220, 2));
		Assert.assertTrue(NumberUtil.hasAsMostNumberOfDecimal(232.99, 2));
		Assert.assertTrue(NumberUtil.hasAsMostNumberOfDecimal(113.09, 2));
		Assert.assertTrue(NumberUtil.hasAsMostNumberOfDecimal(325.12, 2));
		Assert.assertTrue(NumberUtil.hasAsMostNumberOfDecimal(451.01, 2));
		
		Assert.assertFalse(NumberUtil.hasAsMostNumberOfDecimal(155.121, 2));
		Assert.assertFalse(NumberUtil.hasAsMostNumberOfDecimal(214.012, 2));
		Assert.assertFalse(NumberUtil.hasAsMostNumberOfDecimal(1.0 / 3, 2));
		Assert.assertFalse(NumberUtil.hasAsMostNumberOfDecimal(232.9900000001, 2));
		Assert.assertFalse(NumberUtil.hasAsMostNumberOfDecimal(341.221, 2));
	}
	
	@Test
	public void testIntegerNumber() {
		Assert.assertTrue(NumberUtil.isInteger(155.0));
		Assert.assertTrue(NumberUtil.isInteger(155d));
		Assert.assertTrue(NumberUtil.isInteger(155.00));
		
		Assert.assertFalse(NumberUtil.isInteger(155.000000001));
		Assert.assertFalse(NumberUtil.isInteger(155.01));
		Assert.assertFalse(NumberUtil.isInteger(155.9));
	}

}
