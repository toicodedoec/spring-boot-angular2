/*
 * PersonlicheAngaben
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author hhg
 *
 */
public class PersonlicheAngabenDto {

	private String address;
	private String name;
	private String givenName;
	private LocalDate dateOfBirth;
	private String ahv;
	private String maritalStatus;
	private String children;
	private String placeOfOrigin;
	private String nationalities;
	private AddressDto residence;
	private String phone;
	private String prevOccupation;
	private String prevCompensation;
	private LocalDate from;
	private LocalDate to;
	private BigDecimal prevIncome;
	private String vak;
	private String union;
	private String mitarbeit;
	private String mitarbeitRolle;
	private String mitarbeitBezeichnung;
	private String mitarbeitName;
	private String mitarbeitStrasse;
	private String mitarbeitPlzOrt;

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGivenName() {
		return givenName;
	}
	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getAhv() {
		return ahv;
	}
	public void setAhv(String ahv) {
		this.ahv = ahv;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getChildren() {
		return children;
	}
	public void setChildren(String children) {
		this.children = children;
	}
	public String getPlaceOfOrigin() {
		return placeOfOrigin;
	}
	public void setPlaceOfOrigin(String placeOfOrigin) {
		this.placeOfOrigin = placeOfOrigin;
	}
	public String getNationalities() {
		return nationalities;
	}
	public void setNationalities(String nationalities) {
		this.nationalities = nationalities;
	}
	public AddressDto getResidence() {
		return residence;
	}
	public void setResidence(AddressDto residence) {
		this.residence = residence;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPrevOccupation() {
		return prevOccupation;
	}
	public void setPrevOccupation(String prevOccupation) {
		this.prevOccupation = prevOccupation;
	}
	public String getPrevCompensation() {
		return prevCompensation;
	}
	public void setPrevCompensation(String prevCompensation) {
		this.prevCompensation = prevCompensation;
	}
	public LocalDate getFrom() {
		return from;
	}
	public void setFrom(LocalDate from) {
		this.from = from;
	}
	public LocalDate getTo() {
		return to;
	}
	public void setTo(LocalDate to) {
		this.to = to;
	}
	public BigDecimal getPrevIncome() {
		return prevIncome;
	}
	public void setPrevIncome(BigDecimal prevIncome) {
		this.prevIncome = prevIncome;
	}
	public String getVak() {
		return vak;
	}
	public void setVak(String vak) {
		this.vak = vak;
	}
	public String getUnion() {
		return union;
	}
	public void setUnion(String union) {
		this.union = union;
	}
	public String getMitarbeit() {
		return mitarbeit;
	}
	public void setMitarbeit(String mitarbeit) {
		this.mitarbeit = mitarbeit;
	}
	public String getMitarbeitRolle() {
		return mitarbeitRolle;
	}
	public void setMitarbeitRolle(String mitarbeitRolle) {
		this.mitarbeitRolle = mitarbeitRolle;
	}
	public String getMitarbeitBezeichnung() {
		return mitarbeitBezeichnung;
	}
	public void setMitarbeitBezeichnung(String mitarbeitBezeichnung) {
		this.mitarbeitBezeichnung = mitarbeitBezeichnung;
	}
	public String getMitarbeitName() {
		return mitarbeitName;
	}
	public void setMitarbeitName(String mitarbeitName) {
		this.mitarbeitName = mitarbeitName;
	}
	public String getMitarbeitStrasse() {
		return mitarbeitStrasse;
	}
	public void setMitarbeitStrasse(String mitarbeitStrasse) {
		this.mitarbeitStrasse = mitarbeitStrasse;
	}
	public String getMitarbeitPlzOrt() {
		return mitarbeitPlzOrt;
	}
	public void setMitarbeitPlzOrt(String mitarbeitPlzOrt) {
		this.mitarbeitPlzOrt = mitarbeitPlzOrt;
	}
}
