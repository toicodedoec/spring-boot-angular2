/*
 * IMWSTService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.mwst.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;

import ch.admin.oss.common.IProcessService;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.MwstAbmeldungEntity;
import ch.admin.oss.domain.MwstAdressaenderungEntity;
import ch.admin.oss.domain.MwstAnmeldungEntity;
import ch.admin.oss.domain.MwstEintrBestEntity;
import ch.admin.oss.domain.MwstFristverlangerungEntity;
import ch.admin.oss.domain.OrganisationEntity;

/**
 * @author hha
 */
@Validated
public interface IMWSTService extends IProcessService<MwstAnmeldungEntity> {

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	MwstFristverlangerungEntity createMwstFirstverlangerung(MwstFristverlangerungEntity entity, long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	MwstFristverlangerungEntity getMwstFristverlangerung(long prozessId, long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<AdresseEntity> getMwstAdressaenderungAdresseKorrespondenzByOrgId(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<AdresseEntity> getMwstEintrBestAdresseByOrgId(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	MwstAdressaenderungEntity createMwstAdressaenderung(@Valid MwstAdressaenderungEntity entity, long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	MwstAdressaenderungEntity getMwstAdressaenderungByProzessId(long prozessId, long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	MwstAbmeldungEntity createMwstAbmeldung(@Valid MwstAbmeldungEntity entity, long orgId);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	MwstAbmeldungEntity getMwstAbmeldungByProzessId(long prozessId, long orgId);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity getOrganisation(long orgId);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	MwstEintrBestEntity createMwstEintrBest(@Valid MwstEintrBestEntity entity, long orgId);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	MwstEintrBestEntity getMwstEintrBestByProzessId(long prozessId, long orgId);

	// This method is use in the MOA context hence hence it don't to have the Authorization here.
	MwstAnmeldungEntity signProcessFromMOA(Long userId, MwstAnmeldungEntity mwstAnmeldung);
	
	// This method is use in the MOA context hence hence it don't to have the Authorization here.
	MwstAnmeldungEntity getMwstAnmeldungFromMOA(Long orgId);
}
