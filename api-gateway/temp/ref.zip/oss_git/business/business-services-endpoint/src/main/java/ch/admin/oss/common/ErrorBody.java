/*
 * ErrorBody
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

/**
 * Model of a error body to be sent to client in case error happens in the backend. Should includes at least a
 * correlation ID and the relevant error message.
 * 
 * @author phd
 */
class ErrorBody {
	String correlationId;
	String message;

	ErrorBody(String correlationId, String message) {
		this.correlationId = correlationId;
		this.message = message;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public String getMessage() {
		return message;
	}

}