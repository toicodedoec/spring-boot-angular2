/*
 * Marinfo
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.swissreg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author hhg
 *
 */
public class MarinfoDto implements Serializable {

	private static final long serialVersionUID = 1676487806857507630L;

	private String markve;
	private String marpicn;
	private String marpicrem;
	private GsgrDto gsgr;
	private List<RegadrDto> regadr = new ArrayList<>();

	public String getMarkve() {
		return markve;
	}

	public void setMarkve(String markve) {
		this.markve = markve;
	}

	public String getMarpicn() {
		return marpicn;
	}

	public void setMarpicn(String marpicn) {
		this.marpicn = marpicn;
	}

	public String getMarpicrem() {
		return marpicrem;
	}

	public void setMarpicrem(String marpicrem) {
		this.marpicrem = marpicrem;
	}

	public List<RegadrDto> getRegadr() {
		return regadr;
	}

	public GsgrDto getGsgr() {
		return gsgr;
	}

	public void setGsgr(GsgrDto gsgr) {
		this.gsgr = gsgr;
	}

	public void setRegadr(List<RegadrDto> regadr) {
		this.regadr = regadr;
	}
}
