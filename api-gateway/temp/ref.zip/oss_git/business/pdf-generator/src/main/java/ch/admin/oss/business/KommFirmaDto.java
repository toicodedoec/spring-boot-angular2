/*
 * KommFirmaDocumentDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;

/**
 * @author hha
 */
public class KommFirmaDto implements IShowAsCollection {
	
	private boolean last;
	
	private HrDto hr;

	private AddressDto domizil;
	private BigDecimal haftung;
	private String einlage;
	private String rechtsform;
	private String name;
	private String hrNummer;
	
	@Override
	public boolean isLast() {
		return last;
	}

	@Override
	public void setLast(boolean last) {
		this.last = last;
	}

	public HrDto getHr() {
		return hr;
	}

	public void setHr(HrDto hr) {
		this.hr = hr;
	}

	public AddressDto getDomizil() {
		return domizil;
	}

	public void setDomizil(AddressDto domizil) {
		this.domizil = domizil;
	}

	public BigDecimal getHaftung() {
		return haftung;
	}

	public void setHaftung(BigDecimal haftung) {
		this.haftung = haftung;
	}

	public String getEinlage() {
		return einlage;
	}

	public void setEinlage(String einlage) {
		this.einlage = einlage;
	}

	public String getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(String rechtsform) {
		this.rechtsform = rechtsform;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHrNummer() {
		return hrNummer;
	}

	public void setHrNummer(String hrNummer) {
		this.hrNummer = hrNummer;
	}

}
