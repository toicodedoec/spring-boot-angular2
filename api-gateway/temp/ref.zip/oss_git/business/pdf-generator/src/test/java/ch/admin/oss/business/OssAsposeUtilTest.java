package ch.admin.oss.business;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.time.DateUtils;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.aspose.words.ControlChar;
import com.aspose.words.Document;

import ch.admin.oss.OssPdfConfig;
import ch.admin.oss.generator.aspose.OssAsposeContext;
import ch.admin.oss.generator.aspose.converter.OssAsposeConverter;
import ch.admin.oss.util.OssAsposeUtil;

@ActiveProfiles("unittest")
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = OssPdfConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Ignore
public class OssAsposeUtilTest {

	private OssAsposeContext context;

	@Before
	public void init() {
		context = new OssAsposeContext();
		context.register(Date.class, new OssAsposeConverter<Date>() {
			@Override
			public Object convert(OssAsposeContext context, Date value) {
				if (value == null) {
					return value;
				}
				return null;
			}
		});
	}

	@Test
	public void testGenerateFromRootObject_EN() throws Exception {
		this.testGenerateFromRootObject("EN");
	}

	@Test
	public void testGenerateFromRootObject_DE() throws Exception {
		this.testGenerateFromRootObject("DE");
	}

	@Test
	public void testGenerateFromRootObjects_EN() throws Exception {
		this.testGenerateFromRootObjects("EN");
	}

	@Test
	public void testGenerateFromRootObjects_DE() throws Exception {
		this.testGenerateFromRootObjects("DE");
	}

	@Test
	public void testCombineDocuments() throws Exception {
		List<String> files = Arrays.asList("EF_01_Info_de.docx", "EF_02_Header_de.docx", "EF_03_Data_de.docx",
			"EF_04_Owner_de.docx", "EF_05_Signatory_de.docx");
		List<Document> documents = new ArrayList<>();
		files.stream().skip(1).forEach(file -> {
			try {
				documents.add(new Document(this.getClass().getClassLoader().getResourceAsStream("aspose/" + file)));
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
		Document target = new Document(this.getClass().getClassLoader().getResourceAsStream("aspose/" + files.get(0)));
		OssAsposeUtil.combineDocuments(target, documents);

		target.save("D:/combined_files" + "_" + DateUtils.toCalendar(new Date()).getTimeInMillis() + ".pdf");
	}

	public void testGenerateFromRootObject(String language) throws Exception {
		Document doc = new Document(
			this.getClass().getClassLoader().getResourceAsStream("aspose/oneRootTemplate.docx"));

		OssAsposeUtil.merge(doc, context, generateData());

		doc.save("D:/oneRoot_generated_" + language + "_" + DateUtils.toCalendar(new Date()).getTimeInMillis() + ".pdf");
	}

	public void testGenerateFromRootObjects(String language) throws Exception {
		Document doc = new Document(
			this.getClass().getClassLoader().getResourceAsStream("aspose/multipleRootTemplate.docx"));

		List<TemplateDto> dtos = new ArrayList<>();
		dtos.add(generateData());
		dtos.add(generateData());
		dtos.add(generateData());
		
		dtos.get(0).setFirst(true);
		dtos.get(dtos.size() - 1).setLast(true);

		OssAsposeUtil.merge(doc, context, dtos);

		doc.save("D:/aa/multipleRoot_generated_" + language + "_" + DateUtils.toCalendar(new Date()).getTimeInMillis() + ".docx");
	}

	private TemplateDto generateData() {
		TemplateDto item = new TemplateDto();

		item.setUser(new UserDetail("HHA FN", "HHA LN"));
		item.setTelefon("+84 905396123");
		item.setStrasse("HHA Strasess");
		item.setHausnr("HHA Hau");
		item.setPostfach("HHA Post");
		item.setHomePage("http://google.com");
		item.setPlz("HHA Plz");
		item.setOrt("HH Ort");

		item.setContracts(generateContracts());
		item.setInformations(generateInformations());
		return item;
	}

	private List<Information> generateInformations() {
		List<Information> informations = new ArrayList<>();
		Information information = new Information();
		information.setVerband(10000);
		information.setBvg(DateUtils.addDays(new Date(), 2));
		information.setInnerInfos(createInnerInfos(4));

		informations.add(information);
		information = new Information();
		information.setVerband(10001);
		information.setBvg(DateUtils.addDays(new Date(), 3));
		information.setInnerInfos(createInnerInfos(5));
		informations.add(information);

		information = new Information();
		information.setVerband(10002);
		information.setBvg(DateUtils.addDays(new Date(), 4));
		information.setInnerInfos(createInnerInfos(2));
		informations.add(information);
		return informations;
	}

	private List<Contract> generateContracts() {
		List<Contract> contracts = new ArrayList<>();
		Contract contract = new Contract();
		contract.setGivenName("GV 1");
		contract.setName("NV 1");
		contracts.add(contract);

		contract = new Contract();
		contract.setGivenName("GV 2");
		contract.setName("NV 2");
		contracts.add(contract);

		contract = new Contract();
		contract.setGivenName("GV 3");
		contract.setName("NV 3");
		contracts.add(contract);
		return contracts;
	}

	private Set<InnerInfo> createInnerInfos(int index) {
		Set<InnerInfo> innerInfos = new LinkedHashSet<>();
		for (int i = 1; i <= index; i++) {
			InnerInfo innerInfo = new InnerInfo();
			innerInfo.setName("INNER " + i);
			innerInfo.setValue("VALUE " + i);
			innerInfos.add(innerInfo);
		}
		return innerInfos;
	}

	public static class Contract {

		private String givenName;
		private String name;

		public String getGivenName() {
			return givenName;
		}

		public void setGivenName(String givenName) {
			this.givenName = givenName;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
	}

	public static class Information {

		public long verband;
		public Date bvg;
		private Set<InnerInfo> innerInfos;

		public long getVerband() {
			return verband;
		}

		public void setVerband(long verband) {
			this.verband = verband;
		}

		public Date getBvg() {
			return bvg;
		}

		public void setBvg(Date bvg) {
			this.bvg = bvg;
		}

		public Set<InnerInfo> getInnerInfos() {
			return innerInfos;
		}

		public void setInnerInfos(Set<InnerInfo> innerInfos) {
			this.innerInfos = innerInfos;
		}
	}

	public static class InnerInfo {
		private String name;
		private String value;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}
	}

	public static class UserDetail {
		public String firstName;
		public String lastName;

		public UserDetail(String firstName, String lastName) {
			this.firstName = firstName;
			this.lastName = lastName;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
	}

	public static class TemplateDto {
		
		private String breakPage = ControlChar.LINE_BREAK;

		private boolean first;
		private boolean last;

		private UserDetail user;
		private String telefon;
		private String postfach;
		private String strasse;
		private String hausnr;
		private String homePage;
		private String plz;
		private String ort;

		private List<Contract> contracts;
		private List<Information> informations;

		public boolean isFirst() {
			return first;
		}

		public void setFirst(boolean first) {
			this.first = first;
		}

		public boolean isLast() {
			return last;
		}

		public void setLast(boolean last) {
			this.last = last;
		}

		public UserDetail getUser() {
			return user;
		}

		public void setUser(UserDetail user) {
			this.user = user;
		}

		public String getTelefon() {
			return telefon;
		}

		public void setTelefon(String telefon) {
			this.telefon = telefon;
		}

		public String getPostfach() {
			return postfach;
		}

		public void setPostfach(String postfach) {
			this.postfach = postfach;
		}

		public String getStrasse() {
			return strasse;
		}

		public void setStrasse(String strasse) {
			this.strasse = strasse;
		}

		public String getHausnr() {
			return hausnr;
		}

		public void setHausnr(String hausnr) {
			this.hausnr = hausnr;
		}

		public String getHomePage() {
			return homePage;
		}

		public void setHomePage(String homePage) {
			this.homePage = homePage;
		}

		public String getPlz() {
			return plz;
		}

		public void setPlz(String plz) {
			this.plz = plz;
		}

		public String getOrt() {
			return ort;
		}

		public void setOrt(String ort) {
			this.ort = ort;
		}

		public List<Contract> getContracts() {
			return contracts;
		}

		public void setContracts(List<Contract> contracts) {
			this.contracts = contracts;
		}

		public List<Information> getInformations() {
			return informations;
		}

		public void setInformations(List<Information> informations) {
			this.informations = informations;
		}

		public String getBreakPage() {
			return breakPage;
		}

		public void setBreakPage(String breakPage) {
			this.breakPage = breakPage;
		}
		
	}
}
