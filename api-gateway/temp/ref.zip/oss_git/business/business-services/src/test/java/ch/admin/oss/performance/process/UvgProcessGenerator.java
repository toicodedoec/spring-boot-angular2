/*
 * GenerateDataTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.performance.process;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.stereotype.Component;

import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.KontotypEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.common.enums.VersichererWunschEnum;
import ch.admin.oss.common.enums.ZahlungszweckEnum;
import ch.admin.oss.domain.KontoEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.UvgAnmeldungEntity;
import ch.admin.oss.domain.UvgGesellschafterEntity;
import ch.admin.oss.uvg.service.IUVGService;

/**
 * @author hha
 */
@Component
public class UvgProcessGenerator extends ProcessGenerator<UvgAnmeldungEntity, IUVGService> {
	
	@Override
	public UvgAnmeldungEntity generate(UvgAnmeldungEntity entity) {
		entity.setAngestellteHeute(BigDecimal.valueOf(1000));
		entity.setErsteAnstellung(LocalDate.now());

		OrganisationEntity organisation = entity.getProzess().getOrganisation();
		RechtsformEnum rechtsform = organisation.getRechtsform();
		if (rechtsform == RechtsformEnum.EINZELFIRMA) {
			entity.setAngestellteZukunft(BigDecimal.valueOf(1000));
			entity.setErsteAnstellungZukunft(LocalDate.now());
			
			entity.setAngestelltePartner(true);
			entity.setAngestellteFamilie(true);
		} else {
			entity.setAngestellteGesellschafter(true);
		}

		entity.setAngestellteLehrling(true);
		entity.setAngestellteOhneLohn(true);
		entity.setAngestellteAushilfe(true);
		entity.setUvgInhaberFreiwillig(true);

		entity.setLohnsumme(BigDecimal.valueOf(1000));
		entity.setLohnsummeFolgejahr(BigDecimal.valueOf(1000));
		entity.setZahlungsmodus(dataHelper.getZahlungsmodus());
		
		entity.setAhvName("AHV Test Name");
		entity.setAhvNummer("123");

		entity.setVersicherungName("Versich Name");
		entity.setVersicherungNummer("999");
		
		entity.setBemerkungen("Test");
		entity.setKontaktName("KName");
		entity.setKontaktVorname("KVName");
		
		entity.setKontaktAdresse(dataHelper.createAddress());
		entity.setPartnerName("PName");
		entity.setPartnerLohnsumme(BigDecimal.valueOf(1000));

		entity.setPartnerFreiwillig(true);
		entity.setAngehoerigeLohnsumme(BigDecimal.valueOf(1000));
		entity.setAngehoerigeAnzahl(BigDecimal.valueOf(1000));
		
		entity.setAngehoerigeFreiwillig(true);
		entity.setGlAnzahl(1000);
		entity.setGlLohnsumme(BigDecimal.valueOf(1000));
		entity.setVrLohnsumme(BigDecimal.valueOf(1000));
		entity.setVersichererWunsch(VersichererWunschEnum.CONTRACT);

		organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)
			.forEach(item -> entity.getGesellschafters().add(createGesellschafter(entity, item.getPerson())));

		entity.getVersicherer().addAll(cacheService.getVersicherungs().subList(1, 3));

		KontoEntity konten = new KontoEntity();
		konten.setOrganisation(organisation);
		konten.setZweck(ZahlungszweckEnum.UVG);
		konten.setTyp(KontotypEnum.NOCH);
		kontoRepository.save(konten);

		return service.completeProcess(entity);
	}

	private UvgGesellschafterEntity createGesellschafter(UvgAnmeldungEntity uvgAnmeldung, PersonEntity person) {
		UvgGesellschafterEntity uvgGesellschafter = new UvgGesellschafterEntity();
		uvgGesellschafter.setUvgAnmeldung(uvgAnmeldung);
		uvgGesellschafter.setPerson(person);
		uvgGesellschafter.setLohnsumme(BigDecimal.valueOf(500));
		return uvgGesellschafter;
	}

	@Override
	protected ProzessTypEnum getProcessType() {
		return ProzessTypEnum.UVG;
	}

}
