package ch.admin.oss.mwst.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

import ch.admin.oss.domain.MwstFristverlangerungEntity;

/**
 * 
 * @author hhu
 *
 */
public interface IMwstFristverlangerungRepository extends JpaRepository<MwstFristverlangerungEntity, Long>, QueryDslPredicateExecutor<MwstFristverlangerungEntity>{

}
