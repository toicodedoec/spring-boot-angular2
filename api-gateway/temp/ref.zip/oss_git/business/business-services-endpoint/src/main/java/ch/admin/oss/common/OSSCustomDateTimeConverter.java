/*
 * OSSCustomDateTimeConverter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;


import java.time.LocalDateTime;
import java.util.Date;

import org.dozer.DozerConverter;

import ch.admin.oss.util.OSSDateUtil;

/**
 * 
 * @author hhu
 *
 */
public class OSSCustomDateTimeConverter extends DozerConverter<Date, LocalDateTime> {

	public OSSCustomDateTimeConverter() {
		super(Date.class, LocalDateTime.class);
	}

	@Override
	public LocalDateTime convertTo(Date source, LocalDateTime destination) {
		return OSSDateUtil.toLocalDateTime(source);	
	}

	@Override
	public Date convertFrom(LocalDateTime source, Date destination) {
		return OSSDateUtil.toDate(source);
	}

}
