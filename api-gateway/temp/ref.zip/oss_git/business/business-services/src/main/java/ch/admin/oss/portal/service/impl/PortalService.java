/*
 * PortalService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.service.impl;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.application.repository.IFlowHistoryRepository;
import ch.admin.oss.common.AbstractOSSService;
import ch.admin.oss.common.enums.AccessStatusEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.EinladungEntity;
import ch.admin.oss.domain.FlowHistoryEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QAdresseEntity;
import ch.admin.oss.domain.QCHOrtEntity;
import ch.admin.oss.domain.QEinladungEntity;
import ch.admin.oss.domain.QFirmennameEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QPflichtenabklaerungenEntity;
import ch.admin.oss.domain.QProzessEntity;
import ch.admin.oss.domain.QUserEntity;
import ch.admin.oss.domain.QZugriffEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.exception.EinladungNotFoundException;
import ch.admin.oss.exception.InvitationWasExpiredException;
import ch.admin.oss.exception.UserWasAlreadyLinkedToOrganizationException;
import ch.admin.oss.organisation.repository.IEinladungRepository;
import ch.admin.oss.organisation.repository.IOrganisationRepository;
import ch.admin.oss.organisation.repository.IPflichtenabklaerungenRepository;
import ch.admin.oss.organisation.repository.IZugriffRepository;
import ch.admin.oss.portal.repository.IUserRepository;
import ch.admin.oss.portal.service.IPortalService;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.JpaUtil;
import ch.admin.oss.util.NestedProjection;

/**
 * @author tdm
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class PortalService extends AbstractOSSService implements IPortalService {

	@PersistenceContext
	private EntityManager em;

	@Autowired
	private IUserRepository userRepository;
	
	@Autowired
	private IPflichtenabklaerungenRepository pflichtenabklaerungenRepo;
	
	@Autowired
	private IEinladungRepository einladungRepo;
	
	@Autowired
	private IZugriffRepository zugriffRepo;
	
	@Autowired
	private IOrganisationRepository orgRepo;
	
	@Autowired
	private IFlowHistoryRepository flowHistoryRepo;

	@Autowired
	private JpaUtil jpaUtil;
	
	@Value("${oss.prozess.numOfFinishedProzessToDisplay}")
	private int numOfFinishedProzessToDisplay;
	
	@Value("${oss.chort.numOfAutoCompleteRecordsToDisplay}")
	private int numOfAutoCompleteRecordsToDisplay;
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public long countUser() {
		return userRepository.count();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<CHOrtEntity> getCHOrts(String ort) {
		List<CHOrtEntity> results = new JPAQuery<CHOrtEntity>(em)
			.from(QCHOrtEntity.cHOrtEntity)
			.where(QCHOrtEntity.cHOrtEntity.ort.containsIgnoreCase(ort))
			.orderBy(QCHOrtEntity.cHOrtEntity.ort.indexOf(ort.toLowerCase()).asc())		
			.offset(0)
			.limit(numOfAutoCompleteRecordsToDisplay)
			.fetch();
		
		Collections.sort(results, new Comparator<CHOrtEntity>() {

			@Override
			public int compare(CHOrtEntity o1, CHOrtEntity o2) {
				int index1 = StringUtils.indexOfIgnoreCase(o1.getOrt(), ort);
				int index2 = StringUtils.indexOfIgnoreCase(o2.getOrt(), ort);
				if(index1 == index2) {
					return o1.getOrt().compareTo(o2.getOrt());
				}
				if(index1 < index2) {
					return -1;
				}
				return 1;
			}
		});
		
		return results;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public UserEntity save(UserEntity entity) {
		return userRepository.save(entity);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public UserEntity findUserByName(String username) {
		return userRepository.findOne(QUserEntity.userEntity.eid.eq(username));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PflichtenabklaerungenEntity getPflichtenabklaerungenById(Long id) {
		return jpaUtil.initialize(pflichtenabklaerungenRepo.findOne(id),
			QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.beruf,
			QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.branches,
			QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.flowHistory.items.any().data);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PflichtenabklaerungenEntity save(PflichtenabklaerungenEntity entity) {
		if (!entity.isPersisted()) {
			FlowHistoryEntity fhe = new FlowHistoryEntity();
			flowHistoryRepo.save(fhe);
			entity.setFlowHistory(fhe);
		}
		return pflichtenabklaerungenRepo.save(entity);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PflichtenabklaerungenEntity findPflichtenabklaerungenByUsername(String username) {
		return jpaUtil.initialize(findPflichtenabklaerungenByCriteria(
			QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.user.eid.eq(username)
		), QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.flowHistory.items.any().data);
	}

	@Override
	public long countProcesses(Long orgId, boolean isOpened) {
		return new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.organisation.id.eq(orgId)
					.and(QProzessEntity.prozessEntity.status.in(isOpened == true ? ProzessStatusEnum.openStatus() 
						: ProzessStatusEnum.finishStatus())))			
			.fetchCount();
	}
	
	@Override
	public List<ProzessEntity> getProcessesSummary(List<Long> orgIds, boolean isOpened, Long offset, Long limit) {
		QProzessEntity prozess = QProzessEntity.prozessEntity;
		QOrganisationEntity organisation = new QOrganisationEntity("organisation");

		JPAQuery<ProzessEntity> query = new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity, prozess)
			.join(QProzessEntity.prozessEntity.organisation, organisation)
			.where(organisation.id.in(orgIds)
				.and(prozess.status.in(isOpened == true ? ProzessStatusEnum.openStatus() : ProzessStatusEnum.finishStatus())))
			.orderBy(prozess.bearbdatum.desc());
		
		if (limit > 0) {
			query.offset(offset).limit(limit);
		}
		
		return query.select(NestedProjection.of(ProzessEntity.class,
			prozess.id,
			prozess.bearbdatum,
			prozess.typ,
			prozess.status,
			organisation.id,
			organisation.hrStatus,
			organisation.rechtsform,
			organisation.zefixImportDate)).fetch();
	}

	/**
	 * {@inheritDoc}
	 * @throws EinladungNotFoundException 
	 */
	@Override
	public EinladungEntity getEinladungByEinladungCode(String einladungCode) throws EinladungNotFoundException {
		EinladungEntity einladungEntity = new JPAQuery<EinladungEntity>(em).from(QEinladungEntity.einladungEntity)
			.innerJoin(QEinladungEntity.einladungEntity.einladender, QUserEntity.userEntity).fetchJoin()
			.innerJoin(QEinladungEntity.einladungEntity.organisation, QOrganisationEntity.organisationEntity).fetchJoin()
			.innerJoin(QOrganisationEntity.organisationEntity.namens, QFirmennameEntity.firmennameEntity).fetchJoin()
			.where(QEinladungEntity.einladungEntity.einladungsCode.eq(einladungCode)
				.and(QFirmennameEntity.firmennameEntity.isDefault.isTrue()))
			.fetchOne();
		if(einladungEntity == null) {
			throw new EinladungNotFoundException("Can not find Einladung with einladungCode: " + einladungCode);
		}
		return einladungEntity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void deleteEinladungById(long einladungId, int version) {
		EinladungEntity einladungEntity = einladungRepo
			.findOne(QEinladungEntity.einladungEntity.id.eq(einladungId).and(QEinladungEntity.einladungEntity.version.eq(version)));
		if (einladungEntity == null) {
			throw new OptimisticLockingFailureException("Concurrent on delete Einladung id = " + einladungId);
		}
		einladungRepo.delete(einladungEntity);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ZugriffEntity createZugriffFromInvitation(long orgId, long einladungId) throws InvitationWasExpiredException, UserWasAlreadyLinkedToOrganizationException {
		EinladungEntity einladung = einladungRepo.findOne(einladungId);
		
		if(einladung.getAblauf().isBefore(LocalDate.now())) {
			throw new InvitationWasExpiredException(einladungId);
		}
		
		OrganisationEntity organisation = orgRepo.findOne(orgId);
		if (organisation == null) {
			throw new IllegalArgumentException("Invalid input: Cannot found the organisation with id = " + orgId);
		}
		
		long linkedOrgCount = new JPAQuery<ZugriffEntity>(em)
			.from(QZugriffEntity.zugriffEntity)
			.where(QZugriffEntity.zugriffEntity.organisation.id.eq(orgId)
				.and(QZugriffEntity.zugriffEntity.user.eid.eq(SecurityUtil.currentUser().getUsername())))
			.fetchCount();
		
		if (linkedOrgCount > 0) {
			throw new UserWasAlreadyLinkedToOrganizationException(SecurityUtil.currentUser().getUsername(), orgId);
		}
		
		UserEntity userEntity = userRepository.findOne(QUserEntity.userEntity.eid.eq(SecurityUtil.currentUser().getUsername()));
		ZugriffEntity zugriffEntity = new ZugriffEntity();
		zugriffEntity.setAccessLevel(einladung.getZugriffsstufe());
		zugriffEntity.setFromDate(einladung.getZugriffVon());
		zugriffEntity.setToDate(einladung.getZugriffBis());
		zugriffEntity.setOrganisation(organisation);
		zugriffEntity.setUser(userEntity);
		zugriffEntity.setStatus(AccessStatusEnum.GRANTED);
		einladungRepo.delete(einladung);
		return jpaUtil.initialize(zugriffRepo.save(zugriffEntity), QZugriffEntity.zugriffEntity.organisation.domizil);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PflichtenabklaerungenEntity findPflichtenabklaerungenByOrganisation(long orgId) {
		return findPflichtenabklaerungenByCriteria(
			QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.organisation.id.eq(orgId)
		);
	}
	
	private PflichtenabklaerungenEntity findPflichtenabklaerungenByCriteria(Predicate criteria) {
		return jpaUtil.initialize(
			new JPAQuery<PflichtenabklaerungenEntity>(em)
			.from(QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity)
			.where(criteria)
			.fetchOne(),
			QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.beruf,
			QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.beruf.standardText.translations,
			QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.branches,
			QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.branches.any().standardText.translations
		);
	}

	@Override
	public List<AdresseEntity> getAdresses(List<Long> addressIds) {
		return new JPAQuery<AdresseEntity>(em)
				.from(QAdresseEntity.adresseEntity)
				.leftJoin(QAdresseEntity.adresseEntity.land).fetchJoin()
				.where(QAdresseEntity.adresseEntity.id.in(addressIds))
				.fetch();
	}
}