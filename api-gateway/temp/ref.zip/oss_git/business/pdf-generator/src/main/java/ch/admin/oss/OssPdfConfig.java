package ch.admin.oss;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.aspose.words.License;

/**
 * Provide configuration for PDF generator.
 * 
 * @author hha
 */
@Configuration
public class OssPdfConfig {

	/**
	 * Aspose License.
	 * 
	 * @return {@link License} instance.
	 * @throws Exception
	 */
	@Bean
	public License AsposeLicense() throws Exception {
		License license = new License();
		license.setLicense(Thread.currentThread().getContextClassLoader().getResourceAsStream("aspose/Aspose.Words.lic"));
		return license;
	}

}
