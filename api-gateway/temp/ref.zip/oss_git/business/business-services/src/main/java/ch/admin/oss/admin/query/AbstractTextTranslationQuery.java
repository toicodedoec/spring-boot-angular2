package ch.admin.oss.admin.query;

import javax.persistence.EntityManager;

import com.querydsl.jpa.impl.JPAQuery;

/**
 * This is the contract class for screens that need to
 * load the text translation as well as applying the filter condition.
 *   
 * @author hhu
 */
public abstract class AbstractTextTranslationQuery <E, T> {
	
	/**
	 * Build the query based on client criteria.
	 * @param criteria
	 * @param em
	 * @return JPAQuery<T>
	 */
	public abstract JPAQuery<T> buildQuery(E criteria, EntityManager em);
}
