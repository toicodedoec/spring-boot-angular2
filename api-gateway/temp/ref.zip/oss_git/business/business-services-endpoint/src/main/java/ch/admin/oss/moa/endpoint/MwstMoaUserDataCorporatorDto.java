package ch.admin.oss.moa.endpoint;

public class MwstMoaUserDataCorporatorDto {

	private int personType;

	private MwstMoaUserDataCorporatorAddressDto address;

	private MwstMoaUserDataCorporatorPersonDto person;

	private boolean leading;

	private String uid;

	private String mwst;

	private String vatStatus;

	private boolean chDomicile;

	private boolean chRegistered;

	private boolean uidRegistered;

	private boolean hrRegistered;

	private final boolean manualInput = false;

	private final boolean uidSearch = false;

	public MwstMoaUserDataCorporatorDto() {
		uid = null;
		mwst = null;
		vatStatus = null;
		
		chDomicile = false;
		chRegistered = false;
		uidRegistered = false;
		hrRegistered = false;
	}

	public int getPersonType() {
		return personType;
	}

	public void setPersonType(int personType) {
		this.personType = personType;
	}

	public MwstMoaUserDataCorporatorAddressDto getAddress() {
		return address;
	}

	public void setAddress(MwstMoaUserDataCorporatorAddressDto address) {
		this.address = address;
	}

	public MwstMoaUserDataCorporatorPersonDto getPerson() {
		return person;
	}

	public void setPerson(MwstMoaUserDataCorporatorPersonDto person) {
		this.person = person;
	}

	public boolean isLeading() {
		return leading;
	}

	public void setLeading(boolean leading) {
		this.leading = leading;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getMwst() {
		return mwst;
	}

	public void setMwst(String mwst) {
		this.mwst = mwst;
	}

	public String getVatStatus() {
		return vatStatus;
	}

	public void setVatStatus(String vatStatus) {
		this.vatStatus = vatStatus;
	}

	public boolean isChDomicile() {
		return chDomicile;
	}

	public void setChDomicile(boolean chDomicile) {
		this.chDomicile = chDomicile;
	}

	public boolean isChRegistered() {
		return chRegistered;
	}

	public void setChRegistered(boolean chRegistered) {
		this.chRegistered = chRegistered;
	}

	public boolean isUidRegistered() {
		return uidRegistered;
	}

	public void setUidRegistered(boolean uidRegistered) {
		this.uidRegistered = uidRegistered;
	}

	public boolean isHrRegistered() {
		return hrRegistered;
	}

	public void setHrRegistered(boolean hrRegistered) {
		this.hrRegistered = hrRegistered;
	}

	public boolean isManualInput() {
		return manualInput;
	}

	public boolean isUidSearch() {
		return uidSearch;
	}
}
