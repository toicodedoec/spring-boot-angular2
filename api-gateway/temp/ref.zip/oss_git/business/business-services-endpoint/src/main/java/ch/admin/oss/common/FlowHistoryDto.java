/*
 * FlowHistoryDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.util.ArrayList;
import java.util.List;

/**
 * @author phd
 */
public class FlowHistoryDto {

	private Long id;
	private List<FlowHistoryItemDto> items = new ArrayList<FlowHistoryItemDto>();
	private String callbackURL;

	public FlowHistoryDto() {}

	public FlowHistoryDto(Long id) {
		this.id = id;
	}

	public FlowHistoryDto(Long id, String callbackURL, List<FlowHistoryItemDto> items) {
		this.id = id;
		this.items = items;
		this.callbackURL = callbackURL;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<FlowHistoryItemDto> getItems() {
		return items;
	}

	public void setItems(List<FlowHistoryItemDto> items) {
		this.items = items;
	}

	public String getCallbackURL() {
		return callbackURL;
	}

	public void setCallbackURL(String callbackURL) {
		this.callbackURL = callbackURL;
	}
}
