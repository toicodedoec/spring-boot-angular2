/*
 * OssAsposeConverter
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.generator.aspose.converter;

import ch.admin.oss.generator.aspose.OssAsposeContext;

/**
 * @author hha
 */
public interface OssAsposeConverter<T> {

	Object convert(OssAsposeContext context, T value);

	@SuppressWarnings("unchecked")
	default Object convertObject(OssAsposeContext context, Object value) {
		return convert(context, (T) value);
	}

}