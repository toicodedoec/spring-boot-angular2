package ch.admin.oss.admin.query;

import javax.persistence.EntityManager;

import com.querydsl.core.types.dsl.CaseBuilder;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.admin.criteria.BranchenCriteria;
import ch.admin.oss.common.enums.AktivFilterEnum;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.QBerufEntity;

/**
 * @author xdg
 */
public class BerufTextTranslationQuery extends AbstractTextTranslationQuery<BranchenCriteria, BerufEntity> {		

	@Override
	public JPAQuery<BerufEntity> buildQuery(BranchenCriteria criteria, EntityManager em) {
		QBerufEntity qBeruf = QBerufEntity.berufEntity;
		QBerufEntity qParentBeruf = new QBerufEntity("parent");

		JPAQuery<BerufEntity> query = new JPAQuery<BerufEntity>(em)
			.from(qBeruf)
			.leftJoin(qBeruf.parent, qParentBeruf).fetchJoin()
			.leftJoin(qBeruf.branche).fetchJoin()
			.leftJoin(qBeruf.standardText).fetchJoin()
			.orderBy(
				new CaseBuilder()
				.when(qParentBeruf.id.isNotNull()).then(qParentBeruf.pos)
				.otherwise(qBeruf.pos).asc())
			.orderBy(qParentBeruf.id.asc().nullsFirst())
			.orderBy(qBeruf.pos.asc());

		if (criteria.getStatus() == AktivFilterEnum.Unaktiv) {
			query.where(QBerufEntity.berufEntity.aktiv.eq(false));
		} else if (criteria.getStatus() == AktivFilterEnum.Aktiv) {
			query.where(QBerufEntity.berufEntity.aktiv.eq(true));
		}
		
		return query;
	}
	
	
}
