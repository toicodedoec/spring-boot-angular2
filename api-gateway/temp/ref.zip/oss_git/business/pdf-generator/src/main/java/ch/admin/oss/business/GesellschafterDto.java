/*
 * GesellschafterDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

/**
 * @author hhg
 *
 */
public class GesellschafterDto {

	private String givenName;
	private String name;
	private String city;
	private String liability;
	
	public GesellschafterDto(String givenName, String name, String city, String liability) {
		this.givenName = givenName;
		this.name = name;
		this.city = city;
		this.liability = liability;
	}

	public String getGivenName() {
		return givenName;
	}
	public String getName() {
		return name;
	}
	public String getCity() {
		return city;
	}
	public String getLiability() {
		return liability;
	}
}
