/*
 * LandingPageService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.landing.service.impl;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import ch.admin.oss.common.AbstractOSSService;
import ch.admin.oss.domain.NewsletterHitsEntity;
import ch.admin.oss.domain.QNewsletterHitsEntity;
import ch.admin.oss.landing.repository.INewsletterHitsRepository;
import ch.admin.oss.landing.service.ILandingPageService;

/**
 * @author hha
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class LandingPageService extends AbstractOSSService implements ILandingPageService {
	
	@Autowired
	private INewsletterHitsRepository newsletterHitsRepository;

	@Override
	public void trackLandingPage(String code, String campaign) {
		NewsletterHitsEntity newsletterHit = newsletterHitsRepository.findOne(
			QNewsletterHitsEntity.newsletterHitsEntity.uid.equalsIgnoreCase(code).and(
				QNewsletterHitsEntity.newsletterHitsEntity.campaign.equalsIgnoreCase(campaign))
		);
		if (newsletterHit == null) {
			newsletterHit = new NewsletterHitsEntity();
			newsletterHit.setUid(code);
			newsletterHit.setCampaign(campaign);
			newsletterHit.setTimestamp(LocalDateTime.now());
			newsletterHitsRepository.save(newsletterHit);
		}
	}

}
