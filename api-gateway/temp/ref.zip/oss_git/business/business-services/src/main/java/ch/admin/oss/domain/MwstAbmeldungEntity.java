/*
 * MwstAbmeldungEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.ProzessTypEnum;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_MWST_ABMELDUNG")
public class MwstAbmeldungEntity extends AbstractOSSEntity {

	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name="FK_MWST_AB_PROZESS"))
	private ProzessEntity prozess;
	
	/**
	 * Company UID
	 */
	@NotNull
	@Column(name = "MWSTNR")
	private String mwstNr;
	
	/**
	 * Company name
	 */
	@NotNull
	@Column(name = "NAME")
	private String name;
	
	/**
	 * Domicil address of the company
	 */
	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE", foreignKey = @ForeignKey(name="FK_MWST_AB_ADRESSE"))
	private AdresseEntity adresse;
	
	/**
	 * Name of the contact person
	 */
	@Column(name = "KONTAKT_PERSON")
	private String kontaktPerson;
	
	/**
	 * CodeWert ID (category "MWST_ABMELD_GRUND")
	 */
	@Column(name = "GRUND")
	private Long grund;

	/**
	 * Name of the successor (only if grund = MWST_ABMELD_GRUND.Uebergabe Nachfolger)
	 */
	@Column(name = "NACHFOLGER_NAME")
	private String nachfolgerName;
	
	/**
	 * Mwst nr of the successor
	 */
	@Column(name = "NACHFOLGER_MWSTNR")
	private String nachfolgerMwstNr;
	
	/**
	 * remarks
	 */
	@Column(name = "BEMERKUNGEN")
	private String bemerkungen;
	
	@Column(name = "PER_DATUM")
	private LocalDate perDatum;
	
	public MwstAbmeldungEntity() {
		prozess = new ProzessEntity(ProzessTypEnum.MWST_ABMELDUNG, false);
	}

	public ProzessEntity getProzess() {
		return prozess;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	public String getMwstNr() {
		return mwstNr;
	}

	public void setMwstNr(String mwstNr) {
		this.mwstNr = mwstNr;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AdresseEntity getAdresse() {
		return adresse;
	}

	public void setAdresse(AdresseEntity adresse) {
		this.adresse = adresse;
	}

	public String getKontaktPerson() {
		return kontaktPerson;
	}

	public void setKontaktPerson(String kontaktPerson) {
		this.kontaktPerson = kontaktPerson;
	}

	public Long getGrund() {
		return grund;
	}

	public void setGrund(Long grund) {
		this.grund = grund;
	}

	public String getNachfolgerName() {
		return nachfolgerName;
	}

	public void setNachfolgerName(String nachfolgerName) {
		this.nachfolgerName = nachfolgerName;
	}

	public String getNachfolgerMwstNr() {
		return nachfolgerMwstNr;
	}

	public void setNachfolgerMwstNr(String nachfolgerMwstNr) {
		this.nachfolgerMwstNr = nachfolgerMwstNr;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public LocalDate getPerDatum() {
		return perDatum;
	}

	public void setPerDatum(LocalDate perDatum) {
		this.perDatum = perDatum;
	}
}
