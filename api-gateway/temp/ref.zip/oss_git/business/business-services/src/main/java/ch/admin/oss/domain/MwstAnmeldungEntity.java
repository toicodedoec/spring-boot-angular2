/*
 * MwstAnmeldungEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.ProzessTypEnum;

/**
 *  
 * @author coh
 */
@Entity
@Table(name = "T_MWST_ANMELDUNG")
public class MwstAnmeldungEntity extends AbstractOSSEntity implements IProzessEntity {

	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name="FK_MWST_PROZESS"))
	private ProzessEntity prozess;
	
	@Lob
	@Column(name = "PDF1", columnDefinition = "BLOB")
	private byte[] pdf1;
	
	@Lob
	@Column(name = "PDF2", columnDefinition = "BLOB")
	private byte[] pdf2;
	
	@Lob
	@Column(name = "PDF3", columnDefinition = "BLOB")
	private byte[] pdf3;
	
	@Lob
	@Column(name = "PDF4", columnDefinition = "BLOB")
	private byte[] pdf4;
	
	public MwstAnmeldungEntity() {
		prozess = new ProzessEntity(ProzessTypEnum.MWST, true);
	}

	public ProzessEntity getProzess() {
		return prozess;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	public byte[] getPdf1() {
		return pdf1;
	}

	public void setPdf1(byte[] pdf1) {
		this.pdf1 = pdf1;
	}

	public byte[] getPdf2() {
		return pdf2;
	}

	public void setPdf2(byte[] pdf2) {
		this.pdf2 = pdf2;
	}

	public byte[] getPdf3() {
		return pdf3;
	}

	public void setPdf3(byte[] pdf3) {
		this.pdf3 = pdf3;
	}

	public byte[] getPdf4() {
		return pdf4;
	}

	public void setPdf4(byte[] pdf4) {
		this.pdf4 = pdf4;
	}
}
