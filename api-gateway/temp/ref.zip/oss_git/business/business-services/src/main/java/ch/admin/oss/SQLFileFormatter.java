/*
 * SQLFileFormatter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URISyntaxException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.hibernate.engine.jdbc.internal.DDLFormatterImpl;

/**
 * TODO [COH / V1.0.0] This class just intend to support during development phase before system go-live. It will be removed after production
 * all the migration script later will be added and format manually.  
 * 
 * An utility class in order to help to format the auto generated DDL file from Spring JPA. 
 * 
 * @author coh
 *
 */
public class SQLFileFormatter {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws URISyntaxException 
	 */
	public static void main(String[] args) throws IOException, URISyntaxException {
		try {
			// It is intend to hardcoded like this as we just interest on the file V1.0.0.001__create_base.sql
			File sqlFile = new File("D:\\projects\\oss\\app\\database\\src\\main\\resources\\sql\\V1.0.0.001__create_base.sql");

			InputStream resourceAsStream = new FileInputStream(sqlFile);
			StringWriter writer = new StringWriter();
			IOUtils.copy(resourceAsStream, writer);
			String theString = writer.toString();

			StringReader lowLevel = new StringReader(theString);
			BufferedReader highLevel = new BufferedReader(lowLevel);
			DDLFormatterImpl formatter = new DDLFormatterImpl();

			StringBuilder builder = new StringBuilder();

			highLevel.lines().forEach(x -> {
				builder.append(formatter.format(x + ";"));
			});
			
			String sqlFormatted = builder.toString();
			
			sqlFormatted = sqlFormatted.replaceAll( 
				"create sequence hibernate_sequence start with 1 increment by 1;", 
				"");
			sqlFormatted = sqlFormatted.replaceAll("    create table.*Dto(.|\\r\\n)*?\\);\\r\\n", "");
			sqlFormatted = sqlFormatted.replaceAll("    create table.*_aud(.|\\r\\n)*?\\);\\r\\n", "");
			sqlFormatted = sqlFormatted.replaceAll("    create table T_REVISION_INFO(.|\\r\\n)*?\\);\\r\\n", "");
			sqlFormatted = sqlFormatted.replaceAll("    alter table .*_aud(.|\\r\\n)*?references T_REVISION_INFO;\\r\\n", "");
			sqlFormatted = sqlFormatted.replaceAll("    alter table .*_aud(.|\\r\\n)*?references T_REVISION_INFO;", "");
		
			OutputStream outputStream = new FileOutputStream(sqlFile);
			IOUtils.write(sqlFormatted, outputStream);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
