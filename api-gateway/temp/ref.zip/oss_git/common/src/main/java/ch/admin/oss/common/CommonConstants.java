/*
 * CommonConstants
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

public final class CommonConstants {
	
	public static final String PROFILE_TEST = "unittest";
	public static final String PROFILE_TEST_PERFORMANCE_DATA = "perfgen";

	public static final String SESSION_LANDING_PAGE_CODE_KEY = "landingPage_code";
	public static final String SESSION_LANDING_PAGE_CAMPAIGN_KEY = "landingPage_campaign";
	public static final String EMPTY_STRING = "";
	
	public static final String LOGIN_INVITATION_TARGET = "invitation";

	private CommonConstants() {
		// Do nothing.
	}

}
