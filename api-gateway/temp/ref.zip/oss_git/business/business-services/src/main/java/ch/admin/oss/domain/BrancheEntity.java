/*
 * BrancheEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;

import com.querydsl.core.annotations.QueryProjection;

/**
 * @author coh
 */
@Entity
@Table(name = "T_BRANCHE")
public class BrancheEntity extends AbstractOSSEntity {

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_STANDARD_TEXT", foreignKey = @ForeignKey(name = "FK_BRANCHE_TEXT"))
	private StandardTextEntity standardText;

	@Column(name = "CODE")
	private String code;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PARENT", foreignKey = @ForeignKey(name = "FK_BRANCHE_BRANCHE"))
	private BrancheEntity parent;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "parent", cascade = CascadeType.ALL)
	private Set<BrancheEntity> childBranches = new HashSet<>();

	@Column(name = "AKTIV", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean aktiv;

	@Column(name = "SUVA", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean suva;
	
	@Column(name = "POS")
	private int pos;
	
	public BrancheEntity() {
	}
	
	@QueryProjection
	public BrancheEntity(Long id) {
		setId(id);
	}

	public StandardTextEntity getStandardText() {
		return standardText;
	}

	public String getCode() {
		return code;
	}

	public BrancheEntity getParent() {
		return parent;
	}

	public boolean isAktiv() {
		return aktiv;
	}

	public boolean isSuva() {
		return suva;
	}

	public Set<BrancheEntity> getChildBranches() {
		return childBranches;
	}

	public int getPos() {
		return pos;
	}

	public void setStandardText(StandardTextEntity standardText) {
		this.standardText = standardText;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setParent(BrancheEntity parent) {
		this.parent = parent;
	}

	public void setChildBranches(Set<BrancheEntity> childBranches) {
		this.childBranches = childBranches;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}

	public void setSuva(boolean suva) {
		this.suva = suva;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}
}
