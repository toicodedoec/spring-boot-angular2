/*
 * FirmennameDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.CodeWertDto;

/**
 * @author tdm
 */
public class FirmennameDto extends AbstractOSSDto {

	
	private Long orgId;

	
	private CodeWertDto sprache;

	
	private String bezeichnung;

	private boolean isDefault;

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public CodeWertDto getSprache() {
		return sprache;
	}

	public void setSprache(CodeWertDto sprache) {
		this.sprache = sprache;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}

	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	public boolean isDefault() {
		return isDefault;
	}

	public void setDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}

}
