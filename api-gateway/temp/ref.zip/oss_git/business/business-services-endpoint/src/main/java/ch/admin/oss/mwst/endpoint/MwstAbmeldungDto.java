/*
 * MwstAbmeldungDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.mwst.endpoint;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.CommonAddress;
import ch.admin.oss.common.ProzessDto;

/**
 * @author xdg
 */
public class MwstAbmeldungDto extends AbstractOSSDto {

	private ProzessDto prozess;

	@NotNull
	private String mwstNr;

	@NotNull
	private String name;

	@Valid
	@NotNull(groups = {CommonAddress.class, MwstAbmeldungAddress.class})
	private AdresseDto adresse;

	private String kontaktPerson;

	private Long grund;

	private String nachfolgerName;

	private String nachfolgerMwstNr;

	private String bemerkungen;

	private Date perDatum;

	// ref data

	private List<CodeWertDto> begrundung;

	private AdresseDto orgDomizil;

	public MwstAbmeldungDto() {}

	public ProzessDto getProzess() {
		return prozess;
	}

	public void setProzess(ProzessDto prozess) {
		this.prozess = prozess;
	}

	public String getMwstNr() {
		return mwstNr;
	}

	public void setMwstNr(String mwstNr) {
		this.mwstNr = mwstNr;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AdresseDto getAdresse() {
		return adresse;
	}

	public void setAdresse(AdresseDto adresse) {
		this.adresse = adresse;
	}

	public String getKontaktPerson() {
		return kontaktPerson;
	}

	public void setKontaktPerson(String kontaktPerson) {
		this.kontaktPerson = kontaktPerson;
	}

	public Long getGrund() {
		return grund;
	}

	public void setGrund(Long grund) {
		this.grund = grund;
	}

	public String getNachfolgerName() {
		return nachfolgerName;
	}

	public void setNachfolgerName(String nachfolgerName) {
		this.nachfolgerName = nachfolgerName;
	}

	public String getNachfolgerMwstNr() {
		return nachfolgerMwstNr;
	}

	public void setNachfolgerMwstNr(String nachfolgerMwstNr) {
		this.nachfolgerMwstNr = nachfolgerMwstNr;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public List<CodeWertDto> getBegrundung() {
		return begrundung;
	}

	public void setBegrundung(List<CodeWertDto> begrundung) {
		this.begrundung = begrundung;
	}

	public AdresseDto getOrgDomizil() {
		return orgDomizil;
	}

	public void setOrgDomizil(AdresseDto orgDomizil) {
		this.orgDomizil = orgDomizil;
	}

	public Date getPerDatum() {
		return perDatum;
	}

	public void setPerDatum(Date perDatum) {
		this.perDatum = perDatum;
	}

}
