package ch.admin.oss.util;

import com.aspose.words.Document;

public interface IDocumentMergeCallback<T> {

	void apply(Document doc, T data) throws Exception;

}
