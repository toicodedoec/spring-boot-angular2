/*
 * WHOISCheckResult
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.whois;

/**
 * An enum class to represent the check domain result return according to 
 * https://www.nic.ch/faqs/domaincheck/#collapse-e745fb9f-4fef-11e6-b33a-525400a7a801-2
 * 
 * @author tdm
 *
 */
public enum WHOISCheckResultEnum {

	/**
	 * An Unexpected Error during processing
	 */
	UNEXPECTED_ERROR("-100"),
	/**
	 * Domain name can be registered
	 */
	CAN_REGISTERED("1"),
	/**
	 * Domain name cannot be registered
	 */
	CAN_NOT_REGISTERED("0"),
	/**
	 * Invalid enquiry (i.e. modify enquiry prior to next attempt)
	 */
	INVALID_ENQUIRY("-1"),
	/**
	 * Access restricted (i.e. wait a while and then try again)
	 */
	ACCESS_RESTRICTED("-95"),
	/**
	 * Temporary server error (i.e. wait a while and then try again)
	 */
	TEMPORARY_SERVER_ERROR("-99");
	
	final String code;
	
	WHOISCheckResultEnum(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
	
	public static WHOISCheckResultEnum getFromCode(String code) {
		for (WHOISCheckResultEnum value : values()) {
			if (value.getCode().equals(code)) {
				return value;
			}
		}
		throw new IllegalArgumentException("There's no WHOISCheckResultEnum defined for code = " + code);
	}
}
