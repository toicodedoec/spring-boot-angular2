/*
 * IPortalService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.service;

import java.util.List;

import javax.validation.Valid;

import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.EinladungEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.exception.EinladungNotFoundException;
import ch.admin.oss.exception.InvitationWasExpiredException;
import ch.admin.oss.exception.UserWasAlreadyLinkedToOrganizationException;

/**
 * @author tdm
 */
public interface IPortalService {
	
	List<AdresseEntity> getAdresses(List<Long> addressIds);
	
	long countUser();
	
	long countProcesses(Long orgId, boolean isOpened);
	
	List<ProzessEntity> getProcessesSummary(List<Long> orgId, boolean isOpened, Long offset, Long limit);

	/**
	 * Get list of [Heimatort] entities based on [ort] criterion.
	 * 
	 * @param ort
	 * @return List<HeimatortEntity>
	 */
	List<CHOrtEntity> getCHOrts(String ort);

	/**
	 * Save or update user.
	 * 
	 * @param entity
	 *            User entity to save
	 * @return UserEntity
	 */
	UserEntity save(@Valid UserEntity entity);

	/**
	 * Find user which has the user name match with the given user name.
	 * 
	 * @param username
	 *            User name
	 * @return UserEntity
	 */
	UserEntity findUserByName(String username);

	/**
	 * Get PflichtenabklaerungenEntity by ID
	 * 
	 * @param id
	 *            The ID to get
	 * @return PflichtenabklaerungenEntity
	 */
	PflichtenabklaerungenEntity getPflichtenabklaerungenById(Long id);

	/**
	 * Save or update Pflichtenabklaerungen
	 * 
	 * @param entity
	 *            Pflichtenabklaerungen to save
	 * @return Pflichtenabklaerungen
	 */
	PflichtenabklaerungenEntity save(@Valid PflichtenabklaerungenEntity entity);

	/**
	 * Find PflichtenabklaerungenEntity of the given user name.
	 * 
	 * @param username
	 *            The user name
	 * @return PflichtenabklaerungenEntity
	 */
	PflichtenabklaerungenEntity findPflichtenabklaerungenByUsername(String username);
	
	/**
	 * Find EinladungEntity of the given einladungCode.
	 * 
	 * @param einladungCode
	 *            The unique code of that einladung entity
	 * @return EinladungEntity
	 * @throws EinladungNotFoundException 
	 */
	EinladungEntity getEinladungByEinladungCode(String einladungCode) throws EinladungNotFoundException;
	/**
	 * Delete EinladungEntity of the given einladungId.
	 * 
	 * @param einladungId
	 *            The unique Id of that einladung entity
	 * @param version
	 *            The version of that einladung entity to avoid concurrent update
	 * @return void
	 */
	void deleteEinladungById(long einladungId, int version);
	
	/**
	 * Create ZugriffEntity of the given ZugriffEntity.
	 * 
	 * @param zugriffEntity
	 *            The entity that you want to create
	 * @return ZugriffEntity
	 * @throws UserWasAlreadyLinkedToOrganizationException 
	 * @throws InvitationWasExpiredException 
	 */
	ZugriffEntity createZugriffFromInvitation(long orgId, long einladungId) throws UserWasAlreadyLinkedToOrganizationException, InvitationWasExpiredException;
	
	/**
	 * Find PflichtenabklaerungenEntity of the given organisation.
	 * 
	 * @param orgId
	 *            The organisation id
	 * @return PflichtenabklaerungenEntity
	 */
	PflichtenabklaerungenEntity findPflichtenabklaerungenByOrganisation(long orgId);
}
