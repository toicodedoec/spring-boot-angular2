/*
 * NumberUtil
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * @author hha
 */
public class NumberUtil {
	
	private NumberUtil() {
		// Do nothing
	}
	
	/**
	 * Check if the given value has a most a number of decimals.
	 *  
	 * @param value
	 * @param numOfDecimals
	 */
	public static boolean hasAsMostNumberOfDecimal(double value, int numOfDecimals) {
		double checkValue = value * (Math.pow(10, numOfDecimals));
		return checkValue == Math.floor(checkValue) && Double.isFinite(checkValue);
	}

	/**
	 * Check if the given value is an Integer number.
	 * @param value
	 * @return
	 */
	public static boolean isInteger(double value) {
		return hasAsMostNumberOfDecimal(value, 0);
	}

	/**
	 * Get the actual value of Integer.<br />
	 * {@code 0} will be returned if value is null.
	 */
	public static int getValue(Integer value) {
		return value != null ? value.intValue() : 0;
	}

	public static Integer getIntegerValue(BigInteger value) {
		return value != null ? value.intValue() : null;
	}

	public static Integer getIntegerValue(BigDecimal value) {
		return value != null ? value.intValue() : null;
	}
}
