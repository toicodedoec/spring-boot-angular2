/*
 * AusgleichskasseDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.util.OSSConstants;

/**
 * @author tdm
 */
public class AusgleichskasseDto extends AbstractOSSDto {

	@NotNull
	private String strasse;

	private String hausnummer;

	private String postfach;

	@NotNull
	private String plz;

	@NotNull
	private String ort;

	@NotNull
	private String telefon;

	private String homepage;

	@NotNull
	@Pattern(regexp = OSSConstants.EMAIL_REGEX_PATTERN)
	private String email;

	@NotNull
	private String sprache;

	@NotNull
	private boolean leistungfak;

	@NotNull
	private String zustaendigkeit;

	@NotNull
	private boolean aktiv;

	@Valid
	@NotNull
	StandardTextDto standardText;

	public AusgleichskasseDto() {}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getHausnummer() {
		return hausnummer;
	}

	public void setHausnummer(String hausnummer) {
		this.hausnummer = hausnummer;
	}

	public String getPostfach() {
		return postfach;
	}

	public void setPostfach(String postfach) {
		this.postfach = postfach;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	public String getHomepage() {
		return homepage;
	}

	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSprache() {
		return sprache;
	}

	public void setSprache(String sprache) {
		this.sprache = sprache;
	}

	public boolean isLeistungfak() {
		return leistungfak;
	}

	public void setLeistungfak(boolean leistungfak) {
		this.leistungfak = leistungfak;
	}

	public String getZustaendigkeit() {
		return zustaendigkeit;
	}

	public void setZustaendigkeit(String zustaendigkeit) {
		this.zustaendigkeit = zustaendigkeit;
	}

	public boolean isAktiv() {
		return aktiv;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}

	public StandardTextDto getStandardText() {
		return standardText;
	}

	public void setStandardText(StandardTextDto standardText) {
		this.standardText = standardText;
	}

}
