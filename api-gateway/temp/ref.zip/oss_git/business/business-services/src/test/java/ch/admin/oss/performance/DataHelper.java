/*
 * GenerateProcessFactory
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.performance;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;

import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.common.enums.EinlageEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HaftungEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.NatTypEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.util.OSSConstants;
import generated.FunktionsEnum;
import generated.ZeichnungsberechtigungEnum;

/**
 * @author hha
 */
@Component
public class DataHelper {

	@Autowired
	protected IApplicationService applicationService;

	public AdresseEntity createAddress() {
		AdresseEntity address = new AdresseEntity();
		
		address.setLand(getSwissLand());
		address.setEmpfaenger("Empfa Name");
		address.setStrasse("N1 Dien Bien Phu");
		address.setHausnummer("999.99.999.999");
		address.setZusatz("Binh Thanh");
		address.setPlz("7001");
		address.setOrt("7001");
		address.setPolGemeinde("12345");
		address.setKanton("ZH");
		address.setTelefon("84905123");
		address.setMobile("84905124");
		address.setFax("84905125");

		address.setPostfach("7001");
		address.setPostfachPlz("7001");
		address.setPostfachOrt("7001");
		address.setEmail("hha@elca.vn");

		return address;
	}

	public GeschaftsrolleEntity createOwnerPerson(OrganisationEntity organisation, GeschaeftsrolleTypEnum type) {
		GeschaftsrolleEntity geschaftsrolle = new GeschaftsrolleEntity();
		geschaftsrolle.setOrganisation(organisation);
		geschaftsrolle.setPerson(createPerson());
		geschaftsrolle.setFunktion(getFunkction());
		geschaftsrolle.setHaftung(getCodeWert(KategorieEnum.HAFTUNG, HaftungEnum.BESCHRAENKT.getCode()));
		geschaftsrolle.setHaftungCHF(BigDecimal.valueOf(1500d));
		geschaftsrolle.setZeichnung(getZeichnung());
		geschaftsrolle.setEinlage(getCodeWert(KategorieEnum.EINLAGE, EinlageEnum.BAR.name()));

		geschaftsrolle.setTyp(type);
		geschaftsrolle.setComplete(true);

		geschaftsrolle.setStammanteile(10000);
		return geschaftsrolle;
	}

	public PersonEntity createPerson() {
		PersonEntity person = new PersonEntity();
		person.getNationalitaetens().add(getSwissLand());
		person.setZivilstand(getCodeWert(KategorieEnum.ZIVILSTAND, "1"));
		person.setGeschlecht(getCodeWert(KategorieEnum.GESCHLECHT, "1"));
		person.setAnrede(getCodeWert(KategorieEnum.ANREDE, OSSConstants.ANDERE_MR_CODE));
		person.setWohnadresse(createAddress());
		person.setAuslaenderAusweis(getCodeWert(KategorieEnum.AUSLAUSWEIS, "B"));
		person.setEinreisedatum(LocalDate.now());
		person.setTitel("SE");
		person.setFamilienname("Dang");
		person.setLedigname("Huu");
		person.setVorname("Hoang");
		person.setRufname("Say");
		person.setVornamenliste("Sayuri");
		person.setGeburtsdatum(LocalDate.now().minusYears(20));
		person.setAhvNummer("999.99.999.999");
		person.setNatType(NatTypEnum.CH);
		person.setSteuernUSA(false);
		return person;
	}

	public CodeWertEntity getCodeWert(KategorieEnum kategorie, String code) {
		return getCodeWerts(kategorie, Lists.newArrayList(code)).get(0);
	}

	public List<CodeWertEntity> getCodeWerts(KategorieEnum kategorie, List<String> codes) {
		List<CodeWertEntity> result = applicationService.getCodeWerts(kategorie);
		return result.stream()
			.filter(item -> codes.stream().anyMatch(code -> code.equalsIgnoreCase(item.getCode())))
			.collect(Collectors.toList());
	}

	public CodeWertEntity getSwissLand() {
		return getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT);
	}

	public CodeWertEntity getFunkction() {
		return getCodeWert(KategorieEnum.FUNKTION, FunktionsEnum.INHABER.value());
	}

	public CodeWertEntity getZeichnung() {
		return getCodeWert(KategorieEnum.ZEICHNUNG, ZeichnungsberechtigungEnum.NONE.value());
	}
	
	public CodeWertEntity getZahlungsmodus() {
		return getCodeWert(KategorieEnum.UVGINTERVALL, "Jahr");
	}

}
