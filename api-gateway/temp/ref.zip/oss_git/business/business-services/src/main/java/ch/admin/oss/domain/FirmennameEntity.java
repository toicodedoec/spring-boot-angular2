/*
 * FirmennameEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;
import org.hibernate.validator.constraints.NotBlank;

/**
 *  
 * @author coh
 */
@Audited
@Entity
@Table(name = "T_FIRMENNAME", 
	uniqueConstraints = {
		@UniqueConstraint(name = "UK_FIRMENNAME_ORG_SPRACHE", columnNames = {"LN_ORGANISATION", "LN_SPRACHE"})
	})
public class FirmennameEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name="FK_FIRMENNAME_ORGANISATION"))
	private OrganisationEntity organisation;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_SPRACHE", foreignKey = @ForeignKey(name="FK_FIRMENNAME_CODE_WERT"))
	private CodeWertEntity sprache;
	
	@NotBlank
	@Column(name = "BEZEICHNUNG")
	private String bezeichnung;
	
	@Column(name = "IS_DEFAULT", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean isDefault;

	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public CodeWertEntity getSprache() {
		return sprache;
	}

	public void setSprache(CodeWertEntity sprache) {
		this.sprache = sprache;
	}

	public String getBezeichnung() {
		return bezeichnung;
	}

	public void setBezeichnung(String bezeichnung) {
		this.bezeichnung = bezeichnung;
	}

	public boolean isDefault() {
		return isDefault;
	}

	public void setDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}
}
