/*
 * FunktionRecheDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import java.util.List;

import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.enums.FunktionEnum;
import ch.admin.oss.security.OssRole;

/**
 * @author hha
 */
public class FunktionRechteDto extends AbstractOSSDto {

	@NotNull
	private FunktionEnum funktion;

	@NotNull
	private String beschreibung;

	private List<OssRole> groups;

	public FunktionEnum getFunktion() {
		return funktion;
	}

	public void setFunktion(FunktionEnum funktion) {
		this.funktion = funktion;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	public List<OssRole> getGroups() {
		return groups;
	}

	public void setGroups(List<OssRole> groups) {
		this.groups = groups;
	}

}
