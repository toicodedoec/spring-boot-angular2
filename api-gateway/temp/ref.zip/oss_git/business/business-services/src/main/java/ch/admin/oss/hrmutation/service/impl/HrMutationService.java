/*
 * HrMutationService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.service.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.Query;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aspose.words.Document;
import com.aspose.words.NodeType;
import com.aspose.words.SaveFormat;
import com.google.common.collect.Iterables;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.business.CompanyDto;
import ch.admin.oss.business.HrMutationLegalPersonDto;
import ch.admin.oss.business.HrMutationNaturalPersonDto;
import ch.admin.oss.business.HrMutationPDFDto;
import ch.admin.oss.business.HrMutationTemplateType;
import ch.admin.oss.business.IShowAsCollection;
import ch.admin.oss.common.AbstractProcessService;
import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.OssTechnicalException;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.dto.AutoCompletePersonResultDto;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HrMutationPersonTypeOfChangeEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonRoleEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.NatTypEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrAmtEntity;
import ch.admin.oss.domain.HrMutationEntity;
import ch.admin.oss.domain.HrMutationPersonEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.KommGesEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QAdresseEntity;
import ch.admin.oss.domain.QCHOrtEntity;
import ch.admin.oss.domain.QCodeWertEntity;
import ch.admin.oss.domain.QGeschaftsrolleEntity;
import ch.admin.oss.domain.QHrMutationEntity;
import ch.admin.oss.domain.QHrMutationPersonEntity;
import ch.admin.oss.domain.QKommFirmaEntity;
import ch.admin.oss.domain.QKommGesEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QPersonEntity;
import ch.admin.oss.domain.QStandardTextEntity;
import ch.admin.oss.enums.SupportedFileTypeDownload;
import ch.admin.oss.exception.ValidationException;
import ch.admin.oss.hrmutation.repository.IHrMutationPersonRepository;
import ch.admin.oss.hrmutation.repository.IHrMutationRepository;
import ch.admin.oss.hrmutation.service.IHrMutationService;
import ch.admin.oss.organisation.repository.IAdresseRepository;
import ch.admin.oss.organisation.repository.IKommFirmaRepository;
import ch.admin.oss.organisation.repository.IKommGesRepository;
import ch.admin.oss.organisation.repository.IPersonRepository;
import ch.admin.oss.organisation.service.IOrganisationService;
import ch.admin.oss.security.AuthorizedOrganisation;
import ch.admin.oss.security.OssUser;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.IDocumentMergeCallback;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OssAsposeUtil;
import ch.admin.oss.util.TemplateDto;

/**
 * @author hhg
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class HrMutationService extends AbstractProcessService<HrMutationEntity> implements IHrMutationService {

	@Autowired
	private IHrMutationRepository hrMutationRepo;

	@Autowired
	private IAdresseRepository addressRepo;

	@Autowired
	private IPersonRepository personRepo;

	@Autowired
	private IOrganisationService orgService;
	
	@Autowired
	private IKommGesRepository kommGesRepo;
	
	@Autowired
	private IKommFirmaRepository kommFirmaRepo;

	@Autowired
	private IHrMutationPersonRepository hrMutationPersonRepo;

	@Override
	public HrMutationEntity createProcess(long orgId) {
		// Org load domizil and names for init HrMutationZefixCompareDto
		HrMutationEntity entity = new HrMutationEntity(orgService.getOrganisation(orgId,
			QOrganisationEntity.organisationEntity.domizil, QOrganisationEntity.organisationEntity.namens));
		recordProcessStatusChange(entity.getProzess());
		return hrMutationRepo.save(entity);
	}

	@Override
	public HrMutationEntity updateProcess(long orgId, HrMutationEntity entity) {
		entity = hrMutationRepo.save(entity);
		processUpdated(entity.getProzess());
		return entity;
	}

	@Override
	public AdresseEntity updateDomicile(long orgId, AdresseEntity domicile) {
		return addressRepo.save(domicile);
	}

	@Override
	public HrMutationEntity completeProcess(long orgId, HrMutationEntity entity) {
		validateHrMutation(entity);
		entity = hrMutationRepo.save(entity);
		processCompleted(entity);
		return entity;
	}

	/**
	 * @param entity
	 */
	private void validateHrMutation(HrMutationEntity entity) {
		RechtsformEnum rechtsform = entity.getProzess().getOrganisation().getRechtsform();

		if (!entity.isTaskAddress() && !entity.isTaskName() && !entity.isTaskPersons() && !entity.isTaskPurpose()
			&& !entity.isTaskRevision() && !entity.isTaskDissolution()) {
			throw new ValidationException("HrMutation Process have to have at least one task active");
		}

		if (entity.isTaskName()) {
			validateHrMutationTaskName(entity);
		}
		if (entity.isTaskAddress()) {
			validateHrMutationTaskAddress(entity);
		}
		if (entity.isTaskPurpose()) {
			validateHrMutationTaskPurpose(entity);
		}
		if (entity.isTaskPersons()) {
			validateHrMutationTaskPersons(entity);
		}
		if (entity.isTaskExcerpts()) {
			validateHrMutationTaskExcerpts(entity);
		}
		if (entity.isTaskDissolution()) {
			if (rechtsform == RechtsformEnum.AG || rechtsform == RechtsformEnum.GMBH) {
				throw new ValidationException("Rechtsform " + rechtsform + " can't perform dissolution task");
			}
			validateHrMutationTaskDissolution(entity);
		}
		if (entity.isTaskRevision()) {
			if (rechtsform == RechtsformEnum.KOLLGES || rechtsform == RechtsformEnum.KOMMGES) {
				throw new ValidationException("Rechtsform " + rechtsform + " can't perform revision task");
			}
			validateHrMutationTaskRevision(entity);
		}

	}

	/**
	 * @param entity
	 */
	private void validateHrMutationTaskName(HrMutationEntity entity) {
		if (StringUtils.isEmpty(entity.getNewCompanyName())) {
			throw new ValidationException("Task Name: HrMutationEntity#newCompanyName must not empty");
		}
	}

	/**
	 * @param entity
	 */
	private void validateHrMutationTaskPurpose(HrMutationEntity entity) {
		if (StringUtils.isEmpty(entity.getNewPurpose())) {
			throw new ValidationException("Task Purpose: HrMutationEntity#newPurpose must not empty");
		}
	}

	/**
	 * @param entity
	 */
	private void validateHrMutationTaskPersons(HrMutationEntity entity) {
		
		List<Long> existingIds = entity.getPersons().stream().mapToLong(person -> {
			return person.getExistingLegalPeson() != null ? person.getExistingLegalPeson().getId()
				: person.getExistingNaturalPerson() != null ? person.getExistingNaturalPerson().getId() : -1L;
		}).boxed().collect(Collectors.toList());

		if (hasDuplicatedValues(existingIds.stream().filter(id -> id != -1L).collect(Collectors.toList()))) {
			throw new ValidationException(
				"Task Persons: HrMutationEntity#persons cannot be more than one HrMutationPerson record with the same existingNaturalPerson or existingLegalPerson");
		}
		
		entity.getPersons().stream().forEach(person -> {
			if(person.getTypeOfChange() == null) {
				throw new ValidationException("Task Persons: HrMutationEntity#persons#typeOfChange must not be null");
			}
			switch (person.getTypeOfPerson()) {
				case LEGAL:
					if(person.getTypeOfChange() == HrMutationPersonTypeOfChangeEnum.UPDATE || person.getTypeOfChange() == HrMutationPersonTypeOfChangeEnum.DELETE) {
						if(StringUtils.isEmpty(person.getPrevCompanyName()) ||
							StringUtils.isEmpty(person.getPrevCity()) ||
							StringUtils.isEmpty(person.getPrevLegalForm())) {
							throw new ValidationException("Task Persons: typeOfPerson#LEGAL && typeOfChange#UPDATE|DELETE -> HrMutationEntity#persons#prevCompanyName|prevCity|prevLegalForm must not be null");
						}
					}
					if(person.getTypeOfChange() != HrMutationPersonTypeOfChangeEnum.DELETE) {
						validateLegalPerson(person.getNewLegalPerson());
					}
					break;

				case NATURAL:
					if(person.getTypeOfChange() == HrMutationPersonTypeOfChangeEnum.UPDATE || person.getTypeOfChange() == HrMutationPersonTypeOfChangeEnum.DELETE) {
						if(StringUtils.isEmpty(person.getPrevFamilyName()) ||
							StringUtils.isEmpty(person.getPrevGivenName()) ||
							person.getPrevBirthday() == null) {
							throw new ValidationException("Task Persons: typeOfPerson#NATURAL && typeOfChange#UPDATE|DELETE -> HrMutationEntity#persons#prevFamilyName|prevGivenName|prevBirthday must not be null");
						}
					}
					if(person.getTypeOfChange() != HrMutationPersonTypeOfChangeEnum.DELETE) {
						validateNaturalPerson(person.getNewNaturalPerson(), entity.getProzess().getOrganisation().getRechtsform());
					}
					break;

				default:
					throw new ValidationException("Task Persons: HrMutationEntity#persons#typeOfPerson must LEGAL or NATURAL");
			}
		});
	}
	
	private boolean hasDuplicatedValues(List<Long> ids) {
		Set<Long> lump = new HashSet<Long>(ids);
		return lump.size() < ids.size();
	}

	/**
	 * @param newLegalPerson
	 */
	private void validateLegalPerson(KommFirmaEntity newLegalPerson) {
		if(StringUtils.isNotEmpty(newLegalPerson.getRechtsformAusland()) && newLegalPerson.getRechtsformCH() != null) {
			throw new ValidationException("Task Persons: newLegalPerson#rechtsformCH or rechtsformAusland must be empty");
		}

		if(newLegalPerson.getHaftung() == null || newLegalPerson.getEinlage() == null) {
			throw new ValidationException("Task Persons: newLegalPerson#haftung|einlage must not null");
		}

		AdresseEntity domizil = newLegalPerson.getDomizil();
		validateAddress(domizil, false);
		if(newLegalPerson.getRechtsformCH() != null) {
			if(!domizil.getLand().getCode().equals(OSSConstants.SWISS_CODE_WERT)) {
				throw new ValidationException("Task Persons: newLegalPerson in CH -> domizil#land must be in swiss");
			}
		}
	}

	private void validateAddress(AdresseEntity adresse, boolean isNaturalPerson) {
		if(adresse == null) {
			throw new ValidationException("Task Persons: addresse must not emtpy");
		} else {
			if(StringUtils.isEmpty(adresse.getStrasse()) || StringUtils.isEmpty(adresse.getPlz()) 
				|| StringUtils.isEmpty(adresse.getOrt()) || adresse.getLand() == null) {
				throw new ValidationException("Task Persons: some mandatory field in address are empty");
			}
			if(isNaturalPerson && StringUtils.isEmpty(adresse.getTelefon())) {
				throw new ValidationException("Task Persons: telefon in address are empty");
			}
		}
	}

	/**
	 * @param newNaturalPerson
	 */
	private void validateNaturalPerson(GeschaftsrolleEntity newNaturalPerson, RechtsformEnum rectsform) {
		PersonEntity person = newNaturalPerson.getPerson();
		if(newNaturalPerson.getZeichnung() == null || newNaturalPerson.getHaftung() == null) {
			throw new ValidationException("Task Persons: newNaturalPerson#zeichnung|haftung must not null");
		}
		if(rectsform == RechtsformEnum.KOMMGES && newNaturalPerson.getHaftung().getCode() == OSSConstants.HAFTUNG_CODE_BESCHRAENKT) {
			if(newNaturalPerson.getHaftungCHF() == null || newNaturalPerson.getEinlage() == null) {
				throw new ValidationException("Task Persons: newNaturalPerson#einlage|haftungCHF must not null");
			}
		}
		
		// Basic data for person
		if(StringUtils.isEmpty(person.getFamilienname()) || StringUtils.isEmpty(person.getVorname()) ||
			person.getGeburtsdatum() == null || person.getNatType() == null) {
			throw new ValidationException("Task Persons: person#familienname|vorname|geburtsdatum|nattype must not emtpy");
		}
		
		// Heimatorte && Nationaliens
		if((person.getNatType() == NatTypEnum.CH || person.getNatType() == NatTypEnum.CH_PLUS)) {
			if(CollectionUtils.isEmpty(person.getHeimatortes())) {
				throw new ValidationException("Task Persons: person#natType = CH|CH_PLUS -> heimatortes must not emtpy");
			}
			Optional<CodeWertEntity> swissCodewert = person.getNationalitaetens().stream().filter(national -> national.getCode().equals(OSSConstants.SWISS_CODE_WERT)).findFirst();
			if(!swissCodewert.isPresent()) {
				throw new ValidationException("Task Persons: person#natType = CH|CH_PLUS -> nationalitaetens must have swiss");
			}
		} else {
			if(CollectionUtils.isNotEmpty(person.getHeimatortes())) {
				throw new ValidationException("Task Persons: person#natType = NON_CH -> heimatortes must emtpy");
			}
		}
		
		// Wohnadresse
		AdresseEntity addresse = person.getWohnadresse();
		validateAddress(addresse, true);
		
		if(newNaturalPerson.getTyp() == GeschaeftsrolleTypEnum.EDC && addresse.getLand().getCode().equals(OSSConstants.SWISS_CODE_WERT)
			&& person.getNatType() == NatTypEnum.NON_CH) {
			if(person.getAuslaenderAusweis() == null || person.getEinreisedatum() == null) {
				throw new ValidationException("Task Persons: person#auslaenderAusweis|einreisedatum must not empty");
			}
		} else {
			if(person.getAuslaenderAusweis() != null || person.getEinreisedatum() != null) {
				throw new ValidationException("Task Persons: person#auslaenderAusweis|einreisedatum must empty");
			}
		}
	}

	/**
	 * @param entity
	 */
	private void validateHrMutationTaskExcerpts(HrMutationEntity entity) {
		if (entity.getExcerptsNum() == 0 && entity.getExcerptsNumPrelim() == 0) {
			if (entity.getExcerptsDeliveryAddress() != null || entity.getExcerptsBillingAddress() != null) {
				throw new ValidationException(
					"Task Excerpts: if ExcerptsNum = NumPrelim = 0, delivery, billing address must not exist");
			}
		}
	}

	/**
	 * @param entity
	 */
	private void validateHrMutationTaskDissolution(HrMutationEntity entity) {
		if (StringUtils.isEmpty(entity.getDissLeavingPartnerFamilyName())
			|| StringUtils.isEmpty(entity.getDissLeavingPartnerGivenName())
			|| entity.getDissLeavingPartnerBirthday() == null || StringUtils.isEmpty(entity.getDissNewCompanyName())
			|| entity.getDissNewOwner() == null) {
			throw new ValidationException("Task Dissolution: " + "HrMutationEntity#dissLeavingPartnerFamilyName|"
				+ "dissLeavingPartnerFamilyName|" + "dissLeavingPartnerBirthday|" + "dissNewCompanyName|"
				+ "dissNewOwner must not empty");
		}
	}

	/**
	 * @param entity
	 */
	private void validateHrMutationTaskRevision(HrMutationEntity entity) {
		String revPreviousSeatCity = entity.getRevPreviousSeatCity();
		String revPreviousSeatPolCommunity = entity.getRevPreviousSeatPolCommunity();
		String revPreviousSeatCanton = entity.getRevPreviousSeatCanton();
		Integer revPreviousSeatBfsNr = entity.getRevPreviousSeatBfsNr();
		if (!isRevisionChOrtValid(revPreviousSeatCity, revPreviousSeatPolCommunity, revPreviousSeatCanton, revPreviousSeatBfsNr)) {
			throw new ValidationException("Task Revision: RevPrevious data is invalid. Cannot find the chOrt [revPreviousSeatCity=" + revPreviousSeatCity 
				+ ", revPreviousSeatPolCommunity=" + revPreviousSeatPolCommunity 
				+ ", revPreviousSeatCanton=" + revPreviousSeatCanton 
				+ ", revPreviousSeatBfsNr=" + revPreviousSeatBfsNr + "]");
		}

		String revNewSeatCity = entity.getRevNewSeatCity();
		String revNewSeatPolCommunity = entity.getRevNewSeatPolCommunity();
		String revNewSeatCanton = entity.getRevNewSeatCanton();
		Integer revNewSeatBfsNr = entity.getRevNewSeatBfsNr();
		if (!isRevisionChOrtValid(revNewSeatCity, revNewSeatPolCommunity, revNewSeatCanton, revNewSeatBfsNr)) {
			throw new ValidationException("Task Revision: RevNew data is invalid. Cannot find the chOrt [revNewSeatCity=" + revNewSeatCity 
				+ ", revNewSeatPolCommunity=" + revNewSeatPolCommunity 
				+ ", revNewSeatCanton=" + revNewSeatCanton 
				+ ", revNewSeatBfsNr=" + revNewSeatBfsNr + "]");
		}
	}

	private boolean isRevisionChOrtValid(String ort, String polGemeinde, String kanton, int bfsnr) {
		return new JPAQuery<CHOrtEntity>(em).from(QCHOrtEntity.cHOrtEntity)
			.where(QCHOrtEntity.cHOrtEntity.ort.eq(ort)
				.and(QCHOrtEntity.cHOrtEntity.polGemeinde.eq(polGemeinde))
				.and(QCHOrtEntity.cHOrtEntity.kanton.eq(kanton))
				.and(QCHOrtEntity.cHOrtEntity.bfsnr.eq(bfsnr)))
			.fetchCount() == 1;
	}

	/**
	 * @param entity
	 */
	private void validateHrMutationTaskAddress(HrMutationEntity entity) {
		AdresseEntity newDomicile = entity.getNewDomicile();
		if (newDomicile == null) {
			throw new ValidationException("Task Address: HrMutationEntity#newDomicile must not empty");
		}
		if (StringUtils.isEmpty(newDomicile.getStrasse()) || StringUtils.isEmpty(newDomicile.getPlz())
			|| StringUtils.isEmpty(newDomicile.getTelefon()) || StringUtils.isEmpty(newDomicile.getOrt())) {
			throw new ValidationException(
				"Task Address: HrMutationEntity#newDomicile#strasse|plz|ort|telefon must not empty");
		}
		if (!newDomicile.getPlz().matches("^[0-9]{4}$")) {
			throw new ValidationException("Task Address: HrMutationEntity#newDomicile#plz wrong format");
		}
	}

	@Override
	public HrMutationEntity lockProcess(long orgId, HrMutationEntity entity) {
		entity = hrMutationRepo.save(entity);
		processLocked(entity, true);
		return entity;
	}
	
	private void updateAuthorizedOrganisation(OrganisationEntity entity) {
		OssUser ossUser = SecurityUtil.currentUser();
		for (AuthorizedOrganisation authorizedOrganisation : ossUser.getAuthorizedCompanies()) {
			if (authorizedOrganisation.getOrgId().equals(entity.getId())) {
				authorizedOrganisation.setDefaultOrgName(entity.defaultName());
				authorizedOrganisation.setUidFormatted(OssNumberFormatUtil.formatUid(entity.getUid()));
			}
		}
		SecurityUtil.updateCurrentUser(ossUser);
	}

	@Override
	public HrMutationEntity signProcess(long orgId, HrMutationEntity entity) {
		entity = hrMutationRepo.save(entity);
		processSigned(entity.getProzess());
		updateAuthorizedOrganisation(entity.getProzess().getOrganisation());
		return entity;
	}

	@Override
	public HrMutationEntity relockProcess(long orgId, HrMutationEntity entity) {
		entity = hrMutationRepo.save(entity);
		processLocked(entity, false);
		return entity;
	}

	@Override
	public HrMutationEntity getHrMutationWithReferencedData(long processId, long orgId, Path<?>... associations) {
		QPersonEntity qPerson = QPersonEntity.personEntity;

		HrMutationEntity hrMutation = new JPAQuery<HrMutationEntity>(em).from(QHrMutationEntity.hrMutationEntity)
			.where(QHrMutationEntity.hrMutationEntity.prozess.id.eq(processId)
				.and(QHrMutationEntity.hrMutationEntity.prozess.organisation.id.eq(orgId)))
			.fetchOne();
		jpaUtil.initialize(hrMutation, associations);
		jpaUtil.initialize(hrMutation,
			// TODO [S9]: use FetchProfile to avoid N+1 query
			QHrMutationEntity.hrMutationEntity.prozess.status,
			QHrMutationEntity.hrMutationEntity.prozess.flowHistory.items.any().data,
			QHrMutationEntity.hrMutationEntity.persons.any().existingLegalPeson.domizil,
			QHrMutationEntity.hrMutationEntity.persons.any().existingNaturalPerson.person,
			QHrMutationEntity.hrMutationEntity.persons.any().existingNaturalPerson.zeichnung,
			QHrMutationEntity.hrMutationEntity.persons.any().existingNaturalPerson.funktion,
			QHrMutationEntity.hrMutationEntity.persons.any().newLegalPerson.domizil,
			QHrMutationEntity.hrMutationEntity.persons.any().newLegalPerson.haftung,
			QHrMutationEntity.hrMutationEntity.persons.any().newLegalPerson.einlage,
			QHrMutationEntity.hrMutationEntity.persons.any().newNaturalPerson.person,
			// ----------
			QHrMutationEntity.hrMutationEntity.dissNewOwner.person,
			QHrMutationEntity.hrMutationEntity.oldDomicile.land,
			QHrMutationEntity.hrMutationEntity.newDomicile.land,
			QHrMutationEntity.hrMutationEntity.excerptsBillingAddress.land,
			QHrMutationEntity.hrMutationEntity.excerptsDeliveryAddress.land);

		initDissNewOwner(qPerson, hrMutation.getDissNewOwner());

		hrMutation.getPersons().stream().forEach(person -> {

			if (person.getExistingNaturalPerson() != null) {
				jpaUtil.initialize(person.getExistingNaturalPerson().getZeichnung(), 
					QCodeWertEntity.codeWertEntity.standardText.translations);
				jpaUtil.initialize(person.getExistingNaturalPerson().getFunktion(),
					QCodeWertEntity.codeWertEntity.standardText.translations);
			}

			GeschaftsrolleEntity newNaturalPerson = person.getNewNaturalPerson();
			if (newNaturalPerson != null) {
				jpaUtil.initialize(newNaturalPerson.getPerson(),
					qPerson.wohnadresse.land,
					qPerson.auslaenderAusweis,
					qPerson.auslaenderAusweis.standardText.translations,
					qPerson.nationalitaetens,
					qPerson.nationalitaetens.any().standardText.translations,
					qPerson.heimatortes);
				jpaUtil.initialize(newNaturalPerson.getEinlage(), 
					QCodeWertEntity.codeWertEntity.standardText.translations);
				jpaUtil.initialize(newNaturalPerson.getZeichnung(), 
					QCodeWertEntity.codeWertEntity.standardText.translations);
				jpaUtil.initialize(newNaturalPerson.getFunktion(),
					QCodeWertEntity.codeWertEntity.standardText.translations);
				jpaUtil.initialize(newNaturalPerson.getHaftung(),
					QCodeWertEntity.codeWertEntity.standardText.translations);
			}
			
			if (person.getNewLegalPerson() != null) {
				jpaUtil.initialize(person.getNewLegalPerson().getEinlage(), QCodeWertEntity.codeWertEntity.standardText.translations);
				if (person.getNewLegalPerson().getDomizil() != null) {
					jpaUtil.initialize(person.getNewLegalPerson().getDomizil().getLand(), QCodeWertEntity.codeWertEntity.standardText.translations);
				}
			}

		});

		if (hrMutation.getOldDomicile() != null) {
			jpaUtil.initialize(hrMutation.getOldDomicile().getLand(),
				QCodeWertEntity.codeWertEntity.standardText.translations);
		}

		if (hrMutation.getNewDomicile() != null) {
			jpaUtil.initialize(hrMutation.getNewDomicile().getLand(),
				QCodeWertEntity.codeWertEntity.standardText.translations);
		}

		if (hrMutation.getExcerptsBillingAddress() != null) {
			jpaUtil.initialize(hrMutation.getExcerptsBillingAddress().getLand(),
				QCodeWertEntity.codeWertEntity.standardText.translations);

		}
		if (hrMutation.getExcerptsDeliveryAddress() != null) {
			jpaUtil.initialize(hrMutation.getExcerptsDeliveryAddress().getLand(),
				QCodeWertEntity.codeWertEntity.standardText.translations);
		}
		
		if (hrMutation.getProzess().getOrganisation().getDomizil() != null) {
			jpaUtil.initialize(hrMutation.getProzess().getOrganisation().getDomizil().getLand(),
				QCodeWertEntity.codeWertEntity.standardText.translations);
		}

		return hrMutation;
	}

	private void initDissNewOwner(QPersonEntity qPerson, GeschaftsrolleEntity dissNewOwner) {
		if(dissNewOwner != null) {
			jpaUtil.initialize(dissNewOwner.getPerson(), 
				qPerson.wohnadresse.land,
				qPerson.auslaenderAusweis,
				qPerson.auslaenderAusweis.standardText.translations,
				qPerson.nationalitaetens,
				qPerson.nationalitaetens.any().standardText.translations,
				qPerson.heimatortes);
			jpaUtil.initialize(dissNewOwner.getZeichnung(), 
				QCodeWertEntity.codeWertEntity.standardText.translations);
			jpaUtil.initialize(dissNewOwner.getFunktion(), 
				QCodeWertEntity.codeWertEntity.standardText.translations);
			jpaUtil.initialize(dissNewOwner.getHaftung(), 
				QCodeWertEntity.codeWertEntity.standardText.translations);
			jpaUtil.initialize(dissNewOwner.getEinlage(), 
				QCodeWertEntity.codeWertEntity.standardText.translations);
		}
	}

	@Override
	public HrMutationEntity getHrMutation(long id, int version, long orgId, Path<?>... associations) {
		HrMutationEntity hrMutation = new JPAQuery<HrMutationEntity>(em).from(QHrMutationEntity.hrMutationEntity)
			.where(
				QHrMutationEntity.hrMutationEntity.id.eq(id).and(QHrMutationEntity.hrMutationEntity.version.eq(version))
					.and(QHrMutationEntity.hrMutationEntity.prozess.organisation.id.eq(orgId)))
			.fetchOne();
		return jpaUtil.initialize(hrMutation, associations);
	}

	@Override
	public byte[] generateDocument(HrMutationEntity entity, boolean draft) {
		// SECOOSS-661: In case of domicile change: the new domicile determines the responsible HRAmt (for choosing the correct icon in the header)
		int bfsNr = entity.getNewDomicile() != null ? entity.getNewDomicile().getBfsNr() 
			: entity.getOldDomicile().getBfsNr();
		HrAmtEntity amtEntity = applicationService.getHrAmtByDomizilBfsnr(bfsNr);

		SupportedLanguage language = detectSendingTemplateLanguage(entity);

		HrMutationPDFDto dto = convertHrMutationEntityToPDFDto(entity, amtEntity, language);

		TemplateDto<HrMutationPDFDto> templateDto = new TemplateDto<>(dto,
			HrMutationTemplateType.HR_MUTATION.getFiles(), SaveFormat.PDF, language.name());
		if (draft) {
			templateDto.setWatermark(applicationService.getTranslation("gui_labels.hr.document.watermark", language));
		}

		return OssAsposeUtil.generateDocument(templateDto, new HRMutationMergeCallback());
	}

	private SupportedLanguage detectSendingTemplateLanguage(HrMutationEntity hrMutation) {
		AdresseEntity domizil = null;

		if (hrMutation.isTaskAddress()) {
			domizil = hrMutation.getNewDomicile();
		} else {
			domizil = hrMutation.getOldDomicile();
		}

		HrAmtEntity amtEntity = applicationService.getHrAmtByDomizilBfsnr(domizil.getBfsNr());
		return getSupportedLanguage(amtEntity.getAmtssprachen(), ";");
	}

	private static class HRMutationMergeCallback implements IDocumentMergeCallback<HrMutationPDFDto> {

		@Override
		public void apply(Document doc, HrMutationPDFDto data) throws Exception {
			if (!data.isTaskAddress()) {
				OssAsposeUtil.removeEmptyBlock(doc, "taskAddressP", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "taskAddress", NodeType.TABLE);
			}
			if (!data.isTaskDissolution()) {
				OssAsposeUtil.removeEmptyBlock(doc, "taskDissolutionP", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "taskDissolution", NodeType.TABLE);
			}
			if (!data.isTaskExcerpts()) {
				OssAsposeUtil.removeEmptyBlock(doc, "taskExcerptsP", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "taskExcerpts", NodeType.TABLE);
			} else {
				if (data.getExcerptsBillingAddress() == null) {
					OssAsposeUtil.removeEmptyBlock(doc, "excerptsBillingAddress", NodeType.ROW);
				}
				if (data.getExcerptsDeliveryAddress() == null) {
					OssAsposeUtil.removeEmptyBlock(doc, "excerptsDeliveryAddress", NodeType.ROW);
				}
			}
			if (!data.isTaskName()) {
				OssAsposeUtil.removeEmptyBlock(doc, "taskNameP", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "taskName", NodeType.TABLE);
			}
			if (!data.isTaskPersonAdd()) {
				OssAsposeUtil.removeEmptyBlock(doc, "taskPersonAddP", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "taskPersonAdd", NodeType.TABLE);
			}
			if (!data.isTaskPersonDelete()) {
				OssAsposeUtil.removeEmptyBlock(doc, "taskPersonDeleteP", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "taskPersonDelete", NodeType.TABLE);
			}
			if (!data.isTaskPersonUpdate()) {
				OssAsposeUtil.removeEmptyBlock(doc, "taskPersonUpdateP", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "taskPersonUpdate", NodeType.TABLE);
			}
			if (!data.isTaskPurpose()) {
				OssAsposeUtil.removeEmptyBlock(doc, "taskPurposeP", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "taskPurpose", NodeType.TABLE);
			}
			if (!data.isTaskRevision()) {
				OssAsposeUtil.removeEmptyBlock(doc, "taskRevisionP", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "taskRevision", NodeType.TABLE);
			}
			doc.getRange().getBookmarks().clear();
		}
	}

	private HrMutationPDFDto convertHrMutationEntityToPDFDto(HrMutationEntity entity, HrAmtEntity amtEntity,
		SupportedLanguage language) {

		HrMutationPDFDto dto = new HrMutationPDFDto();
		ProzessEntity prozess = entity.getProzess();
		dto.setProzessUid(prozess.getUid());
		OrganisationEntity organisation = prozess.getOrganisation();

		dto.setAmt(constructHRAmtDto(amtEntity, language));
		dto.setOldCompanyName(entity.getOldCompanyName());
		dto.setOldDomicile(convertAddressToDocumentDto(entity.getOldDomicile(), language));
		CompanyDto companyDto = new CompanyDto();
		companyDto.setUid(organisation.getUid());
		companyDto.setRechtsform(applicationService.getTranslation(organisation.getRechtsform(), language));
		dto.setOrganisation(companyDto);

		dto.setTaskName(entity.isTaskName());
		if (dto.isTaskName()) {
			dto.setNewCompanyName(entity.getNewCompanyName());
		}

		dto.setTaskAddress(entity.isTaskAddress());
		if (dto.isTaskAddress()) {
			dto.setNewDomicile(convertAddressToDocumentDto(entity.getNewDomicile(), language));
		}

		dto.setTaskPurpose(entity.isTaskPurpose());
		if (dto.isTaskPurpose()) {
			dto.setNewPurpose(entity.getNewPurpose());
		}

		Set<HrMutationPersonEntity> persons = entity.getPersons();
		for (HrMutationPersonEntity person : persons) {
			HrMutationPersonTypeOfChangeEnum typeOfChange = person.getTypeOfChange();
			HrMutationTypeOfPersonEnum typeOfPerson = person.getTypeOfPerson();
			switch (typeOfChange) {
				case ADD:
					if (typeOfPerson == HrMutationTypeOfPersonEnum.LEGAL) {
						dto.getAddLegalPersons().add(mapToLegalPartnerDto(person.getNewLegalPerson(), language));
					} else if (typeOfPerson == HrMutationTypeOfPersonEnum.NATURAL) {
						GeschaftsrolleEntity newNaturalPerson = person.getNewNaturalPerson();
						HrMutationNaturalPersonDto addedNaturalPerson = convertNaturalPersonToDocumentDto(
							new HrMutationNaturalPersonDto(), language, newNaturalPerson);
						addedNaturalPerson.setHrMutation(dto);
						addedNaturalPerson.setEinlage(getCodeText(newNaturalPerson.getEinlage(), language));
						dto.getAddNaturalPersons().add(addedNaturalPerson);
					}
					break;
				case UPDATE:
					if (typeOfPerson == HrMutationTypeOfPersonEnum.LEGAL) {
						HrMutationLegalPersonDto legalPartnerDto = mapToLegalPartnerDto(person.getNewLegalPerson(),
							language);
						legalPartnerDto.setPrevCity(person.getPrevCity());
						legalPartnerDto.setPrevLegalForm(person.getPrevLegalForm());
						legalPartnerDto.setPrevCompanyName(person.getPrevCompanyName());
						dto.getUpdateLegalPersons().add(legalPartnerDto);
					} else if (typeOfPerson == HrMutationTypeOfPersonEnum.NATURAL) {
						GeschaftsrolleEntity newNaturalPerson = person.getNewNaturalPerson();
						HrMutationNaturalPersonDto naturalPersonDto = convertNaturalPersonToDocumentDto(
							new HrMutationNaturalPersonDto(), language, newNaturalPerson);
						naturalPersonDto.setHrMutation(dto);
						naturalPersonDto.setEinlage(getCodeText(newNaturalPerson.getEinlage(), language));
						naturalPersonDto.setPrevFamilyName(person.getPrevFamilyName());
						naturalPersonDto.setPrevGivenName(person.getPrevGivenName());
						naturalPersonDto.setPrevBirthday(person.getPrevBirthday());
						dto.getUpdateNaturalPersons().add(naturalPersonDto);
					}
					break;
				case DELETE:
					if (typeOfPerson == HrMutationTypeOfPersonEnum.LEGAL) {
						HrMutationLegalPersonDto legalPartnerDto = new HrMutationLegalPersonDto();
						legalPartnerDto.setPrevCity(person.getPrevCity());
						legalPartnerDto.setPrevLegalForm(person.getPrevLegalForm());
						legalPartnerDto.setPrevCompanyName(person.getPrevCompanyName());
						dto.getDeleteLegalPersons().add(legalPartnerDto);
					} else if (typeOfPerson == HrMutationTypeOfPersonEnum.NATURAL) {
						HrMutationNaturalPersonDto naturalPersonDto = new HrMutationNaturalPersonDto();
						naturalPersonDto.setPrevFamilyName(person.getPrevFamilyName());
						naturalPersonDto.setPrevGivenName(person.getPrevGivenName());
						naturalPersonDto.setPrevBirthday(person.getPrevBirthday());
						dto.getDeleteNaturalPersons().add(naturalPersonDto);
					}
					break;
				default:
					throw new OssTechnicalException(
						"Unsupported typeOfChange for HrMutationPersonEntity : " + typeOfChange);
			}
		}

		List<HrMutationNaturalPersonDto> addUpdateSignatories = new ArrayList<>();
		CollectionUtils.addAll(addUpdateSignatories, dto.getAddNaturalPersons().iterator());
		CollectionUtils.addAll(addUpdateSignatories, dto.getUpdateNaturalPersons().iterator());
		dto.setAddUpdateSignatories(addUpdateSignatories);
		decorateListInfo(addUpdateSignatories);

		dto.setTaskDissolution(entity.isTaskDissolution());
		if (dto.isTaskDissolution()) {
			dto.setDissLeavingPartnerGivenName(entity.getDissLeavingPartnerGivenName());
			dto.setDissLeavingPartnerFamilyName(entity.getDissLeavingPartnerFamilyName());
			dto.setDissLeavingPartnerBirthday(entity.getDissLeavingPartnerBirthday());
			dto.setDissNewOwner(convertNaturalPersonToDocumentDto(new HrMutationNaturalPersonDto(), language,
				entity.getDissNewOwner()));
			dto.setDissNewCompanyName(entity.getDissNewCompanyName());
		}

		dto.setTaskRevision(entity.isTaskRevision());
		if (dto.isTaskRevision()) {
			dto.setRevCompanyName(entity.getRevCompanyName());
			dto.setRevPreviousSeatCity(entity.getRevPreviousSeatCity());
			dto.setRevPreviousSeatPolCommunity(entity.getRevPreviousSeatPolCommunity());
			dto.setRevPreviousSeatCanton(entity.getRevPreviousSeatCanton());
			dto.setRevNewSeatCity(entity.getRevNewSeatCity());
			dto.setRevNewSeatPolCommunity(entity.getRevNewSeatPolCommunity());
			dto.setRevNewSeatCanton(entity.getRevNewSeatCanton());
		}

		dto.setTaskExcerpts(entity.isTaskExcerpts());
		if (dto.isTaskExcerpts()) {
			dto.setExcerptsDeliveryAddress(convertAddressToDocumentDto(entity.getExcerptsDeliveryAddress(), language));
			dto.setExcerptsBillingAddress(convertAddressToDocumentDto(entity.getExcerptsBillingAddress(), language));
			dto.setExcerptsNum(entity.getExcerptsNum());
			dto.setExcerptsNumPrelim(entity.getExcerptsNumPrelim());
		}

		RechtsformEnum rechtsform = organisation.getRechtsform();
		switch (rechtsform) {
			case EINZELFIRMA:
				dto.setSigningHintForLegalForm(
					applicationService.getTranslation("gui_labels.hrMutation.pdf.signingHint.ef", language));
				dto.setSignDocTitle(
					applicationService.getTranslation("gui_labels.hrMutation.pdf.signingDocTitle.ef", language));
				break;
			case KOLLGES:
			case KOMMGES:
				dto.setSigningHintForLegalForm(
					applicationService.getTranslation("gui_labels.hrMutation.pdf.signingHint.kollKomm", language));
				dto.setSignDocTitle(
					applicationService.getTranslation("gui_labels.hrMutation.pdf.signingDocTitle.kollKomm", language));
				dto.setAddMoreFormsIfNecessary(
					applicationService.getTranslation("gui_labels.hrMutation.pdf.addMoreForms", language));
				break;
			case AG:
			case GMBH:
				dto.setSigningHintForLegalForm(
					applicationService.getTranslation("gui_labels.hrMutation.pdf.signingHint.agGmbh", language));
				dto.setSignDocTitle(
					applicationService.getTranslation("gui_labels.hrMutation.pdf.signingDocTitle.agGmbh", language));
				dto.setAddMoreFormsIfNecessary(
					applicationService.getTranslation("gui_labels.hrMutation.pdf.addMoreForms", language));
				break;

			default:
				throw new OssTechnicalException("Unsupported rechtsform type : " + rechtsform);
		}
		return dto;
	}

	private void decorateListInfo(List<? extends IShowAsCollection> list) {
		IShowAsCollection last = Iterables.getLast(list, null);
		if (last != null) {
			last.setLast(true);
		}
	}

	private HrMutationLegalPersonDto mapToLegalPartnerDto(KommFirmaEntity legalPerson, SupportedLanguage language) {
		HrMutationLegalPersonDto result = new HrMutationLegalPersonDto();
		result.setName(legalPerson.getName());
		result.setDomizil(convertAddressToDocumentDto(legalPerson.getDomizil(), language));
		RechtsformEnum rechtsformCH = legalPerson.getRechtsformCH();
		if(rechtsformCH != null) {
			result.setRechtsformCh(applicationService.getTranslation(rechtsformCH, language));
		} else {
			result.setRechtsformAusland(legalPerson.getRechtsformAusland());
		}
		result.setHaftung(legalPerson.getHaftung());
		result.setEinlage(getCodeText(legalPerson.getEinlage(), language));
		return result;
	}

	@Override
	protected ProzessTypEnum getProcessType() {
		return ProzessTypEnum.HR_MUTATION;
	}

	@Override
	public List<AutoCompletePersonResultDto> searchPersons(long orgId, String criterion,
		List<HrMutationTypeOfPersonRoleEnum> personTypes) {
		List<AutoCompletePersonResultDto> result = new ArrayList<>();

		/* search natural person (owner or signatory) */
		List<GeschaeftsrolleTypEnum> naturalPersonTypes = personTypes.stream().map(type -> {
			if (type == HrMutationTypeOfPersonRoleEnum.OWNER) {
				return GeschaeftsrolleTypEnum.EDC;
			}
			if (type == HrMutationTypeOfPersonRoleEnum.SIGNATORY) {
				return GeschaeftsrolleTypEnum.SIGNATORY;
			}
			return null;
		}).filter(type -> type != null).collect(Collectors.toList());

		if (CollectionUtils.isNotEmpty(naturalPersonTypes)) {
			QGeschaftsrolleEntity qGeschaftsrolle = QGeschaftsrolleEntity.geschaftsrolleEntity;
			List<GeschaftsrolleEntity> naturalPersons = new JPAQuery<GeschaftsrolleEntity>(em)
				.from(qGeschaftsrolle)
				.join(qGeschaftsrolle.person, QPersonEntity.personEntity).fetchJoin()
				.where(qGeschaftsrolle.organisation.id.eq(orgId)
					.and(qGeschaftsrolle.person.familienname.containsIgnoreCase(criterion)
						.or(qGeschaftsrolle.person.vorname.containsIgnoreCase(criterion)))
					.and(qGeschaftsrolle.typ.in(naturalPersonTypes))
					.and(qGeschaftsrolle.delete.isFalse()))
				.orderBy(qGeschaftsrolle.person.familienname.asc()).fetch();
			if (CollectionUtils.isNotEmpty(naturalPersons)) {
				for (GeschaftsrolleEntity rollen : naturalPersons) {
					jpaUtil.initialize(rollen, 
						qGeschaftsrolle.funktion.standardText.translations,
						qGeschaftsrolle.zeichnung.standardText.translations);
				}
				result.addAll(naturalPersons.stream().map(p -> convertToAutoCompletePersonResultDto(p))
					.collect(Collectors.toList()));
			}
		}

		/* search legal person (company) */
		if (personTypes.contains(HrMutationTypeOfPersonRoleEnum.LEGAL)) {
			QKommFirmaEntity qKommFirma = QKommFirmaEntity.kommFirmaEntity;
			List<KommFirmaEntity> legalPersons = new JPAQuery<KommFirmaEntity>(em).from(qKommFirma)
				.join(qKommFirma.domizil).fetchJoin()
				.where(qKommFirma.kommges.organisation.id.eq(orgId)
					.and(qKommFirma.name.containsIgnoreCase(criterion))
					.and(qKommFirma.delete.isFalse()))
				.orderBy(qKommFirma.name.asc()).fetch();
			if (CollectionUtils.isNotEmpty(legalPersons)) {
				result.addAll(legalPersons.stream().map(p -> convertToAutoCompletePersonResultDto(p))
					.collect(Collectors.toList()));
			}
		}

		return result;
	}

	private AutoCompletePersonResultDto convertToAutoCompletePersonResultDto(GeschaftsrolleEntity s) {
		HrMutationTypeOfPersonRoleEnum personRole = s.getTyp() == GeschaeftsrolleTypEnum.EDC
			? HrMutationTypeOfPersonRoleEnum.OWNER : HrMutationTypeOfPersonRoleEnum.SIGNATORY;
		String translation = applicationService.getTranslation(
			String.format("enums.HrMutationTypeOfPersonRoleEnum.%s.text", personRole.toString()),
			SecurityUtil.currentUser().getLanguagePreference());
		return new AutoCompletePersonResultDto(
			s.getId(), 
			s.getVersion(), 
			s.getPerson().getFamilienname(),
			s.getPerson().getVorname(),
			s.getFunktion().getStandardText().textTranslation(SecurityUtil.currentUser().getLanguagePreference()),
			s.getZeichnung().getStandardText().textTranslation(SecurityUtil.currentUser().getLanguagePreference()),
			translation, personRole);
	}

	private AutoCompletePersonResultDto convertToAutoCompletePersonResultDto(KommFirmaEntity s) {
		return new AutoCompletePersonResultDto(s.getId(), s.getVersion(), s.getName(), s.getDomizil().getOrt(), HrMutationTypeOfPersonRoleEnum.LEGAL);
	}

	@Override
	public PersonEntity getPerson(long personId) {
		return jpaUtil.initialize(personRepo.findOne(personId), QPersonEntity.personEntity.zivilstand,
			QPersonEntity.personEntity.wohnadresse.land);
	}

	@Override
	public HrMutationPersonEntity getHrMutationPerson(long orgId, long mutationPersonId, int version) {
		HrMutationPersonEntity person = new JPAQuery<HrMutationPersonEntity>(em)
			.from(QHrMutationPersonEntity.hrMutationPersonEntity)
			.where(QHrMutationPersonEntity.hrMutationPersonEntity.id.eq(mutationPersonId)
				.and(QHrMutationPersonEntity.hrMutationPersonEntity.version.eq(version)))
			.fetchOne();
		// TODO [XDG/S9] Review which properties are necessary
		return jpaUtil.initialize(person, QHrMutationPersonEntity.hrMutationPersonEntity.newNaturalPerson,
			QHrMutationPersonEntity.hrMutationPersonEntity.existingLegalPeson,
			QHrMutationPersonEntity.hrMutationPersonEntity.existingNaturalPerson,
			QHrMutationPersonEntity.hrMutationPersonEntity.newLegalPerson);
	}

	@Override
	public GeschaftsrolleEntity saveGeschaftsrolle(GeschaftsrolleEntity ent) {
		return this.geschaftsrolleRepository.save(ent);
	}

	@Override
	public HrMutationPersonEntity saveHrMutationPerson(long orgId, HrMutationPersonEntity entity) {
		return hrMutationPersonRepo.save(entity);
	}

	@Override
	public PersonEntity savePerson(long orgId, PersonEntity entity) {
		return personRepo.save(entity);
	}

	@Override
	public GeschaftsrolleEntity loadGeschaftsrolleById(long orgId, long id, int version) {
		QPersonEntity qPerson = new QPersonEntity(QGeschaftsrolleEntity.geschaftsrolleEntity.person.getMetadata(),
			PathInits.DIRECT);
		QAdresseEntity qPersonAddress = new QAdresseEntity(
			QGeschaftsrolleEntity.geschaftsrolleEntity.person.wohnadresse.getMetadata(), PathInits.DIRECT);

		return jpaUtil.initialize(
			new JPAQuery<GeschaftsrolleEntity>(em).from(QGeschaftsrolleEntity.geschaftsrolleEntity)
				.join(QGeschaftsrolleEntity.geschaftsrolleEntity.person).fetchJoin()
				.where(QGeschaftsrolleEntity.geschaftsrolleEntity.id.eq(id)
					.and(QGeschaftsrolleEntity.geschaftsrolleEntity.version.eq(version)))
				.fetchOne(),
			qPerson.heimatortes, qPerson.auslaenderAusweis, qPerson.nationalitaetens, qPersonAddress.land);
	}

	@Override
	public PersonEntity getPerson(long orgId, long personId, int version) {
		PersonEntity entity = new JPAQuery<PersonEntity>(em).from(QPersonEntity.personEntity)
			.where(QPersonEntity.personEntity.id.eq(personId).and(QPersonEntity.personEntity.version.eq(version)))
			.fetchOne();
		// TODO [XDG/S9] Review which properties are necessary
		return jpaUtil.initialize(entity, QPersonEntity.personEntity.anrede, QPersonEntity.personEntity.zivilstand,
			QPersonEntity.personEntity.nationalitaetens.any().standardText.translations,
			QPersonEntity.personEntity.heimatortes, QPersonEntity.personEntity.wohnadresse,
			QPersonEntity.personEntity.auslaenderAusweis);
	}

	private static final String EXISTING_ADRESSE_SQL = "" + "SELECT DISTINCT adresse.* " + "FROM T_ORGANISATION org "
		+ "LEFT JOIN T_GESCHAEFTSSTELLE ges ON org.PK = ges.LN_ORGANISATION "
		+ "LEFT JOIN T_PROZESS prozess ON org.PK = prozess.LN_ORGANISATION "
		+ "LEFT JOIN T_AHV_ANMELDUNG ahv ON prozess.PK = ahv.LN_PROZESS "
		+ "LEFT JOIN T_HR_ANMELDUNG hr ON prozess.PK = hr.LN_PROZESS "
		+ "LEFT JOIN T_ADRESSE adresse ON adresse.PK = org.LN_DOMIZIL " + "OR adresse.PK = ahv.LN_ADRESSE_KONTAKT "
		+ "OR adresse.PK = hr.LN_ADRESSE_KORRESPONDENZ " + "OR adresse.PK = hr.LN_ADRESSE_RECHNUNG "
		+ "OR adresse.PK = ges.LN_ADRESSE " + "WHERE org.PK = :orgId AND prozess.TYP IN ('AHV', 'HR') ";

	@SuppressWarnings("unchecked")
	@Override
	public List<AdresseEntity> getListExistingAdresse(long orgId) {
		Query nativeQuery = em.createNativeQuery(EXISTING_ADRESSE_SQL, AdresseEntity.class);
		nativeQuery.setParameter("orgId", orgId);
		List<AdresseEntity> entities = nativeQuery.getResultList();

		Map<Long, CodeWertEntity> lands = applicationService.getCodeWerts(KategorieEnum.LAND).stream()
			.collect(Collectors.toMap(key -> key.getId(), value -> value));

		entities.stream().forEach(ent -> {
			ent.setLand(lands.get(ent.getLandId()));
		});

		return entities;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public HrMutationEntity deleteExcerptsAdresse(long orgId, long id, int version) {
		HrMutationEntity entity = new JPAQuery<HrMutationEntity>(em).from(QHrMutationEntity.hrMutationEntity).where(
			QHrMutationEntity.hrMutationEntity.id.eq(id).and(QHrMutationEntity.hrMutationEntity.version.eq(version)))
			.fetchOne();

		jpaUtil.initialize(entity, QHrMutationEntity.hrMutationEntity.excerptsDeliveryAddress,
			QHrMutationEntity.hrMutationEntity.excerptsBillingAddress);

		AdresseEntity delivery = entity.getExcerptsDeliveryAddress();
		AdresseEntity billing = entity.getExcerptsBillingAddress();

		entity.setExcerptsNum(0);
		entity.setExcerptsNumPrelim(0);
		entity.setExcerptsBillingAddress(null);
		entity.setExcerptsDeliveryAddress(null);
		updateProcess(orgId, entity);

		if (delivery != null) {
			addressRepo.delete(delivery);
		}

		if (billing != null) {
			addressRepo.delete(billing);
		}

		return entity;
	}

	@Override
	public GeschaftsrolleEntity loadFullGeschaftsrolleById(long orgId, long id, int version) {
		jpaUtil.enableFetchProfile("full-geschaeftsrollen-except-organisation");
		jpaUtil.enableFetchProfile("full-person-except-zivilstand-teilhaber");
		jpaUtil.enableFetchProfile("adresse-with-land");

		// TODO [XDG/S9] Need to check orgId condition & version to ensure the integrity characteristic?
		GeschaftsrolleEntity entity = geschaftsrolleRepository.findOne(id);

		jpaUtil.disableFetchProfile("full-geschaeftsrollen-except-organisation");
		jpaUtil.disableFetchProfile("full-person-except-zivilstand-teilhaber");
		jpaUtil.disableFetchProfile("adresse-with-land");
		
		jpaUtil.initialize(entity.getFunktion().getStandardText(), QStandardTextEntity.standardTextEntity.translations);
		jpaUtil.initialize(entity.getZeichnung().getStandardText(), QStandardTextEntity.standardTextEntity.translations);
		Set<CodeWertEntity> nationalitaetens = entity.getPerson().getNationalitaetens();
		for (CodeWertEntity codeWertEntity : nationalitaetens) {
			jpaUtil.initialize(codeWertEntity.getStandardText(), QStandardTextEntity.standardTextEntity.translations);
		}

		return entity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public HrMutationEntity deleteMutationPerson(long orgId, long id, int version, long personId, int personVersion) {
		HrMutationEntity entity = new JPAQuery<HrMutationEntity>(em).from(QHrMutationEntity.hrMutationEntity).where(
			QHrMutationEntity.hrMutationEntity.id.eq(id).and(QHrMutationEntity.hrMutationEntity.version.eq(version)))
			.fetchOne();

		jpaUtil.initialize(entity, QHrMutationEntity.hrMutationEntity.persons);

		Optional<HrMutationPersonEntity> personOptional = entity.getPersons().stream()
			.filter(p -> p.getId().equals(personId) && p.getVersion() == personVersion).findFirst();
		if (!personOptional.isPresent()) {
			throw new OptimisticLockingFailureException(
				"This entity has been modified by other user. HrMutationPersonEntity#id = " + personId);
		}

		entity.getPersons().remove(personOptional.get());
		updateProcess(orgId, entity);
		return entity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public HrMutationEntity updateTaskProzess(long orgId, HrMutationEntity entity) {
		AdresseEntity domicilToDelete = null;
		GeschaftsrolleEntity dissNewOwnerToDelete = null;
		AdresseEntity deliveryAddressToDelete = null;
		AdresseEntity billingAddressToDelete = null;

		if (!entity.isTaskName()) {
			entity.setNewCompanyName(null);
		}
		if (!entity.isTaskPurpose()) {
			entity.setNewPurpose(null);
		}
		if (!entity.isTaskExcerpts()) {
			entity.setExcerptsNum(0);
			entity.setExcerptsNumPrelim(0);
			deliveryAddressToDelete = entity.getExcerptsDeliveryAddress();
			entity.setExcerptsDeliveryAddress(null);
			billingAddressToDelete = entity.getExcerptsBillingAddress();
			entity.setExcerptsBillingAddress(null);
		}
		if (!entity.isTaskAddress()) {
			domicilToDelete = entity.getNewDomicile();
			entity.setNewDomicile(null);
		}
		if (!entity.isTaskRevision()) {
			entity.setRevCompanyName(null);
			entity.setRevNewSeatBfsNr(null);
			entity.setRevNewSeatCanton(null);
			entity.setRevNewSeatCity(null);
			entity.setRevNewSeatPolCommunity(null);
			entity.setRevPreviousSeatBfsNr(null);
			entity.setRevPreviousSeatCanton(null);
			entity.setRevPreviousSeatCity(null);
			entity.setRevPreviousSeatPolCommunity(null);
		}
		if (!entity.isTaskDissolution()) {
			dissNewOwnerToDelete = entity.getDissNewOwner();
			entity.setDissNewOwner(null);
			entity.setDissNewCompanyName(null);
			entity.setDissLeavingPartnerBirthday(null);
			entity.setDissLeavingPartnerFamilyName(null);
			entity.setDissLeavingPartnerGivenName(null);
		}
		if (!entity.isTaskPersons()) {
			if (!entity.getPersons().isEmpty()) {
				entity.getPersons().removeAll(entity.getPersons());
			}
		}

		entity = hrMutationRepo.save(entity);
		processUpdated(entity.getProzess());

		if (domicilToDelete != null) {
			addressRepo.delete(domicilToDelete);
		}
		if (dissNewOwnerToDelete != null) {
			geschaftsrolleRepository.delete(dissNewOwnerToDelete);
		}
		if (deliveryAddressToDelete != null) {
			addressRepo.delete(deliveryAddressToDelete);
		}
		if (billingAddressToDelete != null) {
			addressRepo.delete(billingAddressToDelete);
		}
		return entity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public FileDto downloadDocument(long orgId, long prozessId) {
		return new FileDto("hrMutation.pdf", SupportedFileTypeDownload.PDF, getDocument(orgId, prozessId));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public KommFirmaEntity getKommfirmaById(Long id, int version) {
		KommFirmaEntity entity = new JPAQuery<KommFirmaEntity>(em)
			.from(QKommFirmaEntity.kommFirmaEntity)
			.join(QKommFirmaEntity.kommFirmaEntity.kommges, QKommGesEntity.kommGesEntity).fetchJoin()
			.where(QKommFirmaEntity.kommFirmaEntity.id.eq(id)
				.and(QKommFirmaEntity.kommFirmaEntity.version.eq(version)))
			.fetchOne();
		jpaUtil.initialize(entity,
			QKommFirmaEntity.kommFirmaEntity.einlage,
			QKommFirmaEntity.kommFirmaEntity.domizil.land);
		
		if(entity.getDomizil() != null) {
			jpaUtil.initialize(entity.getDomizil().getLand(), QCodeWertEntity.codeWertEntity.standardText.translations);
		}
		
		if(entity.getEinlage() != null) {
			jpaUtil.initialize(entity.getEinlage(), QCodeWertEntity.codeWertEntity.standardText.translations);
		}
		return entity;
	}

	@Override
	public KommGesEntity loadKommgesByOrgId(long orgId) {
		return this.kommGesRepo.findOne(QKommGesEntity.kommGesEntity.organisation.id.eq(orgId));
	}	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public KommGesEntity saveKommGes(KommGesEntity kommGesEntity) {
		return kommGesRepo.save(kommGesEntity);
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
	public HrMutationPersonEntity saveMutationLegalPersonAndDeleteNaturalPerson(long orgId, HrMutationPersonEntity entity) {
		GeschaftsrolleEntity deletedPerson = entity.getNewNaturalPerson();
		entity.setNewNaturalPerson(null);
		entity = hrMutationPersonRepo.save(entity);
		if(deletedPerson != null) {
			geschaftsrolleRepository.delete(deletedPerson);
		}
		return entity;
	}

	@Override
	public HrMutationPersonEntity saveMutationNaturalPersonAndDeleteLegalPerson(long orgId,
		HrMutationPersonEntity entity) {
		KommFirmaEntity deletedPerson = entity.getNewLegalPerson();
		entity.setNewLegalPerson(null);
		entity = hrMutationPersonRepo.save(entity);
		if (deletedPerson != null) {
			kommFirmaRepo.delete(deletedPerson);
		}
		return entity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public HrMutationEntity refreshDissNewOwner(long id, int version, long orgId, GeschaftsrolleEntity geschaftrolle) {
		QPersonEntity qPerson = QPersonEntity.personEntity;
		HrMutationEntity entity = getHrMutation(id, version, orgId, QHrMutationEntity.hrMutationEntity.dissNewOwner.person);
		if(entity.getDissNewOwner() != null) {
			jpaUtil.initialize(entity.getDissNewOwner(), 
				QGeschaftsrolleEntity.geschaftsrolleEntity.person.wohnadresse,
				QGeschaftsrolleEntity.geschaftsrolleEntity.person.heimatortes);
		}
		GeschaftsrolleEntity deletedGes = entity.getDissNewOwner();
		entity.setDissNewOwner(geschaftrolle);
		entity = updateProcess(orgId, entity);
		if(deletedGes != null) {
			geschaftsrolleRepository.delete(deletedGes);
		}
		initDissNewOwner(qPerson, entity.getDissNewOwner());
		return entity;
	}

}
