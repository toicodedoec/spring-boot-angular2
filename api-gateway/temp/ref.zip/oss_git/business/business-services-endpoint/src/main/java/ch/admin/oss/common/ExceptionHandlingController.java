/*
 * ExceptionHandlerController
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedCredentialsNotFoundException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.admin.oss.exception.ValidationException;

/**
 * Centralized place for handling all generic and unexpected exceptions in OSS.
 * 
 * @author phd
 */
@ControllerAdvice
public class ExceptionHandlingController {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ExceptionHandlingController.class);

	private static ObjectMapper objectMapper;

	@Autowired
	public void setObjectMapper(ObjectMapper objectMapper) {
		ExceptionHandlingController.objectMapper = objectMapper;
	}

	@ExceptionHandler(OptimisticLockingFailureException.class)
	public ResponseEntity<?> handleConcurrentUpdate(Exception exception) {
		return log(ResponseEntity.status(HttpStatus.PRECONDITION_FAILED), exception)
			.body(errorFor("You are trying to update a resource that has been modified by another user"));
	}

	@ExceptionHandler(AccessDeniedException.class)
	public ResponseEntity<?> handleAuthorizationException(Exception exception) {
		return log(ResponseEntity.status(HttpStatus.UNAUTHORIZED), exception)
			.body(errorFor("Authorization error occurred"));
	}

	@ExceptionHandler(PreAuthenticatedCredentialsNotFoundException.class)
	public ResponseEntity<?> handlereAuthenticatedCredentialsNotFoundException(Exception exception) {
		return log(ResponseEntity.status(HttpStatus.UNAUTHORIZED), exception)
			.body(errorFor("Authentication error occurred"));
	}

	@ExceptionHandler(AuthenticationException.class)
	public ResponseEntity<?> handleAuthenticationException(Exception exception) {
		return log(ResponseEntity.status(HttpStatus.UNAUTHORIZED), exception)
			.body(errorFor("Authentication error occurred"));
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<?> handleValidationError(Exception exception) {
		return log(ResponseEntity.status(HttpStatus.BAD_REQUEST), exception)
			.body(errorFor("Data validation error occurred"));
	}

	@ExceptionHandler(ValidationException.class)
	public ResponseEntity<?> handleValidationErrorException(ValidationException exception) {
		return log(ResponseEntity.status(HttpStatus.PRECONDITION_FAILED), exception)
			.body(errorFor("Data validation error occurred: " + exception.getMessage()));
	}

	@ExceptionHandler(Throwable.class)
	public ResponseEntity<?> handleUnexpectedException(Throwable exception) {
		return log(ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR), exception)
			.body(errorFor("Internal server error occurred"));
	}

	private BodyBuilder log(BodyBuilder bb, Throwable exception) {
		// Enhancement of the body can happen here.
		LOGGER.error("Unhandled exception occurred", exception);
		return bb;
	}

	public static String errorFor(String message) {
		try {
			return objectMapper.writeValueAsString(new ErrorBody((String) MDC.get(MDCContext.CORRELATION_ID), message));
		} catch (JsonProcessingException e) {
			throw new OssTechnicalException("Error during error serialization", e);
		}
	}
}
