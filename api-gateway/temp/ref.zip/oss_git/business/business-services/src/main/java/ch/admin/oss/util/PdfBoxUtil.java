/*
 * PdfBoxUtil
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.cos.COSString;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.PDSignature;
import org.apache.pdfbox.pdmodel.interactive.form.PDSignatureField;
import org.apache.pdfbox.text.PDFTextStripper;

import ch.admin.oss.common.OssTechnicalException;

public class PdfBoxUtil {

	private static final String X509_CERTIFICATE_TYPE = "X.509";	
	
	private static final String CERT_NAME_TAG = "CN=";
	
	private static final String SHA_256 = "SHA-256";
	
	/**
	 * <p>Compare two signatures list, return {@code true} if signatures list in <strong>pdfBytes</strong> represent in <strong>anotherPdfBytes</strong> </p>
	 * 
	 * <p>{@code false} if at least a signature in <strong>pdfBytes</strong> dosen't exist in <strong>anotherPdfBytes</strong></p>
	 * 
	 * @param pdfBytes
	 * @param anotherPdfBytes
	 * @return {@code true} if signatures list in pdfBytes represent in anotherPdfBytes 
	 * @throws IOException throw when can't load pdf file
	 */
	public static boolean validateSignatures(byte[] pdfBytes, byte[] anotherPdfBytes) throws IOException {
		for (PDSignatureField sign : getSignatureFields(pdfBytes)) {
			String hashSignInRaw = hashBytes(sign.getSignature().getSignedContent(pdfBytes), SHA_256);
			boolean valid = false;
			for (PDSignatureField signInSigned : getSignatureFields(anotherPdfBytes)) {
				String hashSignInEncrypt = hashBytes(signInSigned.getSignature().getSignedContent(anotherPdfBytes), SHA_256);
				valid = StringUtils.equals(hashSignInRaw, hashSignInEncrypt);
				if (valid) {
					break;
				}
			}
			if (!valid) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Extract content of 2 files pdf and compare them each other
	 * 
	 * @param pdfBytes byte array of the pdf file
	 * @param anotherPdfBytes byte array of the pdf file
	 * @return {@code true} if 2 files pdf have the same content and vice versa
	 */
	public static boolean compareContentPdf(byte[] pdfBytes, byte[] anotherPdfBytes) {
		return StringUtils.equals(hashString(extractContent(pdfBytes), SHA_256), hashString(extractContent(anotherPdfBytes), SHA_256));
	}
	
	/**
	 * Retrieve all signature fields from the document
	 * 
	 * @param pdfBytes
	 * @return a <code>List</code> of <code>PDSignatureField</code>s
	 * @throws IOException throw when can't load pdf file
	 */
	public static List<PDSignatureField> getSignatureFields(byte[] pdfBytes) throws IOException {
		try(PDDocument pdDoc = PDDocument.load(pdfBytes)) {
			return pdDoc.getSignatureFields();
		}
	}
	
	/**
	 * Retrieve all the signer from the document
	 * 
	 * @param signatureFields
	 * @return a <code>List</code> of <code>String</code>
	 */
	public static List<String> extractSignees(List<PDSignatureField> signatureFields) {
		List<String> signees = new ArrayList<>();
		for(PDSignatureField sig : signatureFields) {
			signees.add(findSigneeName(extractSignatureToCertificates(sig.getSignature())));
		}
		return signees;
	}

	/**
	 * <p>Retrieve name of Signer in subject</p>
	 * 
	 * @param subject
	 * @return {@code String} name
	 */
	private static String extractSigneeName(String subject) {
		if(subject == null) {
			return "";
		}
		int indexStart = subject.indexOf(CERT_NAME_TAG);
		int indexEnd = subject.indexOf(",", indexStart);
		if(indexEnd >= indexStart) {
			return subject.substring(indexStart, indexEnd).replace(CERT_NAME_TAG, StringUtils.EMPTY);
		} else {
			return subject.substring(indexStart).replace(CERT_NAME_TAG, StringUtils.EMPTY);
		}
	}
	
	/**
	 * <p>Retrieve hash string of {@code bytes} with {@code algorithm}</p>
	 * 
	 * @param bytes input byte array
	 * @param algorithm the name of the algorithm requested.
	 * @return hash {@code String}
	 */
	private static String hashBytes(byte[] bytes, String algorithm) {
		try {
			MessageDigest digest = MessageDigest.getInstance(algorithm);
			byte[] hashedBytes = digest.digest(bytes);
			return convertByteArrayToHexString(hashedBytes);
		} catch (NoSuchAlgorithmException e) {
			throw new OssTechnicalException("Could not generate hash form byte", e);
		}
	}

	/**
	 * <p>Retrieve hash string of {@code plainText} with {@code algorithm}</p>
	 * 
	 * @param plainText input text
	 * @param algorithm the name of the algorithm requested.
	 * @return hash {@code String}
	 */
	private static String hashString(String plainText, String algorithm) {
		try {
			MessageDigest digest = MessageDigest.getInstance(algorithm);
			byte[] hashedBytes = digest.digest(plainText.getBytes("UTF-8"));
			return convertByteArrayToHexString(hashedBytes);
		} catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
			throw new OssTechnicalException("Could not generate hash form string", e);
		}
	}

	/**
	 * <p>Retrieve {@code String} from {@code arrayBytes}</p>
	 * 
	 * @param arrayBytes byte array input
	 * @return {@code String}
	 */
	private static String convertByteArrayToHexString(byte[] arrayBytes) {
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < arrayBytes.length; i++) {
			stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16).substring(1));
		}
		return stringBuffer.toString();
	}

	/**
	 * <p>Retrieve the content of pdf file</p>
	 * 
	 * @param bytes byte array of pdf file
	 * @return String of content
	 */
	private static String extractContent(byte[] bytes) {
		try (PDDocument pdDoc = PDDocument.load(bytes)) {
			PDFTextStripper pdfStripper = new PDFTextStripper();
			return pdfStripper.getText(pdDoc);
		} catch (FileNotFoundException e) {
			throw new OssTechnicalException("File not found", e);
		} catch (IOException e) {
			throw new OssTechnicalException("Could not extract content", e);
		}
	}

	/**
	 * <p>Retrieve List of Certificate from Signature</p>
	 * 
	 * @param sig {@code PDSignature}
	 * @return a <code>List</code> of <code>X509Certificate</code>
	 */
	private static List<X509Certificate> extractSignatureToCertificates(PDSignature sig) {
		try {
			COSString certString = (COSString) sig.getCOSObject().getDictionaryObject(COSName.CONTENTS);
			return CertificateFactory.getInstance(X509_CERTIFICATE_TYPE)
					.generateCertificates(new ByteArrayInputStream(certString.getBytes())).stream()
					.map(c -> (X509Certificate)c)
					.collect(Collectors.toList());
		} catch (CertificateException e) {
			throw new OssTechnicalException("Could not extract signature to certificates", e);
		}
	}
	
	/**
	 * <p>Find name of signer in list certs according following algorithm (<b>SECOOSS-427</b>)</p>
	 * 
	 * <p>1. Find the root cert. This is the cert where issuerDN and subjectDN are equal.</p>
	 * <p>2. Then find a cert which has the root cert's subjectDN as its issuerDN.</p>
	 * <p>3. Find the next cert, which has the subjectDN of the previous cert as its issuerDN  and so on, until no other cert can be found.</p>
	 * 
	 * <p>To find root cert: {@link findRootCert}</p>
	 * <p>To find next cert: {@link findNextCert}</p>
	 * 
	 * @param certs a <code>List</code> of <code>X509Certificate</code>
	 * @return String of signer name
	 */
	private static String findSigneeName(List<X509Certificate> certs) {
		X509Certificate root = findRootCert(certs);
		X509Certificate nextCert = findNextCert(root, certs);
		while(nextCert != null) {
			root = nextCert;
			nextCert = findNextCert(root, certs);
		}
		if(root != null) {
			return extractSigneeName(root.getSubjectDN().getName());
		}
		return StringUtils.EMPTY;
	}
	
	/**
	 * <p>Retrieve the next cert following logic</p>
	 * 
	 * <p>Find a cert in {@code certs} with root#SubjectDN#name == cert#IssuerDN#name and cert#IssuerDN#name != #SubjectDN#name</p>
	 * 
	 * @param root a root cert
	 * @param certs a <code>List</code> of <code>X509Certificate</code>
	 * @return {@link X509Certificate}
	 */
	private static X509Certificate findNextCert(X509Certificate root, List<X509Certificate> certs) {
		Optional<X509Certificate> optional = certs
				.stream()
				.filter(c -> StringUtils.equals(c.getIssuerDN().getName(), root.getSubjectDN().getName())
						&& !StringUtils.equals(c.getIssuerDN().getName(), c.getSubjectDN().getName()))
				.findFirst();
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}

	/**
	 * Retrieve the root cert which has SubjectDN#name == IssuerDN#name in {@code certs}
	 * 
	 * @param certs a <code>List</code> of <code>X509Certificate</code>
	 * @return {@link X509Certificate}
	 */
	private static X509Certificate findRootCert(List<X509Certificate> certs) {
		Optional<X509Certificate> optional = certs
				.stream()
				.filter(c -> StringUtils.equals(c.getSubjectDN().getName(), c.getIssuerDN().getName()))
				.findFirst();
		if(optional.isPresent()) {
			return optional.get();
		}
		return null;
	}
}
