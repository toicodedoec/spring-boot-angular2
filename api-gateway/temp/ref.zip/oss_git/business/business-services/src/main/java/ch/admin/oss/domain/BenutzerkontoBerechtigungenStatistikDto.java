package ch.admin.oss.domain;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;

@Entity
@SqlResultSetMapping(name = "BenutzerkontoBerechtigungenStatistikDto", entities = @EntityResult(entityClass = BenutzerkontoBerechtigungenStatistikDto.class))
public class BenutzerkontoBerechtigungenStatistikDto {
	@Id
	private String groupName;
	private Long quantity;

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

}
