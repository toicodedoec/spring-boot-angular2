/*
 * OssAsposeUtil
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.util;

import static java.time.temporal.ChronoField.DAY_OF_MONTH;
import static java.time.temporal.ChronoField.MONTH_OF_YEAR;
import static java.time.temporal.ChronoField.YEAR;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.SignStyle;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder;

import com.aspose.words.Bookmark;
import com.aspose.words.BreakType;
import com.aspose.words.Document;
import com.aspose.words.DocumentBuilder;
import com.aspose.words.HeaderFooter;
import com.aspose.words.HeaderFooterType;
import com.aspose.words.HorizontalAlignment;
import com.aspose.words.ImportFormatMode;
import com.aspose.words.MailMerge;
import com.aspose.words.MailMergeCleanupOptions;
import com.aspose.words.Node;
import com.aspose.words.Paragraph;
import com.aspose.words.PdfCompliance;
import com.aspose.words.PdfSaveOptions;
import com.aspose.words.RelativeHorizontalPosition;
import com.aspose.words.RelativeVerticalPosition;
import com.aspose.words.SaveFormat;
import com.aspose.words.Section;
import com.aspose.words.SectionStart;
import com.aspose.words.Shape;
import com.aspose.words.ShapeType;
import com.aspose.words.VerticalAlignment;
import com.aspose.words.WrapType;

import ch.admin.oss.OssCurrencyFormatter;
import ch.admin.oss.OssDateFormatter;
import ch.admin.oss.OssPdfGenerateTechnicalException;
import ch.admin.oss.business.AhvDto;
import ch.admin.oss.business.AhvTemplateType;
import ch.admin.oss.generator.aspose.OssAsposeBean;
import ch.admin.oss.generator.aspose.OssAsposeContext;
import ch.admin.oss.generator.aspose.OssAsposeRegion;
import ch.admin.oss.generator.aspose.converter.OssAsposeAnnotationConverter;
import ch.admin.oss.generator.aspose.converter.OssAsposeConverter;
import ch.admin.oss.generator.aspose.handler.HandleMergeImageField;

public class OssAsposeUtil {

	private static final String ROOT_REGION = "root";
	
	/**
	 * AHV template prefix
	 */
	private static final String TEMPLATE_AHV = "AHV";
	
	private static final String BOOKMARK_FOR_SECTION_BREAK = "section_break";

	// TODO [HHG, S9]: This is copied from OssConstants. We should add
	// a dependency to common module and use directly OssConstants.
	private static final DateTimeFormatter DATE_FORMATTER = new DateTimeFormatterBuilder()
		.appendValue(DAY_OF_MONTH, 2)
		.appendLiteral('.')
		.appendValue(MONTH_OF_YEAR, 2)
		.appendLiteral('.')
		.appendValue(YEAR, 4, 10, SignStyle.EXCEEDS_PAD)
		.toFormatter();
	
	private static final DateTimeFormatter DATE_WITHOUT_YEAR_FORMATTER = new DateTimeFormatterBuilder()
		.appendValue(DAY_OF_MONTH, 2)
		.appendLiteral('.')
		.appendValue(MONTH_OF_YEAR, 2)
		.toFormatter();
	
	private static final DateTimeFormatter DATE_TIME_FORMATTER = new DateTimeFormatterBuilder()
		.appendPattern("dd.MM.YYYY, HH:mm")
		.toFormatter();

	// TODO [HHA, S9] Move to common
	public static final String MONEY_PATTERN = "#,##0.00";
	public static final String MONEY_INTEGER_PATTERN = "#,##0";
	public static final DecimalFormat MONEY_FORMATTER;
	public static final DecimalFormat MONEY_INTEGER_FORMATTER;
	static {
		DecimalFormatSymbols symbol = new DecimalFormatSymbols(LocaleContextHolder.getLocale());
		symbol.setGroupingSeparator('\'');
		symbol.setDecimalSeparator('.');
		
		MONEY_FORMATTER = new DecimalFormat(MONEY_PATTERN, symbol);
		MONEY_FORMATTER.setRoundingMode(RoundingMode.HALF_UP);

		MONEY_INTEGER_FORMATTER = new DecimalFormat(MONEY_INTEGER_PATTERN, symbol);
		MONEY_INTEGER_FORMATTER.setRoundingMode(RoundingMode.HALF_UP);

	}
	
	/**
	 * Merge a document with a single entity.
	 * 
	 * @param doc is the document to be merged
	 * @param context is the merging context.
	 * @param object is the root object.
	 * 
	 * @throws Exception
	 */
	public static <T> void merge(Document doc, OssAsposeContext context, T object) throws Exception {
		MailMerge mailMerge = getMailMerge(doc);
		mailMerge.execute(new OssAsposeBean(context, object));
		mailMerge.executeWithRegions(new OssAsposeRegion(context, object));
	}


	/**
	 * Merge a document with a list of entity.
	 * <pre>
	 *   The document must be wrapped in the root region:
	 *   «TableStart:root»
	 *   	«root.property»
	 *   «TableEnd:root»
	 * </pre>
	 * 
	 * @param doc is the document to be merged
	 * @param context is the merging context.
	 * @param objects is the root objects.
	 * 
	 * @throws Exception
	 */
	public static <T> void merge(Document doc, OssAsposeContext context, List<T> objects) throws Exception {
		MailMerge mailMerge = getMailMerge(doc);
		mailMerge.executeWithRegions(new OssAsposeBean(context, objects, ROOT_REGION));
	}

	private static MailMerge getMailMerge(Document doc) {
		MailMerge mailMerge = doc.getMailMerge();
		mailMerge.setTrimWhitespaces(false);
		mailMerge.setCleanupOptions(
			MailMergeCleanupOptions.REMOVE_UNUSED_FIELDS | MailMergeCleanupOptions.REMOVE_CONTAINING_FIELDS
				| MailMergeCleanupOptions.REMOVE_EMPTY_PARAGRAPHS | MailMergeCleanupOptions.REMOVE_UNUSED_REGIONS);
		mailMerge.setFieldMergingCallback(HandleMergeImageField.getInstance());
		return mailMerge;
	}

	/**
	 * Generate HR document.
	 * @param data Data source
	 * @param language Language for texts displayed in template
	 * @param type of template.
	 * 
	 * @return Byte arrays of generated file
	 */
	public static <T> byte[] generateDocument(TemplateDto<T> templateDto, IDocumentMergeCallback<T> callback) {
		List<Document> documents = new ArrayList<>(templateDto.getFiles().size());
		for (TemplateFile file : templateDto.getFiles()) {
			if (StringUtils.isNotEmpty(file.getField())) {
				try {
					Object value = PropertyUtils.getNestedProperty(templateDto.getData(), file.getField());
					if (value == null || (value instanceof Iterable && CollectionUtils.sizeIsEmpty(value))) {
						continue;
					}
				} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
					throw new OssPdfGenerateTechnicalException("Cannot read field " + file.getField(), e);
				}
			}
			String name = file.getFileName() + "_" + templateDto.getLanguage().toLowerCase() + ".docx";
			try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("templates/" + name)) {
				Document document = new Document(is);
				merge(document, context(), templateDto.getData());
				if (callback != null) {
					callback.apply(document, templateDto.getData());
				}
				if (StringUtils.isNoneEmpty(templateDto.getWatermark())) {
					writeWatermark(document, templateDto.getWatermark());
				}
				documents.add(document);
			} catch (Exception e) {
				throw new OssPdfGenerateTechnicalException("Technical error occurred while generating document", e);
			}
		}
		try {
			Document rootDocument = documents.remove(0);
			combineDocuments(rootDocument, documents);
			rootDocument.updatePageLayout();
			return convertDocumentToByteArray(rootDocument, templateDto.getFormat());
		} catch (Exception e) {
			throw new OssPdfGenerateTechnicalException("Technical error occurred while combining documents", e);
		}
	}

	/**
	 * Generate AHV pdf document.
	 * 
	 * @param type AHV template type enum
	 * @param language Language for texts displayed in template
	 * @param data Data source
	 * @return Byte arrays of generated file
	 */
	public static byte[] generateAhvPdf(AhvTemplateType type, String language, AhvDto data, String watermarkText) {
		String name = TEMPLATE_AHV + "_" + type + "_" + language.toLowerCase() + ".docx";
		try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("templates/" + name)) {
			if (is == null) {
				if (!"de".equals(language)) {
					return generateAhvPdf(type, "de", data, watermarkText);
				}
				throw new OssPdfGenerateTechnicalException("No AHV pdf template found language " + language);
			}
			return generateDocument(new Document(is), SaveFormat.PDF, data, watermarkText);
		} catch (Exception e) {
			throw new OssPdfGenerateTechnicalException("Technical error occurred while generating AHV pdf", e);
		}
	}

	private static <T> byte[] generateDocument(Document doc, int format, T data, String watermarkText) throws Exception {
		merge(doc, context(), data);
		if (watermarkText != null) {
			writeWatermark(doc, watermarkText);
		}
		insertSectionBreaks(doc);
		return convertDocumentToByteArray(doc, format);
	}

	private static byte[] convertDocumentToByteArray(Document doc, int format) throws Exception {
		try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
			switch (format) {
				case SaveFormat.PDF:
					PdfSaveOptions saveOptions = new PdfSaveOptions();
					saveOptions.setSaveFormat(format);
					saveOptions.setCompliance(PdfCompliance.PDF_A_1_B);
					doc.save(os, saveOptions);
					break;
				default:
					doc.save(os, format);
			}
			return os.toByteArray();
		}
	}

	private static void insertSectionBreaks(Document doc) throws Exception {
		DocumentBuilder docBuilder = new DocumentBuilder(doc);
		List<Bookmark> bookmarks = getBookmarks(doc);
		if (!bookmarks.isEmpty()) {
			Bookmark lastBookMark = bookmarks.get(bookmarks.size() - 1);
			for (Bookmark bookmark : bookmarks) {
				if (docBuilder.moveToBookmark(bookmark.getName())) {
					if (!lastBookMark.equals(bookmark)) {
						docBuilder.insertBreak(BreakType.SECTION_BREAK_NEW_PAGE);
					}
					bookmark.remove();
				}
			}
			doc.getRange().getBookmarks().clear();
		}
	}

	private static List<Bookmark> getBookmarks(Document doc) {
		List<Bookmark> bookmarks = new ArrayList<>();
		for (Bookmark bookmark : doc.getRange().getBookmarks()) {
			if (StringUtils.startsWith(bookmark.getName(), BOOKMARK_FOR_SECTION_BREAK)) {
				bookmarks.add(bookmark);
			}
		}
		return bookmarks;
	}

	/**
	 * Remove an empty block with marked with a name.
	 * 
	 * @param doc
	 * @param bookmarkName
	 */
	public static void removeEmptyBlock(Document doc, String bookmarkName, int nodeType) throws Exception {
		Bookmark bookmark = doc.getRange().getBookmarks().get(bookmarkName);
		if (bookmark != null) {
			Node table = bookmark.getBookmarkStart().getAncestor(nodeType);
		    if (table != null) {
		    	table.remove();
		    }
		    bookmark.remove();
		}
	}

	private static void writeWatermark(Document doc, String watermarkText) throws Exception {
		Shape watermark = insertWatermark(doc, watermarkText);
		Paragraph watermarkPara = new Paragraph(doc);
		watermarkPara.appendChild(watermark);
		for (Section section : doc.getSections()) {
			insertWatermarkIntoHeader(watermarkPara, section, HeaderFooterType.HEADER_PRIMARY);
			insertWatermarkIntoHeader(watermarkPara, section, HeaderFooterType.HEADER_FIRST);
			insertWatermarkIntoHeader(watermarkPara, section, HeaderFooterType.HEADER_EVEN);
		}
	}

	private static Shape insertWatermark(Document doc, String watermarkText) throws Exception {
		Shape watermark = new Shape(doc, ShapeType.TEXT_PLAIN_TEXT);
		watermark.getTextPath().setText(watermarkText);
		watermark.getTextPath().setFontFamily("Arial");
		watermark.setWidth(500);
		watermark.setHeight(100);
		watermark.setRotation(-40);
		watermark.getFill().setColor(Color.LIGHT_GRAY); 
		watermark.setStrokeColor(Color.LIGHT_GRAY);
		watermark.setRelativeHorizontalPosition(RelativeHorizontalPosition.PAGE);
		watermark.setRelativeVerticalPosition(RelativeVerticalPosition.PAGE);
		watermark.setWrapType(WrapType.NONE);
		watermark.setVerticalAlignment(VerticalAlignment.CENTER);
		watermark.setHorizontalAlignment(HorizontalAlignment.CENTER);
		watermark.setBehindText(true);
		return watermark;
	}
	
	private static void insertWatermarkIntoHeader(Paragraph watermark, Section section, int headerType) throws Exception {
		HeaderFooter header = section.getHeadersFooters().getByHeaderFooterType(headerType);
		if (header == null) {
			header = new HeaderFooter(section.getDocument(), headerType);
			section.getHeadersFooters().insert(headerType, header);
		}
		header.appendChild(watermark.deepClone(true));
	}

	/**
	 * Merge all documents to target document.
	 * 
	 * @param target
	 * @param documents
	 * 
	 * @return
	 * @throws Exception
	 */
	public static void combineDocuments(Document target, List<Document> documents) throws Exception {
		target.getFirstSection().getPageSetup().setRestartPageNumbering(true);
		target.getFirstSection().getPageSetup().setPageStartingNumber(1);
		int pageCount = target.getPageCount();

		for (Document document : documents) {
			document.getFirstSection().getPageSetup().setSectionStart(SectionStart.NEW_PAGE);
			document.getFirstSection().getPageSetup().setPageStartingNumber(pageCount + 1);
			pageCount += document.getPageCount();
			target.appendDocument(document, ImportFormatMode.KEEP_SOURCE_FORMATTING);
		}
	}

	private static OssAsposeContext context() {
		return new OssAsposeContext()
			.register(LocalDate.class, new OssAsposeConverter<LocalDate>() {
				@Override
				public Object convert(OssAsposeContext context, LocalDate value) {
					return value.format(DATE_FORMATTER);
				}
			})
			.register(LocalDateTime.class, new OssAsposeConverter<LocalDateTime>() {
				@Override
				public Object convert(OssAsposeContext context, LocalDateTime value) {
					return value.format(DATE_TIME_FORMATTER);
				}
			})
			.registerAnnotation(OssDateFormatter.class, new OssAsposeAnnotationConverter<OssDateFormatter>() {
				@Override
				public Object convert(OssAsposeContext context, Object originalValue, Object value, OssDateFormatter formatter) {
					if (formatter.hideYear()) {
						return DATE_WITHOUT_YEAR_FORMATTER.format((TemporalAccessor) originalValue);
					} else {
						return DATE_FORMATTER.format((TemporalAccessor) originalValue);
					}
				}
			})
			.registerAnnotation(OssCurrencyFormatter.class, new OssAsposeAnnotationConverter<OssCurrencyFormatter>() {
				@Override
				public Object convert(OssAsposeContext context, Object originalValue, Object value, OssCurrencyFormatter formatter) {
					if (formatter.integer()) {
						return MONEY_INTEGER_FORMATTER.format(originalValue);
					} else {
						return MONEY_FORMATTER.format(originalValue);
					}
				}
			});
	}

}