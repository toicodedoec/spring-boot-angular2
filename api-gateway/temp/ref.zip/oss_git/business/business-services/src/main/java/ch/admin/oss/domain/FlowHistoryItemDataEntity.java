/*
 * FlowHistoryItemDataEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * @author coh
 */
@Entity
@Table(name = "T_FLOW_HISTORY_ITEM_DATA")
public class FlowHistoryItemDataEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_FLOW_HISTORY_ITEM", foreignKey = @ForeignKey(name = "FK_HISTORY_ITEM_DATA"))
	private FlowHistoryItemEntity flowHistoryItem;

	@Column(name = "KEY")
	private String key;

	@Column(name = "VALUE")
	private String value;

	public FlowHistoryItemDataEntity() {}

	public FlowHistoryItemDataEntity(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public void setFlowHistoryItem(FlowHistoryItemEntity flowHistoryItem) {
		this.flowHistoryItem = flowHistoryItem;
	}

	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
