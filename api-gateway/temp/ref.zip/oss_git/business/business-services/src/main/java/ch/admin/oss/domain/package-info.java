/**
 * Package information for this package.
 *
 * @author phd
 */
@QueryEntities(org.hibernate.envers.DefaultRevisionEntity.class)
package ch.admin.oss.domain;

import com.querydsl.core.annotations.QueryEntities;
