/*
 * ZefixTooManyResultsException
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

/**
 * This exception is thrown when searching company via Zefix webservice 
 * and Zefix returns an error code which represents too many result found.
 * 
 * @author hhg
 *
 */
public class ZefixTooManyResultsException extends Exception {

	private static final long serialVersionUID = -7226438557181970428L;

	public ZefixTooManyResultsException(String string) {
		super(string);
	}
}
