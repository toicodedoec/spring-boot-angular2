/*
 * HrDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import ch.admin.oss.util.ImageDto;

/**
 * @author hha
 */
public class HrAmtDto {

	private String chAmtsbezeichnung;
	private String amtsbezeichnung;
	private String unterschriftsbeglaubigung;
	private String kanton;
	private String strasse;
	private String plz;
	private String ort;

	private ImageDto kantonImage;

	public String getChAmtsbezeichnung() {
		return chAmtsbezeichnung;
	}

	public void setChAmtsbezeichnung(String chAmtsbezeichnung) {
		this.chAmtsbezeichnung = chAmtsbezeichnung;
	}

	public String getAmtsbezeichnung() {
		return amtsbezeichnung;
	}

	public void setAmtsbezeichnung(String amtsbezeichnung) {
		this.amtsbezeichnung = amtsbezeichnung;
	}

	public String getUnterschriftsbeglaubigung() {
		return unterschriftsbeglaubigung;
	}

	public void setUnterschriftsbeglaubigung(String unterschriftsbeglaubigung) {
		this.unterschriftsbeglaubigung = unterschriftsbeglaubigung;
	}

	public String getKanton() {
		return kanton;
	}

	public void setKanton(String kanton) {
		this.kanton = kanton;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public ImageDto getKantonImage() {
		return kantonImage;
	}

	public void setKantonImage(ImageDto kantonImage) {
		this.kantonImage = kantonImage;
	}

}
