/*
 * ApplicationService
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.application.service.impl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.application.repository.IFlowHistoryRepository;
import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.common.AbstractOSSService;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.CHOrtHRAmtEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.FlowHistoryEntity;
import ch.admin.oss.domain.FlowHistoryItemDataEntity;
import ch.admin.oss.domain.FlowHistoryItemEntity;
import ch.admin.oss.domain.HrAmtEntity;
import ch.admin.oss.domain.LandEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.QCHOrtHRAmtEntity;
import ch.admin.oss.domain.QFlowHistoryEntity;
import ch.admin.oss.domain.QHrAmtEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QUserEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.portal.repository.IUserRepository;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSConstants;

/**
 * API for text translation function.
 * 
 * @author xdg
 */

@Service
@Transactional(rollbackFor = Throwable.class)
public class ApplicationService extends AbstractOSSService implements IApplicationService {

	private static final int DURATION_FOR_COUNTING = 12;
	
	private static final String COUNT_ALL_ORG_SQL = ""
		+ " SELECT SUM (NUMOFORG) "
		+ " FROM (SELECT COUNT(ORGANISATI0_.PK) AS NUMOFORG FROM T_ORGANISATION ORGANISATI0_"
		+ "       UNION ALL "
		+ "       SELECT COUNT(KMUADMINDA0_.PK) AS NUMOFORG FROM T_KMU_ADMIN_DATA KMUADMINDA0_ WHERE KMUADMINDA0_.ZEFIX_MATCH_UID IS NULL"
		+ "       UNION ALL "
		+ "       SELECT COUNT(STARTBIZDA0_.PK) AS NUMOFORG FROM T_STARTBIZ_DATA STARTBIZDA0_ WHERE STARTBIZDA0_.LN_ORGANISATION IS NULL)";

	@Autowired
	private IFlowHistoryRepository flowHistoryRepo;

	@Autowired
	private IUserRepository userRepo;
	
	@Value("${oss.portal.intervalOfRefreshingNumberOfOrg}")
	private int intervalOfRefreshingNumberOfOrg;

	@Value("${oss.gui.stats.userAccount12Months}")
	private boolean userAccount12Months;

	@Value("${oss.gui.stats.companies12Months}")
	private boolean companies12Months;

	@Override
	public Map<KategorieEnum, List<CodeWertEntity>> getCodeWerts(List<KategorieEnum> kategories) {
		List<CodeWertEntity> codeWerts = cacheService.getCodeWerts();
		
		Map<KategorieEnum, List<CodeWertEntity>> collect = codeWerts.stream()
				.filter(c -> kategories.contains(c.getKategorie()))
				.collect(Collectors.groupingBy(codeWert -> ((CodeWertEntity) codeWert).getKategorie()));
			collect.forEach((k, v) -> {
				v = v.stream().sorted((codeWert1, codeWert2) -> codeWert1.getPos() - codeWert2.getPos())
					.collect(Collectors.toList());
			});
			
		return collect;
	}
	
	@Override
	public List<CodeWertEntity> getCodeWerts(KategorieEnum kategorie) {
		return cacheService.getCodeWerts().stream()
				.filter(c -> kategorie == c.getKategorie())
				.sorted((codeWert1, codeWert2) -> codeWert1.getPos() - codeWert2.getPos())
				.collect(Collectors.toList());
	}

	@Override
	public CodeWertEntity getCodeWert(Long id) {
		return cacheService.getCodeWerts().stream().filter(c -> c.getId().equals(id)).findFirst().get();
	}

	@Override
	public List<BrancheEntity> getBranches(List<Long> ids) {
		return cacheService.getBranches().stream().filter(b -> ids.contains(b.getId())).collect(Collectors.toList());
	}

	@Override
	public BerufEntity getBeruf(Long id) {
		Optional<BerufEntity> findFirst = cacheService.getBerufs().stream().filter(b -> b.getId().equals(id))
				.findFirst();
		if (findFirst.isPresent()) {
			return findFirst.get();
		}
		throw new IllegalArgumentException("Cannot found the beruf with the specific id : " + id);
	}

	@Override
	public List<CHOrtEntity> getCHOrts(List<Long> ids) {
		return cacheService.getCHOrts().stream().filter(o -> ids.contains(o.getId())).collect(Collectors.toList());
	}

	@Override
	public List<String> getKantons() {
		List<String> kantons = cacheService.getCHOrts().stream().map(o -> o.getKanton()).distinct()
				.collect(Collectors.toList());
		kantons.add(CHOrtEntity.CH_ALL_KANTON);
		return kantons.stream().sorted().collect(Collectors.toList());
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public FlowHistoryEntity saveFlowHistory(FlowHistoryEntity entity) {
		FlowHistoryEntity flowHistory = !entity.isPersisted() ? new FlowHistoryEntity() : getFlowHistory(entity.getId());
		updateFlowHistory(entity, flowHistory);
		return flowHistoryRepo.save(flowHistory);
	}
	
	/**
	 * Update the flow history at server side from what the client send back. With the precondition that
	 * both side respect the order of the steps inside.
	 * 
	 * @param newHistory
	 * @param oldHistory
	 */
	private void updateFlowHistory(FlowHistoryEntity newHistory, FlowHistoryEntity oldHistory) {
		
		oldHistory.setCallbackURL(newHistory.getCallbackURL());
		
		List<FlowHistoryItemEntity> oldItems = oldHistory.getItems();
		List<FlowHistoryItemEntity> newItems = newHistory.getItems();
		
		// If steps at server greater than client means user goes back inside the flow. In this case
		// we just simply remove n steps backward.
		if (oldItems.size() > newItems.size()) {
			int deviant = oldItems.size() - newItems.size();
			for (int i = oldItems.size() - 1, j = 1; j <= deviant; j++, i--) {
				oldItems.remove(i);
			}
		} else if (oldItems.size() < newItems.size()) {
			// otherwise there're user goes forward inside the flow. And we will add n steps forward.
			// Note that as we populate the list from the end hence we need to reverse it before add into the sever steps.
			int deviant = newItems.size() - oldItems.size();
			List<FlowHistoryItemEntity> newItemToAdd = Lists.newArrayList();
			for (int i = newItems.size() - 1, j = 1; j <= deviant; j++, i--) {
				FlowHistoryItemEntity item = new FlowHistoryItemEntity();
				item.setFlowHistory(oldHistory);
				item.setName(newItems.get(i).getName());
				newItemToAdd.add(item);
			}
			Collections.reverse(newItemToAdd);
			oldItems.addAll(newItemToAdd);
		}
		
		// Now we will have both client/server steps in the same order. What we need to do is just update again 
		// each step's data.
		for (int i = 0; i < oldItems.size(); i++) {
			FlowHistoryItemEntity oldItem = oldItems.get(i);
			FlowHistoryItemEntity newItem = newItems.get(i);
			
			oldItem.setName(newItem.getName());
			
			// Update step data.
			Set<FlowHistoryItemDataEntity> newDatas = newItem.getData();
						
			if (newDatas.isEmpty()) {
				oldItem.getData().clear();
			} else {
				for (FlowHistoryItemDataEntity newData : newDatas) {
					FlowHistoryItemDataEntity orElse = oldItem.getData().stream().filter(d -> d.getKey().equals(newData.getKey()))
						.findFirst().orElse(new FlowHistoryItemDataEntity());
					// If not yet exist inside the server just simply add it.
					if (!orElse.isPersisted()) {
						orElse.setFlowHistoryItem(oldItem);
						oldItem.getData().add(orElse);
					}
					orElse.setKey(newData.getKey());
					orElse.setValue(newData.getValue());
				}
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public FlowHistoryEntity getFlowHistory(Long id) {
		return jpaUtil.initialize(flowHistoryRepo.findOne(id), QFlowHistoryEntity.flowHistoryEntity.items, QFlowHistoryEntity.flowHistoryEntity.items.any().data);
	}

	@Override
	public String getTranslation(String code) {
		return getTranslation(code, null, null);
	}

	@Override
	public String getTranslation(String code, SupportedLanguage lang) {
		return getTranslation(code, null, null, lang);
	}

	@Override
	public String getTranslation(String code, String[] params, Object[] values) {
		return getTranslation(code, params, values, SecurityUtil.currentUser().getLanguagePreference());
	}

	@Override
	public Map<String, String> getTranslation(List<String> codes, SupportedLanguage lang) {
		Map<String, String> result = new HashMap<>();
		Map<String, String> translation = cacheService.getTranslationByLang(lang);
		for (String code : codes) {
			result.put(code, translation.get(code));
		}
		return result;
	}

	@Override
	public String getTranslation(String code, String[] params, Object[] values, SupportedLanguage lang) {
		String message = cacheService.getTranslationByLang(lang).get(code);
		if (message == null) {
			return null;
		}
		if (ArrayUtils.isNotEmpty(params) && ArrayUtils.isNotEmpty(values)) {
			for (int i = 0; i < params.length && i < values.length; i++) {
				message = StringUtils.replace(message, "{{" + params[i] + "}}", String.valueOf(values[i]));
			}
		}
		return message;
	}

	@Override
	public String getTranslation(Enum<?> value) {
		return getTranslation(getEnumTransactionKey(value));
	}

	@Override
	public String getTranslation(Enum<?> value, SupportedLanguage lang) {
		return getTranslation(getEnumTransactionKey(value), lang);
	}

	private String getEnumTransactionKey(Enum<?> value) {
		return "enums." + value.getClass().getSimpleName() + "." + value.name();
	}

	@Override
	public HrAmtEntity getHrAmtByDomizilBfsnr(int bfsNr) {
		CHOrtHRAmtEntity entity = new JPAQuery<CHOrtHRAmtEntity>(em).from(QCHOrtHRAmtEntity.cHOrtHRAmtEntity)
				.where(QCHOrtHRAmtEntity.cHOrtHRAmtEntity.bfsnr.eq(bfsNr)).fetchOne();
		// TODO [XDG / S9] Check whether it can be null @here
		if (entity != null) {
			return jpaUtil.initialize(
					new JPAQuery<HrAmtEntity>(em).from(QHrAmtEntity.hrAmtEntity)
							.where(QHrAmtEntity.hrAmtEntity.nr.eq(entity.getHramtNr())).fetchOne(),
					QHrAmtEntity.hrAmtEntity.pubTel1Bemerkungen.translations,
					QHrAmtEntity.hrAmtEntity.pubTel2Bemerkungen.translations,
					QHrAmtEntity.hrAmtEntity.pubFaxBemerkungen.translations,
					QHrAmtEntity.hrAmtEntity.pubMailBemerkungen.translations,
					QHrAmtEntity.hrAmtEntity.unterschriftsbeglaubigung.translations,
					QHrAmtEntity.hrAmtEntity.oeffnungszeitenSchalter.translations);
		}
		return new HrAmtEntity();
	}

	@Override
	public HrAmtEntity getChHrAmt() {
		return new JPAQuery<HrAmtEntity>(em).from(QHrAmtEntity.hrAmtEntity)
				.where(QHrAmtEntity.hrAmtEntity.id.eq(OSSConstants.HR_AMT_CH_ID)).fetchOne();
	}
	
	@Override
	public long countAllOrgs() {
		return ((BigDecimal) this.em.createNativeQuery(COUNT_ALL_ORG_SQL).getSingleResult()).longValue();
	}

	@Override
	public long countOrgsInLastYear() {
		return new JPAQuery<OrganisationEntity>(em)
			.from(QOrganisationEntity.organisationEntity)
			.where(QOrganisationEntity.organisationEntity.createdTimeStamp.after(LocalDateTime.now().minusMonths(DURATION_FOR_COUNTING)))
			.fetchCount();
	}

	@Override
	public long countAllUsers() {
		return userRepo.count();
	}

	@Override
	public long countUsersInLastYear() {
		return new JPAQuery<UserEntity>(em)
			.from(QUserEntity.userEntity)
			.where(QUserEntity.userEntity.createdTimeStamp.after(LocalDateTime.now().minusMonths(DURATION_FOR_COUNTING)))
			.fetchCount();
	}

	@Override
	public LandEntity getLand(CodeWertEntity country) {
		if (country.getKategorie() != KategorieEnum.LAND) {
			throw new IllegalArgumentException("Invalid input. The input codewert must be type of KategorieEnum.LAND. Actual : " + country.getKategorie());
		}
		String bfscode = country.getCode();
		return cacheService.getLands().get(bfscode);
	}
	
	@Override
	public AusgleichskasseEntity findDefaultAusleichskasseInKanton(String kanton, String ort, String plz) {
		List<AusgleichskasseEntity> allAusgleichskasses = cacheService.getAusgleichskasses();
		List<AusgleichskasseEntity> ausgleichskassesInKanton = allAusgleichskasses.stream()
			.filter(aus -> aus.getZustaendigkeit().equals(kanton)).collect(Collectors.toList());

		List<AusgleichskasseEntity> ausgleichskassesInOrt = ausgleichskassesInKanton.stream()
			.filter(aus -> StringUtils.equalsIgnoreCase(aus.getOrt(), ort)).collect(Collectors.toList());
		if (CollectionUtils.isEmpty(ausgleichskassesInOrt)) {
			return ausgleichskassesInKanton.get(0);
		}

		List<AusgleichskasseEntity> ausgleichskassesInPlz = ausgleichskassesInOrt.stream()
			.filter(aus -> StringUtils.equalsIgnoreCase(aus.getPlz(), plz)).collect(Collectors.toList());
		if (CollectionUtils.isEmpty(ausgleichskassesInPlz)) {
			return ausgleichskassesInOrt.get(0);
		}

		return ausgleichskassesInPlz.get(0);
	}
}