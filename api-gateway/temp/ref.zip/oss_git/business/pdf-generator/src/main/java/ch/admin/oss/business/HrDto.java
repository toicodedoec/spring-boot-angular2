/*
 * HrDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import ch.admin.oss.OssCurrencyFormatter;
import ch.admin.oss.OssEmptyFieldMapping;

/**
 * @author hha
 */
public class HrDto {

	private CompanyDto organisation;
	private GeschaftsrolleDto owner;
	
	private String notarAnrede;
	private String notarTitle;
	private String notarName;
	private String notarFamilyName;
	private String notarAdress;
	private String notarTelefon;
	private String notarTelefon2;
	private String notarMail;

	@OssCurrencyFormatter(integer = true)
	private Integer aktienkapital;
	@OssCurrencyFormatter(integer = true)
	private Integer liberierungsumfang;

	@OssCurrencyFormatter(integer = true)
	private Integer stammkapital;
	private Integer stammanteile;

	private String bargruendung;
	@OssCurrencyFormatter
	private BigDecimal shareValue;
	@OssEmptyFieldMapping("descriptionEmpty")
	private String finanzBemerkungen;
	private String bemerkungen;

	private Integer auszuege;
	private Integer auszuegeVor;
	private AddressDto adresseKorrespondenz;
	private AddressDto adresseRechnung;

	private String personType;
	private String personTypePlural;
	private List<HrGruenderDto> gruenders = new ArrayList<>();;
	private List<GeschaftsrolleDto> signatories = new ArrayList<>();;

	private int numberOfSignatories;
	private int numberOfNaturalPersons;
	private int numberOfLegalPersons;
	private int numberOfContributedPersons;

	private HrAmtDto amt;

	private String user;
	private LocalDate date = LocalDate.now();
	private LocalDateTime dateTime = LocalDateTime.now();
	private String registrationNumber;
	private String watermark;

	private boolean steuernUsa;
	private String descriptionEmpty;

	public CompanyDto getOrganisation() {
		return organisation;
	}

	public void setOrganisation(CompanyDto organisation) {
		this.organisation = organisation;
	}

	public GeschaftsrolleDto getOwner() {
		return owner;
	}

	public void setOwner(GeschaftsrolleDto owner) {
		this.owner = owner;
	}

	public String getNotarAnrede() {
		return notarAnrede;
	}

	public void setNotarAnrede(String notarAnrede) {
		this.notarAnrede = notarAnrede;
	}

	public String getNotarTitle() {
		return notarTitle;
	}

	public void setNotarTitle(String notarTitle) {
		this.notarTitle = notarTitle;
	}

	public String getNotarName() {
		return notarName;
	}

	public void setNotarName(String notarName) {
		this.notarName = notarName;
	}

	public String getNotarFamilyName() {
		return notarFamilyName;
	}

	public void setNotarFamilyName(String notarFamilyName) {
		this.notarFamilyName = notarFamilyName;
	}

	public String getNotarAdress() {
		return notarAdress;
	}

	public void setNotarAdress(String notarAdress) {
		this.notarAdress = notarAdress;
	}

	public String getNotarTelefon() {
		return notarTelefon;
	}

	public void setNotarTelefon(String notarTelefon) {
		this.notarTelefon = notarTelefon;
	}

	public String getNotarTelefon2() {
		return notarTelefon2;
	}

	public void setNotarTelefon2(String notarTelefon2) {
		this.notarTelefon2 = notarTelefon2;
	}

	public String getNotarMail() {
		return notarMail;
	}

	public void setNotarMail(String notarMail) {
		this.notarMail = notarMail;
	}

	public Integer getAktienkapital() {
		return aktienkapital;
	}

	public void setAktienkapital(Integer aktienkapital) {
		this.aktienkapital = aktienkapital;
	}

	public Integer getLiberierungsumfang() {
		return liberierungsumfang;
	}

	public void setLiberierungsumfang(Integer liberierungsumfang) {
		this.liberierungsumfang = liberierungsumfang;
	}
	
	public Integer getStammkapital() {
		return stammkapital;
	}

	public void setStammkapital(Integer stammkapital) {
		this.stammkapital = stammkapital;
	}

	public Integer getStammanteile() {
		return stammanteile;
	}

	public void setStammanteile(Integer stammanteile) {
		this.stammanteile = stammanteile;
	}

	public String getBargruendung() {
		return bargruendung;
	}

	public void setBargruendung(String bargruendung) {
		this.bargruendung = bargruendung;
	}

	public BigDecimal getShareValue() {
		return shareValue;
	}

	public void setShareValue(BigDecimal shareValue) {
		this.shareValue = shareValue;
	}

	public String getFinanzBemerkungen() {
		return finanzBemerkungen;
	}

	public void setFinanzBemerkungen(String finanzBemerkungen) {
		this.finanzBemerkungen = finanzBemerkungen;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public Integer getAuszuege() {
		return auszuege;
	}

	public void setAuszuege(Integer auszuege) {
		this.auszuege = auszuege;
	}

	public Integer getAuszuegeVor() {
		return auszuegeVor;
	}

	public void setAuszuegeVor(Integer auszuegeVor) {
		this.auszuegeVor = auszuegeVor;
	}

	public AddressDto getAdresseKorrespondenz() {
		return adresseKorrespondenz;
	}

	public void setAdresseKorrespondenz(AddressDto adresseKorrespondenz) {
		this.adresseKorrespondenz = adresseKorrespondenz;
	}

	public AddressDto getAdresseRechnung() {
		return adresseRechnung;
	}

	public void setAdresseRechnung(AddressDto adresseRechnung) {
		this.adresseRechnung = adresseRechnung;
	}
	
	public String getPersonType() {
		return personType;
	}

	public void setPersonType(String personType) {
		this.personType = personType;
	}

	public String getPersonTypePlural() {
		return personTypePlural;
	}

	public void setPersonTypePlural(String personTypePlural) {
		this.personTypePlural = personTypePlural;
	}

	public List<HrGruenderDto> getGruenders() {
		return gruenders;
	}

	public void setGruenders(List<HrGruenderDto> gruenders) {
		this.gruenders = gruenders;
	}

	public List<GeschaftsrolleDto> getSignatories() {
		return signatories;
	}

	public void setSignatories(List<GeschaftsrolleDto> signatories) {
		this.signatories = signatories;
	}

	public int getNumberOfSignatories() {
		return numberOfSignatories;
	}

	public void setNumberOfSignatories(int numberOfSignatories) {
		this.numberOfSignatories = numberOfSignatories;
	}

	public int getNumberOfNaturalPersons() {
		return numberOfNaturalPersons;
	}

	public void setNumberOfNaturalPersons(int numberOfNaturalPersons) {
		this.numberOfNaturalPersons = numberOfNaturalPersons;
	}

	public int getNumberOfLegalPersons() {
		return numberOfLegalPersons;
	}

	public void setNumberOfLegalPersons(int numberOfLegalPersons) {
		this.numberOfLegalPersons = numberOfLegalPersons;
	}

	public int getNumberOfContributedPersons() {
		return numberOfContributedPersons;
	}

	public void setNumberOfContributedPersons(int numberOfContributedPersons) {
		this.numberOfContributedPersons = numberOfContributedPersons;
	}

	public HrAmtDto getAmt() {
		return amt;
	}

	public void setAmt(HrAmtDto amt) {
		this.amt = amt;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public String getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public String getWatermark() {
		return watermark;
	}

	public void setWatermark(String watermark) {
		this.watermark = watermark;
	}

	public boolean isSteuernUsa() {
		return steuernUsa;
	}

	public void setSteuernUsa(boolean steuernUsa) {
		this.steuernUsa = steuernUsa;
	}

	public String getDescriptionEmpty() {
		return descriptionEmpty;
	}

	public void setDescriptionEmpty(String descriptionEmpty) {
		this.descriptionEmpty = descriptionEmpty;
	}

}
