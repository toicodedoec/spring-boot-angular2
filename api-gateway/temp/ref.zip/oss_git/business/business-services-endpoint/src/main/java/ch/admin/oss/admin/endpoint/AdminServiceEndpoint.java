/*
 * AdminServiceEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ch.admin.oss.admin.criteria.AusgleichskasseCriteria;
import ch.admin.oss.admin.criteria.BerufsverbandeCriteria;
import ch.admin.oss.admin.criteria.BranchenCriteria;
import ch.admin.oss.admin.criteria.FunktionRechteCriteria;
import ch.admin.oss.admin.criteria.PrivatversichererCriteria;
import ch.admin.oss.admin.criteria.StandardTextCriteria;
import ch.admin.oss.admin.criteria.WertelistenCriteria;
import ch.admin.oss.admin.dto.ListResultDto;
import ch.admin.oss.admin.dto.NewsletterResultDto;
import ch.admin.oss.admin.service.IAdminService;
import ch.admin.oss.common.AbstractOSSEndpoint;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.ExceptionHandlingController;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.domain.AbgeschlossenerProzesseStatistikDto;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.BenutzerkontoBerechtigungenStatistikDto;
import ch.admin.oss.domain.BenutzerregistrierungenStatistikDto;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.FunktionRechteEntity;
import ch.admin.oss.domain.GrundungenStatistikDto;
import ch.admin.oss.domain.QAusgleichskasseEntity;
import ch.admin.oss.domain.StandardTextEntity;
import ch.admin.oss.domain.TextTranslationEntity;
import ch.admin.oss.domain.VerbandEntity;
import ch.admin.oss.domain.VerbundenerUnternehmenStatistikDto;
import ch.admin.oss.domain.VersicherungEntity;
import ch.admin.oss.portal.endpoint.BrancheDto;
import ch.admin.oss.security.SecurityUtil;

/**
 * @author hha
 */
@CrossOrigin
@RestController
@RequestMapping("/private/adm")
public class AdminServiceEndpoint extends AbstractOSSEndpoint {
	
	// Dozer map ID
	public static final String ADMIN_BERUF_ENT_DTO = "ADMIN_BERUF_ENT_DTO";
	public static final String ADMIN_BRANCHE_ENT_DTO = "ADMIN_BRANCHE_ENT_DTO";

	@Autowired
	private IAdminService adminService;
	
	@RequestMapping(value = "statistik/abgeschlossenerProzesse", method = RequestMethod.GET)
	public List<AbgeschlossenerProzesseStatistikDto> statistikAbgeschlossenerProzesse() {
		return adminService.statistikAbgeschlossenerProzesse();
	}
	
	@RequestMapping(value = "statistik/grundungen", method = RequestMethod.GET)
	public List<GrundungenStatistikDto> statistikGrundungen() {
		return adminService.statistikGrundungen();
	}
	
	@RequestMapping(value = "statistik/benutzerregistrierungen", method = RequestMethod.GET)
	public List<BenutzerregistrierungenStatistikDto> statistikBenutzerregistrierungen() {
		return adminService.statistikBenutzerregistrierungen();
	}
	
	@RequestMapping(value = "statistik/VerbundenerUnternehmen", method = RequestMethod.GET)
	public List<VerbundenerUnternehmenStatistikDto> statistikVerbundenerUnternehmen() {
		return adminService.statistikVerbundenerUnternehmen();
	}
	
	@RequestMapping(value = "statistik/benutzerkontoBerechtigungen", method = RequestMethod.GET)
	public List<BenutzerkontoBerechtigungenStatistikDto> statistikBenutzerkontoBerechtigungen() {
		return adminService.statistikBenutzerkontoBerechtigungen();
	}
	
	@RequestMapping(value = "statistik/generateCSV", method = RequestMethod.GET)
	public ResponseEntity<?> generateStatistikCSV() {
		return download(adminService.generateStatistikCSV());
	}

	@RequestMapping(value = "funktionRechtes", method = RequestMethod.PUT)
	public ListResultDto<FunktionRechteDto> searchFunktionRechtes(@RequestBody FunktionRechteCriteria criteria) {
		ListResultDto<FunktionRechteEntity> paginationFunktionRechtes = adminService
			.getPaginationFunktionRechtes(criteria);
		return new ListResultDto<FunktionRechteDto>(paginationFunktionRechtes.getTotal(), paginationFunktionRechtes
			.getItems().stream().map(ent -> mapper.map(ent, FunktionRechteDto.class)).collect(Collectors.toList()));
	}

	@PutMapping("saveFunktionRechte")
	public FunktionRechteDto saveFunktionRechte(@RequestBody @Valid FunktionRechteDto dto) {
		if (dto.getId() != null) {
			// Reload entity
			FunktionRechteEntity entity = adminService.getFunktionRechte(dto.getId());
			// Dozer merges list instead of replacing it.
			// TODO [HHA, S9] How to configure it?
			entity.setGruppens(null);
			mapper.map(dto, entity);

			// Save entity
			entity = adminService.saveFunktionRechte(entity);
			if (CollectionUtils.isNotEmpty(dto.getGroups())) {
				dto.getGroups().clear();
			}
			mapper.map(entity, dto);
		}
		return dto;
	}

	@RequestMapping(value = "textverwaltung", method = RequestMethod.PUT)
	public ListResultDto<StandardTextDto> getStandardTexts(@RequestBody StandardTextCriteria criteria) {
		ListResultDto<StandardTextEntity> paginationStandardTexts = adminService.getPaginationStandardTexts(criteria);
		return new ListResultDto<StandardTextDto>(paginationStandardTexts.getTotal(), paginationStandardTexts.getItems()
			.stream().map(ent -> mapper.map(ent, StandardTextDto.class)).collect(Collectors.toList()));
	}

	@PutMapping("saveTextverwaltung")
	public StandardTextDto saveTextverwaltung(@RequestBody @Valid StandardTextDto dto) {
		// reload entity
		StandardTextEntity entity = adminService.getStandardText(dto.getId());
		for (TextTranslationDto translationDto : dto.getTranslations()) {
			Optional<TextTranslationEntity> translationEntity = entity.getTranslations().stream()
				.filter(item -> item.getLanguage() == translationDto.getLanguage()).findFirst();
			translationEntity.get().setText(translationDto.getText());
		}
		// save entity
		entity = adminService.saveStandardText(entity);
		mapper.map(entity, dto);
		return dto;
	}

	@RequestMapping(value = "wertelisten", method = RequestMethod.PUT)
	public ListResultDto<CodeWertDto> codeWertListe(@RequestBody WertelistenCriteria criteria) {
		ListResultDto<CodeWertEntity> result = adminService.getPaginationCodeWertListen(criteria);
		List<CodeWertDto> items = result.getItems().stream().map(ent -> mapper.map(ent, CodeWertDto.class))
			.collect(Collectors.toList());
		return new ListResultDto<CodeWertDto>(result.getTotal(), items);
	}

	@PutMapping("codeWert")
	public CodeWertDto saveCodeWert(@RequestBody @Valid CodeWertDto dto) {
		CodeWertEntity entity = adminService.getCodeWertEntity(dto.getId());
		mapper.map(dto, entity);

		entity.setAktiv(dto.isAktiv());
		entity.setPos(dto.getPos());
		entity.getStandardText().getTranslations().forEach(t -> {
			if (t.getLanguage() == SupportedLanguage.DE) {
				t.setText(dto.getTextDE());
			}
			if (t.getLanguage() == SupportedLanguage.FR) {
				t.setText(dto.getTextFR());
			}
			if (t.getLanguage() == SupportedLanguage.EN) {
				t.setText(dto.getTextEN());
			}
			if (t.getLanguage() == SupportedLanguage.IT) {
				t.setText(dto.getTextIT());
			}
		});

		// Save entity
		entity = adminService.saveCodeWertEntity(entity);
		mapper.map(entity, dto);
		return dto;
	}

	@RequestMapping(value = "branchen", method = RequestMethod.PUT)
	public ListResultDto<BrancheAdminDto> searchBranchen(@RequestBody BranchenCriteria criteria) {
		ListResultDto<BrancheEntity> result = adminService.getPaginationBranchen(criteria);
		List<BrancheAdminDto> rawResult = result.getItems().stream()
			.map(b -> mapper.map(b, BrancheAdminDto.class, ADMIN_BRANCHE_ENT_DTO))
			.collect(Collectors.toList());
		return new ListResultDto<BrancheAdminDto>(result.getTotal(), buildUpAndDownState(rawResult));
	}

	@PutMapping("saveBranche")
	public BrancheAdminDto saveBranche(@RequestBody @Valid BrancheAdminDto dto) {
		BrancheEntity ent = new BrancheEntity();
		
		if (dto.getId() != null) {
			ent = adminService.getBranche(dto.getId(), dto.getVersion());
		}
		
		mapper.map(dto, ent);
		
		if (ent.isPersisted()) {
			if (dto.getParentId() == null) {
				ent.getChildBranches().stream().forEach(c -> c.setAktiv(dto.isAktiv()));
			}

			for (TextTranslationDto translationDto : dto.getStandardText().getTranslations()) {
				Optional<TextTranslationEntity> translationEntity = ent.getStandardText().getTranslations().stream()
					.filter(item -> item.getLanguage() == translationDto.getLanguage()).findFirst();
				if (translationEntity.isPresent()) {
					translationEntity.get().setText(translationDto.getText());
				}
			}
		} else {
			if (dto.getParentId() != null) { // if this is a sub branch
				ent.setPos(adminService.getMaxPosInBrancheGroup(dto.getParentId()) + 1);
			} else { // if this is a parent branch
				ent.setPos(adminService.getMaxAndMinPosOfParentBranche().get(0) + 1);
			}

			StandardTextEntity standard = new StandardTextEntity();
			dto.getStandardText().getTranslations().stream().forEach(translation -> {
				standard.addTextTranslation(translation.getText(), translation.getLanguage());
			});
			ent.setStandardText(standard);
		}
		
		if (dto.getParentId() != null) {
			ent.setParent(adminService.getBranche(dto.getParentId()));
		}

		ent = adminService.saveBranche(ent);
		mapper.map(ent, dto);
		return dto;
	}

	@RequestMapping(value = "brancheGroup", method = RequestMethod.GET)
	public List<BrancheAdminDto> brancheGroup() {
		List<BrancheAdminDto> rawResult = new ArrayList<BrancheAdminDto>();
		adminService.getBrancheGroup().stream().forEach(b -> {
			rawResult.add(mapper.map(b, BrancheAdminDto.class, ADMIN_BRANCHE_ENT_DTO));
		});
		return rawResult;
	}
	
	private <T extends AbstractGruppeDto> List<T> buildUpAndDownState(List<T> rawResult) {
		List<Integer> maxAndMinPosOfParent;
		if (rawResult.size() > 0) {
			if (rawResult.get(0) instanceof BrancheAdminDto) {
				maxAndMinPosOfParent = adminService.getMaxAndMinPosOfParentBranche();
			} else {
				maxAndMinPosOfParent = adminService.getMaxAndMinPosOfParentBeruf();
			}

			IntStream.range(0, rawResult.size()).forEach(idx -> {
				T b = rawResult.get(idx);
				if (b.getParentId() == null) {
					if (b.getPos() == maxAndMinPosOfParent.get(0)) {
						b.setDown(false);
					}
					if (b.getPos() == maxAndMinPosOfParent.get(1)) {
						b.setUp(false);
					}
				} else {
					if (idx == 0) {
						int minPosOfGroup = 0;

						if (rawResult.get(0) instanceof BrancheAdminDto) {
							minPosOfGroup = adminService.getMinPosInBrancheGroup(b.getParentId());
						} else {
							minPosOfGroup = adminService.getMinPosInBerufGroup(b.getParentId());
						}

						if (b.getPos() == minPosOfGroup) {
							b.setUp(false);
						}
						if (idx + 1 < rawResult.size()) {
							if (rawResult.get(idx + 1).getParentId() == null) {
								b.setDown(false);
							}
						} else {
							// this is also the last element
							b.setDown(false);
						}
					} else {
						if (rawResult.get(idx - 1).getParentId() == null) {
							b.setUp(false);
						}
						if (idx + 1 < rawResult.size()) {
							if (rawResult.get(idx + 1).getParentId() == null) {
								b.setDown(false);
							}
						} else {
							// update for the last element
							int maxPosOfGroup = 0;
							if (rawResult.get(0) instanceof BrancheAdminDto) {
								maxPosOfGroup = adminService.getMaxPosInBrancheGroup(b.getParentId());
							} else {
								maxPosOfGroup = adminService.getMaxPosInBerufGroup(b.getParentId());
							}
							if (b.getPos() == maxPosOfGroup) {
								b.setDown(false);
							}
						}
					}
				}
			});
		}

		return rawResult;
	}	

	@RequestMapping(value = "berufsverbande", method = RequestMethod.PUT)
	public ListResultDto<VerbandDto> getVerbandListen(@RequestBody BerufsverbandeCriteria criteria) {
		ListResultDto<VerbandEntity> paginationVerbandListen = adminService.getPaginationVerbandListen(criteria);
		return new ListResultDto<VerbandDto>(paginationVerbandListen.getTotal(), paginationVerbandListen.getItems()
			.stream().map(ent -> mapper.map(ent, VerbandDto.class)).collect(Collectors.toList()));
	}

	@RequestMapping(value = "validBrancheCode", method = RequestMethod.GET)
	public boolean validBrancheCode(@RequestParam String code) {
		return adminService.getBranche(code) == null;
	}

	@PutMapping("saveBerufsverbande")
	public ResponseEntity<VerbandDto> saveVerband(@RequestBody @Valid VerbandDto dto) {
		VerbandEntity verbandEntity = new VerbandEntity();

		if (dto.getId() != null) {
			verbandEntity = adminService.getVerband(dto.getId());
		}
		mapper.map(dto, verbandEntity);

		if(verbandEntity.isPersisted()) {
			for (TextTranslationDto translationDto : dto.getStandardText().getTranslations()) {
				Optional<TextTranslationEntity> translationEntity = verbandEntity.getStandardText().getTranslations().stream()
						.filter(item -> item.getLanguage() == translationDto.getLanguage()).findFirst();
				if (translationEntity.isPresent()) {
					translationEntity.get().setText(translationDto.getText());
				}
			}
		} else {
			StandardTextEntity standard = new StandardTextEntity();
			dto.getStandardText().getTranslations().stream().forEach(translation -> {
				standard.addTextTranslation(translation.getText(), translation.getLanguage());
			});
			verbandEntity.setStandardText(standard);
		}

		// TODO [HHG / S9]: To check with hhg should i save aktiv field?
		// ausEntity.setAktiv(dto.isAktiv());
		verbandEntity.setAusgleichskasse(adminService.getAusgleichskasse(dto.getAusgleichskasse().getId()));

		mapper.map(adminService.saveVerband(verbandEntity), dto);

		return ResponseEntity.ok(dto);
	}

	@RequestMapping(value = "privatversicherer", method = RequestMethod.PUT)
	public ListResultDto<VersicherungDto> versicherungListe(@RequestBody PrivatversichererCriteria criteria) {
		ListResultDto<VersicherungEntity> paginationPrivatversichererListen = adminService
			.getPaginationPrivatversichererListen(criteria);
		return new ListResultDto<VersicherungDto>(paginationPrivatversichererListen.getTotal(),
			paginationPrivatversichererListen.getItems().stream().map(ent -> mapper.map(ent, VersicherungDto.class))
				.collect(Collectors.toList()));
	}
	
	@PutMapping("saveVersicherung")
	public ResponseEntity<?> saveVersicherung(@RequestBody @Valid VersicherungDto dto) {
		boolean isValidSprache = validateSprachen(dto.getSprache());
		if (!isValidSprache) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Sprache value is invalid. One or more language is not supportted: " + dto.getSprache()));
		}

		boolean isValidKanton = applicationService.getKantons().contains(dto.getKanton());
		if (!isValidKanton) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Kanton is invalid or not supportted: " + dto.getKanton()));
		}

		// Reload entity
		VersicherungEntity entity = new VersicherungEntity();
		
		if(dto.getId() != null) {
			entity = adminService.getVersicherungEntity(dto.getId());
		}		
		mapper.map(dto, entity);
		
		if(entity.isPersisted()) {
			for (TextTranslationDto translationDto : dto.getStandardText().getTranslations()) {
				Optional<TextTranslationEntity> translationEntity = entity.getStandardText().getTranslations().stream()
						.filter(item -> item.getLanguage() == translationDto.getLanguage()).findFirst();
				if (translationEntity.isPresent()) {
					translationEntity.get().setText(translationDto.getText());
				}
			}
		} else {
			StandardTextEntity standard = new StandardTextEntity();
			dto.getStandardText().getTranslations().stream().forEach(translation -> {
				standard.addTextTranslation(translation.getText(), translation.getLanguage());
			});
			entity.setStandardText(standard);
		}
		
		// Save entity
		entity = adminService.saveVersicherungEntity(entity);
		mapper.map(entity, dto);
		
		return ResponseEntity.ok(dto);
	}

	/*
	 * Validate the sprache value must be in list supported languages
	 */
	private boolean validateSprachen(String sprache) {
		List<String> supportedLanguages = Stream.of(SupportedLanguage.values())
			.map(lang -> lang.name().toLowerCase())
			.collect(Collectors.toList());
		String[] sprachens = StringUtils.split(sprache, ",");
		for (String s : sprachens) {
			if (!supportedLanguages.contains(s.trim())) {
				return false;
			}
		}
		return true;
	}

	@RequestMapping(value = "activAusgleichskasses", method = RequestMethod.GET)
	public ResponseEntity<List<AusgleichskasseDto>> getActivAusgleichskasse() {
		List<AusgleichskasseEntity> listAusEntity = adminService.getActivAusgleichskasse();
		return ResponseEntity.ok(listAusEntity.stream().map(aus -> mapper.map(aus, AusgleichskasseDto.class))
				.collect(Collectors.toList()));
	}

	@RequestMapping(value = "ausgleichskasses", method = RequestMethod.PUT)
	public ListResultDto<AusgleichskasseDto> getAusgleichskasseListen(@RequestBody AusgleichskasseCriteria criteria) {
		ListResultDto<AusgleichskasseEntity> paginationAusgleichskasseListen = adminService
			.getPaginationAusgleichskasseListen(criteria);
		return new ListResultDto<AusgleichskasseDto>(paginationAusgleichskasseListen.getTotal(),
			paginationAusgleichskasseListen.getItems().stream().map(ent -> mapper.map(ent, AusgleichskasseDto.class))
				.collect(Collectors.toList()));
	}

	@RequestMapping(value = "upBranche", method = RequestMethod.PUT)
	public ResponseEntity<?> upBranche(@RequestBody BrancheAdminDto dto) {
		return updateBranchePos(dto, true);
	}

	@RequestMapping(value = "downBranche", method = RequestMethod.PUT)
	public ResponseEntity<?> downBranche(@RequestBody BrancheAdminDto dto) {
		return updateBranchePos(dto, false);
	}

	private ResponseEntity<?> updateBranchePos(BrancheAdminDto dto, boolean isUp) {
		BrancheEntity nextEnt;
		if (dto.getParentId() == null) {
			// get next parent-branche
			nextEnt = adminService.getParentBrancheToSwap(dto.getPos(), isUp);
		} else {
			// get next sub-branche
			nextEnt = adminService.getSubBrancheToSwap(dto.getPos(), dto.getParentId(), isUp);
		}

		// update pos
		int posTemp = nextEnt.getPos();
		nextEnt.setPos(dto.getPos());

		BrancheEntity curEnt = adminService.getBranche(dto.getId(), dto.getVersion());
		
		if (curEnt == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Can not find branche"));
		}
		
		curEnt.setPos(posTemp);

		adminService.saveBranches(curEnt, nextEnt);

		return ResponseEntity.ok("{ \"message\": \"ok\"}");
	}

	@PutMapping("saveAusgleichskasse")
	public ResponseEntity<?> saveAusgleichskasse(@RequestBody @Valid AusgleichskasseDto dto) {
		boolean isValidSprache = validateSprachen(dto.getSprache());
		if (!isValidSprache) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Sprache value is invalid. One or more language is not supportted: " + dto.getSprache()));
		}

		boolean isValidZustaendigkeit = applicationService.getKantons().contains(dto.getZustaendigkeit());
		if (!isValidZustaendigkeit) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Zustaendigkeit is invalid or not supportted: " + dto.getZustaendigkeit()));
		}

		AusgleichskasseEntity ausgleichskasseEntity = new AusgleichskasseEntity();

		if (dto.getId() != null) {
			ausgleichskasseEntity = adminService.getAusgleichskasse(dto.getId(),
				QAusgleichskasseEntity.ausgleichskasseEntity.standardText.translations);
		}
		mapper.map(dto, ausgleichskasseEntity);
		
		if(ausgleichskasseEntity.isPersisted()) {
			for (TextTranslationDto translationDto : dto.getStandardText().getTranslations()) {
				Optional<TextTranslationEntity> translationEntity = ausgleichskasseEntity.getStandardText().getTranslations().stream()
						.filter(item -> item.getLanguage() == translationDto.getLanguage()).findFirst();
				if (translationEntity.isPresent()) {
					translationEntity.get().setText(translationDto.getText());
				}
			}
		} else {
			StandardTextEntity standard = new StandardTextEntity();
			dto.getStandardText().getTranslations().stream().forEach(translation -> {
				standard.addTextTranslation(translation.getText(), translation.getLanguage());
			});
			ausgleichskasseEntity.setStandardText(standard);
		}

		mapper.map(adminService.saveAusgleichskasse(ausgleichskasseEntity), dto);

		return ResponseEntity.ok(dto);
	}
	
	@RequestMapping(value = "berufe", method = RequestMethod.PUT)
	public ListResultDto<BerufAdminDto> searchBerufe(@RequestBody BranchenCriteria criteria) {
		ListResultDto<BerufEntity> result = adminService.getPaginationBerufe(criteria);
		List<BerufAdminDto> rawResult = new ArrayList<>();
		result.getItems().stream().forEach(b -> {
			BerufAdminDto localDto = mapper.map(b, BerufAdminDto.class, ADMIN_BERUF_ENT_DTO);
			rawResult.add(localDto);
		});
		return new ListResultDto<BerufAdminDto>(result.getTotal(), buildUpAndDownState(rawResult));
	}

	@PutMapping("saveBeruf")
	public BerufAdminDto saveBeruf(@RequestBody @Valid BerufAdminDto dto) {
		BerufEntity ent = new BerufEntity();

		if (dto.getId() != null) {
			ent = adminService.getBeruf(dto.getId(), dto.getVersion());
		}

		mapper.map(dto, ent);		
		
		if (ent.isPersisted()) {
			if (dto.getParentId() == null) {
				ent.getChildBerufs().stream().forEach(c -> c.setAktiv(dto.isAktiv()));
			}

			for (TextTranslationDto translationDto : dto.getStandardText().getTranslations()) {
				Optional<TextTranslationEntity> translationEntity = ent.getStandardText().getTranslations()
					.stream()
					.filter(item -> item.getLanguage() == translationDto.getLanguage())
					.findFirst();
				if (translationEntity.isPresent()) {
					translationEntity.get().setText(translationDto.getText());
				}
			}
		} else {
			if (dto.getParentId() != null) { // if this is a sub beruf
				ent.setPos(adminService.getMaxPosInBerufGroup(dto.getParentId()) + 1);
			} else { // if this is a parent beruf
				ent.setPos(adminService.getMaxAndMinPosOfParentBeruf().get(0) + 1);
			}

			StandardTextEntity standard = new StandardTextEntity();
			dto.getStandardText().getTranslations().stream().forEach(translation -> {
				standard.addTextTranslation(translation.getText(), translation.getLanguage());
			});
			ent.setStandardText(standard);
		}

		if (dto.getParentId() != null) {
			ent.setParent(adminService.getBeruf(dto.getParentId()));
		}
		
		if (dto.getBrancheId() != null) {
			ent.setBranche(adminService.getBranche(dto.getBrancheId()));
		}

		ent = adminService.saveBeruf(ent);
		mapper.map(ent, dto);
		return dto;
	}

	@RequestMapping(value = "berufDetailInitData", method = RequestMethod.GET)
	public BerufDetailInitDataDto berufDetailInitData() {
		BerufDetailInitDataDto dto = new BerufDetailInitDataDto();
		List<BerufAdminDto> berufe = new ArrayList<BerufAdminDto>();
		adminService.getBerufGroup().stream().forEach(b -> {
			berufe.add(mapper.map(b, BerufAdminDto.class, ADMIN_BERUF_ENT_DTO));
		});

		List<BrancheDto> branchen = new ArrayList<BrancheDto>();
		adminService.getSubBranchen().stream().forEach(b -> {
			branchen.add(new BrancheDto(b, SecurityUtil.currentUser().getLanguagePreference()));
		});

		dto.setBrachen(branchen);
		dto.setBerufe(berufe);
		return dto;
	}
	
	@RequestMapping(value = "validBerufCode", method = RequestMethod.GET)
	public boolean validBerufCode(@RequestParam String code) {
		return adminService.getBeruf(code) == null;
	}
	
	@RequestMapping(value = "upBeruf", method = RequestMethod.PUT)
	public ResponseEntity<?> upBeruf(@RequestBody BerufAdminDto dto) {
		return updateBerufPos(dto, true);
	}

	@RequestMapping(value = "downBeruf", method = RequestMethod.PUT)
	public ResponseEntity<?> downBeruf(@RequestBody BerufAdminDto dto) {
		return updateBerufPos(dto, false);
	}

	private ResponseEntity<?> updateBerufPos(BerufAdminDto dto, boolean isUp) {
		BerufEntity nextEnt;
		if (dto.getParentId() == null) {
			// get next parent-branche
			nextEnt = adminService.getParentBerufToSwap(dto.getPos(), isUp);
		} else {
			// get next sub-branche
			nextEnt = adminService.getSubBerufToSwap(dto.getPos(), dto.getParentId(), isUp);
		}

		// update pos
		int posTemp = nextEnt.getPos();
		nextEnt.setPos(dto.getPos());

		BerufEntity curEnt = adminService.getBeruf(dto.getId(), dto.getVersion());
		
		if (curEnt == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Can not find beruf"));
		}
		
		curEnt.setPos(posTemp);

		adminService.saveBerufe(curEnt, nextEnt);

		return ResponseEntity.ok("{ \"message\": \"ok\"}");
	}
	
	@RequestMapping(value = "campaigns", method = RequestMethod.GET)
	public NewsletterDto getCampaigns() {
		return new NewsletterDto(adminService.getCampaigns());
	}

	@RequestMapping(value = "campaignInfo", method = RequestMethod.GET)
	public NewsletterResultDto getCampaignInfo(@RequestParam("campaign") String campaign) {
		return adminService.getCampaignInfo(campaign);
	}
}
