/*
 * ErwerbsUndSelbstkostenDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

/**
 * @author hhg
 *
 */
public class ErwerbsUndSelbstkostenDto {

	private String risk;
	private String wage;
	private String cost;
	private String maintenance;
	private String faults;
	private String material;
	private String loss;
	private String collection;
	private String typeOfCompensation;

	public String getRisk() {
		return risk;
	}
	public void setRisk(String risk) {
		this.risk = risk;
	}
	public String getWage() {
		return wage;
	}
	public void setWage(String wage) {
		this.wage = wage;
	}
	public String getCost() {
		return cost;
	}
	public void setCost(String cost) {
		this.cost = cost;
	}
	public String getMaintenance() {
		return maintenance;
	}
	public void setMaintenance(String maintenance) {
		this.maintenance = maintenance;
	}
	public String getFaults() {
		return faults;
	}
	public void setFaults(String faults) {
		this.faults = faults;
	}
	public String getMaterial() {
		return material;
	}
	public void setMaterial(String material) {
		this.material = material;
	}
	public String getLoss() {
		return loss;
	}
	public void setLoss(String loss) {
		this.loss = loss;
	}
	public String getCollection() {
		return collection;
	}
	public void setCollection(String collection) {
		this.collection = collection;
	}
	public String getTypeOfCompensation() {
		return typeOfCompensation;
	}
	public void setTypeOfCompensation(String typeOfCompensation) {
		this.typeOfCompensation = typeOfCompensation;
	}
}
