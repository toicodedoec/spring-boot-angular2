/*
 * PermissionEvaluatorConfiguration
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.security;

import java.io.Serializable;
import java.time.LocalDate;

import org.slf4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.core.Authentication;

import ch.admin.oss.common.enums.AccessLevelEnum;
import ch.admin.oss.common.enums.FunktionEnum;
import ch.admin.oss.enums.SecuredEntityEnum;
import ch.admin.oss.util.OSSDateUtil;

/**
 * @author phd
 */
@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class MethodSecurityInterceptingConfiguration {

	private static final Logger LOGGER = org.slf4j.LoggerFactory
		.getLogger(MethodSecurityInterceptingConfiguration.class);

	@Bean
	public PermissionEvaluator permissionEvaluator() {
		return new PermissionEvaluator() {

			@Override
			public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType,
				Object permission) {

				boolean hasPermission = false;
				SecuredEntityEnum securedEntity = SecuredEntityEnum.valueOf(targetType);
				switch (securedEntity) {
					case ORGANISATION:
						hasPermission = SecurityUtil.currentUser().getAuthorizedCompanies().stream()
							.anyMatch(authorizedOrg -> authorizedOrg.getOrgId().equals(targetId)
								&& authorizedOrg.getPermission().getAccessLevel().ordinal() >= ((AccessLevelEnum) permission).ordinal()
								&& (authorizedOrg.getPermission().getToDate() == null
										|| !authorizedOrg.getPermission().getToDate().before(OSSDateUtil.toDate(LocalDate.now()))));
						break;
					case ADMIN:
						hasPermission = SecurityUtil.currentUser().getFunktions().stream().anyMatch(f -> f == ((FunktionEnum) permission));
						break;
					default:
						hasPermission = false;
						break;
				}
				if (!hasPermission) {
					LOGGER.error(
						"Requested access with permission [{}] on object type/ID [{}/{}] was denied for user [{}]",
						permission, targetType, targetId, authentication.getName());
				}
				return hasPermission;
			}

			@Override
			public boolean hasPermission(Authentication authentication, Object targetDomainObject, Object permission) {
				throw new UnsupportedOperationException("This overloading of the API is not supported");
			}
		};
	}
}
