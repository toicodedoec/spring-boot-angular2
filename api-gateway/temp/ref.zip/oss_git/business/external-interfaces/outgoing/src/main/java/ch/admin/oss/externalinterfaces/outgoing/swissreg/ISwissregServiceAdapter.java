/*
 * ISwissregServiceAdapter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.swissreg;

/**
 * @author hhg
 *
 */
public interface ISwissregServiceAdapter {

	/**
	 * Check trademark conflicts via SwissReg web service. Return NULL if no conflict, otherwise return details
	 * of trademark conflicts.
	 * 
	 * @param trademark Trademark text
	 * @return Details of trademark conflicts
	 */
	TmtransDto checkCompanyTrademark(String trademark) throws SwissregBusinessException;
}
