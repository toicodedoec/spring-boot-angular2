/*
 * GenerateDataTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.performance.process;

import java.util.Arrays;

import org.springframework.stereotype.Component;

import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.HrAnmeldungEntity;
import ch.admin.oss.domain.HrGruenderEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.hr.service.IHRService;
import ch.admin.oss.util.OSSConstants;

/**
 * @author hha
 */
@Component
public class HrProcessGenerator extends ProcessGenerator<HrAnmeldungEntity, IHRService> {

	@Override
	public HrAnmeldungEntity generate(HrAnmeldungEntity entity) {
		entity.setTranslate(true);
		entity.setAdresseKorrespondenz(dataHelper.createAddress());
		entity.setAdresseRechnung(dataHelper.createAddress());
		
		entity.setBemerkungen("Dummy");
		entity.setElektronisch(false);

		// 2 Signatories
		OrganisationEntity organisation = entity.getProzess().getOrganisation();
		dataHelper.createOwnerPerson(organisation, GeschaeftsrolleTypEnum.SIGNATORY);
		dataHelper.createOwnerPerson(organisation, GeschaeftsrolleTypEnum.SIGNATORY);

		organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)
			.forEach(item -> {
				item.setAnzNamensaktien(0);
				item.setAnzInhaberaktien(0);
				item.setAnzStammanteile(0);
			});

		RechtsformEnum rechtsform = organisation.getRechtsform();
		if (Arrays.asList(RechtsformEnum.EINZELFIRMA, RechtsformEnum.KOMMGES, RechtsformEnum.KOLLGES).contains(rechtsform)) {
			entity.setAuszuege(1);
			entity.setAuszuegeVor(1);
		}

		if (Arrays.asList(RechtsformEnum.AG, RechtsformEnum.GMBH).contains(rechtsform)) {
			entity.setNotarAnrede(dataHelper.getCodeWert(KategorieEnum.ANREDE, OSSConstants.ANDERE_MR_CODE));
			entity.setNotarTelefon("123456");
			entity.setNotarName("No Name");
			entity.setNotarVorname("No VName");
			entity.setNotarPostadresse("70001");
			entity.setNotarTelefon("1234657");
			entity.setNotarEmail("hha@elca.vn");

			entity.getGruenders().add(createFounder(entity));
			entity.getGruenders().add(createFounder(entity));
		}

		if (rechtsform == RechtsformEnum.AG) {
			entity.setAktienkapital(100_000);
			entity.setLiberierungsumfang(50_000);
			entity.setNamensaktien(100);
			entity.setInhaberaktien(100);
			entity.setFinanzBemerkungen("Test AG");
			
			entity.getGruenders().forEach(item -> {
				item.setAnzNamensaktien(50);
				item.setAnzInhaberaktien(50);
			});
		} else if (rechtsform == RechtsformEnum.GMBH) {
			entity.setStammkapital(200_000);
			entity.setStammanteile(1_00);
			entity.setFinanzBemerkungen("Test GMBH");

			entity.getGruenders().forEach(item -> {
				item.setAnzStammanteile(50);
			});
		}

		return service.completeProcess(entity);
	}

	private HrGruenderEntity createFounder(HrAnmeldungEntity hrAnmeldung) {
		HrGruenderEntity founder = new HrGruenderEntity();
		founder.setHrAnmeldung(hrAnmeldung);
		founder.setPerson(dataHelper.createPerson());
		founder.setFunktion(dataHelper.getFunkction());
		founder.setComplete(true);
		founder.setZeichnung(dataHelper.getZeichnung());
		return founder;
	}

	@Override
	protected ProzessTypEnum getProcessType() {
		return ProzessTypEnum.HR;
	}

}
