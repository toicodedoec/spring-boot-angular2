/*
 * AbstractOssService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.time.LocalDateTime;

import org.apache.commons.lang3.NotImplementedException;
import org.springframework.beans.factory.annotation.Autowired;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.ahv.service.IAhvService;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QGeschaftsrolleEntity;
import ch.admin.oss.domain.QStatuswechselEntity;
import ch.admin.oss.domain.StatuswechselEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.organisation.repository.IGeschaftsrolleRepository;
import ch.admin.oss.portal.repository.IProzessRepository;
import ch.admin.oss.security.SecurityUtil;

/**
 * @author hha
 */
public abstract class AbstractOrganisationService extends AbstractOSSService {

	@Autowired
	protected IProzessRepository prozessRepository;
	
	@Autowired
	protected IGeschaftsrolleRepository geschaftsrolleRepository;

	protected GeschaftsrolleEntity internalSaveUnvalidatedGeschaftsrolle(GeschaftsrolleEntity ent, RechtsformEnum rechtsform) {
		ent.setComplete(false);
		GeschaftsrolleEntity result =  geschaftsrolleRepository.save(ent);
		if (result.getTyp() == GeschaeftsrolleTypEnum.EDC
			&& rechtsform != null
			&& rechtsform != RechtsformEnum.AG
			&& rechtsform != RechtsformEnum.GMBH) {
			getAhvService().createAhvTeilhaber(result);
		}
		return result;
	}

	protected GeschaftsrolleEntity internalSaveValidatedGeschaftsrolle(GeschaftsrolleEntity ent) {
		ent.setComplete(true);
		return geschaftsrolleRepository.save(ent);
	}

	protected void internalDeleteGeschaftsrolle(GeschaftsrolleEntity geschaftsrolleEntity) {
		jpaUtil.initialize(geschaftsrolleEntity, QGeschaftsrolleEntity.geschaftsrolleEntity.person.teilhaber);
		geschaftsrolleRepository.delete(geschaftsrolleEntity);
	}

	/**
	 * This method is only available in Organisation service.
	 */
	protected IAhvService getAhvService() {
		throw new NotImplementedException("This method is not supported in " + this.getClass());
	}

	protected void recordProcessStatusChange(ProzessEntity prozess) {
		recordProcessStatusChange(prozess, null);
	}

	protected void recordProcessStatusChange(ProzessEntity prozess, Long userId) {
		if (userId == null) {
			userId = SecurityUtil.currentUser().getUserId();
		}
		if (!prozess.isPersisted() || isProcessStatusChange(prozess)) {
			addProcessStatusChange(prozess, userId);
		}
	}

	private boolean isProcessStatusChange(ProzessEntity prozess) {
		StatuswechselEntity lastStatus = new JPAQuery<StatuswechselEntity>(em)
			.from(QStatuswechselEntity.statuswechselEntity)
			.where(QStatuswechselEntity.statuswechselEntity.prozess.id.eq(prozess.getId()))
			.orderBy(QStatuswechselEntity.statuswechselEntity.zeitstempel.desc())
			.limit(1)
			.fetchOne();
		return lastStatus.getStatus() != prozess.getStatus();
	}

	private void addProcessStatusChange(ProzessEntity prozess, Long userId) {
		StatuswechselEntity statuswechselEntity = new StatuswechselEntity();
		statuswechselEntity.setProzess(prozess);
		statuswechselEntity.setStatus(prozess.getStatus());
		statuswechselEntity.setZeitstempel(LocalDateTime.now());
		statuswechselEntity.setUser(new UserEntity(userId));
		prozess.getStatuswechsels().add(statuswechselEntity);
	}
	
	/**
	 * <p>
	 * Apply business logic when process is updated.
	 * <ul>
	 * <li>Completed = false</li>
	 * <li>Status = {@link ProzessStatusEnum#BEARBEITUNG}</li>
	 * <li>Record status history (if have)</li>
	 * </ul>
	 * </p>
	 * 
	 * @param prozessEntity
	 */
	protected void processUpdated(ProzessEntity prozessEntity) {
		verifyProcessBeforeUpdated(prozessEntity);
		prozessEntity.setCompleted(false);
		prozessEntity.setStatus(ProzessStatusEnum.BEARBEITUNG);
		prozessEntity.setBearbdatum(LocalDateTime.now());
		recordProcessStatusChange(prozessEntity);
	}
	
	protected void verifyProcessBeforeUpdated(ProzessEntity prozessEntity) {
		if (prozessEntity.getStatus() == ProzessStatusEnum.EXTERN) {
			throw new UnsupportedOperationException("Update data on External process is not supported !");
		}
	}
}
