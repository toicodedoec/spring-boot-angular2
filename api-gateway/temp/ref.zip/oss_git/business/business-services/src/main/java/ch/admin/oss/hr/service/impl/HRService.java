/*
 * HRServiceImpl
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hr.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aspose.words.Document;
import com.aspose.words.NodeType;
import com.aspose.words.SaveFormat;
import com.google.common.collect.Iterables;
import com.querydsl.core.types.dsl.PathInits;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.business.CompanyDto;
import ch.admin.oss.business.FirmennameDto;
import ch.admin.oss.business.GeschaeftsstelleDto;
import ch.admin.oss.business.GeschaftsrolleDto;
import ch.admin.oss.business.HrDto;
import ch.admin.oss.business.HrGruenderDto;
import ch.admin.oss.business.HrTemplateType;
import ch.admin.oss.business.IShowAsCollection;
import ch.admin.oss.business.KommFirmaDto;
import ch.admin.oss.common.AbstractProcessService;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.dto.PersonResultDto;
import ch.admin.oss.common.enums.EinlageEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HaftungEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.FirmennameEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrAmtEntity;
import ch.admin.oss.domain.HrAnmeldungEntity;
import ch.admin.oss.domain.HrGruenderEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QCodeWertEntity;
import ch.admin.oss.domain.QGeschaftsrolleEntity;
import ch.admin.oss.domain.QHrAnmeldungEntity;
import ch.admin.oss.domain.QHrGruenderEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QPersonEntity;
import ch.admin.oss.domain.QProzessEntity;
import ch.admin.oss.enums.HrEmailTemplateType;
import ch.admin.oss.enums.SupportedFileTypeDownload;
import ch.admin.oss.exception.ValidationException;
import ch.admin.oss.hr.repository.IHrAnmeldungRepository;
import ch.admin.oss.hr.repository.IHrGruenderRepository;
import ch.admin.oss.hr.service.IHRService;
import ch.admin.oss.organisation.repository.IFirmennameRepository;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.DataUtil;
import ch.admin.oss.util.IDocumentMergeCallback;
import ch.admin.oss.util.MailMessage;
import ch.admin.oss.util.NumberUtil;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OssAsposeUtil;
import ch.admin.oss.util.TemplateDto;

/**
 * @author coh
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class HRService extends AbstractProcessService<HrAnmeldungEntity> implements IHRService {

	private static final String HR_DOCX_FILENAME = "hr.docx";

	private static final String HR_PDF_FILENAME = "hr.pdf";

	private static final String HR_LANGUAGE_SAPARATOR = ";";

	private static final int AG_CAPITAL_MIN = 100_000;
	private static final int AG_SCOPE_OF_PAYMENT = 50_000;
	private static final double AG_VALUE_OF_SHARE_MIN = 0.01;
	
	private static final int GMBH_CAPITAL_MIN = 20000;
	private static final int GMBH_NUMBER_OF_SHARE_MIN = 1;
	private static final int GMBH_VALUE_OF_SHARE_MIN = 100;
	
	private static final QOrganisationEntity QORGANISATION = new QOrganisationEntity(
		QHrAnmeldungEntity.hrAnmeldungEntity.prozess.organisation.getMetadata(), PathInits.DIRECT);
	private static final QCodeWertEntity QADRESSEKORRESPONDENZ_LAND = new QCodeWertEntity(
		QHrAnmeldungEntity.hrAnmeldungEntity.adresseKorrespondenz.land.getMetadata(), PathInits.DIRECT);
	private static final QCodeWertEntity QADRESSERECHNUNG_LAND = new QCodeWertEntity(
		QHrAnmeldungEntity.hrAnmeldungEntity.adresseRechnung.land.getMetadata(), PathInits.DIRECT);
	
	@Autowired
	private IHrAnmeldungRepository hrAnmeldungRepository;
	@Autowired
	private IHrGruenderRepository hrGruenderRepo;
	@Autowired
	private IFirmennameRepository firmennameRepo;
	
	@Override
	public HrAnmeldungEntity createProcess(OrganisationEntity organisation) {
		HrAnmeldungEntity entity = new HrAnmeldungEntity();
		entity.getProzess().setOrganisation(organisation);
		if (organisation.getPflichtenabklaerungen().isAnmeldungHR()) {
			entity.getProzess().setStatus(ProzessStatusEnum.EXTERN);
		}
		recordProcessStatusChange(entity.getProzess());
		return hrAnmeldungRepository.save(entity);
	}

	@Override
	public HrAnmeldungEntity getByOrganisationId(long orgId) {
		return getByOrganisationId(orgId, true);
	}

	@Override
	public HrAnmeldungEntity updateProcess(HrAnmeldungEntity entity) {
		processUpdated(entity.getProzess());
		return hrAnmeldungRepository.save(entity);
	}

	@Override
	public HrAnmeldungEntity completeProcess(HrAnmeldungEntity entity) {
		validateHrAnmeldung(entity);
		processCompleted(entity);
		return hrAnmeldungRepository.save(entity);
	}

	@Override
	public HrAnmeldungEntity lockProcess(HrAnmeldungEntity entity) {
		processLocked(entity, true);
		sendEmail(entity);
		return hrAnmeldungRepository.save(entity);
	}
	
	private void sendEmail(HrAnmeldungEntity hrAnmeldung) {
		MailMessage message = new MailMessage();

		boolean isEfJuspaceElectronic = SecurityUtil.currentUser().isLoginSuisseId() 
				&& BooleanUtils.isTrue(hrAnmeldung.getElektronisch());
		
		ProzessEntity prozessEntity = hrAnmeldung.getProzess();

		OrganisationEntity organisation = prozessEntity.getOrganisation();
		RechtsformEnum rechtsform = organisation.getRechtsform();
		SupportedLanguage language = detectSendingTemplateLanguage(organisation);
		
		if (rechtsform == RechtsformEnum.AG || rechtsform == RechtsformEnum.GMBH) {
			message.setSubject(applicationService.getTranslation("gui_labels.hr.email.subject.AGAndGMBH", language));
			if (organisation.getPflichtenabklaerungen().isDigital()) {
				message.setTemplateName(HrEmailTemplateType.AG_DIGITAL.getFilePath(language));
			} else {
				message.setTemplateName(HrEmailTemplateType.AG_ANALOG.getFilePath(language));
			}
		} else if (rechtsform == RechtsformEnum.EINZELFIRMA && isEfJuspaceElectronic) {
			message.setSubject(applicationService.getTranslation("gui_labels.hr.email.subject.EF", language));
			message.setTemplateName(HrEmailTemplateType.EF_JUSPACE.getFilePath(language));
		} else {
			message.setSubject(applicationService.getTranslation("gui_labels.hr.email.subject.remainning", language));
			message.setTemplateName(HrEmailTemplateType.EF_KOLLG_KOMMG_NORMAL.getFilePath(language));
		}
		message.setFrom(helpdeskEmail);
		message.setTo(SecurityUtil.currentUser().getEmail());
		
		// SECOOSS-401 : AHV registration and HR registration email attachment is missing
		int saveFormat = getDocumentFormat(rechtsform);
		switch (saveFormat) {
			case SaveFormat.PDF:
				message.getAttachmentDatas().put(HR_PDF_FILENAME, hrAnmeldung.getProzess().getPdf());
				break;
			case SaveFormat.DOCX:
				message.getAttachmentDatas().put(HR_DOCX_FILENAME, hrAnmeldung.getProzess().getPdf());
				break;
			default:
				throw new IllegalArgumentException("Unsupported generate document type " + saveFormat);
		}

		FirmennameEntity firmennameEntity = organisation.getNamens().stream()
			.filter(item -> item.isDefault()).findFirst().get();
		String companyName = firmennameEntity.getBezeichnung();

		Map<String, Object> emailData = new HashMap<String, Object>();
		emailData.put("companyName", companyName);
		message.setTemplateModel(emailData);

		mailUtil.send(message);
	}

	private SupportedLanguage detectSendingTemplateLanguage(OrganisationEntity organisation) {
		switch (organisation.getRechtsform()) {
			case AG:
			case GMBH:
				return SecurityUtil.currentUser().getLanguagePreference();
			case EINZELFIRMA:
			case KOLLGES:
			case KOMMGES:
				HrAmtEntity amtEntity = applicationService.getHrAmtByDomizilBfsnr(organisation.getDomizil().getBfsNr());
				SupportedLanguage language = getSupportedLanguage(amtEntity.getAmtssprachen(), HR_LANGUAGE_SAPARATOR);
				return language;
			default:
				throw new IllegalArgumentException("Detect sending template language for type " + organisation.getRechtsform() + " is not supported.");
		}
	}

	@Override
	public HrAnmeldungEntity relockProcess(HrAnmeldungEntity entity) {
		processLocked(entity, false);
		return hrAnmeldungRepository.save(entity);
	}

	@Override
	public HrAnmeldungEntity signProcess(HrAnmeldungEntity entity) {
		processSigned(entity.getProzess());
		return hrAnmeldungRepository.save(entity);
	}

	@Override
	public void markProcessExternal(ProzessEntity prozess, boolean external) {
		throw new UnsupportedOperationException("Mark HR process internal / external is not supported!");
	}

	private void initData(HrAnmeldungEntity entity) {
		entity = jpaUtil.initialize(entity,
			QHrAnmeldungEntity.hrAnmeldungEntity.prozess.statuswechsels,
			QHrAnmeldungEntity.hrAnmeldungEntity.notarAnrede.standardText.translations,
			QHrAnmeldungEntity.hrAnmeldungEntity.gruenders.any().person,
			QADRESSEKORRESPONDENZ_LAND.standardText.translations,
			QADRESSERECHNUNG_LAND.standardText.translations,
			QHrAnmeldungEntity.hrAnmeldungEntity.prozess.flowHistory.items.any().data,
			QORGANISATION.domizil,
			QORGANISATION.pflichtenabklaerungen,
			QORGANISATION.kontens,
			QORGANISATION.geschaeftsstellens.any().adresse,
			QORGANISATION.geschaeftsrollens.any().funktion,
			QORGANISATION.geschaeftsrollens.any().haftung,
			QORGANISATION.geschaeftsrollens.any().zeichnung,
			QORGANISATION.geschaeftsrollens.any().person,
			QORGANISATION.geschaeftsrollens.any().einlage,
			QORGANISATION.namens.any().sprache.standardText.translations,
			QORGANISATION.branches.any().standardText.translations,
			QORGANISATION.flowHistory.items.any().data
		);
		
		jpaUtil.initialize(entity.getProzess().getOrganisation().getDomizil().getLand(), QCodeWertEntity.codeWertEntity.standardText.translations);

		if (entity.getProzess().getOrganisation().getRechtsform() == RechtsformEnum.KOMMGES) {
			jpaUtil.initialize(entity.getProzess().getOrganisation(),
					QOrganisationEntity.organisationEntity.kommGes.kommFirmas.any().domizil,
					QOrganisationEntity.organisationEntity.kommGes.kommFirmas.any().einlage.standardText.translations);
			entity.getProzess().getOrganisation().getKommGes().getKommFirmas().forEach(item -> {
				jpaUtil.initialize(item.getDomizil().getLand(),
					QCodeWertEntity.codeWertEntity.standardText.translations);
			});	
		}

		QPersonEntity qPerson = QPersonEntity.personEntity;
		entity.getGruenders().forEach(item -> {
			jpaUtil.initialize(item, 
				QHrGruenderEntity.hrGruenderEntity.funktion.standardText.translations,
				QHrGruenderEntity.hrGruenderEntity.zeichnung.standardText.translations
			);
			initPersonData(item.getPerson(), qPerson);
		});
		// This is special case where we need to initial the whole geschaeftsrollens.
		entity.getProzess().getOrganisation().getGeschaeftsrollens().stream().forEach(item -> {
			jpaUtil.initialize(item,
				QGeschaftsrolleEntity.geschaftsrolleEntity.haftung.standardText.translations,
				QGeschaftsrolleEntity.geschaftsrolleEntity.funktion.standardText.translations,
				QGeschaftsrolleEntity.geschaftsrolleEntity.zeichnung.standardText.translations
			);
			initPersonData(item.getPerson(), qPerson);
		});
	}

	private void initPersonData(PersonEntity personEntity, QPersonEntity qPerson) {
		jpaUtil.initialize(personEntity, 
			qPerson.wohnadresse.land,
			qPerson.heimatortes,
			qPerson.auslaenderAusweis.standardText.translations,
			qPerson.anrede.standardText.translations,
			qPerson.zivilstand.standardText.translations,
			qPerson.nationalitaetens.any().standardText.translations
		);
		
		jpaUtil.initialize(personEntity.getWohnadresse().getLand(), QCodeWertEntity.codeWertEntity.standardText.translations);
	}

	private void validateHrAnmeldung(HrAnmeldungEntity entity) {
		RechtsformEnum rechtsform = entity.getProzess().getOrganisation().getRechtsform();
		if (rechtsform == RechtsformEnum.AG) {
			validateCapitalShareAG(entity);
		} else if (rechtsform == RechtsformEnum.GMBH) {
			validateCapitalShareGMBH(entity);
		}
		
		if (rechtsform == RechtsformEnum.AG || rechtsform == RechtsformEnum.GMBH) {
			if (!entity.getProzess().getOrganisation().getPflichtenabklaerungen().isDigital()) {
				validateOfflineNotary(entity);
			}
		}
	}

	private void validateCapitalShareAG(HrAnmeldungEntity entity) {
		if (entity.getAktienkapital() == null || entity.getAktienkapital().intValue() < AG_CAPITAL_MIN) {
			throw new ValidationException("Aktienkapital must be >= 100'000 CHF");
		}
		if (entity.getLiberierungsumfang() == null || entity.getLiberierungsumfang() < AG_SCOPE_OF_PAYMENT) {
			throw new ValidationException("Liberierungsumfang must be >= 50'000 CHF");
		}
		if (entity.getLiberierungsumfang().intValue() > entity.getAktienkapital().intValue()) {
			throw new ValidationException("Liberierungsumfang must be <= Aktienkapital");
		}
		double twentyPercentageOfCapital = entity.getAktienkapital().doubleValue() * 20 / 100;
		if (entity.getLiberierungsumfang().doubleValue() < twentyPercentageOfCapital) {
			throw new ValidationException("Liberierungsumfang must be >= 20 % of Aktienkapital");
		}
		// Shares
		if (NumberUtil.getValue(entity.getNamensaktien()) < 0) {
			throw new ValidationException("Namensaktien must be >= 0");
		}
		if (NumberUtil.getValue(entity.getInhaberaktien()) < 0) {
			throw new ValidationException("Inhaberaktien must be >= 0");
		}
		int totalOfShares = NumberUtil.getValue(entity.getNamensaktien()) + NumberUtil.getValue(entity.getInhaberaktien());
		if (totalOfShares <= 0) {
			throw new ValidationException("Sum of Namensaktien and Inhaberaktien must be > 0");
		}
		double valueOfShare = entity.getAktienkapital().doubleValue() / totalOfShares;
		if (!NumberUtil.hasAsMostNumberOfDecimal(valueOfShare, 2)) {
			throw new ValidationException("The value of share must not has more than 2 decimal places. (E.g 1.23 is OK, 1.234 is NOT)");
		}
		if (valueOfShare < AG_VALUE_OF_SHARE_MIN) {
			throw new ValidationException("The value of share must be >= 0.01 CHF");
		}
		int totalOfNamensaktien = 0;
		int totalOfInhaberaktien = 0;
		for (GeschaftsrolleEntity item : entity.getProzess().getOrganisation().getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)) {
			totalOfNamensaktien += NumberUtil.getValue(item.getAnzNamensaktien());
			totalOfInhaberaktien += NumberUtil.getValue(item.getAnzInhaberaktien());
		}
		for (HrGruenderEntity item : entity.getGruenders()) {
			totalOfNamensaktien += NumberUtil.getValue(item.getAnzNamensaktien());
			totalOfInhaberaktien += NumberUtil.getValue(item.getAnzInhaberaktien());
		}
		if (totalOfNamensaktien != NumberUtil.getValue(entity.getNamensaktien())
			|| totalOfInhaberaktien != NumberUtil.getValue(entity.getInhaberaktien())) {
			throw new ValidationException("All nominal shares and all transferrable shares must be distributed among the shareholders");
		}
	}

	private void validateCapitalShareGMBH(HrAnmeldungEntity entity) {
		if (entity.getStammkapital() == null || entity.getStammkapital().intValue() < GMBH_CAPITAL_MIN) {
			throw new ValidationException("Stammkapital must be >= 20'000 CHF");
		}
		if (entity.getStammanteile() == null || entity.getStammanteile().intValue() < GMBH_NUMBER_OF_SHARE_MIN) {
			throw new ValidationException("Stammanteile must be > 0");
		}
		double valueOfShare = entity.getStammkapital().doubleValue() / entity.getStammanteile().intValue();
		if (!NumberUtil.isInteger(valueOfShare)) {
			throw new ValidationException("Value of share must be an Integer");
		}
		if (valueOfShare < GMBH_VALUE_OF_SHARE_MIN) {
			throw new ValidationException("Value of share must be at least 100 CHF");
		}
		int totalOfShares = 0;
		for (GeschaftsrolleEntity item : entity.getProzess().getOrganisation().getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)) {
			totalOfShares += NumberUtil.getValue(item.getAnzStammanteile());
		}
		for (HrGruenderEntity item : entity.getGruenders()) {
			totalOfShares += NumberUtil.getValue(item.getAnzStammanteile());
		}
		if (totalOfShares != NumberUtil.getValue(entity.getStammanteile())) {
			throw new ValidationException("All shares must be distributed among the shareholders");
		}
	}

	private void validateOfflineNotary(HrAnmeldungEntity entity) {
		if (entity.getNotarAnrede() == null) {
			throw new ValidationException("Notar Anrede is required");
		}
		if (StringUtils.isEmpty(entity.getNotarName())) {
			throw new ValidationException("Notar Name is required");
		}
		if (StringUtils.isEmpty(entity.getNotarPostadresse())) {
			throw new ValidationException("Notar Address is required");
		}
	}

	@Override
	public FileDto downloadDocument(long orgId) {
		RechtsformEnum rechtsform = new JPAQuery<>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.organisation.id.eq(orgId))
			.where(QProzessEntity.prozessEntity.typ.eq(ProzessTypEnum.HR))
			.select(QProzessEntity.prozessEntity.organisation.rechtsform)
			.fetchFirst();

		byte[] document = getDocument(orgId);
		int saveFormat = getDocumentFormat(rechtsform);
		switch (saveFormat) {
			case SaveFormat.PDF:
				return new FileDto(HR_PDF_FILENAME, SupportedFileTypeDownload.PDF, document);
			case SaveFormat.DOCX:
				return new FileDto(HR_DOCX_FILENAME, SupportedFileTypeDownload.DOCX, document);
			default:
				throw new IllegalArgumentException("Unsupported generate document type " + saveFormat);
		}
	}

	@Override
	protected byte[] generateDocument(HrAnmeldungEntity entity, boolean draft) {
		RechtsformEnum rechtsform = entity.getProzess().getOrganisation().getRechtsform();
		HrTemplateType templateType;
		switch (rechtsform) {
			case EINZELFIRMA:
				if (BooleanUtils.isTrue(entity.getElektronisch())) {
					templateType = HrTemplateType.EF_ELECTRONIC;
				} else {
					templateType = HrTemplateType.EF;
				}
				break;
			case KOLLGES:
			case KOMMGES:
				templateType = HrTemplateType.PG;
				break;
			case AG:
			case GMBH:
				if (StringUtils.isNotBlank(entity.getNotarUpRegUUID())) {
					templateType = HrTemplateType.KG_DIGITAL;
				} else {
					templateType = HrTemplateType.KG_ANALOG;
				}
				break;
			default:
				throw new IllegalArgumentException("Unknown rechtform " + rechtsform);
		}

		SupportedLanguage language = detectSendingTemplateLanguage(entity.getProzess().getOrganisation());

		HrAmtEntity amtEntity = applicationService.getHrAmtByDomizilBfsnr(entity.getProzess().getOrganisation().getDomizil().getBfsNr());
		HrDto dto = convertHrEntityToDocumentDto(entity, amtEntity, language, templateType);

		TemplateDto<HrDto> templateDto = new TemplateDto<>(dto,
			templateType.getFiles(),
			getDocumentFormat(rechtsform),
			language.name()
		);
		if (draft) {
			switch (rechtsform) {
				case AG:
				case GMBH:
					dto.setWatermark(applicationService.getTranslation("gui_labels.hr.document.watermark", language) + " - ");
					break;
				default:
					templateDto.setWatermark(applicationService.getTranslation("gui_labels.hr.document.watermark", language));
			}
		}
		return OssAsposeUtil.generateDocument(templateDto, new HRMergeCallback(entity));
	}
	
	private int getDocumentFormat(RechtsformEnum rechtsform) {
		return rechtsform == RechtsformEnum.AG || rechtsform == RechtsformEnum.GMBH
			? SaveFormat.DOCX : SaveFormat.PDF;
	}
	
	private static class HRMergeCallback implements IDocumentMergeCallback<HrDto> {
		
		private HrAnmeldungEntity hrEntity;
		
		public HRMergeCallback(HrAnmeldungEntity hrEntity) {
			this.hrEntity = hrEntity;
		}
		
		@Override
		public void apply(Document doc, HrDto data) throws Exception {
			RechtsformEnum rechtsform = hrEntity.getProzess().getOrganisation().getRechtsform();
			if (rechtsform == RechtsformEnum.AG) {
				OssAsposeUtil.removeEmptyBlock(doc, "table_gmbh_person", NodeType.TABLE);
				if (data.getGruenders().isEmpty()) {
					OssAsposeUtil.removeEmptyBlock(doc, "table_ag_person_gruender", NodeType.CELL);
				}
			} else if (rechtsform == RechtsformEnum.GMBH) {
				OssAsposeUtil.removeEmptyBlock(doc, "ag_info", NodeType.PARAGRAPH);
				OssAsposeUtil.removeEmptyBlock(doc, "table_ag_person", NodeType.TABLE);
				if (data.getGruenders().isEmpty()) {
					OssAsposeUtil.removeEmptyBlock(doc, "table_gmbh_person_gruender", NodeType.CELL);
				}
			}
			if (data.getOrganisation().getFirmennames().isEmpty()) {
				OssAsposeUtil.removeEmptyBlock(doc, "otherCompanyNames", NodeType.ROW);
			}
			doc.getRange().getBookmarks().clear();
		}
	}

	private HrDto convertHrEntityToDocumentDto(HrAnmeldungEntity entity, HrAmtEntity amtEntity, SupportedLanguage language, HrTemplateType templateType) {
		HrDto dto = new HrDto();
		ProzessEntity prozess = entity.getProzess();
		OrganisationEntity organisationEntity = prozess.getOrganisation();
		RechtsformEnum rechtsform = organisationEntity.getRechtsform();

		// HR
		dto.setUser(SecurityUtil.currentUser().getUsername());
		dto.setAmt(constructHRAmtDto(amtEntity, language));
		dto.setNotarAnrede(getCodeText(entity.getNotarAnrede(), language));
		dto.setNotarTitle(entity.getNotarTitel());
		dto.setNotarName(entity.getNotarVorname());
		dto.setNotarFamilyName(entity.getNotarName());
		dto.setNotarAdress(entity.getNotarPostadresse());
		dto.setNotarTelefon(entity.getNotarTelefon());
		dto.setNotarTelefon2(entity.getNotarFax());
		dto.setNotarMail(entity.getNotarEmail());
		dto.setBargruendung(entity.isBargruendung()
			? applicationService.getTranslation("gui_labels.hr.capital_share.ag.liberierungsart.elektronisch", language)
			: applicationService.getTranslation("gui_labels.hr.capital_share.ag.liberierungsart.bargruendung", language));

		dto.setFinanzBemerkungen(entity.getFinanzBemerkungen());
		dto.setBemerkungen(entity.getBemerkungen());
		dto.setDescriptionEmpty(applicationService.getTranslation("gui_labels.description.empty", language));

		dto.setAuszuege(entity.getAuszuege());
		dto.setAuszuegeVor(entity.getAuszuegeVor());

		dto.setAdresseKorrespondenz(convertAddressToDocumentDto(entity.getAdresseKorrespondenz(), language));
		dto.setAdresseRechnung(convertAddressToDocumentDto(entity.getAdresseRechnung(), language));

		dto.setAktienkapital(entity.getAktienkapital());
		dto.setLiberierungsumfang(entity.getLiberierungsumfang());
		dto.setStammkapital(entity.getStammkapital());
		dto.setStammanteile(entity.getStammanteile());
		switch (rechtsform) {
			case AG:
				int totalOfShares = NumberUtil.getValue(entity.getNamensaktien()) + NumberUtil.getValue(entity.getInhaberaktien());
				dto.setShareValue(BigDecimal.valueOf(NumberUtil.getValue(entity.getAktienkapital()) * 1d / totalOfShares));
				break;
			case GMBH:
				dto.setShareValue(BigDecimal.valueOf(NumberUtil.getValue(entity.getStammkapital()) * 1d / NumberUtil.getValue(entity.getStammanteile())));
				break;
			default:
				// No share value
		}

		dto.setRegistrationNumber(prozess.getUid());

		// Organisation
		CompanyDto organisation = new CompanyDto();
		dto.setOrganisation(organisation);
		organisation.setDigital(organisationEntity.getPflichtenabklaerungen().isDigital());
		organisation.setEroeffnungsdatum(organisationEntity.getEroeffnungsDatum());
		organisation.setGeschaeftsjahrEnde(organisationEntity.getGeschaeftsjahrEnd());
		organisation.setRechtsform(applicationService.getTranslation(organisationEntity.getRechtsform(), language));
		organisation.setDomizil(convertAddressToDocumentDto(organisationEntity.getDomizil(), language));
		organisation.setZweck(organisationEntity.getZweck());

		organisation.setAg(rechtsform == RechtsformEnum.AG);

		organisationEntity.getNamens().stream().filter(item -> item.isDefault())
			.forEach(item -> {
				FirmennameDto firmenname = new FirmennameDto();
				organisation.setDefaultFirmenname(firmenname);
				firmenname.setBezeichnung(item.getBezeichnung());
				firmenname.setSprache(getCodeText(item.getSprache(), language));
				organisation.setName(firmenname.getBezeichnung());
			});
		organisation.setFirmennames(organisationEntity.getNamens().stream()
			.filter(item -> !item.isDefault())
			.map(item -> {
				FirmennameDto firmenname = new FirmennameDto();
				firmenname.setBezeichnung(item.getBezeichnung());
				firmenname.setSprache(getCodeText(item.getSprache(), language));
				return firmenname;
			})
			.collect(Collectors.toList())
		);
		dto.getOrganisation().setCombinedFirmenname(DataUtil.joinStrings(", ", organisationEntity.getNamens().stream()
			.filter(item -> !item.isDefault())
			.map(item -> item.getBezeichnung())
			.toArray(size -> new String[size])));

		// SECOOSS-386 HR Registration despite no branch office selected shown in PDF
		organisation.setGeschaeftsstellens(organisationEntity.getGeschaeftsstellens().stream().filter(g -> g.isInHR())
			.map(item -> {
				GeschaeftsstelleDto geschaeftsstelleDto = new GeschaeftsstelleDto();
				geschaeftsstelleDto.setAdr(convertAddressToDocumentDto(item.getAdresse(), language));
				return geschaeftsstelleDto;
			})
			.collect(Collectors.toList()));

		// Root founder
		if (rechtsform == RechtsformEnum.AG
			|| rechtsform == RechtsformEnum.GMBH
			|| rechtsform == RechtsformEnum.EINZELFIRMA) {
			GeschaftsrolleEntity founderEntity = organisationEntity
				.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream().findFirst().get();
			dto.setOwner(convertNaturalPersonToDocumentDto(new GeschaftsrolleDto(), language, founderEntity).setHr(dto));
		}
		
		if (rechtsform == RechtsformEnum.AG) {
			dto.setPersonType(applicationService.getTranslation("gui_labels.hr.capital_share.ag.personType_label", language));
			dto.setPersonTypePlural(applicationService.getTranslation("gui_labels.hr.capital_share.ag.aktionare_label", language));
		} else if (rechtsform == RechtsformEnum.GMBH) {
			dto.setPersonType(applicationService.getTranslation("gui_labels.hr.capital_share.gmbh.gesellschafter_label", language));
			dto.setPersonTypePlural(applicationService.getTranslation("gui_labels.hr.capital_share.gmbh.gesellschafter_label", language));
		}

		// Founders
		AtomicInteger founderCounter = new AtomicInteger(1);
		dto.setGruenders(entity.getGruenders().stream()
			.map(item -> {
				HrGruenderDto person = new HrGruenderDto();
				person.setHr(dto);
				
				person.setAnrede(getCodeText(item.getPerson().getAnrede(), language));
				person.setTitel(item.getPerson().getTitel());
				person.setFamilienname(item.getPerson().getFamilienname());
				person.setVorname(item.getPerson().getVorname());
				person.setLedigname(item.getPerson().getLedigname());
				person.setWeitereVornamen(item.getPerson().getVornamenliste());
				person.setGeburtsdatum(item.getPerson().getGeburtsdatum());
				person.setAhvNummer(item.getPerson().getAhvNummer());
				person.setHeimatortCombined(DataUtil.formatHeimatorte(item.getPerson().getHeimatortes()));
				person.setFunktion(getCodeText(item.getFunktion(), language));
				person.setZeichnung(getCodeText(item.getZeichnung(), language));
				person.setZivilstand(getCodeText(item.getPerson().getZivilstand(), language));

				person.setShareValue(dto.getShareValue());
				person.setIndex(founderCounter.incrementAndGet());

				person.setAnzInhaberaktien(item.getAnzInhaberaktien());
				person.setAnzNamensaktien(item.getAnzNamensaktien());
				person.setAnzStammanteile(item.getAnzStammanteile());

				person.setAdr(convertAddressToDocumentDto(item.getPerson().getWohnadresse(), language));
				return person;
			})
			.collect(Collectors.toList()));
		decorateListInfo(dto.getGruenders());
		dto.setSteuernUsa(organisationEntity.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream()
			.anyMatch(item -> BooleanUtils.isTrue(item.getPerson().getSteuernUSA())));
		if (!dto.isSteuernUsa()) {
			dto.setSteuernUsa(entity.getGruenders().stream()
				.anyMatch(item -> BooleanUtils.isTrue(item.getPerson().getSteuernUSA())));
		}

		// Signatures
		AtomicInteger signatoryCounter = new AtomicInteger();
		dto.setSignatories(organisationEntity.getGeschaeftsrollens(GeschaeftsrolleTypEnum.SIGNATORY).stream()
			.map(item -> {
				GeschaftsrolleDto person = convertNaturalPersonToDocumentDto(new GeschaftsrolleDto(), language, item).setHr(dto);
				person.setIndex(signatoryCounter.incrementAndGet());
				return person;
			})
			.collect(Collectors.toList())
		);
		dto.setNumberOfSignatories(dto.getSignatories().size());
		decorateListInfo(dto.getSignatories());

		List<GeschaftsrolleDto> naturalPersons = new ArrayList<>(organisationEntity.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).size());
		AtomicInteger natuaralPersonCounter = new AtomicInteger();

		// Unlimited person
		AtomicInteger unlimitedPersonCounter = new AtomicInteger();
		dto.getOrganisation().setUnlimitedPersons(organisationEntity
			.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream()
			.filter(item -> item.getHaftung() != null
				&& HaftungEnum.UNBESCHRAENKT.getCode().equals(item.getHaftung().getCode()))
			.map(item -> {
				GeschaftsrolleDto person = convertNaturalPersonToDocumentDto(new GeschaftsrolleDto(), language, item).setHr(dto);
				person.setIndex(unlimitedPersonCounter.incrementAndGet());
				
				GeschaftsrolleDto naturalPerson = convertNaturalPersonToDocumentDto(new GeschaftsrolleDto(), language, item).setHr(dto);
				naturalPersons.add(naturalPerson);
				naturalPerson.setIndex(natuaralPersonCounter.incrementAndGet());
				return person;
			})
			.collect(Collectors.toList())
		);
		decorateListInfo(dto.getOrganisation().getUnlimitedPersons());

		// Limited person
		AtomicInteger limitedPersonCounter = new AtomicInteger();
		dto.getOrganisation().setLimitedPersons(organisationEntity.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream()
			.filter(item -> item.getHaftung() != null
				&& HaftungEnum.BESCHRAENKT.getCode().equals(item.getHaftung().getCode()))
			.map(item -> {
				GeschaftsrolleDto person = convertNaturalPersonToDocumentDto(new GeschaftsrolleDto(), language, item).setHr(dto);
				person.setIndex(limitedPersonCounter.incrementAndGet());
				person.setOwnerType(", " + applicationService.getTranslation("gui_labels.onwerType.limited.label", language));

				GeschaftsrolleDto naturalPerson = convertNaturalPersonToDocumentDto(new GeschaftsrolleDto(), language, item).setHr(dto);
				naturalPerson.setOwnerType(", " + applicationService.getTranslation("gui_labels.onwerType.limited.label", language));
				naturalPersons.add(naturalPerson);
				naturalPerson.setIndex(natuaralPersonCounter.incrementAndGet());
				return person;
			})
			.collect(Collectors.toList())
		);
		decorateListInfo(dto.getOrganisation().getLimitedPersons());

		dto.getOrganisation().setNaturalPersons(naturalPersons);
		dto.setNumberOfNaturalPersons(naturalPersons.size());
		decorateListInfo(dto.getOrganisation().getNaturalPersons());
		
		dto.setNumberOfContributedPersons((int) (
			organisationEntity.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)
				.stream()
				.filter(item -> item.getEinlage() != null
					&& EinlageEnum.SACH.name().equals(item.getEinlage().getCode()))
				.count())
		);

		if (rechtsform == RechtsformEnum.KOMMGES) {
			dto.setNumberOfContributedPersons(dto.getNumberOfContributedPersons() + 
				(int) (organisationEntity.getKommGes().getKommFirmas()
					.stream()
					.filter(item -> item.getEinlage() != null
						&& EinlageEnum.SACH.name().equals(item.getEinlage().getCode()))
					.count())
			);

			// Legal shareholders
			dto.getOrganisation().setKommFirmas(organisationEntity.getKommGes().getKommFirmas().stream()
				.map(item -> {
					KommFirmaDto newItem = new KommFirmaDto();
					newItem.setHr(dto);
					
					newItem.setName(item.getName());
					newItem.setDomizil(convertAddressToDocumentDto(item.getDomizil(), language));
					newItem.setEinlage(getCodeText(item.getEinlage(), language));
					newItem.setHaftung(item.getHaftung());
					newItem.setHrNummer(item.getHrNummer());
					if (item.getRechtsformCH() != null) {
						newItem.setRechtsform(applicationService.getTranslation(item.getRechtsformCH()));
					} else {
						newItem.setRechtsform(item.getRechtsformAusland());
					}
					return newItem;
				})
				.collect(Collectors.toList())
			);
			decorateListInfo(dto.getOrganisation().getKommFirmas());
			dto.setNumberOfLegalPersons(dto.getOrganisation().getKommFirmas().size());
		}
		return dto;
	}

	private void decorateListInfo(List<? extends IShowAsCollection> list) {
		IShowAsCollection last = Iterables.getLast(list, null);
		if (last != null) {
			last.setLast(true);
		}
	}

	/**
	 * @param orgId is just for authentication.
	 */
	@Override
	public HrGruenderEntity getHrGruenderById(long orgId, long id, int version) {
		return jpaUtil.initialize(new JPAQuery<HrGruenderEntity>(em)
			.from(QHrGruenderEntity.hrGruenderEntity)
			.join(QHrGruenderEntity.hrGruenderEntity.person, QPersonEntity.personEntity).fetchJoin()
			.where(
				QHrGruenderEntity.hrGruenderEntity.id.eq(id)
				.and(QHrGruenderEntity.hrGruenderEntity.version.eq(version)))
			.fetchOne(),
			QHrGruenderEntity.hrGruenderEntity.person.heimatortes);
	}

	@Override
	public PersonResultDto<HrGruenderEntity, HrAnmeldungEntity> saveUnvalidatedHrGruender(long orgId, HrGruenderEntity ent) {
		ent.setComplete(false);
		return new PersonResultDto<>(hrGruenderRepo.save(ent), updateProcess(getByOrganisationId(orgId, false)));
	}

	@Override
	public PersonResultDto<HrGruenderEntity, HrAnmeldungEntity> saveValidatedHrGruender(long orgId, @Valid HrGruenderEntity ent) {
		ent.setComplete(true);
		return new PersonResultDto<>(hrGruenderRepo.save(ent), updateProcess(getByOrganisationId(orgId, false)));
	}

	@Override
	public PersonResultDto<HrGruenderEntity, HrAnmeldungEntity> deleteHrGruender(long orgId, HrGruenderEntity ent) {
		hrGruenderRepo.delete(ent);
		return new PersonResultDto<>(null, updateProcess(getByOrganisationId(orgId, false)));
	}
	
	@Override
	public PersonResultDto<GeschaftsrolleEntity, HrAnmeldungEntity> saveUnvalidatedGeschaftsrolle(long orgId, GeschaftsrolleEntity ent) {
		return new PersonResultDto<>(internalSaveUnvalidatedGeschaftsrolle(ent, null), updateProcess(getByOrganisationId(orgId, false)));
	}

	@Override
	public PersonResultDto<GeschaftsrolleEntity, HrAnmeldungEntity> saveValidatedGeschaftsrolle(long orgId, GeschaftsrolleEntity ent) {
		return new PersonResultDto<>(internalSaveValidatedGeschaftsrolle(ent), updateProcess(getByOrganisationId(orgId, false)));
	}

	@Override
	public PersonResultDto<GeschaftsrolleEntity, HrAnmeldungEntity> deleteGeschaftsrolle(long orgId, GeschaftsrolleEntity ent) {
		super.internalDeleteGeschaftsrolle(ent);
		return new PersonResultDto<>(null, updateProcess(getByOrganisationId(orgId, false)));
	}

	@Override
	public FirmennameEntity saveFirmenname(Long orgId, FirmennameEntity ent) {
		return firmennameRepo.save(ent);
	}

	@Override
	public FirmennameEntity findFirmennameById(Long orgId, Long id) {
		return firmennameRepo.findOne(id);
	}

	private HrAnmeldungEntity getByOrganisationId(long orgId, boolean initData) {
		HrAnmeldungEntity entity = new JPAQuery<HrAnmeldungEntity>(em)
			.from(QHrAnmeldungEntity.hrAnmeldungEntity)
			.join(QHrAnmeldungEntity.hrAnmeldungEntity.prozess).fetchJoin()
			.where(QHrAnmeldungEntity.hrAnmeldungEntity.prozess.organisation.id.eq(orgId))
			.fetchOne();
		if (initData) {
			initData(entity);
		}
		return entity;
	}

	@Override
	public List<AdresseEntity> getHrAdresseKorrespondenzByOrgId(long orgId) {
		return new JPAQuery<HrAnmeldungEntity>(em)
			.from(QHrAnmeldungEntity.hrAnmeldungEntity)
			.join(QHrAnmeldungEntity.hrAnmeldungEntity.prozess).fetchJoin()
			.join(QHrAnmeldungEntity.hrAnmeldungEntity.adresseKorrespondenz).fetchJoin()
			.where(QHrAnmeldungEntity.hrAnmeldungEntity.prozess.organisation.id.eq(orgId)
				.and(QHrAnmeldungEntity.hrAnmeldungEntity.adresseKorrespondenz.land.code.eq(OSSConstants.SWISS_CODE_WERT)))
			.fetch()
			.stream()
			.map(a -> a.getAdresseKorrespondenz())
			.collect(Collectors.toList());
	}

	@Override
	public boolean isHrProcessCompleted(long orgId) {
		long count = new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity)
			.where(
				QProzessEntity.prozessEntity.organisation.id.eq(orgId)
				.and(QProzessEntity.prozessEntity.typ.eq(ProzessTypEnum.HR))
				.and(QProzessEntity.prozessEntity.completed.eq(Boolean.TRUE))
			).fetchCount();
		return count > 0;
	}

	@Override
	protected ProzessTypEnum getProcessType() {
		return ProzessTypEnum.HR;
	}

	@Override
	public HrAnmeldungEntity updateProcess(long orgId, HrAnmeldungEntity entity) {
		throw new UnsupportedOperationException("Not use in UVG process");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ProzessStatusEnum getProcessStatusByOrgId(long orgId) {
		return getProcessStatus(orgId);
	}

}
