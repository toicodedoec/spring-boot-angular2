/*
 * VerbandDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;

/**
 * @author tdm
 */
public class VerbandDto extends AbstractOSSDto {

	private String text;
	@NotNull
	private boolean aktiv;
	@NotNull
	StandardTextDto standardText;
	@NotNull
	private AusgleichskasseDto ausgleichskasse;

	public VerbandDto() {}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public boolean isAktiv() {
		return aktiv;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}

	public StandardTextDto getStandardText() {
		return standardText;
	}

	public void setStandardText(StandardTextDto standardText) {
		this.standardText = standardText;
	}

	public AusgleichskasseDto getAusgleichskasse() {
		return ausgleichskasse;
	}

	public void setAusgleichskasse(AusgleichskasseDto ausgleichskasse) {
		this.ausgleichskasse = ausgleichskasse;
	}

}
