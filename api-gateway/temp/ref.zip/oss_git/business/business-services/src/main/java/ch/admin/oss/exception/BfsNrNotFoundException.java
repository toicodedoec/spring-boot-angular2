/*
 * BfsNrNotFoundException
 * 
 * Project: OSS
 *
 * Copyright 2017 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.exception;

/**
 * @author xdg
 */
public class BfsNrNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 6008062419302387954L;

	public BfsNrNotFoundException(String message) {
		super(message);
	}

}
