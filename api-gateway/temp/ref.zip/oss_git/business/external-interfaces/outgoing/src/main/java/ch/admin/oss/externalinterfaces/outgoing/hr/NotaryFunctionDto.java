/*
 * NotaryFunctionDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.hr;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author hha
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class NotaryFunctionDto implements Serializable {

	private static final long serialVersionUID = -2335337279969292618L;

	private String name;
	private String canton;
	private NotaryOrganisationDto organisation;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCanton() {
		return canton;
	}

	public void setCanton(String canton) {
		this.canton = canton;
	}

	public NotaryOrganisationDto getOrganisation() {
		return organisation;
	}

	public void setOrganisation(NotaryOrganisationDto organisation) {
		this.organisation = organisation;
	}

}
