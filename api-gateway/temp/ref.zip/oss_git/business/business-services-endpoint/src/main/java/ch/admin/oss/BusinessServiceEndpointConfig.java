/*
 * WebConfig
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss;

import java.util.Arrays;

import org.dozer.DozerBeanMapper;
import org.dozer.loader.api.BeanMappingBuilder;
import org.dozer.loader.api.TypeMappingOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;

import ch.admin.oss.admin.endpoint.AdminServiceEndpoint;
import ch.admin.oss.admin.endpoint.BerufAdminDto;
import ch.admin.oss.admin.endpoint.BrancheAdminDto;
import ch.admin.oss.ahv.endpoint.AHVServiceEndpoint;
import ch.admin.oss.ahv.endpoint.AhvAnmeldungDto;
import ch.admin.oss.ahv.endpoint.AhvTeilhaberDto;
import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.common.CommonWebConfig;
import ch.admin.oss.common.HibernateLazyAwareFieldMapper;
import ch.admin.oss.common.IfNotNullConverter;
import ch.admin.oss.common.OSSCustomObjectMapper;
import ch.admin.oss.common.ProzessDto;
import ch.admin.oss.domain.AhvAnmeldungEntity;
import ch.admin.oss.domain.AhvTeilhaberEntity;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.HrAnmeldungEntity;
import ch.admin.oss.domain.HrMutationEntity;
import ch.admin.oss.domain.HrMutationPersonEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QAhvAnmeldungEntity;
import ch.admin.oss.domain.QAhvTeilhaberEntity;
import ch.admin.oss.domain.QHrAnmeldungEntity;
import ch.admin.oss.domain.QHrMutationEntity;
import ch.admin.oss.domain.QHrMutationPersonEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QPflichtenabklaerungenEntity;
import ch.admin.oss.domain.QProzessEntity;
import ch.admin.oss.domain.QUvgAnmeldungEntity;
import ch.admin.oss.domain.QZugriffEntity;
import ch.admin.oss.domain.UvgAnmeldungEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.hr.endpoint.HRDto;
import ch.admin.oss.hr.endpoint.HRServiceEndpoint;
import ch.admin.oss.hrmutation.endpoint.HrMutationDto;
import ch.admin.oss.hrmutation.endpoint.HrMutationPersonDto;
import ch.admin.oss.hrmutation.endpoint.HrMutationServiceEndpoint;
import ch.admin.oss.organisation.endpoint.ExternalProcessDeclarationDto;
import ch.admin.oss.organisation.endpoint.OrganisationDto;
import ch.admin.oss.organisation.endpoint.OrganisationServiceEndpoint;
import ch.admin.oss.organisation.endpoint.ZugriffDto;
import ch.admin.oss.portal.endpoint.ActivityDto;
import ch.admin.oss.portal.endpoint.PflichtenabklaerungenDto;
import ch.admin.oss.portal.endpoint.PrivatePortalServiceEndpoint;
import ch.admin.oss.uvg.endpoint.UvgAnmeldungDto;
import ch.admin.oss.uvg.endpoint.UvgServiceEndpoint;

/**
 * Main Spring configuration for "business-service-endpoint" module.
 * 
 * @author phd
 */
@SpringBootApplication(scanBasePackageClasses = BusinessServiceEndpointConfig.class)
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, FreeMarkerAutoConfiguration.class})
@PropertySource(value = {"classpath:application.internal.properties"})
@Import(CommonWebConfig.class)
public class BusinessServiceEndpointConfig extends SpringBootServletInitializer {

	@Autowired
	private IApplicationService applicationService;

	@Bean
	public DozerBeanMapper mapper() {
		DozerBeanMapper mapper = new DozerBeanMapper();
		mapper.setCustomFieldMapper(new HibernateLazyAwareFieldMapper());
		mapper.setCustomConverters(Lists.newArrayList(new IfNotNullConverter(), new CodeWertConverter(applicationService)));
		mapper.setMappingFiles(Arrays.asList("dozer-global-config.xml"));
		mapper.addMapping(new BeanMappingBuilder() {
			@Override
			protected void configure() {
				mapping(ZugriffDto.class, ZugriffEntity.class,
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(OrganisationServiceEndpoint.ENTERPRISE_ZUGRIFF)
				)
				.exclude(QZugriffEntity.zugriffEntity.user.getMetadata().getName());
				
				mapping(PflichtenabklaerungenDto.class, PflichtenabklaerungenEntity.class,
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(PrivatePortalServiceEndpoint.PORTAL_PFLICHTENABKLAERUNGEN)
				)
				.exclude(QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.beruf.getMetadata().getName())
				.exclude(QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.branches.getMetadata().getName());
				
				mapping(OrganisationDto.class, OrganisationEntity.class,
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(OrganisationServiceEndpoint.ORG_ORGANISATION)
				)
				.exclude(QOrganisationEntity.organisationEntity.kontens.getMetadata().getName())
				.exclude(QOrganisationEntity.organisationEntity.geschaeftsrollens.getMetadata().getName())
				.exclude(QOrganisationEntity.organisationEntity.kommGes.getMetadata().getName())
				.exclude(QOrganisationEntity.organisationEntity.branches.getMetadata().getName())
				.exclude(QOrganisationEntity.organisationEntity.pflichtenabklaerungen.getMetadata().getName())
				.exclude(QOrganisationEntity.organisationEntity.geschaeftsstellens.getMetadata().getName())
				.exclude(QOrganisationEntity.organisationEntity.baseDataLocked.getMetadata().getName());
				
				mapping(HRDto.class, HrAnmeldungEntity.class,
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(HRServiceEndpoint.HR_ANMELDUNG)
				)
				.exclude(QHrAnmeldungEntity.hrAnmeldungEntity.prozess.getMetadata().getName())
				.exclude(QHrAnmeldungEntity.hrAnmeldungEntity.gruenders.getMetadata().getName())
				.exclude(QHrAnmeldungEntity.hrAnmeldungEntity.notarAnrede.getMetadata().getName())
				.exclude("selectedOwner");
				
				mapping(ProzessDto.class, ProzessEntity.class,
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true)
				).exclude(QProzessEntity.prozessEntity.organisation.getMetadata().getName());
				
				mapping(AhvTeilhaberDto.class, AhvTeilhaberEntity.class,
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(AHVServiceEndpoint.AHV_TEILHABER)
				)
				.exclude(QAhvTeilhaberEntity.ahvTeilhaberEntity.person.getMetadata().getName())
				.exclude(QAhvTeilhaberEntity.ahvTeilhaberEntity.partner.getMetadata().getName());	
				
				mapping(BerufEntity.class, BerufAdminDto.class, 
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(AdminServiceEndpoint.ADMIN_BERUF_ENT_DTO)
				)
				.fields("parent.id", "parentId")
				.fields("branche.id", "brancheId");
				
				mapping(BrancheEntity.class, BrancheAdminDto.class, 
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(AdminServiceEndpoint.ADMIN_BRANCHE_ENT_DTO)
					)
				.fields("parent.id", "parentId");
				
				mapping(ExternalProcessDeclarationDto.class, PflichtenabklaerungenEntity.class,
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(OrganisationServiceEndpoint.ORGANISATION_PFLICHTENABKLAERUNGEN)
				)
				.exclude(QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.anmeldungHR.getMetadata().getName());
				
				mapping(ProzessEntity.class, ActivityDto.class, 
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(PrivatePortalServiceEndpoint.ACTIVITY_DTO_DOZER_MAPPER_ID)
				)
				.fields("organisation.id", "orgId")
				.fields("organisation.hrStatus", "hrStatus")
				.fields("organisation.rechtsform", "rechtsform")
				.fields("typ", "processTyp")
				.fields("id", "processId");
				
				mapping(AhvAnmeldungDto.class, AhvAnmeldungEntity.class,
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(AHVServiceEndpoint.AHV_PROZESS)
				)
				.exclude(QAhvAnmeldungEntity.ahvAnmeldungEntity.prozess.getMetadata().getName());
				
				mapping(UvgAnmeldungDto.class, UvgAnmeldungEntity.class,
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(UvgServiceEndpoint.UVG_ANMELDUNG)
				)
				.exclude(QUvgAnmeldungEntity.uvgAnmeldungEntity.prozess.getMetadata().getName())
				.exclude(QUvgAnmeldungEntity.uvgAnmeldungEntity.gesellschafters.getMetadata().getName());
				
				mapping(HrMutationDto.class, HrMutationEntity.class,
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(HrMutationServiceEndpoint.HR_MUTATION_COMPLETE_PROZESS)
				)
				.exclude(QHrMutationEntity.hrMutationEntity.dissNewOwner.getMetadata().getName());
				
				mapping(HrMutationDto.class, HrMutationEntity.class,
						TypeMappingOptions.oneWay(),
						TypeMappingOptions.wildcard(true),
						TypeMappingOptions.mapId(HrMutationServiceEndpoint.HR_MUTATION_PROZESS)
					)
					.exclude(QHrMutationEntity.hrMutationEntity.oldDomicile.getMetadata().getName())
					.exclude(QHrMutationEntity.hrMutationEntity.newDomicile.getMetadata().getName())
					.exclude(QHrMutationEntity.hrMutationEntity.excerptsDeliveryAddress.getMetadata().getName())
					.exclude(QHrMutationEntity.hrMutationEntity.excerptsBillingAddress.getMetadata().getName())					
					.exclude(QHrMutationEntity.hrMutationEntity.persons.getMetadata().getName())
					.exclude(QHrMutationEntity.hrMutationEntity.dissNewOwner.getMetadata().getName());
				
				mapping(HrMutationPersonDto.class, HrMutationPersonEntity.class,
					TypeMappingOptions.oneWay(),
					TypeMappingOptions.wildcard(true),
					TypeMappingOptions.mapId(HrMutationServiceEndpoint.HR_MUTATION_PERSON_DTO_ENT)
				)
				.exclude(QHrMutationPersonEntity.hrMutationPersonEntity.newNaturalPerson.getMetadata().getName())
				.exclude(QHrMutationPersonEntity.hrMutationPersonEntity.existingNaturalPerson.getMetadata().getName())
				;

			}
		});
		return mapper;
	}
	
	@Bean
	public ObjectMapper objectMapper() {
		return new OSSCustomObjectMapper();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return builder.sources(BusinessServiceEndpointConfig.class);
	}
}
