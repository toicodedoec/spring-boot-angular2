package ch.admin.oss.portal.endpoint;

import java.util.ArrayList;
import java.util.List;

import ch.admin.oss.common.AbstractOSSDto;

public class AbstractGroupDto<T> extends AbstractOSSDto {

	private long parentId;

	private int pos;
	
	private List<T> children = new ArrayList<>();

	public long getParentId() {
		return parentId;
	}

	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public List<T> getChildren() {
		return children;
	}

	public void setChildren(List<T> childBranches) {
		this.children = childBranches;
	}

}
