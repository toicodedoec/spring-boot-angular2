/*
 * HRServiceEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.endpoint;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;
import com.querydsl.core.types.dsl.PathInits;

import ch.admin.oss.common.AbstractQuickwinProzessEndpoint;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.FlowHistoryDto;
import ch.admin.oss.common.GeschaftsrolleDto;
import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.OssTechnicalException;
import ch.admin.oss.common.PersonDto;
import ch.admin.oss.common.ProcessAccessStatus;
import ch.admin.oss.common.dto.AutoCompletePersonResultDto;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.HaftungEnum;
import ch.admin.oss.common.enums.HrMutationPersonTypeOfChangeEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonRoleEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrMutationEntity;
import ch.admin.oss.domain.HrMutationPersonEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.KommGesEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PersonHeimatortEntity;
import ch.admin.oss.domain.QHrMutationEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyDetailedInfoDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.DetailledResponseDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.IZefixServiceAdapter;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixBusinessException;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixInvalidUIDException;
import ch.admin.oss.hr.endpoint.HrAmtDto;
import ch.admin.oss.hrmutation.service.IHrMutationService;
import ch.admin.oss.organisation.endpoint.KommFirmaDto;
import ch.admin.oss.organisation.service.IOrganisationService;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OSSDateUtil;

/**
 * @author hhg
 */
@CrossOrigin
@RestController
@RequestMapping("/private/ext/hrmutation")
public class HrMutationServiceEndpoint extends AbstractQuickwinProzessEndpoint<HrMutationDto> {

	public static final String HR_MUTATION_PROZESS = "HR_MUTATION_PROZESS";
	public static final String HR_MUTATION_PERSON_DTO_ENT = "HR_MUTATION_PERSON_DTO_ENT";
	public static final String HR_MUTATION_GESCHAFSROLLE_ENT_ENT = "HR_MUTATION_GESCHAFSROLLE_ENT_ENT";
	public static final String HR_MUTATION_COMPLETE_PROZESS = "HR_MUTATION_COMPLETE_PROZESS";
	private static final QOrganisationEntity QORGANISATION = new QOrganisationEntity(
		QHrMutationEntity.hrMutationEntity.prozess.organisation.getMetadata(), PathInits.DIRECT);

	@Autowired
	private IHrMutationService hrMutationService;

	@Autowired
	private IZefixServiceAdapter zefixService;

	@Autowired
	private IOrganisationService organisationService;

	@Override
	public ResponseEntity<HrMutationDto> interruptProzess(@RequestBody HrMutationDto dto) {
		HrMutationEntity entity = mapToHrMutationEntity(dto);
		entity = hrMutationService.updateProcess(dto.getOrgId(), entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@GetMapping("/access/prozess/{orgId}")
	public ProcessAccessStatus canAccessProcess(@PathVariable long orgId) {
		OrganisationEntity organisation = organisationService.getOrganisation(orgId);
		if (organisation.getHrStatus() == HRStatusEnum.REGISTERED && organisation.getZefixImportDate() != null) {
			return ProcessAccessStatus.OK;
		}
		return ProcessAccessStatus.KO_HR_NOT_COMPLETED;
	}

	@GetMapping("new")
	public ResponseEntity<HrMutationDto> newProcess(@RequestParam Long orgId) {
		HrMutationEntity entity = hrMutationService.createProcess(orgId);
		HrMutationDto dto = mapToHrMutationDto(entity, entity.getProzess().getOrganisation(),
			entity.getProzess().getId());
		return ResponseEntity.ok(dto);
	}

	@Override
	public ResponseEntity<HrMutationDto> getProzess(Long prozessId, Long orgId) {
		OrganisationEntity org = getOrganisation(orgId);
		HrMutationEntity entity = hrMutationService.getHrMutationWithReferencedData(prozessId, orgId);
		HrMutationDto dto = mapToHrMutationDto(entity, org, prozessId);
		return ResponseEntity.ok(dto);
	}

	private OrganisationEntity getOrganisation(Long orgId) {
		OrganisationEntity organisation = organisationService.getOrganisation(orgId,
			QOrganisationEntity.organisationEntity.domizil, QOrganisationEntity.organisationEntity.namens);
		return organisation;
	}

	@Override
	public ResponseEntity<HrMutationDto> lockProzess(Long id, Integer version, Long orgId) {
		HrMutationEntity entity = hrMutationService.getHrMutation(id, version, orgId);
		entity = hrMutationService.lockProcess(orgId, entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@Override
	public ResponseEntity<HrMutationDto> relockProzess(Long id, Integer version, Long orgId) {
		HrMutationEntity entity = hrMutationService.getHrMutation(id, version, orgId);
		entity = hrMutationService.relockProcess(orgId, entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@Override
	public ResponseEntity<HrMutationDto> signProzess(Long id, Integer version, Long orgId) {
		HrMutationEntity entity = hrMutationService.getHrMutationWithReferencedData(id, orgId,
			QHrMutationEntity.hrMutationEntity.prozess.organisation, QORGANISATION.domizil, QORGANISATION.namens);
		updateDataBackToBase(entity, orgId);
		entity = hrMutationService.signProcess(orgId, entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	private void updateDataBackToBase(HrMutationEntity entity, Long orgId) {
		// name
		if (entity.isTaskName()) {
			entity.getProzess().getOrganisation().updateDefaultName(entity.getNewCompanyName());
		}
		// purpose
		if (entity.isTaskPurpose()) {
			entity.getProzess().getOrganisation().setZweck(entity.getNewPurpose());
		}
		// address
		if (entity.isTaskAddress()) {
			AdresseEntity baseDomizil = entity.getProzess().getOrganisation().getDomizil();
			baseDomizil.copyFrom(entity.getNewDomicile());
			entity.getProzess().getOrganisation().setDomizil(baseDomizil);
		}
		// person
		if (entity.isTaskPersons()) {
			for (HrMutationPersonEntity p : entity.getPersons()) {
				if (HrMutationTypeOfPersonEnum.NATURAL == p.getTypeOfPerson()) {
					switch (p.getTypeOfChange()) {
						case ADD:
						case UPDATE:
							if (p.getExistingNaturalPerson() != null) {
								GeschaftsrolleEntity fullExistingNaturalPerson = hrMutationService
									.loadFullGeschaftsrolleById(orgId, p.getExistingNaturalPerson().getId(),
										p.getExistingNaturalPerson().getVersion());
																
								GeschaftsrolleEntity fullNewNaturalPerson = hrMutationService
									.loadFullGeschaftsrolleById(orgId, p.getNewNaturalPerson().getId(),
										p.getNewNaturalPerson().getVersion());

								fullExistingNaturalPerson.copyFrom(fullNewNaturalPerson);
								
								p.setExistingNaturalPerson(fullExistingNaturalPerson);
							} else {
								p.getNewNaturalPerson().setOrganisation(entity.getProzess().getOrganisation());
							}
							break;
						case DELETE:
							if (p.getExistingNaturalPerson() != null) {
								p.getExistingNaturalPerson().setDelete(true);
							}
							break;
						default:
							throw new OssTechnicalException(
								"Unknown HrMutationPersonTypeOfChangeEnum: " + p.getTypeOfChange());
					}
				} else if (HrMutationTypeOfPersonEnum.LEGAL == p.getTypeOfPerson()) {
					switch (p.getTypeOfChange()) {
						case ADD:
						case UPDATE:
							if (p.getExistingLegalPeson() != null) {
								KommFirmaEntity fullExistingLegalPerson = hrMutationService.getKommfirmaById(
									p.getExistingLegalPeson().getId(), p.getExistingLegalPeson().getVersion());
								KommFirmaEntity fullNewLegalPerson = hrMutationService.getKommfirmaById(
									p.getNewLegalPerson().getId(), p.getNewLegalPerson().getVersion());
								fullExistingLegalPerson.copyFrom(fullNewLegalPerson);
								p.setExistingLegalPeson(fullExistingLegalPerson);
							} else {
								p.getNewLegalPerson().setKommges(hrMutationService.loadKommgesByOrgId(orgId));
							}
							break;
						case DELETE:
							if (p.getExistingLegalPeson() != null) {
								p.getExistingLegalPeson().setDelete(true);
							}
							break;
					}
				}
			}
		}
	}

	@PutMapping("updateOldCompanyData")
	public ResponseEntity<HrMutationDto> updateOldCompanyData(@RequestBody HrMutationOldCompanyDataUpdateDto dto) {
		HrMutationEntity entity = hrMutationService.getHrMutation(dto.getHrMutationId(), dto.getHrMutationVersion(),
			dto.getOrgId(), QHrMutationEntity.hrMutationEntity.oldDomicile.land);

		entity.setOldDomicile(mapper.map(dto.getDataUpdate().getDomizil(), AdresseEntity.class));
		entity.getOldDomicile().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
		;
		entity.setOldCompanyName(dto.getDataUpdate().getCompanyName());
		entity.setOldPurpose(dto.getDataUpdate().getCompanyPurpose());
		if (dto.isZefixUpdate()) {
			entity.setZefixUpdateDate(LocalDateTime.now());
		} else {
			entity.setZefixUpdateDate(null);
		}
		entity = hrMutationService.updateProcess(dto.getOrgId(), entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@PutMapping("deliveryAddress")
	public ResponseEntity<HrMutationDto> updateDeliveryAddress(@RequestBody HrMutationAddressUpdateDto dto) {
		HrMutationEntity entity = hrMutationService.getHrMutation(dto.getHrMutationId(), dto.getHrMutationVersion(),
			dto.getOrgId());
		entity.setExcerptsDeliveryAddress(mapper.map(dto.getAddress(), AdresseEntity.class));
		return ResponseEntity
			.ok(mapper.map(hrMutationService.updateProcess(dto.getOrgId(), entity), HrMutationDto.class));
	}

	@PutMapping("billingAddress")
	public ResponseEntity<HrMutationDto> updateBillingAddress(@RequestBody HrMutationAddressUpdateDto dto) {
		HrMutationEntity entity = hrMutationService.getHrMutation(dto.getHrMutationId(), dto.getHrMutationVersion(),
			dto.getOrgId());
		entity.setExcerptsBillingAddress(mapper.map(dto.getAddress(), AdresseEntity.class));
		return ResponseEntity
			.ok(mapper.map(hrMutationService.updateProcess(dto.getOrgId(), entity), HrMutationDto.class));
	}

	@PutMapping("domicile")
	public ResponseEntity<HrMutationDto> updateDomicile(@RequestBody HrMutationAddressUpdateDto dto) {
		HrMutationEntity entity = hrMutationService.getHrMutation(dto.getHrMutationId(), dto.getHrMutationVersion(),
			dto.getOrgId());
		entity.setNewDomicile(mapper.map(dto.getAddress(), AdresseEntity.class));
		// SECOOSS-610: The field LN_LAND of table T_ADRESSE should be SWISS address in this case
		entity.getNewDomicile().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
		entity = hrMutationService.updateProcess(dto.getOrgId(), entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@GetMapping("existingAddresses")
	public ResponseEntity<List<AdresseDto>> getListExistingAddresses(@RequestParam Long orgId) {
		if (orgId == null) {
			return null;
		}
		List<AdresseDto> result = new ArrayList<>();
		List<AdresseEntity> listExistingAdresse = hrMutationService.getListExistingAdresse(orgId);
		listExistingAdresse.stream().forEach(adresse -> {
			result.add(mapper.map(adresse, AdresseDto.class));
		});
		return ResponseEntity.ok(result);
	}

	@GetMapping("zefixCompare")
	public ResponseEntity<HrMutationZefixCompareDto> getHrMutationZefixCompare(@RequestParam Long orgId) throws ZefixInvalidUIDException, ZefixBusinessException {
		if (orgId == null) {
			return null;
		}

		OrganisationEntity org = organisationService.getOrganisation(orgId,
			QOrganisationEntity.organisationEntity.namens, QOrganisationEntity.organisationEntity.domizil,
			QOrganisationEntity.organisationEntity.domizil.land);
		// search organization detail from ZEFIX to compare with the existing one in EasyGov
		DetailledResponseDto zefixDetail = zefixService.getCompanyDetailByUid(Integer.parseInt(org.getUid()),
			org.getRechtsform());
		HrMutationOrgInfoDto orgInfoInZefix = mapToHrMutationOrgInfoDto(zefixDetail);
		HrMutationOrgInfoDto orgInfoInEasygov = mapToHrMutationOrgInfoDto(org);
		return ResponseEntity.ok(new HrMutationZefixCompareDto(orgInfoInEasygov, orgInfoInZefix));
	}

	@DeleteMapping("deleteExcerptsAddress")
	public ResponseEntity<?> deleteExcerptsAddresse(@RequestParam Long orgId, @RequestParam Long mutationId,
		@RequestParam Integer mutationVersion) {
		if (orgId == null || mutationId == null || mutationVersion == null) {
			return null;
		}
		HrMutationEntity entity = hrMutationService.deleteExcerptsAdresse(orgId, mutationId, mutationVersion);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@DeleteMapping("deleteMutationPerson")
	public ResponseEntity<?> deleteMutationPerson(@RequestParam Long orgId, @RequestParam Long personId,
		@RequestParam Integer personVersion, @RequestParam Long id, @RequestParam Integer version) {
		if (orgId == null || personId == null || personVersion == null || id == null || version == null) {
			return null;
		}
		HrMutationEntity entity = hrMutationService.deleteMutationPerson(orgId, id, version, personId, personVersion);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	private HrMutationOrgInfoDto mapToHrMutationOrgInfoDto(DetailledResponseDto detailResponse) {
		CompanyDetailedInfoDto zefixData = detailResponse.getCompanyDetailedInfo().iterator().next();
		HrMutationOrgInfoDto zefix = new HrMutationOrgInfoDto();
		zefix.setCompanyName(zefixData.getName());
		zefix.setCompanyPurpose(zefixData.getPurpose());
		zefix.setLegalSeat(zefixData.getLegalSeat());
		zefix.setUid(zefixData.getUidFormatted());
		AdresseDto domizil = new AdresseDto();
		domizil.setPolGemeinde(zefixData.getLegalSeat());
		domizil.setBfsNr(zefixData.getLegalSeatId());
		if (zefixData.getAddress() != null) {
			domizil.setStrasse(zefixData.getAddress().getStreet());
			domizil.setHausnummer(zefixData.getAddress().getHouseNumber());
			domizil.setOrt(zefixData.getAddress().getTown());
			if (zefixData.getAddress().getSwissZipCode() != null) {
				domizil.setPlz(zefixData.getAddress().getSwissZipCode().toString());
			}
		}
		zefix.setDomizil(domizil);
		return zefix;
	}

	private HrMutationOrgInfoDto mapToHrMutationOrgInfoDto(OrganisationEntity organisation) {
		HrMutationOrgInfoDto easygov = new HrMutationOrgInfoDto();
		easygov.setCompanyName(organisation.defaultName());
		easygov.setCompanyPurpose(organisation.getZweck());
		easygov.setLegalSeat(organisation.getDomizil().getPolGemeinde());
		easygov.setUid(OssNumberFormatUtil.formatUid(organisation.getUid()));
		easygov.setDomizil(mapper.map(organisation.getDomizil(), AdresseDto.class));
		return easygov;
	}

	@Override
	public ResponseEntity<HrMutationDto> updateProzess(@RequestBody HrMutationDto dto) {
		HrMutationEntity entity = mapToHrMutationEntity(dto);
		entity = hrMutationService.updateProcess(dto.getOrgId(), entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@PutMapping("updateTaskProzess")
	public ResponseEntity<HrMutationDto> updateTaskProzess(@RequestBody HrMutationDto dto) {
		HrMutationEntity entity = hrMutationService.getHrMutation(dto.getId(), dto.getVersion(), dto.getOrgId(),
			QHrMutationEntity.hrMutationEntity.persons, QHrMutationEntity.hrMutationEntity.newDomicile,
			QHrMutationEntity.hrMutationEntity.dissNewOwner, QHrMutationEntity.hrMutationEntity.excerptsBillingAddress,
			QHrMutationEntity.hrMutationEntity.excerptsDeliveryAddress);
		mapper.map(dto, entity, HR_MUTATION_PROZESS);
		entity = hrMutationService.updateTaskProzess(dto.getOrgId(), entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	public ResponseEntity<HrMutationDto> completeProzess(@RequestBody HrMutationDto dto) {
		// Load orgnisation to get rechtsform for validation purpose
		HrMutationEntity entity = hrMutationService.getHrMutationWithReferencedData(dto.getProzessId(), dto.getOrgId(),
			QHrMutationEntity.hrMutationEntity.prozess.organisation);
		//TODO S9 HOT Fix : no destination hint of dozermapping for HrMutationEntity#dissNewOwner#person#heimatortes
		mapper.map(dto, entity, HR_MUTATION_COMPLETE_PROZESS);

		// --->HOT<---Fix for special case:
		// 1. Create new HrMutation process
		// 2. Choose task update address.
		// 3. Update old company data. response not return land.
		// 4. Go to review page. document generate
		if (entity.getOldDomicile().getLand() == null) {
			entity.getOldDomicile().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
		}

		// Handle for case: HrMutationDomicile -> HrMutationReview. submit new Address.
		// By default set land of domicile is swiss
		// And cover the case the same with OldDomicile.
		if (entity.getNewDomicile() != null && entity.getNewDomicile().getLand() == null) {
			entity.getNewDomicile().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
		}

		// Cover newLegalPerson in CH.
		entity.getPersons().stream().forEach(person -> {
			if (person.getNewLegalPerson() != null && person.getNewLegalPerson().getRechtsformCH() != null) {
				person.getNewLegalPerson().getDomizil()
					.setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
			}
		});

		entity = hrMutationService.completeProcess(dto.getOrgId(), entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@RequestMapping(value = "/document", method = RequestMethod.GET)
	public ResponseEntity<?> downloadPdf(@RequestParam long orgId, @RequestParam long prozessId) {
		return download(hrMutationService.downloadDocument(orgId, prozessId));
	}

	private HrMutationEntity mapToHrMutationEntity(HrMutationDto dto) {
		HrMutationEntity entity = hrMutationService.getHrMutation(dto.getId(), dto.getVersion(), dto.getOrgId(),
			QHrMutationEntity.hrMutationEntity.persons);
		mapper.map(dto, entity, HR_MUTATION_PROZESS);
		return entity;
	}

	@RequestMapping(value = "persons", method = RequestMethod.GET)
	public List<AutoCompletePersonResultDto> searchPersons(@RequestParam Long orgId,
		@RequestParam String personRoleTypes, @RequestParam(required=false) String selectedExistingPersonIds,
		@RequestParam String criterion) {
		List<HrMutationTypeOfPersonRoleEnum> personTypes = Stream.of(StringUtils.split(personRoleTypes, ","))
			.map(type -> HrMutationTypeOfPersonRoleEnum.values()[Integer.valueOf(type)]).collect(Collectors.toList());
		
		final List<Long> selectedIds = Lists.newArrayList();
		if (StringUtils.isNotBlank(selectedExistingPersonIds)) {
			selectedIds.addAll(Stream.of(StringUtils.split(selectedExistingPersonIds, ",")).mapToLong(Long::parseLong)
				.boxed().collect(Collectors.toList()));
		}

		List<AutoCompletePersonResultDto> persons = hrMutationService.searchPersons(orgId, criterion, personTypes);
		
		// filter to remove the existing persons that are selected
		persons = persons.stream().filter(p -> !selectedIds.contains(p.getId())).collect(Collectors.toList());
		
		// last item for add new person button
		persons.add(new AutoCompletePersonResultDto(-1L, 0,
			applicationService.getTranslation("gui_labels.hrMutationUbersicht.addNewPerson",
				SecurityUtil.currentUser().getLanguagePreference()),
			"", "", "", "", null));

		return persons;
	}

	private HrMutationDto mapToHrMutationDto(HrMutationEntity entity, OrganisationEntity org, Long prozessId) {
		HrMutationDto dto = new HrMutationDto(prozessId, org.getId(), org.getRechtsform());
		mapper.map(entity, dto);
		if (dto.getOldCompanyName() == null) {
			dto.setOldCompanyName(org.defaultName());
		}
		dto.setFlowHistory(mapper.map(entity.getProzess().getFlowHistory(), FlowHistoryDto.class));

		Set<HrMutationPersonDto> persons = dto.getPersons();
		for (HrMutationPersonDto person : persons) {
			if (person.getNewNaturalPerson() != null) {
				if (person.getNewNaturalPerson().getTyp() == GeschaeftsrolleTypEnum.EDC) {
					person.setTypeOfPersonRole(HrMutationTypeOfPersonRoleEnum.OWNER);
				} else {
					person.setTypeOfPersonRole(HrMutationTypeOfPersonRoleEnum.SIGNATORY);
				}
			} else if (person.getNewLegalPerson() != null) {
				person.setTypeOfPersonRole(HrMutationTypeOfPersonRoleEnum.LEGAL);
			}
		}

		dto.setStatus(entity.getProzess().getStatus());

		return dto;
	}

	@PutMapping("dissolutionNewOwnerMapping")
	public ResponseEntity<?> dissolutionNewOwnerMapping(@RequestBody HrMutationDissolutionMappingDto dto) {
		GeschaftsrolleEntity dissNewOwner = new GeschaftsrolleEntity();
		dissNewOwner.setPerson(new PersonEntity());
		dissNewOwner.getPerson().setWohnadresse(new AdresseEntity());
		if (dto.getMappingOwner().getId() != null) {
			GeschaftsrolleEntity mappingOwner = hrMutationService.loadFullGeschaftsrolleById(dto.getOrgId(),
				dto.getMappingOwner().getId(), dto.getMappingOwner().getVersion());
			dissNewOwner = cloneGeschaftrolleEntity(mappingOwner);
		} else {
			dissNewOwner.setTyp(GeschaeftsrolleTypEnum.EDC);
			dissNewOwner.setHaftung(applicationService.getCodeWerts(KategorieEnum.HAFTUNG)
				.stream().filter(c -> HaftungEnum.UNBESCHRAENKT.getCode().equals(c.getCode())).findFirst().get());
		}
		HrMutationEntity entity = hrMutationService.refreshDissNewOwner(dto.getHrMutationId(), dto.getHrMutationVersion(),
			dto.getOrgId(), dissNewOwner);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@RequestMapping(value = "/deleteDissolutionNewOwner", method = RequestMethod.DELETE)
	public ResponseEntity<?> deleteDissolutionNewOwner(@RequestParam Long orgId, @RequestParam Long id,
		@RequestParam Integer version) {
		if (orgId == null || id == null || version == null) {
			return null;
		}
		HrMutationEntity entity = hrMutationService.refreshDissNewOwner(id, version, orgId, null);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	private GeschaftsrolleEntity cloneGeschaftrolleEntity(GeschaftsrolleEntity source) {
		GeschaftsrolleEntity dest = null;
		try {
			dest = (GeschaftsrolleEntity) BeanUtils.cloneBean(source);
		} catch (IllegalAccessException | InstantiationException | InvocationTargetException
			| NoSuchMethodException e) {
			throw new OssTechnicalException("A technical error occurred while cloning bean", e);
		}

		// keep id and version
		dest.setId(null);
		dest.setVersion(0);
		dest.setOrganisation(null);
		dest.getPerson().setId(null);
		dest.getPerson().setVersion(0);
		dest.getPerson().getWohnadresse().setId(null);
		dest.getPerson().getWohnadresse().setVersion(0);
		dest.getPerson().setTeilhaber(null);

		// Copy nationalitaetens
		Set<CodeWertEntity> nationalitaetens = dest.getPerson().getNationalitaetens();
		Set<CodeWertEntity> newNationalitaetens = new HashSet<>();
		dest.getPerson().setNationalitaetens(newNationalitaetens);
		newNationalitaetens.addAll(nationalitaetens);

		// Copy heimatortes
		Set<PersonHeimatortEntity> heimatortes = dest.getPerson().getHeimatortes();
		for (PersonHeimatortEntity heimatort : heimatortes) {
			heimatort.setId(null);
			heimatort.setVersion(0);
		}
		HashSet<PersonHeimatortEntity> newHeimatortes = new HashSet<>();
		dest.getPerson().setHeimatortes(newHeimatortes);
		newHeimatortes.addAll(heimatortes);
		return dest;
	}

	@PutMapping("mutationPerson")
	public HrMutationPersonDto createNewMutationPerson(@RequestBody HrMutationPersonChangeDto dto) {
		HrMutationPersonDto personDto = dto.getMutationPerson();
		HrMutationEntity hrMutation = hrMutationService.getHrMutation(dto.getHrMutationId(), dto.getHrMutationVersion(),
			dto.getOrgId());
		HrMutationPersonEntity hrMutationPerson = new HrMutationPersonEntity();
		hrMutationPerson.setHrMutation(hrMutation);
		hrMutationPerson.setTypeOfChange(personDto.getTypeOfChange());
		hrMutationPerson.setTypeOfPerson(personDto.getTypeOfPerson());
		if (personDto.getTypeOfChange() == HrMutationPersonTypeOfChangeEnum.DELETE) {
			initializeHrMutationPersonToDelete(dto.getOrgId(), personDto, hrMutationPerson);
		} else {
			initializeHrMutationPersonToAddOrModify(dto.getOrgId(), personDto, hrMutationPerson);
		}

		if (hrMutationPerson.getTypeOfPerson() == null) {
			hrMutationPerson.setTypeOfPerson(HrMutationTypeOfPersonEnum.NATURAL);
		}

		HrMutationPersonEntity saveHrMutationPerson = hrMutationService.saveHrMutationPerson(dto.getOrgId(),
			hrMutationPerson);
		return mapper.map(saveHrMutationPerson, HrMutationPersonDto.class);
	}

	private void initializeHrMutationPersonToAddOrModify(long orgId, HrMutationPersonDto personDto,
		HrMutationPersonEntity hrMutationPerson) {
		GeschaftsrolleDto existingNaturalPersonDto = personDto.getExistingNaturalPerson();

		KommFirmaDto existingLegalPesonDto = personDto.getExistingLegalPeson();

		if (hrMutationPerson.getTypeOfPerson() == null) {
			initializeNewNaturalPerson(orgId, personDto, hrMutationPerson, existingNaturalPersonDto);
			initializeNewLegalPerson(orgId, hrMutationPerson, existingLegalPesonDto);
		} else {
			if (hrMutationPerson.getTypeOfPerson() == HrMutationTypeOfPersonEnum.LEGAL) {
				initializeNewLegalPerson(orgId, hrMutationPerson, existingLegalPesonDto);
			} else {
				initializeNewNaturalPerson(orgId, personDto, hrMutationPerson, existingNaturalPersonDto);
			}
		}
	}

	private void initializeNewLegalPerson(long orgId, HrMutationPersonEntity hrMutationPerson,
		KommFirmaDto existingLegalPesonDto) {
		KommGesEntity kommges = null;
		if (existingLegalPesonDto == null) {
			kommges = hrMutationService.saveKommGes(new KommGesEntity());
			KommFirmaEntity newLegalPerson = new KommFirmaEntity();
			newLegalPerson.setKommges(kommges);
			newLegalPerson.setComplete(false);
			hrMutationPerson.setNewLegalPerson(newLegalPerson);
		} else {
			KommFirmaEntity existingLegalPerson = hrMutationService.getKommfirmaById(existingLegalPesonDto.getId(),
				existingLegalPesonDto.getVersion());
			hrMutationPerson.setExistingLegalPeson(existingLegalPerson);
			hrMutationPerson.setPrevCompanyName(existingLegalPerson.getName());
			if (existingLegalPerson.getRechtsformCH() == null) {
				hrMutationPerson.setPrevLegalForm(existingLegalPerson.getRechtsformAusland());
			} else {
				hrMutationPerson
					.setPrevLegalForm(applicationService.getTranslation(existingLegalPerson.getRechtsformCH()));
			}
			hrMutationPerson.setPrevCity(existingLegalPerson.getDomizil().getOrt());
			KommFirmaEntity newLegalPerson = mapper.map(existingLegalPerson, KommFirmaEntity.class);
			newLegalPerson.setId(null);
			newLegalPerson.setVersion(0);
			kommges = mapper.map(existingLegalPerson.getKommges(), KommGesEntity.class);
			kommges.setId(null);
			kommges.setVersion(0);
			kommges.setOrganisation(null);
			kommges = hrMutationService.saveKommGes(kommges);
			newLegalPerson.setKommges(kommges);
			newLegalPerson.getDomizil().setId(null);
			newLegalPerson.getDomizil().setVersion(0);
			newLegalPerson.setComplete(false);
			hrMutationPerson.setNewLegalPerson(newLegalPerson);
		}
	}

	private void initializeNewNaturalPerson(long orgId, HrMutationPersonDto personDto,
		HrMutationPersonEntity hrMutationPerson, GeschaftsrolleDto existingNaturalPersonDto) {
		if (existingNaturalPersonDto == null) {
			GeschaftsrolleEntity newNatualPerson = new GeschaftsrolleEntity();
			newNatualPerson.setPerson(new PersonEntity());
			newNatualPerson.setTyp(GeschaeftsrolleTypEnum.EDC);
			if (personDto.getTypeOfPersonRole() == HrMutationTypeOfPersonRoleEnum.SIGNATORY) {
				newNatualPerson.setTyp(GeschaeftsrolleTypEnum.SIGNATORY);
			}
			newNatualPerson.setHaftung(applicationService.getCodeWerts(KategorieEnum.HAFTUNG)
				.stream().filter(c -> HaftungEnum.UNBESCHRAENKT.getCode().equals(c.getCode())).findFirst().get());
			hrMutationPerson.setNewNaturalPerson(newNatualPerson);
		} else {
			GeschaftsrolleEntity existingNaturalPerson = hrMutationService.loadFullGeschaftsrolleById(orgId,
				existingNaturalPersonDto.getId(), existingNaturalPersonDto.getVersion());
			hrMutationPerson.setExistingNaturalPerson(existingNaturalPerson);
			hrMutationPerson.setPrevFamilyName(existingNaturalPerson.getPerson().getFamilienname());
			hrMutationPerson.setPrevGivenName(existingNaturalPerson.getPerson().getVorname());
			hrMutationPerson.setPrevBirthday(existingNaturalPerson.getPerson().getGeburtsdatum());
			GeschaftsrolleEntity newNatualPerson = cloneGeschaftrolleEntity(existingNaturalPerson);

			hrMutationPerson.setNewNaturalPerson(newNatualPerson);
		}
	}

	private void initializeHrMutationPersonToDelete(long orgId, HrMutationPersonDto personDto,
		HrMutationPersonEntity hrMutationPerson) {
		GeschaftsrolleDto existingNaturalPersonDto = personDto.getExistingNaturalPerson();

		KommFirmaDto existingLegalPesonDto = personDto.getExistingLegalPeson();

		if (hrMutationPerson.getTypeOfPerson() == null) {
			initializeDeletionNaturalPerson(orgId, hrMutationPerson, existingNaturalPersonDto);
			initializeDeletionLegalPerson(orgId, hrMutationPerson, existingLegalPesonDto);
		} else {
			if (hrMutationPerson.getTypeOfPerson() == HrMutationTypeOfPersonEnum.LEGAL) {
				initializeDeletionLegalPerson(orgId, hrMutationPerson, existingLegalPesonDto);
			} else {
				initializeDeletionNaturalPerson(orgId, hrMutationPerson, existingNaturalPersonDto);
			}
		}
	}

	private void initializeDeletionLegalPerson(long orgId, HrMutationPersonEntity hrMutationPerson,
		KommFirmaDto existingLegalPesonDto) {
		if (existingLegalPesonDto != null) {
			KommFirmaEntity existingLegalPeson = hrMutationService.getKommfirmaById(existingLegalPesonDto.getId(),
				existingLegalPesonDto.getVersion());
			hrMutationPerson.setExistingLegalPeson(existingLegalPeson);
			hrMutationPerson.setPrevCompanyName(existingLegalPeson.getName());
			if (existingLegalPeson.getRechtsformCH() == null) {
				hrMutationPerson.setPrevLegalForm(existingLegalPeson.getRechtsformAusland());
			} else {
				hrMutationPerson
					.setPrevLegalForm(applicationService.getTranslation(existingLegalPeson.getRechtsformCH()));
			}
			hrMutationPerson.setPrevCity(existingLegalPeson.getDomizil().getOrt());
		}
	}

	private void initializeDeletionNaturalPerson(long orgId, HrMutationPersonEntity hrMutationPerson,
		GeschaftsrolleDto existingNaturalPersonDto) {
		if (existingNaturalPersonDto != null) {
			GeschaftsrolleEntity existingNaturalPerson = hrMutationService.loadFullGeschaftsrolleById(orgId,
				existingNaturalPersonDto.getId(), existingNaturalPersonDto.getVersion());
			hrMutationPerson.setExistingNaturalPerson(existingNaturalPerson);
			hrMutationPerson.setPrevFamilyName(existingNaturalPerson.getPerson().getFamilienname());
			hrMutationPerson.setPrevGivenName(existingNaturalPerson.getPerson().getVorname());
			hrMutationPerson.setPrevBirthday(existingNaturalPerson.getPerson().getGeburtsdatum());
		}
	}

	@PutMapping("mutationPersonDeletion")
	public ResponseEntity<?> updateDeletionPerson(@RequestBody HrMutationPersonDeletionDto dto) {
		HrMutationEntity entity = hrMutationService.getHrMutation(dto.getHrMutationId(), dto.getHrMutationVersion(),
			dto.getOrgId(), QHrMutationEntity.hrMutationEntity.persons);
		Optional<HrMutationPersonEntity> optional = entity.getPersons().stream()
			.filter(p -> p.getId().equals(dto.getPersonId()) && p.getVersion() == dto.getPersonVersion()).findFirst();
		if (!optional.isPresent()) {
			throw new OptimisticLockingFailureException(
				"This entity has been modified by other user. HrMutationPersonEntity#id = " + dto.getPersonId());
		}
		mapper.map(dto, optional.get());
		entity = hrMutationService.updateProcess(dto.getOrgId(), entity);
		return ResponseEntity.ok(mapper.map(entity, HrMutationDto.class));
	}

	@PutMapping("mutationLegalPerson")
	public ResponseEntity<HrMutationPersonDto> updateLegalPerson(@RequestBody HrMutationPersonDto dto) {
		KommFirmaEntity kommFirma = hrMutationService.getKommfirmaById(dto.getNewLegalPerson().getId(),
			dto.getNewLegalPerson().getVersion());
		mapper.map(dto.getNewLegalPerson(), kommFirma);
		// Legal person in CH.
		if (kommFirma.getRechtsformCH() != null && kommFirma.getDomizil() != null) {
			kommFirma.getDomizil().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
		}

		HrMutationPersonEntity mutationPersonEnt = hrMutationService
			.getHrMutationPerson(dto.getNewLegalPerson().getOrgId(), dto.getId(), dto.getVersion());
		if (mutationPersonEnt == null) {
			throw new OptimisticLockingFailureException(
				"This entity has been modified by other user. HrMutationPersonEntity#id = " + dto.getId());
		}
		mutationPersonEnt.setPrevCompanyName(dto.getPrevCompanyName());
		mutationPersonEnt.setPrevCity(dto.getPrevCity());
		mutationPersonEnt.setPrevLegalForm(dto.getPrevLegalForm());
		mutationPersonEnt.setTypeOfPerson(dto.getTypeOfPerson());
		mutationPersonEnt.setNewLegalPerson(kommFirma);

		if (mutationPersonEnt.getNewNaturalPerson() != null) {
			dto = mapper.map(hrMutationService.saveMutationLegalPersonAndDeleteNaturalPerson(
				dto.getNewLegalPerson().getOrgId(), mutationPersonEnt), HrMutationPersonDto.class);
		} else {
			dto = mapper.map(
				hrMutationService.saveHrMutationPerson(dto.getNewLegalPerson().getOrgId(), mutationPersonEnt),
				HrMutationPersonDto.class);
		}
		return ResponseEntity.ok(dto);
	}

	@PutMapping("mutationNaturalPerson")
	public HrMutationPersonDto updateNaturalPerson(@RequestBody HrMutationPersonDto dto) {
		GeschaftsrolleEntity geschaftsrolle = mapToGeschaftsrolleEntity(dto.getNewNaturalPerson().getOrgId(),
			dto.getNewNaturalPerson());

		if (dto.getId() == null) {
			dto.setNewNaturalPerson(
				mapper.map(hrMutationService.saveGeschaftsrolle(geschaftsrolle), GeschaftsrolleDto.class));
		} else {
			HrMutationPersonEntity mutationPersonEnt = hrMutationService
				.getHrMutationPerson(dto.getNewNaturalPerson().getOrgId(), dto.getId(), dto.getVersion());
			if (mutationPersonEnt == null) {
				throw new OptimisticLockingFailureException(
					"This entity has been modified by other user. HrMutationPersonEntity#id = " + dto.getId());
			}
			mutationPersonEnt.setPrevBirthday(OSSDateUtil.toLocalDate(dto.getPrevBirthday()));
			mutationPersonEnt.setPrevFamilyName(dto.getPrevFamilyName());
			mutationPersonEnt.setPrevGivenName(dto.getPrevGivenName());
			mutationPersonEnt.setNewNaturalPerson(geschaftsrolle);

			if (mutationPersonEnt.getNewLegalPerson() != null) {
				dto = mapper.map(hrMutationService.saveMutationNaturalPersonAndDeleteLegalPerson(
					dto.getNewNaturalPerson().getOrgId(), mutationPersonEnt), HrMutationPersonDto.class);
			} else {
				dto = mapper.map(
					hrMutationService.saveHrMutationPerson(dto.getNewNaturalPerson().getOrgId(), mutationPersonEnt),
					HrMutationPersonDto.class);
			}
		}

		return dto;
	}

	private GeschaftsrolleEntity mapToGeschaftsrolleEntity(Long orgId, GeschaftsrolleDto geschaftsrolleDto) {
		GeschaftsrolleEntity geschaftsrolle = hrMutationService.loadGeschaftsrolleById(orgId, geschaftsrolleDto.getId(),
			geschaftsrolleDto.getVersion());
		geschaftsrolle.getPerson().getHeimatortes().clear();
		geschaftsrolle.setComplete(geschaftsrolleDto.isComplete());
		/*
		 * update person general info
		 */
		PersonDto personDto = geschaftsrolleDto.getPerson();
		mapper.map(personDto, geschaftsrolle.getPerson());

		// update person address
		if (personDto.getWohnadresse().getLand() != null && personDto.getWohnadresse().getLand().getCode() != null) {
			CodeWertEntity land = getCodeWert(KategorieEnum.LAND, personDto.getWohnadresse().getLand().getCode());
			geschaftsrolle.getPerson().getWohnadresse().setLand(land);
		}

		// update person place of births
		if (CollectionUtils.isNotEmpty(personDto.getHeimatortes())) {
			for (PersonHeimatortEntity personHeimatort : geschaftsrolle.getPerson().getHeimatortes()) {
				personHeimatort.setPerson(geschaftsrolle.getPerson());
			}
		}

		geschaftsrolle.getPerson().getNationalitaetens().clear();
		if (CollectionUtils.isNotEmpty(personDto.getNationalitaetens())) {
			List<String> codes = personDto.getNationalitaetens().stream().map(n -> n.getCode())
				.collect(Collectors.toList());
			geschaftsrolle.getPerson().getNationalitaetens().addAll(getCodeWerts(KategorieEnum.LAND, codes));
		}

		if (geschaftsrolleDto.getTyp() != geschaftsrolle.getTyp()) {
			geschaftsrolle.setTyp(geschaftsrolleDto.getTyp());
		}
		// update codewerts
		if (geschaftsrolleDto.getFunktion() != null) {
			geschaftsrolle.setFunktion(getCodeWert(KategorieEnum.FUNKTION, geschaftsrolleDto.getFunktion().getCode()));
		}

		if (geschaftsrolleDto.getZeichnung() != null) {
			geschaftsrolle
				.setZeichnung(getCodeWert(KategorieEnum.ZEICHNUNG, geschaftsrolleDto.getZeichnung().getCode()));
		}

		geschaftsrolle.setNurHauptsitz(geschaftsrolleDto.isNurHauptsitz());

		if (geschaftsrolleDto.getHaftung() != null) {
			geschaftsrolle.setHaftung(getCodeWert(KategorieEnum.HAFTUNG, geschaftsrolleDto.getHaftung().getCode()));
		}

		geschaftsrolle.setHaftungCHF(geschaftsrolleDto.getHaftungCHF());

		if (geschaftsrolleDto.getEinlage() != null && geschaftsrolleDto.getEinlage().getCode() != null) {
			geschaftsrolle.setEinlage(getCodeWert(KategorieEnum.EINLAGE, geschaftsrolleDto.getEinlage().getCode()));
		} else {
			geschaftsrolle.setEinlage(null);
		}

		if (personDto.getAuslaenderAusweis() != null) {
			geschaftsrolle.getPerson().setAuslaenderAusweis(
				getCodeWert(KategorieEnum.AUSLAUSWEIS, personDto.getAuslaenderAusweis().getCode()));
		} else {
			geschaftsrolle.getPerson().setAuslaenderAusweis(null);
		}

		return geschaftsrolle;
	}

	@GetMapping("amtAddressInfo")
	public HrAmtDto getAmtAddressInfo(@RequestParam int bfsnr) {
		return mapper.map(applicationService.getHrAmtByDomizilBfsnr(bfsnr), HrAmtDto.class);
	}
}
