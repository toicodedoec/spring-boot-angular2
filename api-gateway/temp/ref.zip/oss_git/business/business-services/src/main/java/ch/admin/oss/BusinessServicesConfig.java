/*
 * BusinessServicesConfig
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss;

import java.util.Arrays;
import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.transaction.TransactionAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import ch.admin.oss.admin.repository.IFunktionRecheRepository;
import ch.admin.oss.ahv.repository.IAhvAnmeldungRepository;
import ch.admin.oss.application.repository.IFlowHistoryRepository;
import ch.admin.oss.application.service.impl.CacheService;
import ch.admin.oss.domain.AbstractOSSEntity;
import ch.admin.oss.hr.repository.IHrAnmeldungRepository;
import ch.admin.oss.hrmutation.repository.IHrMutationRepository;
import ch.admin.oss.landing.repository.INewsletterHitsRepository;
import ch.admin.oss.mwst.repository.IMwstAnmeldungRepository;
import ch.admin.oss.organisation.repository.IOrganisationRepository;
import ch.admin.oss.portal.repository.IUserRepository;
import ch.admin.oss.uvg.repository.IUvgAnmeldungRepository;

/**
 * Spring configuration for module "business-service".
 * 
 * @author phd
 */
@Configuration
@ComponentScan(basePackageClasses = BusinessServicesConfig.class)
@EnableJpaRepositories(basePackageClasses = {
	IOrganisationRepository.class,
	IUserRepository.class,
	IFunktionRecheRepository.class,
	IFunktionRecheRepository.class,
	IHrAnmeldungRepository.class,
	IAhvAnmeldungRepository.class,
	IMwstAnmeldungRepository.class,
	IUvgAnmeldungRepository.class,
	IFlowHistoryRepository.class,
	INewsletterHitsRepository.class,
	IHrMutationRepository.class
})
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, FreeMarkerAutoConfiguration.class,
	TransactionAutoConfiguration.class})
@EnableTransactionManagement
@EnableCaching
@PropertySource(value = {"classpath:businessServiceConfig/application.internal.properties"})
public class BusinessServicesConfig {

	@Autowired
	private Environment env;

	@Autowired
	private ApplicationContext ac;

	@Bean(name = "entityManagerFactory")
	public LocalContainerEntityManagerFactoryBean localEntityManagerFactory(EntityManagerFactoryBuilder builder) {
		return builder.dataSource(ac.getBean(DataSource.class)).packages(AbstractOSSEntity.class)
			.persistenceUnit("ossUnit").properties(new HashMap<String, Object>() {
				private static final long serialVersionUID = -5383444565364467050L;

				{
					// Hibernate.
					put("hibernate.show_sql", env.getProperty("hibernate.show_sql", boolean.class));
					put("hibernate.format_sql", env.getProperty("hibernate.format_sql", boolean.class));
					
					// Envers.
					put("org.hibernate.envers.audit_table_prefix", "");
					put("org.hibernate.envers.audit_table_suffix", "_aud");
					put("org.hibernate.envers.do_not_audit_optimistic_locking_field", "true");
					put("org.hibernate.envers.store_data_at_delete", "true");
					put("org.hibernate.envers.revision_on_collection_change", "false");
				}
			}).build();
	}

	@ConditionalOnProperty(name = "ossDataSource.useJndi", havingValue = "false")
	@Bean
	@ConfigurationProperties(prefix = "ossDataSource")
	public ComboPooledDataSource devDataSource() {
		return new ComboPooledDataSource();
	}

	/**
	 * To supports Bean Validation on service method level.
	 */
	@Bean
	public MethodValidationPostProcessor methodValidationPostProcessor() {
		return new MethodValidationPostProcessor();
	}

	@Profile("!unittest")
	@Bean
	@ConfigurationProperties(prefix = "oss.mail")
	public JavaMailSender mailSender() {
		return new JavaMailSenderImpl();
	}

	@Bean
	public FreeMarkerConfigurationFactoryBean freemarkerEngine() {
		FreeMarkerConfigurationFactoryBean factory = new FreeMarkerConfigurationFactoryBean();
		factory.setTemplateLoaderPath("classpath:mailTemplate");
		factory.setPreferFileSystemAccess(false);
		return factory;
	}

	@ConditionalOnProperty(name = "ossDataSource.useJndi", havingValue = "true")
	@Bean
	public DataSource jndiDataSource() {
		JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
		dsLookup.setResourceRef(true);
		return dsLookup.getDataSource("java:/ossDataSource");
	}

	@Bean(name = "transactionManager")
	public PlatformTransactionManager jpaTransactionManager() {
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
		jpaTransactionManager.setDataSource(ac.getBean(DataSource.class));
		return jpaTransactionManager;
	}
	
	@Bean(name = "cacheManager")
	public CacheManager cacheManager() {
		SimpleCacheManager cacheManager = new SimpleCacheManager();
		cacheManager.setCaches(Arrays.asList(
			new ConcurrentMapCache(CacheService.TRANSLATION_CACHE_MAP),
			new ConcurrentMapCache(CacheService.CODE_WERT_CACHE_MAP),
			new ConcurrentMapCache(CacheService.BRANCHE_CACHE_MAP),
			new ConcurrentMapCache(CacheService.VERBAN_CACHE_MAP),
			new ConcurrentMapCache(CacheService.BERUF_CACHE_MAP),
			new ConcurrentMapCache(CacheService.CH_ORT_CACHE_MAP),
			new ConcurrentMapCache(CacheService.AUSGLEICHSKASSE_CACHE_MAP),
			new ConcurrentMapCache(CacheService.VERSICHERUNG_CACHE_MAP),
			new ConcurrentMapCache(CacheService.LAND_CACHE_MAP)));
		return cacheManager;
	}
}
