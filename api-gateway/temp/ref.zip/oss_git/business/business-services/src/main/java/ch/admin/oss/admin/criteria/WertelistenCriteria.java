package ch.admin.oss.admin.criteria;

import ch.admin.oss.common.enums.AktivFilterEnum;
import ch.admin.oss.common.enums.KategorieEnum;

/**
 * @author hhu
 */
public class WertelistenCriteria extends AbstractPaginationCriteria{	
	private KategorieEnum kategorie;
	private AktivFilterEnum status;
	private String code;
	private String text;
	
	public KategorieEnum getKategorie() {
		return kategorie;
	}
	public void setKategorie(KategorieEnum kategorie) {
		this.kategorie = kategorie;
	}	
	public AktivFilterEnum getStatus() {
		return status;
	}
	public void setStatus(AktivFilterEnum status) {
		this.status = status;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
}
