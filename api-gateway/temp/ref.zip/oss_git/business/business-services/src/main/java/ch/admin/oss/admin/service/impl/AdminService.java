/*
 * AdminService
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.core.types.dsl.NumberExpression;
import com.querydsl.jpa.JPAExpressions;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.admin.criteria.AusgleichskasseCriteria;
import ch.admin.oss.admin.criteria.BerufsverbandeCriteria;
import ch.admin.oss.admin.criteria.BranchenCriteria;
import ch.admin.oss.admin.criteria.FunktionRechteCriteria;
import ch.admin.oss.admin.criteria.PrivatversichererCriteria;
import ch.admin.oss.admin.criteria.StandardTextCriteria;
import ch.admin.oss.admin.criteria.WertelistenCriteria;
import ch.admin.oss.admin.dto.ListResultDto;
import ch.admin.oss.admin.dto.NewsletterResultDto;
import ch.admin.oss.admin.query.AusgleichskasseTextTranslationQuery;
import ch.admin.oss.admin.query.BerufTextTranslationQuery;
import ch.admin.oss.admin.query.BerufsverbandeTextTranslationQuery;
import ch.admin.oss.admin.query.BranchenTextTranslationQuery;
import ch.admin.oss.admin.query.PrivatversichererTextTranslationQuery;
import ch.admin.oss.admin.query.WertelistenTextTranslationQuery;
import ch.admin.oss.admin.repository.IAusgleichskasseRepository;
import ch.admin.oss.admin.repository.IBrancheRepository;
import ch.admin.oss.admin.repository.IFunktionRecheRepository;
import ch.admin.oss.admin.repository.IStandardTextRepository;
import ch.admin.oss.admin.service.IAdminService;
import ch.admin.oss.application.service.impl.CacheService;
import ch.admin.oss.common.AbstractOSSService;
import ch.admin.oss.common.OssTechnicalException;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.enums.FunktionEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.StandardTextTypeEnum;
import ch.admin.oss.domain.AbgeschlossenerProzesseStatistikDto;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.BenutzerkontoBerechtigungenStatistikDto;
import ch.admin.oss.domain.BenutzerregistrierungenStatistikDto;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.FunktionRechteEntity;
import ch.admin.oss.domain.GrundungenStatistikDto;
import ch.admin.oss.domain.QAusgleichskasseEntity;
import ch.admin.oss.domain.QBerufEntity;
import ch.admin.oss.domain.QBrancheEntity;
import ch.admin.oss.domain.QCodeWertEntity;
import ch.admin.oss.domain.QFunktionRechteEntity;
import ch.admin.oss.domain.QNewsletterHitsEntity;
import ch.admin.oss.domain.QStandardTextEntity;
import ch.admin.oss.domain.QStatuswechselEntity;
import ch.admin.oss.domain.QTextTranslationEntity;
import ch.admin.oss.domain.QVerbandEntity;
import ch.admin.oss.domain.QVersicherungEntity;
import ch.admin.oss.domain.StandardTextEntity;
import ch.admin.oss.domain.VerbandEntity;
import ch.admin.oss.domain.VerbundenerUnternehmenStatistikDto;
import ch.admin.oss.domain.VersicherungEntity;
import ch.admin.oss.enums.SupportedFileTypeDownload;
import ch.admin.oss.landing.repository.INewsletterHitsRepository;
import ch.admin.oss.organisation.repository.ICodeWertRepository;
import ch.admin.oss.portal.repository.IBerufRepository;
import ch.admin.oss.portal.repository.IVerbandRepository;
import ch.admin.oss.portal.repository.IVersicherungRepository;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSConstants;

/**
 * Implement of {@link IAdminService}
 *
 * @author hha
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class AdminService extends AbstractOSSService implements IAdminService {

	public static final String GUI_LABELS_STATISTIK_CSV_MINDESTENS_PROZESS_DATUM = "gui_labels.statistikCSV.mindestensProzessDatum";
	public static final String GUI_LABELS_STATISTIK_CSV_MINDESTENS_PROZESS = "gui_labels.statistikCSV.mindestensProzess";
	public static final String GUI_LABELS_STATISTIK_CSV_MINDESTENS_DIENST_DATUM = "gui_labels.statistikCSV.mindestensDienstDatum";
	public static final String GUI_LABELS_STATISTIK_CSV_MINDESTENS_DIENST = "gui_labels.statistikCSV.mindestensDienst";
	public static final String GUI_LABELS_STATISTIK_CSV_UVG_DATUM = "gui_labels.statistikCSV.uvgDatum";
	public static final String GUI_LABELS_STATISTIK_CSV_UVG = "gui_labels.statistikCSV.uvg";
	public static final String GUI_LABELS_STATISTIK_CSV_MWST_DATUM = "gui_labels.statistikCSV.mwstDatum";
	public static final String GUI_LABELS_STATISTIK_CSV_MWST = "gui_labels.statistikCSV.mwst";
	public static final String GUI_LABELS_STATISTIK_CSV_AHV_DATUM = "gui_labels.statistikCSV.ahvDatum";
	public static final String GUI_LABELS_STATISTIK_CSV_AHV = "gui_labels.statistikCSV.ahv";
	public static final String GUI_LABELS_STATISTIK_CSV_HR_DIGITAL = "gui_labels.statistikCSV.hrDigital";
	public static final String GUI_LABELS_STATISTIK_CSV_HR_DATUM = "gui_labels.statistikCSV.hrDatum";
	public static final String GUI_LABELS_STATISTIK_CSV_HR = "gui_labels.statistikCSV.hr";
	public static final String GUI_LABELS_STATISTIK_CSV_BERUFSBEZEICHNUNG = "gui_labels.statistikCSV.berufsbezeichnung";
	public static final String GUI_LABELS_STATISTIK_CSV_RECHTSFORM = "gui_labels.statistikCSV.rechtsform";
	public static final String GUI_LABELS_STATISTIK_CSV_FIRMENNAME = "gui_labels.statistikCSV.firmenname";
	public static final String GUI_LABELS_STATISTIK_CSV_KANTON = "gui_labels.statistikCSV.kanton";
	public static final String GUI_LABELS_STATISTIK_CSV_BFSNR = "gui_labels.statistikCSV.bfsnr";
	public static final String GUI_LABELS_STATISTIK_CSV_ORT = "gui_labels.statistikCSV.ort";
	public static final String GUI_LABELS_STATISTIK_CSV_PLZ = "gui_labels.statistikCSV.plz";
	public static final String GUI_LABELS_STATISTIK_CSV_NUMMER = "gui_labels.statistikCSV.nummer";
	public static final String GUI_LABELS_STATISTIK_CSV_STRASSE = "gui_labels.statistikCSV.strasse";
	public static final String GUI_LABELS_STATISTIK_CSV_EMPFANGER = "gui_labels.statistikCSV.empfanger";
	public static final String GUI_LABELS_STATISTIK_CSV_ERSTELL_DATUM = "gui_labels.statistikCSV.erstellDatum";

	@Autowired
	private IFunktionRecheRepository funktionRecheRepository;
	
	@Autowired
	private ICodeWertRepository codeWertRepository;
	
	@Autowired
	private IStandardTextRepository standardTextRepository;

	@Autowired
	private IBrancheRepository brancheRepo;
	
	@Autowired
	private IVerbandRepository verbandRepo;
	
	@Autowired
	private IAusgleichskasseRepository ausgleichRepo;
	
	@Autowired
	private IVersicherungRepository versicherungRepo;
	
	@Autowired
	private IBerufRepository berufRepo;
	
	@Autowired
	private INewsletterHitsRepository newsletterHitsRepository;
	
	private static final String STATISTIK_USER_PER_MONTH_QUERY = ""
		+ "    SELECT count(u.PK) as userNumber, to_char(u.CREATED_TS, 'yyyy/MM'), to_char(u.CREATED_TS, 'MM/yyyy') as month "
		+ "    FROM T_USER u "
		+ "    GROUP BY to_char(u.CREATED_TS, 'MM/yyyy'), to_char(u.CREATED_TS, 'yyyy/MM') "
		+ "    ORDER BY to_char(u.CREATED_TS, 'yyyy/MM')";
	
	private static final String STATISTIK_COMPANIES_PER_MONTH_QUERY = ""
		+ "    SELECT DISTINCT org.yearMon, org.monYear, "
		+ "    sum(org.EINZELFIRMA) as ef, "
		+ "    sum(org.KOMMGES) as kom,"
		+ "    sum(org.KOLLGES) as koll, "
		+ "    sum(org.AG) as ag, "
		+ "    sum(org.GMBH) as gmbh "
		+ "    from ( "
		+ "    select to_char(o.CREATED_TS, 'yyyy/MM') yearMon, to_char(o.CREATED_TS, 'MM/yyyy') monYear, "
		+ "    case when o.rechtsform = 'EINZELFIRMA' then count(distinct o.pk) else 0 end as EINZELFIRMA, "
		+ "    case when o.rechtsform = 'KOMMGES' then count(distinct o.pk) else 0 end as KOMMGES, "
		+ "    case when o.rechtsform = 'KOLLGES' then count(distinct o.pk) else 0 end as KOLLGES, "
		+ "    case when o.rechtsform = 'AG' then count(distinct o.pk) else 0 end as AG, "
		+ "    case when o.rechtsform = 'GMBH' then count(distinct o.pk) else 0 end as GMBH "
		+ "    from T_ORGANISATION o "
		+ "    where o.rechtsform is not null "
		+ "    GROUP BY o.Rechtsform, to_char(o.CREATED_TS, 'yyyy/MM'), to_char(o.CREATED_TS, 'MM/yyyy') "
		+ "    order by to_char(o.CREATED_TS, 'yyyy/MM') "
		+ "    ) org "
		+ "    group by org.yearMon, org.monYear "
		+ "    order by org.yearMon ";
	
	private static final String STATISTIK_GRUNDUNGEN_QUERY = ""
		+ " select distinct process.monat,"
		+ " process.monYear,"
		+ " sum(process.EINZELFIRMA) as ef,"
		+ " sum(process.KOMMGES) as kom,"
		+ " sum(process.KOLLGES) as koll,"
		+ " sum(process.AG) as ag,"
		+ " sum(process.GMBH) as gmbh"
		+ " from ("
		+ " select to_char(s.zeitstempel, 'yyyy/MM') monat, to_char(s.zeitstempel, 'MM/yyyy') monYear,"
		+ " case when o.rechtsform = 'EINZELFIRMA' then count(distinct o.pk) else 0 end as EINZELFIRMA,"
		+ " case when o.rechtsform = 'KOMMGES' then count(distinct o.pk) else 0 end as KOMMGES,"
		+ " case when o.rechtsform = 'KOLLGES' then count(distinct o.pk) else 0 end as KOLLGES,"
		+ " case when o.rechtsform = 'AG' then count(distinct o.pk) else 0 end as AG,"
		+ " case when o.rechtsform = 'GMBH' then count(distinct o.pk) else 0 end as GMBH"
		+ " from T_ORGANISATION o"
		+ " JOIN T_PROZESS p on p.LN_ORGANISATION = o.pk"
		+ " JOIN T_STATUSWECHSEL s on p.PK = s.LN_PROZESS and p.BEARB_DATUM <= s.ZEITSTEMPEL"
		+ " where s.STATUS = 'GESENDET' and p.STATUS in ('GESENDET', 'EMPFANGEN', 'ZURUECK', 'AKZEPTIERT')"
		+ " and p.typ in ('UVG', 'AHV', 'MWST', 'HR')"
		+ " group by o.rechtsform, to_char(s.zeitstempel, 'yyyy/MM'), to_char(s.zeitstempel, 'MM/yyyy')"
		+ " order by to_char(zeitstempel, 'yyyy/MM'), o.rechtsform"
		+ " ) process"
		+ " group by process.monat, process.monYear"
		+ " order by process.monat";
	
	private static final String STATISTIK_BENUTZERKONTO_BERECHTIGUNGEN_QUERY = ""
		+ " select usr.groupName , count(usr.ln_user) as quantity"
		+ " from ("
		+ " select distinct ln_user, count(pk),"
		+ " case "
		+ " when count(pk) = 1 then '1' "
		+ " when (count(pk) > 1 and count(pk) < 10) then '2-9'"
		+ " else '>10'"
		+ " end as groupName"
		+ " from t_zugriff"
		+ " group by ln_user"
		+ " ) usr"
		+ " group by usr.groupName";
	
	private static final String STATISTIK_PROZESS_COMPLETE_PER_MONTH_QUERY = ""
		+ "    select distinct process.yearMon, process.monYear,"
		+ "    sum(process.HR) as hr,"
		+ "    sum(process.AHV) as ahv,"
		+ "    sum(process.UVG) as uvg, "
		+ "    sum(process.MWST) as mwst, "
		+ "    sum(process.MWST_EINTRBEST) as mwstEintrbest,"
		+ "    sum(process.MWST_ABMELDUNG) as mwstAbmeldung,"
		+ "    sum(process.MWST_ADRESSAENDERUNG) as mwstAdressaenderung,"
		+ "    sum(process.MWST_FRISTVERLAENGERUNG) as mwstFristverlaengerung"
		+ "    from ("
		+ "    select to_char(zeitstempel, 'yyyy/MM') yearMon, to_char(zeitstempel, 'MM/yyyy') monYear,"
		+ "    case when p.typ = 'HR' then count(distinct p.pk) else 0 end as HR,"
		+ "    case when p.typ = 'AHV' then count(distinct p.pk) else 0 end as AHV,"
		+ "    case when p.typ = 'UVG' then count(distinct p.pk) else 0 end as UVG,"
		+ "    case when p.typ = 'MWST' then count(distinct p.pk) else 0 end as MWST,"
		+ "    case when p.typ = 'MWST_EINTRBEST' then count(distinct p.pk) else 0 end as MWST_EINTRBEST,"
		+ "    case when p.typ = 'MWST_ABMELDUNG' then count(distinct p.pk) else 0 end as MWST_ABMELDUNG,"
		+ "    case when p.typ = 'MWST_ADRESSAENDERUNG' then count(distinct p.pk) else 0 end as MWST_ADRESSAENDERUNG,"
		+ "    case when p.typ = 'MWST_FRISTVERLAENGERUNG' then count(distinct p.pk) else 0 end as MWST_FRISTVERLAENGERUNG"
		+ "    from T_PROZESS p"
		+ "    join T_STATUSWECHSEL s on p.PK = s.LN_PROZESS and p.BEARB_DATUM <= s.ZEITSTEMPEL"
		+ "    where s.STATUS = 'GESENDET' and p.STATUS in ('GESENDET', 'EMPFANGEN', 'ZURUECK', 'AKZEPTIERT')"
		+ "    group by p.typ, to_char(zeitstempel, 'yyyy/MM'), to_char(zeitstempel, 'MM/yyyy')"
		+ "    ) process"
		+ "    group by process.yearMon, process.monYear"
		+ "    order by process.yearMon";
	
	
	private static final String STATISTIK_CSV_SQL = "SELECT TO_CHAR(ORG.CREATED_TS, 'DD.MM.YYYY') as erstellDatum,"
		+ "     DOMIZIL.EMPFAENGER as empfanger,"
		+ "     DOMIZIL.STRASSE as strasse," 
		+ "     DOMIZIL.HAUSNUMMER as nummer," 
		+ "     DOMIZIL.PLZ as plz,"
		+ "     DOMIZIL.ORT as ort," 
		+ "     DOMIZIL.BFS_NR as bfsnr,"
		+ "     DOMIZIL.KANTON as kanton," 
		+ "     NAMEN.BEZEICHNUNG as firmenname,"
		+ "     ORG.RECHTSFORM as rechtsform,"
		
		+ "     TO_CHAR((SELECT BERUFTEXTTRAN.TEXT"
		+ "      FROM T_BERUF BERUF"
		+ "      LEFT JOIN T_STANDARD_TEXT BERUFTEXT ON BERUF.LN_STANDARD_TEXT = BERUFTEXT.PK"
		+ "      LEFT JOIN T_TEXT_TRANSLATION BERUFTEXTTRAN ON (BERUFTEXTTRAN.LN_STANDARD_TEXT = BERUFTEXT.PK AND BERUFTEXTTRAN.LANGUAGE = '%(language)')"
		+ "      WHERE BERUF.PK = PFLICH.LN_BERUF"
		+ "     )) as berufsbezeichnung,"
		
		+ "     (CASE WHEN (SELECT COUNT(S.PK)"
		+ "                 FROM T_STATUSWECHSEL S"
		+ "                 WHERE S.STATUS = '%(gesedent)' AND S.LN_PROZESS = HR.PK) > 0"
		+ "           THEN 1"
		+ "           ELSE 0 END) as hr,"
		
		+ "     TO_CHAR((SELECT MIN(s.zeitstempel)"
		+ "      FROM T_STATUSWECHSEL S"
		+ "      WHERE S.STATUS = '%(gesedent)' AND S.LN_PROZESS = HR.PK), 'DD.MM.YYYY') as hrDatum,"
		
		+ "     (CASE WHEN HR.DIGITAL_SIGNEES IS NOT NULL THEN 1 ELSE 0 END) as hrDigital,"
		
		+ "     (CASE WHEN (SELECT COUNT(S.PK)"
		+ "                 FROM T_STATUSWECHSEL S"
		+ "                 WHERE S.STATUS = '%(gesedent)' AND S.LN_PROZESS = AHV.PK) > 0"
		+ "           THEN 1"
		+ "           ELSE 0 END) as ahv,"
		
		+ "     TO_CHAR((SELECT MIN(s.zeitstempel)"
		+ "      FROM T_STATUSWECHSEL S"
		+ "      WHERE S.STATUS = '%(gesedent)' AND S.LN_PROZESS = AHV.PK), 'DD.MM.YYYY') as ahvDatum,"
		
		+ "     (CASE WHEN (SELECT COUNT(S.PK)"
		+ "                 FROM T_STATUSWECHSEL S"
		+ "                 WHERE S.STATUS = '%(gesedent)' AND S.LN_PROZESS = MWST.PK) > 0"
		+ "           THEN 1"
		+ "           ELSE 0 END) as mwst,"
		
		+ "     TO_CHAR((SELECT MIN(s.zeitstempel)"
		+ "      FROM T_STATUSWECHSEL S"
		+ "      WHERE S.STATUS = '%(gesedent)' AND S.LN_PROZESS = MWST.PK), 'DD.MM.YYYY') as mwstDatum,"
		
		+ "     (CASE WHEN (SELECT COUNT(S.PK)"
		+ "                 FROM T_STATUSWECHSEL S"
		+ "                 WHERE S.STATUS = '%(gesedent)' AND S.LN_PROZESS = UVG.PK) > 0"
		+ "           THEN 1"
		+ "           ELSE 0 END) as uvg,"
		
		+ "     TO_CHAR((SELECT MIN(s.zeitstempel)"
		+ "      FROM T_STATUSWECHSEL S"
		+ "      WHERE S.STATUS = '%(gesedent)' AND S.LN_PROZESS = UVG.PK), 'DD.MM.YYYY') as uvgDatum,"
		
		+ "     CASE WHEN (SELECT COUNT(S.PK)"
		+ "                FROM T_STATUSWECHSEL S"
		+ "                INNER JOIN T_PROZESS P ON (S.LN_PROZESS = P.PK)"
		+ "                WHERE P.LN_ORGANISATION = ORG.PK"
		+ "                AND P.TYP IN ('%(hr)','%(ahv)','%(mwst)','%(uvg)')"
		+ "                AND S.STATUS = '%(gesedent)') = 0 THEN 0 ELSE 1 END"
		+ "     as mindestens,"
		+ "     TO_CHAR((SELECT MIN(S.ZEITSTEMPEL)" 
		+ "      FROM T_STATUSWECHSEL S" 
		+ "      INNER JOIN T_PROZESS P ON (S.LN_PROZESS = P.PK)"
		+ "      WHERE P.LN_ORGANISATION = ORG.PK"
		+ "      AND P.TYP IN ('%(hr)','%(ahv)','%(mwst)','%(uvg)')"
		+ "      AND S.STATUS = '%(gesedent)'), 'YYYY')"
		+ "     as mindestensDatum,"
		+ "     CASE WHEN (SELECT COUNT(S.PK)" 
		+ "                FROM T_STATUSWECHSEL S" 
		+ "                INNER JOIN T_PROZESS P ON (S.LN_PROZESS = P.PK)"
		+ "                WHERE P.LN_ORGANISATION = ORG.PK "
		+ "                AND S.STATUS = '%(gesedent)') = 0 THEN 0 ELSE 1 END"
		+ "     as minprocess,"
		+ "     TO_CHAR((SELECT MIN(S.ZEITSTEMPEL)" 
		+ "      FROM T_STATUSWECHSEL S" 
		+ "      INNER JOIN T_PROZESS P ON (S.LN_PROZESS = P.PK)"
		+ "      WHERE P.LN_ORGANISATION = ORG.PK AND S.STATUS = '%(gesedent)'), 'YYYY')"
		+ "     as minprocessdatum,"
		+ "     %(branchesProjection)"
        + " "
		+ " FROM T_ORGANISATION ORG "
		+ " INNER JOIN T_ADRESSE DOMIZIL ON (ORG.LN_DOMIZIL = DOMIZIL.PK) "
		+ " INNER JOIN T_FIRMENNAME NAMEN ON (NAMEN.LN_ORGANISATION = ORG.PK) "
		+ " LEFT JOIN T_PFLICHTENABKLAERUNGEN PFLICH ON PFLICH.LN_ORGANISATION = ORG.PK "
		+ " LEFT JOIN T_PROZESS HR ON (HR.LN_ORGANISATION = ORG.PK AND HR.TYP = '%(hr)') "
		+ " LEFT JOIN T_PROZESS AHV ON (AHV.LN_ORGANISATION = ORG.PK AND AHV.TYP = '%(ahv)') "
		+ " LEFT JOIN T_PROZESS MWST ON (MWST.LN_ORGANISATION = ORG.PK AND MWST.TYP = '%(mwst)') "
		+ " LEFT JOIN T_PROZESS UVG ON (UVG.LN_ORGANISATION = ORG.PK AND UVG.TYP = '%(uvg)')";
	
	
	
	@Override
	public ListResultDto<FunktionRechteEntity> getPaginationFunktionRechtes(FunktionRechteCriteria criteria) {
		long total = buildFunktionRechtesQuery(criteria).fetchCount();
		return new ListResultDto<FunktionRechteEntity>(total,
			criteria.applyPaginationToQuery(buildFunktionRechtesQuery(criteria)).fetch());
	}

	@Override
	public FunktionRechteEntity getFunktionRechte(long id) {
		return funktionRecheRepository.findOne(id);
	}

	@Override
	public FunktionRechteEntity saveFunktionRechte(FunktionRechteEntity entity) {
		return funktionRecheRepository.save(entity);
	}	

	@Override
	public ListResultDto<StandardTextEntity> getPaginationStandardTexts(StandardTextCriteria criteria) {
		long total = buildStandardTextQuery(criteria).fetchCount();
		List<StandardTextEntity> texts = criteria.applyPaginationToQuery(buildStandardTextQuery(criteria)).fetch();
		if (!texts.isEmpty()) {
			jpaUtil.initialize(texts.get(0), QStandardTextEntity.standardTextEntity.translations);
		}
		return new ListResultDto<StandardTextEntity>(total, texts);
	}

	@Override
	public StandardTextEntity getStandardText(long id) {
		return jpaUtil.initialize(standardTextRepository.findOne(id),
			QStandardTextEntity.standardTextEntity.translations);
	}

	@Override
	@CacheEvict(value = CacheService.TRANSLATION_CACHE_MAP, allEntries = true)
	public StandardTextEntity saveStandardText(StandardTextEntity entity) {
		return standardTextRepository.save(entity);
	}	

	@Override
	public ListResultDto<CodeWertEntity> getPaginationCodeWertListen(WertelistenCriteria criteria) {
		JPAQuery<CodeWertEntity> buildQuery = new WertelistenTextTranslationQuery().buildQuery(criteria, em);
		long total = buildQuery.fetchCount();
		List<CodeWertEntity> codeWerts = buildQuery.fetch();
		codeWerts.stream().forEach(code -> {
			jpaUtil.initialize(code, QCodeWertEntity.codeWertEntity.standardText.translations);
		});
		return new ListResultDto<CodeWertEntity>(total, codeWerts);
	}

	@Override
	@CacheEvict(value = CacheService.CODE_WERT_CACHE_MAP, allEntries = true)
	public CodeWertEntity saveCodeWertEntity(CodeWertEntity entity) {
		return codeWertRepository.save(entity);
	}

	@Override
	public CodeWertEntity getCodeWertEntity(long id) {
		CodeWertEntity code = new JPAQuery<CodeWertEntity>(em).from(QCodeWertEntity.codeWertEntity)
			.leftJoin(QCodeWertEntity.codeWertEntity.standardText).fetchJoin()
			.where(QCodeWertEntity.codeWertEntity.id.eq(id)).fetchOne();

		code.getStandardText().getTranslations().forEach(trans -> {
			jpaUtil.initialize(trans, QCodeWertEntity.codeWertEntity.standardText.translations);
		});
		return code;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ListResultDto<BrancheEntity> getPaginationBranchen(BranchenCriteria criteria) {		
		JPAQuery<BrancheEntity> buildQuery = new BranchenTextTranslationQuery().buildQuery(criteria, em);
		
		long total = buildQuery.fetchCount();
		
		List<BrancheEntity> branchen = criteria.applyPaginationToQuery(buildQuery).fetch();
		branchen.stream().forEach(b -> {
			b.getStandardText().getTranslations().forEach(trans -> {
				jpaUtil.initialize(trans, QBrancheEntity.brancheEntity.standardText.translations);
			});
		});
		
		return new ListResultDto<BrancheEntity>(total, branchen);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<BrancheEntity> getBrancheGroup() {
		List<BrancheEntity> branchen = new JPAQuery<BrancheEntity>(em)
			.from(QBrancheEntity.brancheEntity)
			.leftJoin(QBrancheEntity.brancheEntity.standardText).fetchJoin()
			.where(QBrancheEntity.brancheEntity.parent.id.isNull())
			.orderBy(QBrancheEntity.brancheEntity.pos.asc())
			.fetch();
		branchen.stream().forEach(b -> {
			b.getStandardText().getTranslations().forEach(trans -> {
				jpaUtil.initialize(trans, QBrancheEntity.brancheEntity.standardText.translations);
			});
		});
		return branchen;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BrancheEntity getBranche(long id, int... version) {
		JPAQuery<BrancheEntity> query = new JPAQuery<BrancheEntity>(em)
			.from(QBrancheEntity.brancheEntity)
			.leftJoin(QBrancheEntity.brancheEntity.standardText).fetchJoin()
			.where(QBrancheEntity.brancheEntity.id.eq(id));
		
		if (version.length > 0) {
			query.where(QBrancheEntity.brancheEntity.version.eq(version[0]));
		}

		BrancheEntity ent = query.fetchOne();

		if (ent != null) {
			ent.getStandardText().getTranslations().forEach(trans -> {
				jpaUtil.initialize(trans, QBrancheEntity.brancheEntity.standardText.translations);
			});

			jpaUtil.initialize(ent, QBrancheEntity.brancheEntity.childBranches.any());
		}

		return ent;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@CacheEvict(value = CacheService.BRANCHE_CACHE_MAP, allEntries = true)
	public BrancheEntity saveBranche(BrancheEntity ent) {
		return brancheRepo.save(ent);
	}

	private JPAQuery<FunktionRechteEntity> buildFunktionRechtesQuery(FunktionRechteCriteria criteria) {
		JPAQuery<FunktionRechteEntity> query = new JPAQuery<FunktionRechteEntity>(em)
			.from(QFunktionRechteEntity.funktionRechteEntity)
			.orderBy(QFunktionRechteEntity.funktionRechteEntity.funktion.asc());

		if (StringUtils.isNotBlank(criteria.getFunktionOrBeschreibung())) {
			String freeText = StringUtils.trim(criteria.getFunktionOrBeschreibung());
			BooleanBuilder bb = new BooleanBuilder(
				QFunktionRechteEntity.funktionRechteEntity.beschreibung.containsIgnoreCase(freeText));
			List<FunktionEnum> possibleFunctions = FunktionEnum.getPossibleFunction(freeText);
			if (!possibleFunctions.isEmpty()) {
				bb.or(QFunktionRechteEntity.funktionRechteEntity.funktion.in(possibleFunctions));
			}
			query = query.where(bb.getValue());
		}

		if (criteria.getGruppen() != null) {
			query = query
				.where(QFunktionRechteEntity.funktionRechteEntity.gruppens.contains(criteria.getGruppen().name()));
		}
		return query;
	}

	private JPAQuery<StandardTextEntity> buildStandardTextQuery(StandardTextCriteria criteria) {
		JPAQuery<StandardTextEntity> query = new JPAQuery<StandardTextEntity>(em)
			.from(QStandardTextEntity.standardTextEntity)
			.where(QStandardTextEntity.standardTextEntity.code.isNotNull())
			.orderBy(QStandardTextEntity.standardTextEntity.code.asc());

		if (criteria.getType() != null) {
			query = query.where(
				QStandardTextEntity.standardTextEntity.richText.eq(criteria.getType() == StandardTextTypeEnum.RICH));
		}

		if (StringUtils.isNotBlank(criteria.getCode())) {
			String code = StringUtils.trim(criteria.getCode());
			query = query.where(QStandardTextEntity.standardTextEntity.code.containsIgnoreCase(code));
		}

		if (StringUtils.isNotBlank(criteria.getText())) {
			String text = StringUtils.trim(criteria.getText());
			query = query.where(JPAExpressions.selectFrom(QTextTranslationEntity.textTranslationEntity)
				.where(QTextTranslationEntity.textTranslationEntity.standardText
					.eq(QStandardTextEntity.standardTextEntity))
				.where(QTextTranslationEntity.textTranslationEntity.text.containsIgnoreCase(text)).exists());
		}
		return query;
	}	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ListResultDto<VerbandEntity> getPaginationVerbandListen(BerufsverbandeCriteria criteria) {
		JPAQuery<VerbandEntity> buildQuery = new BerufsverbandeTextTranslationQuery().buildQuery(criteria, em);
		long total = buildQuery.fetchCount();

		List<VerbandEntity> verbands = criteria.applyPaginationToQuery(buildQuery).fetch();

		verbands.stream().forEach(verband -> {
			jpaUtil.initialize(verband, QVerbandEntity.verbandEntity.standardText.translations,
				QVerbandEntity.verbandEntity.ausgleichskasse.aktiv);
		});

		return new ListResultDto<VerbandEntity>(total, verbands);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getMinPosInBrancheGroup(Long brancheGroupId) {
		QBrancheEntity brancheentity = QBrancheEntity.brancheEntity;
		BrancheEntity ent = new JPAQuery<BrancheEntity>(em)
			.from(brancheentity)
			.where(brancheentity.parent.id.eq(brancheGroupId))
			.orderBy(brancheentity.pos.asc())
			.fetchFirst();
		return (ent != null) ? ent.getPos() : OSSConstants.DEFAULT_MIN_POS;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public VerbandEntity getVerband(long id) {
		VerbandEntity verbandEntity = new JPAQuery<VerbandEntity>(em)
			.from(QVerbandEntity.verbandEntity)
			.leftJoin(QVerbandEntity.verbandEntity.ausgleichskasse, QAusgleichskasseEntity.ausgleichskasseEntity).fetchJoin() 
			.leftJoin(QVerbandEntity.verbandEntity.standardText).fetchJoin()
			.where(QVerbandEntity.verbandEntity.id.eq(id)).fetchOne();

		verbandEntity.getStandardText().getTranslations().forEach(trans -> {
			jpaUtil.initialize(trans, QVerbandEntity.verbandEntity.standardText.translations);
		});
		return verbandEntity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@CacheEvict(value = CacheService.VERBAN_CACHE_MAP, allEntries = true)
	public VerbandEntity saveVerband(VerbandEntity verbandEntity) {
		return verbandRepo.save(verbandEntity);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public AusgleichskasseEntity getAusgleichskasse(long id, Path<?>... associations) {
		AusgleichskasseEntity ausEntity = new JPAQuery<AusgleichskasseEntity>(em)
			.from(QAusgleichskasseEntity.ausgleichskasseEntity)
			.leftJoin(QAusgleichskasseEntity.ausgleichskasseEntity.standardText).fetchJoin()
			.where(QAusgleichskasseEntity.ausgleichskasseEntity.id.eq(id)).fetchOne();
		
		ausEntity.getStandardText().getTranslations().forEach(trans -> {
			jpaUtil.initialize(trans, associations);
		});
		return ausEntity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<AusgleichskasseEntity> getActivAusgleichskasse() {
		List<AusgleichskasseEntity> listAusEntity = new JPAQuery<AusgleichskasseEntity>(em)
			.from(QAusgleichskasseEntity.ausgleichskasseEntity)
			.where(QAusgleichskasseEntity.ausgleichskasseEntity.aktiv.isTrue())
			.orderBy(QAusgleichskasseEntity.ausgleichskasseEntity.strasse.asc())
			.fetch();
		
		listAusEntity.stream().forEach(entity -> {
			jpaUtil.initialize(entity, QAusgleichskasseEntity.ausgleichskasseEntity.standardText.translations);
		});
		
		return listAusEntity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ListResultDto<AusgleichskasseEntity> getPaginationAusgleichskasseListen(AusgleichskasseCriteria criteria) {
		AusgleichskasseTextTranslationQuery attq = new AusgleichskasseTextTranslationQuery();

		JPAQuery<AusgleichskasseEntity> buildQuery = attq.buildQuery(criteria, em);
		long total = buildQuery.fetchCount();

		List<AusgleichskasseEntity> ausgleichs = criteria.applyPaginationToQuery(buildQuery).fetch();

		ausgleichs.stream().forEach(verband -> {
			jpaUtil.initialize(verband, QAusgleichskasseEntity.ausgleichskasseEntity.standardText.translations);
		});

		return new ListResultDto<AusgleichskasseEntity>(total, ausgleichs);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BrancheEntity getParentBrancheToSwap(int currentPos, boolean isUp) {
		BooleanExpression posCondition = isUp ? QBrancheEntity.brancheEntity.pos.lt(currentPos)
			: QBrancheEntity.brancheEntity.pos.gt(currentPos);
		OrderSpecifier<Integer> posOrderCondition = isUp ? QBrancheEntity.brancheEntity.pos.desc()
			: QBrancheEntity.brancheEntity.pos.asc();
		return new JPAQuery<BrancheEntity>(em)
			.from(QBrancheEntity.brancheEntity)
			.where(QBrancheEntity.brancheEntity.parent.id.isNull().and(posCondition))
			.orderBy(posOrderCondition)
			.fetchFirst();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BrancheEntity getSubBrancheToSwap(int currentPos, long parentId, boolean isUp) {
		BooleanExpression posCondition = isUp ? QBrancheEntity.brancheEntity.pos.lt(currentPos)
			: QBrancheEntity.brancheEntity.pos.gt(currentPos);
		OrderSpecifier<Integer> posOrderCondition = isUp ? QBrancheEntity.brancheEntity.pos.desc()
			: QBrancheEntity.brancheEntity.pos.asc();
		return new JPAQuery<BrancheEntity>(em)
			.from(QBrancheEntity.brancheEntity)
			.where(QBrancheEntity.brancheEntity.parent.id.eq(parentId).and(posCondition))
			.orderBy(posOrderCondition)
			.fetchFirst();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Integer> getMaxAndMinPosOfParentBranche() {
		NumberExpression<Integer> max = QBrancheEntity.brancheEntity.pos.max();
		NumberExpression<Integer> min = QBrancheEntity.brancheEntity.pos.min();		
		List<Integer> res = new ArrayList<Integer>();
		new JPAQuery<BerufEntity>(em)
			.from(QBrancheEntity.brancheEntity)
			.where(QBrancheEntity.brancheEntity.parent.id.isNull())
			.select(max, min)
			.fetch()
			.stream().forEach(r -> {
				res.add(r.get(max));
				res.add(r.get(min));
			});
		return res;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@CacheEvict(value = CacheService.BRANCHE_CACHE_MAP, allEntries = true)
	public void saveBranches(BrancheEntity... ent) {
		brancheRepo.save(Arrays.asList(ent));
	}

	@Override
	public ListResultDto<VersicherungEntity> getPaginationPrivatversichererListen(PrivatversichererCriteria criteria) {
		JPAQuery<VersicherungEntity> buildQuery = new PrivatversichererTextTranslationQuery().buildQuery(criteria, em);
		long total = buildQuery.fetchCount();

		List<VersicherungEntity> ents = criteria.applyPaginationToQuery(buildQuery).fetch();

		ents.stream().forEach(ent -> {
			jpaUtil.initialize(ent, QVersicherungEntity.versicherungEntity.standardText.translations);
		});

		return new ListResultDto<VersicherungEntity>(total, ents);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BrancheEntity getBranche(String code) {
		return new JPAQuery<BrancheEntity>(em)
			.from(QBrancheEntity.brancheEntity)
			.where(QBrancheEntity.brancheEntity.code.eq(code))
			.fetchFirst();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getMaxPosInBrancheGroup(Long brancheGroupId) {
		BrancheEntity maxPosEnt = new JPAQuery<BrancheEntity>(em)
			.from(QBrancheEntity.brancheEntity)
			.where(QBrancheEntity.brancheEntity.parent.id.eq(brancheGroupId))
			.orderBy(QBrancheEntity.brancheEntity.pos.desc())
			.fetchFirst();
		return (maxPosEnt != null) ? maxPosEnt.getPos() : OSSConstants.DEFAULT_MAX_POS;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	@CacheEvict(value = CacheService.AUSGLEICHSKASSE_CACHE_MAP, allEntries = true)
	public AusgleichskasseEntity saveAusgleichskasse(AusgleichskasseEntity ent) {
		return ausgleichRepo.save(ent);
	}

	@Override
	public VersicherungEntity getVersicherungEntity(long id) {
		VersicherungEntity entity = new JPAQuery<VersicherungEntity>(em)
				.from(QVersicherungEntity.versicherungEntity)
				.leftJoin(QVersicherungEntity.versicherungEntity.standardText).fetchJoin()
				.where(QVersicherungEntity.versicherungEntity.id.eq(id)).fetchOne();

		entity.getStandardText().getTranslations().forEach(trans -> {
			jpaUtil.initialize(trans, QVersicherungEntity.versicherungEntity.standardText.translations);
		});
		return entity;
	}

	@Override
	@CacheEvict(value = CacheService.VERSICHERUNG_CACHE_MAP, allEntries = true)
	public VersicherungEntity saveVersicherungEntity(VersicherungEntity ent) {
		return versicherungRepo.save(ent);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ListResultDto<BerufEntity> getPaginationBerufe(BranchenCriteria criteria) {
		JPAQuery<BerufEntity> buildBerufeQuery = new BerufTextTranslationQuery().buildQuery(criteria, em);
		
		long total = buildBerufeQuery.fetchCount();

		List<BerufEntity> berufe = criteria.applyPaginationToQuery(buildBerufeQuery).fetch();

		berufe.stream().forEach(b -> {
			b.getStandardText().getTranslations().forEach(trans -> {
				jpaUtil.initialize(trans, QBerufEntity.berufEntity.standardText.translations);
			});
		});

		return new ListResultDto<BerufEntity>(total, berufe);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<BerufEntity> getBerufGroup() {
		List<BerufEntity> berufe = new JPAQuery<BerufEntity>(em)
			.from(QBerufEntity.berufEntity)
			.leftJoin(QBerufEntity.berufEntity.branche).fetchJoin()
			.leftJoin(QBerufEntity.berufEntity.standardText).fetchJoin()
			.where(QBerufEntity.berufEntity.parent.id.isNull())
			.orderBy(QBerufEntity.berufEntity.pos.asc())
			.fetch();
		berufe.stream().forEach(b -> {
			b.getStandardText().getTranslations().forEach(trans -> {
				jpaUtil.initialize(trans, QBrancheEntity.brancheEntity.standardText.translations);
			});
		});
		return berufe;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BerufEntity getBeruf(long id, int... version) {
		JPAQuery<BerufEntity> query = new JPAQuery<BerufEntity>(em)
			.from(QBerufEntity.berufEntity)
			.leftJoin(QBerufEntity.berufEntity.standardText).fetchJoin()
			.where(QBerufEntity.berufEntity.id.eq(id));
		
		if (version.length > 0) {
			query.where(QBerufEntity.berufEntity.version.eq(version[0]));
		}
		
		BerufEntity ent = query.fetchOne();

		if (ent != null) {
			ent.getStandardText().getTranslations().forEach(trans -> {
				jpaUtil.initialize(trans, QBerufEntity.berufEntity.standardText.translations);
			});
			jpaUtil.initialize(ent, QBerufEntity.berufEntity.childBerufs.any());
		}
		
		return ent;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@CacheEvict(value = CacheService.BERUF_CACHE_MAP, allEntries = true)
	public BerufEntity saveBeruf(BerufEntity ent) {
		return berufRepo.save(ent);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BerufEntity getBeruf(String code) {
		return new JPAQuery<BerufEntity>(em)
			.from(QBerufEntity.berufEntity)
			.where(QBerufEntity.berufEntity.code.eq(code))
			.fetchFirst();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getMaxPosInBerufGroup(Long berufGroupId) {
		BerufEntity maxPosEnt = new JPAQuery<BerufEntity>(em)
			.from(QBerufEntity.berufEntity)
			.where(QBerufEntity.berufEntity.parent.id.eq(berufGroupId))
			.orderBy(QBerufEntity.berufEntity.pos.desc())
			.fetchFirst();
		return (maxPosEnt != null) ? maxPosEnt.getPos() : OSSConstants.DEFAULT_MAX_POS;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BerufEntity getParentBerufToSwap(int currentPos, boolean isUp) {
		BooleanExpression posCondition = isUp ? QBerufEntity.berufEntity.pos.lt(currentPos)
			: QBerufEntity.berufEntity.pos.gt(currentPos);
		OrderSpecifier<Integer> posOrderCondition = isUp ? QBerufEntity.berufEntity.pos.desc()
			: QBerufEntity.berufEntity.pos.asc();
		return new JPAQuery<BerufEntity>(em)
			.from(QBerufEntity.berufEntity)
			.where(QBerufEntity.berufEntity.parent.id.isNull()
				.and(posCondition)).orderBy(posOrderCondition)
			.fetchFirst();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public BerufEntity getSubBerufToSwap(int currentPos, long parentId, boolean isUp) {
		BooleanExpression posCondition = isUp ? QBerufEntity.berufEntity.pos.lt(currentPos)
			: QBerufEntity.berufEntity.pos.gt(currentPos);
		OrderSpecifier<Integer> posOrderCondition = isUp ? QBerufEntity.berufEntity.pos.desc()
			: QBerufEntity.berufEntity.pos.asc();
		return new JPAQuery<BerufEntity>(em)
			.from(QBerufEntity.berufEntity)
			.where(QBerufEntity.berufEntity.parent.id.eq(parentId).and(posCondition))
			.orderBy(posOrderCondition)
			.fetchFirst();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<Integer> getMaxAndMinPosOfParentBeruf() {
		NumberExpression<Integer> max = QBerufEntity.berufEntity.pos.max();
		NumberExpression<Integer> min = QBerufEntity.berufEntity.pos.min();		
		List<Integer> res = new ArrayList<Integer>();
		new JPAQuery<BerufEntity>(em)
			.from(QBerufEntity.berufEntity)			
			.where(QBerufEntity.berufEntity.parent.id.isNull())
			.select(max, min)
			.fetch()
			.stream().forEach(r -> {
				res.add(r.get(max));
				res.add(r.get(min));
			});
		return res;
	}	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getMinPosInBerufGroup(Long berufGroupId) {
		BerufEntity minPosEnt = new JPAQuery<BerufEntity>(em)
			.from(QBerufEntity.berufEntity)
			.where(QBerufEntity.berufEntity.parent.id.eq(berufGroupId))
			.orderBy(QBerufEntity.berufEntity.pos.asc())
			.fetchFirst();
		return (minPosEnt != null) ? minPosEnt.getPos() : OSSConstants.DEFAULT_MIN_POS;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@CacheEvict(value = CacheService.BERUF_CACHE_MAP, allEntries = true)
	public void saveBerufe(BerufEntity... ent) {
		berufRepo.save(Arrays.asList(ent));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<BrancheEntity> getSubBranchen() {
		List<BrancheEntity> branchen = new JPAQuery<BrancheEntity>(em)
			.from(QBrancheEntity.brancheEntity)
			.leftJoin(QBrancheEntity.brancheEntity.standardText).fetchJoin()
			.where(QBrancheEntity.brancheEntity.parent.id.isNotNull())
			.orderBy(QBrancheEntity.brancheEntity.parent.id.asc(), QBrancheEntity.brancheEntity.pos.asc())
			.fetch();
		branchen.stream().forEach(b -> {
			b.getStandardText().getTranslations().forEach(trans -> {
				jpaUtil.initialize(trans, QBrancheEntity.brancheEntity.standardText.translations);
			});
		});
		return branchen;
	}

	@Override
	public List<String> getCampaigns() {
		return new JPAQuery<String>(em)
			.from(QNewsletterHitsEntity.newsletterHitsEntity)
			.select(QNewsletterHitsEntity.newsletterHitsEntity.campaign)
			.distinct()
			.orderBy(QNewsletterHitsEntity.newsletterHitsEntity.campaign.asc())
			.fetch();
	}

	@Override
	public NewsletterResultDto getCampaignInfo(String campaign) {
		NewsletterResultDto result = new NewsletterResultDto();
		result.setNumberOfHit(newsletterHitsRepository.count(QNewsletterHitsEntity.newsletterHitsEntity.campaign.eq(campaign)));
		result.setNumberOfRegistration(newsletterHitsRepository.count(QNewsletterHitsEntity.newsletterHitsEntity.campaign.eq(campaign)
			.and(QNewsletterHitsEntity.newsletterHitsEntity.user.isNotNull())));

		result.setNumberOfAdministrativeApplication(new JPAQuery<>(em)
			.from(QNewsletterHitsEntity.newsletterHitsEntity)
			.where(QNewsletterHitsEntity.newsletterHitsEntity.campaign.eq(campaign))
			.where(
				new JPAQuery<>()
					.from(QStatuswechselEntity.statuswechselEntity)
					.where(QStatuswechselEntity.statuswechselEntity.user.eq(QNewsletterHitsEntity.newsletterHitsEntity.user))
					.where(QStatuswechselEntity.statuswechselEntity.status.eq(ProzessStatusEnum.GESENDET))
					.exists()
			)
			.select(QNewsletterHitsEntity.newsletterHitsEntity.user.countDistinct())
			.fetchOne()
		);
		return result;
	}	

	@SuppressWarnings("unchecked")
	@Override
	public List<AbgeschlossenerProzesseStatistikDto> statistikAbgeschlossenerProzesse() {
		return em.createNativeQuery(STATISTIK_PROZESS_COMPLETE_PER_MONTH_QUERY, AbgeschlossenerProzesseStatistikDto.class).getResultList();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<GrundungenStatistikDto> statistikGrundungen() {
		return em.createNativeQuery(STATISTIK_GRUNDUNGEN_QUERY, GrundungenStatistikDto.class).getResultList();		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BenutzerregistrierungenStatistikDto> statistikBenutzerregistrierungen() {
		return em.createNativeQuery(STATISTIK_USER_PER_MONTH_QUERY, BenutzerregistrierungenStatistikDto.class).getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<VerbundenerUnternehmenStatistikDto> statistikVerbundenerUnternehmen() {
		return em.createNativeQuery(STATISTIK_COMPANIES_PER_MONTH_QUERY, VerbundenerUnternehmenStatistikDto.class).getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BenutzerkontoBerechtigungenStatistikDto> statistikBenutzerkontoBerechtigungen() {
		return em.createNativeQuery(STATISTIK_BENUTZERKONTO_BERECHTIGUNGEN_QUERY, BenutzerkontoBerechtigungenStatistikDto.class).getResultList();
	}

	@Override
	public FileDto generateStatistikCSV() {
		return new FileDto("statistik.csv", SupportedFileTypeDownload.CSV, generateCSVForStatistik());
	}
	
	private byte[] generateCSVForStatistik() {
		ByteArrayOutputStream result = new ByteArrayOutputStream();
        CSVFormat csvFileFormat = CSVFormat.DEFAULT.withRecordSeparator("\n");
				
		try (ByteArrayOutputStreamWriter writer = new ByteArrayOutputStreamWriter(result);
			CSVPrinter csvFilePrinter = new CSVPrinter(writer, csvFileFormat)) { 
			
			List<BrancheEntity> sortedBranches = cacheService.getBranches().stream().filter(b -> b.getParent() != null)
			.sorted((b1, b2) -> b1.getCode().compareTo(b2.getCode())).collect(Collectors.toList());
			
			// Create CSV file header
			generateStatistikCSVHeader(csvFilePrinter, sortedBranches);
			// Create CSV file content			
			generateStatistikCSVContent(csvFilePrinter, sortedBranches);
	        writer.flush();
		} catch (Exception e) {
			throw new OssTechnicalException("Technical error occurred while generating Statistik CSV file", e);
		} 
		
		return result.toByteArray();
	}

	@SuppressWarnings({"unchecked"})
	private void generateStatistikCSVContent(CSVPrinter csvFilePrinter, List<BrancheEntity> sortedBranches) throws IOException {
		
		List<Long> brancheIds = sortedBranches.stream().map(b -> b.getId()).collect(Collectors.toList());
		
		List<String> brancheProjections = new ArrayList<>();
		for (Long brancheId : brancheIds) {
			brancheProjections.add("CASE WHEN (SELECT ORGBRANCHE.LN_ORGANISATION "
				+ "FROM T_ORGANISATION_BRANCHE ORGBRANCHE "
				+ "WHERE ORGBRANCHE.LN_BRANCHE = " + brancheId + " AND ORGBRANCHE.LN_ORGANISATION = ORG.PK) IS NOT NULL THEN 1 ELSE 0 END "
				+ "as branch_" + brancheId);
		}
		
		String sql = STATISTIK_CSV_SQL.replace("%(language)", SecurityUtil.currentUser().getLanguagePreference().toString())
									  .replace("%(gesedent)", ProzessStatusEnum.GESENDET.toString())
									  .replace("%(hr)", ProzessTypEnum.HR.toString())
									  .replace("%(ahv)", ProzessTypEnum.AHV.toString())
									  .replace("%(mwst)", ProzessTypEnum.MWST.toString())
									  .replace("%(uvg)", ProzessTypEnum.UVG.toString())
									  .replace("%(branchesProjection)", StringUtils.join(brancheProjections, ", "));
		
		List<Object[]> resultList = em.createNativeQuery(sql).getResultList();
		
        for (Object[] dto : resultList) {
            csvFilePrinter.printRecord(dto);
		}
	}

	private void generateStatistikCSVHeader(CSVPrinter csvFilePrinter, List<BrancheEntity> sortedBranches) throws IOException {
		// Fix header
		SupportedLanguage lang = SecurityUtil.currentUser().getLanguagePreference();
		
		List<String> headerCodes = Lists.newArrayList(GUI_LABELS_STATISTIK_CSV_ERSTELL_DATUM, //Erstell Datum
			GUI_LABELS_STATISTIK_CSV_EMPFANGER, // Empfanger
			GUI_LABELS_STATISTIK_CSV_STRASSE, // Strasse
			GUI_LABELS_STATISTIK_CSV_NUMMER, // Nummer
			GUI_LABELS_STATISTIK_CSV_PLZ, // PLZ
			GUI_LABELS_STATISTIK_CSV_ORT, // Ort
			GUI_LABELS_STATISTIK_CSV_BFSNR, // BFSNr
			GUI_LABELS_STATISTIK_CSV_KANTON, // Kanton
			GUI_LABELS_STATISTIK_CSV_FIRMENNAME, // Firmenname
			GUI_LABELS_STATISTIK_CSV_RECHTSFORM, // Rechtsform
			GUI_LABELS_STATISTIK_CSV_BERUFSBEZEICHNUNG, // Berufsbezeichnung
			GUI_LABELS_STATISTIK_CSV_HR, // HR
			GUI_LABELS_STATISTIK_CSV_HR_DATUM, // HR Datum
			GUI_LABELS_STATISTIK_CSV_HR_DIGITAL, // HR Digital
			GUI_LABELS_STATISTIK_CSV_AHV, // AHV
			GUI_LABELS_STATISTIK_CSV_AHV_DATUM, // AHV Datum
			GUI_LABELS_STATISTIK_CSV_MWST, // MWST
			GUI_LABELS_STATISTIK_CSV_MWST_DATUM, // MWST Datum
			GUI_LABELS_STATISTIK_CSV_UVG, // UVG
			GUI_LABELS_STATISTIK_CSV_UVG_DATUM, // UVG Datum
			GUI_LABELS_STATISTIK_CSV_MINDESTENS_DIENST, // Mindestens bei 1 Dienst angemeldet
			GUI_LABELS_STATISTIK_CSV_MINDESTENS_DIENST_DATUM, // Datum erste Dienstanmeldung
			GUI_LABELS_STATISTIK_CSV_MINDESTENS_PROZESS, // Mindestens 1 Prozess abgeschlossen 
			GUI_LABELS_STATISTIK_CSV_MINDESTENS_PROZESS_DATUM); // Datum erster Prozess
		
		Map<String, String> translation = applicationService.getTranslation(headerCodes, lang);
		
		List<String> fixHeader = Lists.newArrayList(translation.get(GUI_LABELS_STATISTIK_CSV_ERSTELL_DATUM),  
			translation.get(GUI_LABELS_STATISTIK_CSV_EMPFANGER), 
			translation.get(GUI_LABELS_STATISTIK_CSV_STRASSE), 
			translation.get(GUI_LABELS_STATISTIK_CSV_NUMMER),
			translation.get(GUI_LABELS_STATISTIK_CSV_PLZ),
			translation.get(GUI_LABELS_STATISTIK_CSV_ORT),
			translation.get(GUI_LABELS_STATISTIK_CSV_BFSNR),
			translation.get(GUI_LABELS_STATISTIK_CSV_KANTON),
			translation.get(GUI_LABELS_STATISTIK_CSV_FIRMENNAME),
			translation.get(GUI_LABELS_STATISTIK_CSV_RECHTSFORM),
			translation.get(GUI_LABELS_STATISTIK_CSV_BERUFSBEZEICHNUNG),
			translation.get(GUI_LABELS_STATISTIK_CSV_HR),
			translation.get(GUI_LABELS_STATISTIK_CSV_HR_DATUM),
			translation.get(GUI_LABELS_STATISTIK_CSV_HR_DIGITAL),
			translation.get(GUI_LABELS_STATISTIK_CSV_AHV),
			translation.get(GUI_LABELS_STATISTIK_CSV_AHV_DATUM),
			translation.get(GUI_LABELS_STATISTIK_CSV_MWST),
			translation.get(GUI_LABELS_STATISTIK_CSV_MWST_DATUM),
			translation.get(GUI_LABELS_STATISTIK_CSV_UVG),
			translation.get(GUI_LABELS_STATISTIK_CSV_UVG_DATUM),
			translation.get(GUI_LABELS_STATISTIK_CSV_MINDESTENS_DIENST),
			translation.get(GUI_LABELS_STATISTIK_CSV_MINDESTENS_DIENST_DATUM),
			translation.get(GUI_LABELS_STATISTIK_CSV_MINDESTENS_PROZESS),
			translation.get(GUI_LABELS_STATISTIK_CSV_MINDESTENS_PROZESS_DATUM));
		
		SupportedLanguage currentLang = lang;
		
		List<String> branches = sortedBranches.stream().map(b -> b.getStandardText().getTranslations()
				.stream().filter(t -> t.getLanguage() == currentLang).findFirst().get().getText())
			.collect(Collectors.toList());
			
		CollectionUtils.addAll(fixHeader, branches.iterator());
		
        csvFilePrinter.printRecord(fixHeader);
	}
	
	private class ByteArrayOutputStreamWriter extends OutputStreamWriter {
		public ByteArrayOutputStreamWriter(ByteArrayOutputStream outputStream) throws UnsupportedEncodingException {
			super(outputStream, "UTF-8");
		}
	}
}
