/*
 * HrSaveType
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hr.endpoint;

/**
 * @author hha
 */
public enum HrSaveType {

	SAVE(true),
	COMPLETE(true),
	LOCK(false),
	SIGN(false),
	RELOCK(false);

	private boolean updateData;

	private HrSaveType(boolean updateData) {
		this.updateData = updateData;
	}

	public boolean isUpdateData() {
		return updateData;
	}
}
