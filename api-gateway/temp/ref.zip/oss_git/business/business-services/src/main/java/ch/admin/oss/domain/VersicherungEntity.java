/*
 * VersicherungEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.querydsl.core.annotations.QueryProjection;

/**
 * @author coh
 *
 */
@Entity
@Table(name = "T_VERSICHERUNG")
public class VersicherungEntity extends AbstractOSSEntity {
	
	@Column(name = "NAME_INTERN")
	private String nameIntern;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_STANDARD_TEXT", foreignKey = @ForeignKey(name="FK_VERSICHERUNG_TEXT"))
	private StandardTextEntity standardText;
	
	@Column(name = "POSTFACH")
	private String postfach;
	
	@Column(name = "STRASSE")
	private String strasse;
	
	@Column(name = "HAUSNUMMER")
	private String hausnummer;
	
	@Column(name = "PLZ")
	private String plz;
	
	@Column(name = "ORT")
	private String ort;
	
	@Column(name = "HOMEPAGE")
	private String homepage;
	
	@Column(name = "EMAIL_KUNDENANFRAGEN")
	private String emailKundenanfragen;
	
	@Column(name = "TELEFON")
	private String telefon;
	
	@Column(name = "FAX")
	private String fax;
	
	@Column(name = "EMAIL_DATENVERSAND")
	private String emailDatenversand;
	
	@Column(name = "MITGLIED_VERBAND", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean mitgliedVerband;
	
	@Column(name = "ANMELDUNG_MOEGLICH", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean anmeldungMoeglich;
	
	@Column(name = "KANTON")
	private String kanton;
	
	@Column(name = "SPRACHE")
	private String sprache;
	
	@Column(name = "AKTIV", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean aktiv;
	
	public VersicherungEntity() {
	}
	
	@QueryProjection
	public VersicherungEntity(Long id) {
		setId(id);
	}

	public VersicherungEntity(String postfach, String strasse, String hausnummer, String plz, String ort,
			String homepage, String emailKundenanfragen, String telefon, String fax, String emailDatenversand,
			boolean mitgliedVerband, boolean anmeldungMoeglich, String kanton, String sprache, boolean aktiv) {
		super();
		this.postfach = postfach;
		this.strasse = strasse;
		this.hausnummer = hausnummer;
		this.plz = plz;
		this.ort = ort;
		this.homepage = homepage;
		this.emailKundenanfragen = emailKundenanfragen;
		this.telefon = telefon;
		this.fax = fax;
		this.emailDatenversand = emailDatenversand;
		this.mitgliedVerband = mitgliedVerband;
		this.anmeldungMoeglich = anmeldungMoeglich;
		this.kanton = kanton;
		this.sprache = sprache;
		this.aktiv = aktiv;
	}

	public String getNameIntern() {
		return nameIntern;
	}

	public void setNameIntern(String nameIntern) {
		this.nameIntern = nameIntern;
	}

	public StandardTextEntity getStandardText() {
		return standardText;
	}

	public void setStandardText(StandardTextEntity standardText) {
		this.standardText = standardText;
	}

	public String getPostfach() {
		return postfach;
	}

	public void setPostfach(String postfach) {
		this.postfach = postfach;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getHausnummer() {
		return hausnummer;
	}

	public void setHausnummer(String hausnummer) {
		this.hausnummer = hausnummer;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getHomepage() {
		return homepage;
	}

	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}

	public String getEmailKundenanfragen() {
		return emailKundenanfragen;
	}

	public void setEmailKundenanfragen(String emailKundenanfragen) {
		this.emailKundenanfragen = emailKundenanfragen;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmailDatenversand() {
		return emailDatenversand;
	}

	public void setEmailDatenversand(String emailDatenversand) {
		this.emailDatenversand = emailDatenversand;
	}

	public boolean isMitgliedVerband() {
		return mitgliedVerband;
	}

	public void setMitgliedVerband(boolean mitgliedVerband) {
		this.mitgliedVerband = mitgliedVerband;
	}

	public boolean isAnmeldungMoeglich() {
		return anmeldungMoeglich;
	}

	public void setAnmeldungMoeglich(boolean anmeldungMoeglich) {
		this.anmeldungMoeglich = anmeldungMoeglich;
	}

	public String getKanton() {
		return kanton;
	}

	public void setKanton(String kanton) {
		this.kanton = kanton;
	}

	public String getSprache() {
		return sprache;
	}

	public void setSprache(String sprache) {
		this.sprache = sprache;
	}

	public boolean isAktiv() {
		return aktiv;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}
}
