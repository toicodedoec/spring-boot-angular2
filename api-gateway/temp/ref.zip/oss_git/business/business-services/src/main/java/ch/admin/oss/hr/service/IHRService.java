/*
 * IHRService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hr.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;

import ch.admin.oss.common.IProcessService;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.dto.PersonResultDto;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.FirmennameEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrAnmeldungEntity;
import ch.admin.oss.domain.HrGruenderEntity;

/**
 * @author coh
 *
 */
@Validated
public interface IHRService extends IProcessService<HrAnmeldungEntity> {

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	PersonResultDto<HrGruenderEntity, HrAnmeldungEntity> saveUnvalidatedHrGruender(long orgId, HrGruenderEntity ent);
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	PersonResultDto<HrGruenderEntity, HrAnmeldungEntity> saveValidatedHrGruender(long orgId, @Valid HrGruenderEntity ent);
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	PersonResultDto<HrGruenderEntity, HrAnmeldungEntity> deleteHrGruender(long orgId, HrGruenderEntity ent);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	PersonResultDto<GeschaftsrolleEntity, HrAnmeldungEntity> saveUnvalidatedGeschaftsrolle(long orgId, GeschaftsrolleEntity ent);
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	PersonResultDto<GeschaftsrolleEntity, HrAnmeldungEntity> saveValidatedGeschaftsrolle(long orgId, @Valid GeschaftsrolleEntity ent);
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	PersonResultDto<GeschaftsrolleEntity, HrAnmeldungEntity> deleteGeschaftsrolle(long orgId, GeschaftsrolleEntity ent);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrGruenderEntity getHrGruenderById(long orgId, long id, int version);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	FirmennameEntity saveFirmenname(Long orgId, FirmennameEntity ent);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	FirmennameEntity findFirmennameById(Long orgId, Long id);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	FileDto downloadDocument(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<AdresseEntity> getHrAdresseKorrespondenzByOrgId(long orgId);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	boolean isHrProcessCompleted(long orgId);
}
