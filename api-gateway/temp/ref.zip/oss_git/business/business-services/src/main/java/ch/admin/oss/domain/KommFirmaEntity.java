/*
 * KommFirmaEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;

import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author coh
 */
@Entity
@Table(name = "T_KOMM_FIRMA")
public class KommFirmaEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_KOMMGES", foreignKey = @ForeignKey(name = "FK_KOMM_FIRMA_KOMMGES"))
	private KommGesEntity kommges;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_DOMIZIL", foreignKey = @ForeignKey(name = "FK_KOMM_FIRMA_ADRESSE"))
	private AdresseEntity domizil;

	@Column(name = "HAFTUNG")
	private BigDecimal haftung;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_EINLAGE", foreignKey = @ForeignKey(name = "FK_KOMM_FIRMA_CODE_WERT"))
	private CodeWertEntity einlage;

	@Column(name = "RECHTSFORM_CH")
	@Enumerated(EnumType.STRING)
	private RechtsformEnum rechtsformCH;

	@Column(name = "RECHTSFORM_AUSLAND")
	private String rechtsformAusland;

	@Column(name = "NAME")
	private String name;

	@Column(name = "HR_NUMMER")
	private String hrNummer;

	@Column(name = "COMPLETE", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean complete;

	@Column(name = "DELETED", length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean delete = false;

	public KommGesEntity getKommges() {
		return kommges;
	}

	public void setKommges(KommGesEntity kommges) {
		this.kommges = kommges;
	}

	public AdresseEntity getDomizil() {
		return domizil;
	}

	public void setDomizil(AdresseEntity domizil) {
		this.domizil = domizil;
	}

	public BigDecimal getHaftung() {
		return haftung;
	}

	public void setHaftung(BigDecimal haftung) {
		this.haftung = haftung;
	}

	public CodeWertEntity getEinlage() {
		return einlage;
	}

	public void setEinlage(CodeWertEntity einlage) {
		this.einlage = einlage;
	}

	public RechtsformEnum getRechtsformCH() {
		return rechtsformCH;
	}

	public void setRechtsformCH(RechtsformEnum rechtsformCH) {
		this.rechtsformCH = rechtsformCH;
	}

	public String getRechtsformAusland() {
		return rechtsformAusland;
	}

	public void setRechtsformAusland(String rechtsformAusland) {
		this.rechtsformAusland = rechtsformAusland;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHrNummer() {
		return hrNummer;
	}

	public void setHrNummer(String hrNummer) {
		this.hrNummer = hrNummer;
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	public boolean isDelete() {
		return delete;
	}

	public void setDelete(boolean delete) {
		this.delete = delete;
	}

	public void copyFrom(KommFirmaEntity entityToCopy) {
		setDelete(entityToCopy.isDelete());
		domizil.copyFrom(entityToCopy.getDomizil());
		setComplete(entityToCopy.isComplete());
		setEinlage(entityToCopy.getEinlage());
		setHaftung(entityToCopy.getHaftung());
		setHrNummer(entityToCopy.getHrNummer());
		setName(entityToCopy.getName());
		setRechtsformAusland(entityToCopy.getRechtsformAusland());
		setRechtsformCH(entityToCopy.getRechtsformCH());
	}
}
