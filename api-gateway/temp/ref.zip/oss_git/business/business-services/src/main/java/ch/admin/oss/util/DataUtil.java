/*
 * DataUtil
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collection;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;

import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.PersonHeimatortEntity;

/**
 * @author hha
 */
public class DataUtil {
	
	private static final String NESTED_SEPARATOR = " ";
	private static final String ROW_SEPARATOR = ", ";

	public static String formatAddress(AdresseEntity entity, SupportedLanguage language) {
		if (entity == null) {
			return StringUtils.EMPTY;
		}
		
		String land = "";
		if (entity.getLand() != null && entity.getLand().getStandardText() != null
			&& !OSSConstants.SWISS_CODE_WERT.equals(entity.getLand().getCode())) {
			land = entity.getLand().getStandardText().textTranslation(language);
		}
		
		return joinStrings(ROW_SEPARATOR,
			joinStrings(NESTED_SEPARATOR, entity.getStrasse(), entity.getHausnummer()),
			entity.getZusatz(),
			entity.getPostfach(),
			joinStrings(NESTED_SEPARATOR, entity.getPlz(), entity.getOrt()),
			land
		);
	}

	public static String formatAddressWithName(AdresseEntity entity, SupportedLanguage language) {
		if (entity == null) {
			return StringUtils.EMPTY;
		}
		return joinStrings(ROW_SEPARATOR,
			entity.getEmpfaenger(),
			formatAddress(entity, language)
		);
	}
	
	public static String formatHeimatorte(Collection<PersonHeimatortEntity> items) {
		if (CollectionUtils.isEmpty(items)) {
			return StringUtils.EMPTY; 
		}
		return joinStrings("; ", items.stream()
			.map(item -> {
				return item.getPolGemeinde() + " (" + item.getKanton() + ")";
			})
			.distinct()
			.toArray(size -> new String[size])
		);
	}
	
 	public static String joinStrings(String separator, String... values) {
		return StringUtils.join(Arrays.stream(values)
			.filter(item -> StringUtils.isNotBlank(item))
			.toArray(), separator);
	}
 	
 	public static String removeDiacritic(String s){
 		return StringUtils.stripAccents(s).replaceAll("\\u00D0", "D").replaceAll("\\u00F0", "d");
 	}

 	public static String getUID(LocalDateTime date) {
 		// Return the date and a random number with 10 digits.
 		return OSSDateUtil.formatForUID(date) + ":" + RandomUtils.nextLong(1_000_000_000L, 10_000_000_000L);
 	}

	private DataUtil() {
		// Do nothing
	}
	
}
