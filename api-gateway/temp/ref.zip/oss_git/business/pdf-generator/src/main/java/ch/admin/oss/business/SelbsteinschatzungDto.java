/*
 * SelbsteinschätzungDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * @author hhg
 *
 */
public class SelbsteinschatzungDto {

	private BigDecimal income;
	private BigDecimal ownCapital;
	private BigDecimal debt;
	private LocalDate from;
	private LocalDate to;
	
	public SelbsteinschatzungDto(BigDecimal income, BigDecimal ownCapital, BigDecimal debt, LocalDate from,
		LocalDate to) {
		this.income = income;
		this.ownCapital = ownCapital;
		this.debt = debt;
		this.from = from;
		this.to = to;
	}

	public BigDecimal getIncome() {
		return income;
	}

	public BigDecimal getOwnCapital() {
		return ownCapital;
	}

	public BigDecimal getDebt() {
		return debt;
	}

	public LocalDate getFrom() {
		return from;
	}

	public LocalDate getTo() {
		return to;
	}
}
