/*
 * MwstEintrBestDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.mwst.endpoint;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.CommonAddress;
import ch.admin.oss.common.ProzessDto;

/**
 * @author xdg
 */
public class MwstEintrBestDto extends AbstractOSSDto {

	private ProzessDto prozess;

	@NotNull
	private String mwstNr;

	@NotNull
	private String name;

	@Valid
	@NotNull(groups = {CommonAddress.class, MwstEintrBestAddress.class})
	private AdresseDto adresse;

	@NotNull
	private String branche;

	private BigDecimal jahr;

	@Valid
	@NotNull(groups = CommonAddress.class)
	private AdresseDto zustellAdresse;

	private String bemerkungen;

	private Boolean apostille = false;

	// ref data

	private MwstDomizilCollectionDto refDomizilData;

	private List<Integer> jahren;

	public List<Integer> getJahren() {
		return jahren;
	}

	public void setJahren(List<Integer> jahren) {
		this.jahren = jahren;
	}

	public MwstEintrBestDto() {}

	public ProzessDto getProzess() {
		return prozess;
	}

	public void setProzess(ProzessDto prozess) {
		this.prozess = prozess;
	}

	public String getMwstNr() {
		return mwstNr;
	}

	public void setMwstNr(String mwstNr) {
		this.mwstNr = mwstNr;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AdresseDto getAdresse() {
		return adresse;
	}

	public void setAdresse(AdresseDto adresse) {
		this.adresse = adresse;
	}

	public String getBranche() {
		return branche;
	}

	public void setBranche(String branche) {
		this.branche = branche;
	}

	public BigDecimal getJahr() {
		return jahr;
	}

	public void setJahr(BigDecimal jahr) {
		this.jahr = jahr;
	}

	public AdresseDto getZustellAdresse() {
		return zustellAdresse;
	}

	public void setZustellAdresse(AdresseDto zustellAdresse) {
		this.zustellAdresse = zustellAdresse;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public Boolean getApostille() {
		return apostille;
	}

	public void setApostille(Boolean apostille) {
		this.apostille = apostille;
	}

	public MwstDomizilCollectionDto getRefDomizilData() {
		return refDomizilData;
	}

	public void setRefDomizilData(MwstDomizilCollectionDto refDomizilData) {
		this.refDomizilData = refDomizilData;
	}

}
