package ch.admin.oss.portal.endpoint;

import java.util.ArrayList;
import java.util.List;

public class OrganisationProcessesDto extends AbstractPaginationDashboardDto {
	private List<ActivityDto> processes;
	
	public OrganisationProcessesDto() {
		this.processes = new ArrayList<>();
	}

	public List<ActivityDto> getProcesses() {
		return processes;
	}

	public void setProcesses(List<ActivityDto> processes) {
		this.processes = processes;
	}

}
