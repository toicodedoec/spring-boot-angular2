/*
 * RevisionEntityListener
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import org.hibernate.envers.RevisionListener;

import ch.admin.oss.domain.RevisionEntity;
import ch.admin.oss.security.SecurityUtil;

/**
 * @author phd
 *
 */
public class RevisionEntityListener implements RevisionListener {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void newRevision(Object revisionEntity) {
		RevisionEntity.class.cast(revisionEntity).setChangedBy(SecurityUtil.currentUser().getUsername());
	}
}
