/*
 * CodeWertCriteriaDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.util.List;

import ch.admin.oss.common.enums.KategorieEnum;

/**
 * @author coh
 */
public class CodeWertCriteriaDto {

	private KategorieEnum kategorie;
	private List<String> codes;
	private SupportedLanguage language;

	public KategorieEnum getKategorie() {
		return kategorie;
	}

	public void setKategorie(KategorieEnum kategorie) {
		this.kategorie = kategorie;
	}

	public List<String> getCodes() {
		return codes;
	}

	public void setCodes(List<String> codes) {
		this.codes = codes;
	}

	public SupportedLanguage getLanguage() {
		return language;
	}

	public void setLanguage(SupportedLanguage language) {
		this.language = language;
	}
}
