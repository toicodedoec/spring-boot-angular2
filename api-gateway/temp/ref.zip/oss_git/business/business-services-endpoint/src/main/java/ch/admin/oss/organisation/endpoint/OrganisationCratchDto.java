/*
 * OrganisationCratchDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.organisation.endpoint;

/**
 * @author xdg
 */
public class OrganisationCratchDto {
	private String orgName;
	private boolean isConnectToDuty;

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public boolean isConnectToDuty() {
		return isConnectToDuty;
	}

	public void setConnectToDuty(boolean isConnectToDuty) {
		this.isConnectToDuty = isConnectToDuty;
	}
}
