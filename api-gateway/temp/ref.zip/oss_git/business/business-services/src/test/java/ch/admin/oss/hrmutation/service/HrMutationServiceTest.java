/*
 * HrMutationServiceTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.service;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.business.AbstractOSSTest;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.common.enums.HrMutationPersonTypeOfChangeEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.NatTypEnum;
import ch.admin.oss.common.enums.OrganisationCreationTypeEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrMutationEntity;
import ch.admin.oss.domain.HrMutationPersonEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PersonHeimatortEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.hrmutation.repository.IHrMutationRepository;
import ch.admin.oss.organisation.repository.IOrganisationRepository;
import ch.admin.oss.portal.repository.IProzessRepository;

/**
 * @author coh
 *
 */
@ActiveProfiles(CommonConstants.PROFILE_TEST)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Transactional
public class HrMutationServiceTest extends AbstractOSSTest {
	
	@Autowired
	private IOrganisationRepository orgRepo;
	
	@Autowired
	private IProzessRepository prozessRepo;
	
	@Autowired
	private IHrMutationService hrMutationService;
	
	@Autowired
	private IHrMutationRepository hrMutationRepository;
	
	@Test
	public void testHRMutationPDFGenerate() throws IOException {
		OrganisationEntity organisation = new OrganisationEntity();
		organisation.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		organisation.setRechtsform(RechtsformEnum.KOLLGES);
		organisation.setUid(UUID.randomUUID().toString());
		AdresseEntity domizil = new AdresseEntity();
		domizil.setBfsNr(3668);
		organisation.setDomizil(domizil);
		organisation = orgRepo.save(organisation);
	
		ProzessEntity prozessEntity = new ProzessEntity();
		prozessEntity.setUid(UUID.randomUUID().toString());
		prozessEntity.setOrganisation(organisation);
		prozessEntity = prozessRepo.save(prozessEntity);
		
		HrMutationEntity entity = new HrMutationEntity();
		entity.setOldCompanyName("oldCompanyName");
		entity.setOldDomicile(createAdresse("oldDomicile"));
		entity.setProzess(prozessEntity);
		
		prepareHrMutationTaskName(entity);
		prepareHrMutationTaskAddress(entity);
		prepareHrMutationTaskPurpose(entity);
		prepareHrMutationPerson(entity);
		prepareHrMutationTaskDissolution(entity);
		prepareHrMutationTaskRevision(entity);
		prepareHrMutationTaskExcerpts(entity);
		
		entity = hrMutationRepository.save(entity);
		
		byte[] generateDocument = hrMutationService.generateDocument(entity, false);
		
		File pdf = new File("hrMutation" + UUID.randomUUID().toString() + ".pdf");
		FileUtils.writeByteArrayToFile(pdf, generateDocument);
	}

	private void prepareHrMutationTaskExcerpts(HrMutationEntity entity) {
		entity.setTaskExcerpts(true);
		entity.setExcerptsNum(10);
		entity.setExcerptsNumPrelim(10);
		entity.setExcerptsDeliveryAddress(createAdresse("setExcerptsDeliveryAddress"));
		entity.setExcerptsBillingAddress(createAdresse("setExcerptsBillingAddress"));
	}

	private void prepareHrMutationTaskRevision(HrMutationEntity entity) {
		entity.setTaskRevision(true);
		entity.setRevCompanyName("setRevCompanyName");
		entity.setRevPreviousSeatCity("setRevPreviousSeatCity");
		entity.setRevPreviousSeatPolCommunity("setRevPreviousSeatPolCommunity");
		entity.setRevPreviousSeatCanton("setRevPreviousSeatCanton");
		entity.setRevNewSeatCity("setRevNewSeatCity");
		entity.setRevNewSeatPolCommunity("setRevNewSeatPolCommunity");
		entity.setRevNewSeatCanton("setRevNewSeatCanton");
	}

	private void prepareHrMutationTaskDissolution(HrMutationEntity entity) {
		entity.setTaskDissolution(true);
		entity.setDissLeavingPartnerGivenName("DissLeavingPartnerGivenName");
		entity.setDissLeavingPartnerFamilyName("setDissLeavingPartnerFamilyName");
		entity.setDissLeavingPartnerBirthday(LocalDate.now());
		entity.setDissNewOwner(createGeschaftsrolleEntity(null, 0));
		entity.setDissNewCompanyName("setDissNewCompanyName");
	}

	private void prepareHrMutationPerson(HrMutationEntity entity) {
		putNaturalPerson(entity, HrMutationPersonTypeOfChangeEnum.ADD);
		putNaturalPerson(entity, HrMutationPersonTypeOfChangeEnum.ADD);
		putNaturalPerson(entity, HrMutationPersonTypeOfChangeEnum.UPDATE);
		putNaturalPerson(entity, HrMutationPersonTypeOfChangeEnum.UPDATE);
		putNaturalPerson(entity, HrMutationPersonTypeOfChangeEnum.DELETE);
		putNaturalPerson(entity, HrMutationPersonTypeOfChangeEnum.DELETE);
		putNaturalPerson(entity, HrMutationPersonTypeOfChangeEnum.DELETE);
		
		putLegalPerson(entity, HrMutationPersonTypeOfChangeEnum.ADD, getSwissLand());
		putLegalPerson(entity, HrMutationPersonTypeOfChangeEnum.ADD, 
			applicationService.getCodeWerts(KategorieEnum.LAND).stream().filter(l -> l.getCode().equals("8545")).findFirst().get());
		putLegalPerson(entity, HrMutationPersonTypeOfChangeEnum.UPDATE, getSwissLand());
		putLegalPerson(entity, HrMutationPersonTypeOfChangeEnum.UPDATE, 
			applicationService.getCodeWerts(KategorieEnum.LAND).stream().filter(l -> l.getCode().equals("8545")).findFirst().get());
		putLegalPerson(entity, HrMutationPersonTypeOfChangeEnum.DELETE, getSwissLand());
		putLegalPerson(entity, HrMutationPersonTypeOfChangeEnum.DELETE, getSwissLand());
		putLegalPerson(entity, HrMutationPersonTypeOfChangeEnum.DELETE, 
			applicationService.getCodeWerts(KategorieEnum.LAND).stream().filter(l -> l.getCode().equals("8545")).findFirst().get());
	}

	private void prepareHrMutationTaskPurpose(HrMutationEntity entity) {
		entity.setTaskPurpose(true);
		entity.setNewPurpose("newPurpose");
	}

	private void prepareHrMutationTaskAddress(HrMutationEntity entity) {
		entity.setTaskAddress(true);
		entity.setNewDomicile(createAdresse("new Domicile"));
	}

	private void prepareHrMutationTaskName(HrMutationEntity entity) {
		entity.setTaskName(true);
		entity.setNewCompanyName("newCompanyName");
	}
	
	private void putLegalPerson(HrMutationEntity mutationEntity, HrMutationPersonTypeOfChangeEnum type, CodeWertEntity land) {
		HrMutationPersonEntity hrMutationPersonEntity = new HrMutationPersonEntity();
		hrMutationPersonEntity.setHrMutation(mutationEntity);
		HrMutationTypeOfPersonEnum legal = HrMutationTypeOfPersonEnum.LEGAL;
		hrMutationPersonEntity.setTypeOfPerson(legal);
		hrMutationPersonEntity.setTypeOfChange(type);
		
		long index = mutationEntity.getPersons().stream()
			.filter(p -> p.getTypeOfPerson() == legal && p.getTypeOfChange() == type).count();
		
		if (type == HrMutationPersonTypeOfChangeEnum.UPDATE 
			|| type == HrMutationPersonTypeOfChangeEnum.DELETE) {
			hrMutationPersonEntity.setPrevCompanyName(type + "prevCompanyName" + index);
			hrMutationPersonEntity.setPrevLegalForm(type + "prevLegalForm" + index);
			hrMutationPersonEntity.setPrevCity(type + "prevCity" + index);
		}
		
		KommFirmaEntity kommFirmaEntity = new KommFirmaEntity();
		kommFirmaEntity.setName(type + "name" + index);
		kommFirmaEntity.setDomizil(createAdresse(type + "strasse" + index, land));
		kommFirmaEntity.setRechtsformAusland("rechtsformAusland");
		kommFirmaEntity.setRechtsformCH(RechtsformEnum.EINZELFIRMA);
		kommFirmaEntity.setHaftung(BigDecimal.valueOf(10000));
		kommFirmaEntity.setEinlage(applicationService.getCodeWerts(KategorieEnum.EINLAGE).get(0));
		hrMutationPersonEntity.setNewLegalPerson(kommFirmaEntity);
		mutationEntity.getPersons().add(hrMutationPersonEntity);
	}
	
	private void putNaturalPerson(HrMutationEntity mutationEntity, HrMutationPersonTypeOfChangeEnum type) {
		HrMutationPersonEntity hrMutationPersonEntity = new HrMutationPersonEntity();
		hrMutationPersonEntity.setHrMutation(mutationEntity);
		HrMutationTypeOfPersonEnum natural = HrMutationTypeOfPersonEnum.NATURAL;
		hrMutationPersonEntity.setTypeOfPerson(natural);
		hrMutationPersonEntity.setTypeOfChange(type);
		
		long index = mutationEntity.getPersons().stream()
			.filter(p -> p.getTypeOfPerson() == natural && p.getTypeOfChange() == type).count();
		
		if (type == HrMutationPersonTypeOfChangeEnum.UPDATE
			|| type == HrMutationPersonTypeOfChangeEnum.DELETE) {
			hrMutationPersonEntity.setPrevFamilyName(type + "prevFamilyName" + index);
			hrMutationPersonEntity.setPrevGivenName(type + "prevGivenName" + index);
			hrMutationPersonEntity.setPrevBirthday(LocalDate.now());
		}
		
		GeschaftsrolleEntity geschaftsrolleEntity = createGeschaftsrolleEntity(type, index);
		
		hrMutationPersonEntity.setNewNaturalPerson(geschaftsrolleEntity);
		mutationEntity.getPersons().add(hrMutationPersonEntity);
	}

	private GeschaftsrolleEntity createGeschaftsrolleEntity(HrMutationPersonTypeOfChangeEnum type, long index) {
		GeschaftsrolleEntity geschaftsrolleEntity = new GeschaftsrolleEntity();
		PersonEntity person = new PersonEntity();
		person.setFamilienname(type + "familienname" + index);
		person.setLedigname(type + "ledigname" + index);
		person.setVorname(type + "vorname" + index);
		person.setVornamenliste(type + "vornamenliste" + index);
		person.setTitel(type + "titel" + index);
		person.setGeburtsdatum(LocalDate.now());
		person.setNatType(NatTypEnum.CH);
		
		PersonHeimatortEntity personHeimatortEntity = new PersonHeimatortEntity();
		personHeimatortEntity.setPerson(person);
		personHeimatortEntity.setPolGemeinde(type + "polGemeinde 1" + index);
		person.getHeimatortes().add(personHeimatortEntity);
		personHeimatortEntity = new PersonHeimatortEntity();
		personHeimatortEntity.setPerson(person);
		personHeimatortEntity.setPolGemeinde(type + "polGemeinde 2" + index);
		person.getHeimatortes().add(personHeimatortEntity);
		
		person.getNationalitaetens().addAll(new HashSet<>(applicationService.getCodeWerts(KategorieEnum.LAND)));
		person.setAuslaenderAusweis(applicationService.getCodeWerts(KategorieEnum.AUSLAUSWEIS).get(0));
		person.setEinreisedatum(LocalDate.now());
		
		person.setWohnadresse(createAdresse("Wohnadresse"));
		
		geschaftsrolleEntity.setPerson(person);
		geschaftsrolleEntity.setHaftung(applicationService.getCodeWerts(KategorieEnum.HAFTUNG).get(0));
		geschaftsrolleEntity.setHaftungCHF(BigDecimal.valueOf(10000));
		geschaftsrolleEntity.setEinlage(applicationService.getCodeWerts(KategorieEnum.EINLAGE).get(0));
		geschaftsrolleEntity.setFunktion(applicationService.getCodeWerts(KategorieEnum.FUNKTION).get(0));
		geschaftsrolleEntity.setZeichnung(applicationService.getCodeWerts(KategorieEnum.ZEICHNUNG).get(0));
		geschaftsrolleEntity.setNurHauptsitz(false);
		return geschaftsrolleEntity;
	}
	
	private AdresseEntity createAdresse(String strasse) {
		return createAdresse(strasse, getSwissLand());
	}
	
	private AdresseEntity createAdresse(String strasse, CodeWertEntity land) {
		AdresseEntity address = new AdresseEntity();
		address.setStrasse(strasse);
		address.setHausnummer("new hausnummer");
		address.setZusatz("new zusatz");
		address.setPostfach("new Postfach");
		address.setPlz("new plz");
		address.setOrt("new ort");
		address.setPolGemeinde("new polGemeinde");
		address.setKanton("new kanton");
		address.setTelefon("new telefon");
		address.setMobile("new mobile");
		address.setFax("new fax");
		address.setEmail("new email");
		address.setBfsNr(3668);
		address.setLand(land);
		return address;
	}
}