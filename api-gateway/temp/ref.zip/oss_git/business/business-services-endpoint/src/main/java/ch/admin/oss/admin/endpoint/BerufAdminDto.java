/*
 * BerufAdminDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.HREPflichtEnum;

/**
 * @author xdg
 */
public class BerufAdminDto extends AbstractGruppeDto {

	@NotNull
	private String code;

	@NotNull
	private boolean aktiv;

	@NotNull
	private boolean handel;
	private Long brancheId;
	
	@NotNull
	private HREPflichtEnum hrePflicht;
	
	@Valid
	@NotNull
	private StandardTextDto standardText;

	public BerufAdminDto() {}

	public boolean isAktiv() {
		return aktiv;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public boolean isHandel() {
		return handel;
	}

	public void setHandel(boolean handel) {
		this.handel = handel;
	}

	public Long getBrancheId() {
		return brancheId;
	}

	public void setBrancheId(Long brancheId) {
		this.brancheId = brancheId;
	}

	public HREPflichtEnum getHrePflicht() {
		return hrePflicht;
	}

	public void setHrePflicht(HREPflichtEnum hrePflicht) {
		this.hrePflicht = hrePflicht;
	}

	public StandardTextDto getStandardText() {
		return standardText;
	}

	public void setStandardText(StandardTextDto standardText) {
		this.standardText = standardText;
	}

}
