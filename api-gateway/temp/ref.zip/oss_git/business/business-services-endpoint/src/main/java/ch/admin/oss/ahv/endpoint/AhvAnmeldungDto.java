/*
 * AhvAnmeldungDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.ahv.endpoint;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import ch.admin.oss.admin.endpoint.AusgleichskasseDto;
import ch.admin.oss.admin.endpoint.VerbandDto;
import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.AbstractPersonRoleDto;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.OwnerInfoDto;
import ch.admin.oss.common.ProzessDto;
import ch.admin.oss.common.enums.AhvGruendungsartEnum;
import ch.admin.oss.common.enums.AhvUebernahmeEnum;
import ch.admin.oss.common.enums.AhvVerbandszugehoerigkeitEnum;
import ch.admin.oss.common.enums.AnmeldungHRBefundEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyDetailedInfoDto;
import ch.admin.oss.hr.endpoint.EditingState;

/**
 * @author hhg
 *
 */
public class AhvAnmeldungDto extends AbstractOSSDto {

	@NotNull
	private HRStatusEnum zefixStatus;

	@NotNull
	private AhvVerbandszugehoerigkeitEnum verbandZugehoerigkeit;

	@NotNull
	private AhvGruendungsartEnum gruendArt;

	@Min(0)
	@NotNull
	private BigDecimal kapitalEigen;

	@Min(0)
	@NotNull
	private Integer taetigAnzKunden;

	@NotNull
	private ProzessDto prozess;

	private Date verbandBeitrittDatum;
	private Long verbandId;
	private VerbandDto verbandDto;
	private AusgleichskasseDto ausgleichskasseDto;
	private boolean verbandFak = true;	
	private String zefixCompanyName;
	private String zefixPolGemeinde;
	private String zefixChNr;
	private String zefixUid;
	private String zefixShabNr;
	private Date zefixShabDate;
	private AnmeldungHRBefundEnum hrRegistrationStatus;
	private CompanyDetailedInfoDto importData;
	private BigDecimal kapitalDarlehen;
	private BigDecimal investWerkzeugKauf;
	private BigDecimal investFahrzeugKauf;
	private BigDecimal investWarenInvKauf;	
	private String investWeitereKaufArt;	
	private BigDecimal investWeitereKauf;
	private BigDecimal investBueroMiete;
	private BigDecimal investLadenMiete;
	private BigDecimal investWerkstattMiete;
	private BigDecimal investLagerMiete;
	private BigDecimal investFahrzeugMiete;
	private String investWeitereMieteArt;
	private BigDecimal investWeitereMiete;
	private Boolean raumKeine;
	private Boolean raumEigene;
	private Boolean raumWohnung;
	private Boolean raumKunde;
	private String gruendAlteBezeichnung;	
	private AhvUebernahmeEnum gruendUebernameArt;
	private String gruendUebernameName;
	private String gruendUebernameNummer;	
	private BigDecimal angestellteVrHonorare;
	private Integer angestellteGiAnz;
	private BigDecimal angestellteGiLohnSumme;
	private Date angestellteGiLohnSeit;
	private Boolean angestellteGiHatKinder;
	private Integer angestellteAngAnz;
	private BigDecimal angestellteAngLohnSumme;
	private Date angestellteAngLohnSeit;
	private Boolean angestellteAngHatKinder;
	private Integer angestellteUebAnz;
	private BigDecimal angestellteUebLohnSumme;
	private Date angestellteUebLohnSeit;
	private Boolean angestellteUebHatKinder;
	private String taetigKunde1;
	private String taetigKunde2;
	private String taetigKunde3;
	private String taetigArtAuftraege;
	private Date taetigDatumLetzterAuftrag;
	private Boolean taetigAgent;
	private String taetigAuftraggeber;
	private Boolean taetigGemeinsameKunden;
	private String sozialversUvg;
	private Boolean sozialversBvg;
	private String sozialversBvgName;
	private String sozialversBvgGrund;
	private Boolean lohnbuchPapier;
	private Boolean lohnbuchComputer;
	private Boolean lohnbuchSuva;
	private Boolean lohnbuchTreuhaender;
	private List<AhvFilialeDto> ahvFiliales = new ArrayList<>();
	private List<AhvTeilhaberDto> ahvTeilhabers = new ArrayList<>();
	private AhvTeilhaberDto teilhaberSelected;
	private AdresseDto adresseTreuhand;
	private AdresseDto adresseKontakt;
	private String kontaktVorname;
	private String kontaktFamilienname;
	private String kontaktTelefon;
	private String kontaktMobile;
	private String kontaktEmail;
	private String kontaktBemerkungen;
	private Boolean sonderPartnerWeb;
	private Boolean sonderVerband;
	private Boolean sonderBvg;
	private Boolean sonderUvg;
	private Boolean sonderKkv;
	private Boolean sonderWeitere;
	private Integer sonderFormulare;
	private EditingState editingState;
	
	private OwnerInfoDto<AbstractPersonRoleDto> selectedOwner;
	
	public OwnerInfoDto<AbstractPersonRoleDto> getSelectedOwner() {
		return selectedOwner;
	}

	public void setSelectedOwner(OwnerInfoDto<AbstractPersonRoleDto> selectedOwner) {
		this.selectedOwner = selectedOwner;
	}

	public Long getVerbandId() {
		return verbandId;
	}

	public void setVerbandId(Long verbandId) {
		this.verbandId = verbandId;
	}

	public Date getVerbandBeitrittDatum() {
		return verbandBeitrittDatum;
	}

	public void setVerbandBeitrittDatum(Date verbandBeitrittDatum) {
		this.verbandBeitrittDatum = verbandBeitrittDatum;
	}	

	public AhvVerbandszugehoerigkeitEnum getVerbandZugehoerigkeit() {
		return verbandZugehoerigkeit;
	}

	public void setVerbandZugehoerigkeit(AhvVerbandszugehoerigkeitEnum verbandZugehoerigkeit) {
		this.verbandZugehoerigkeit = verbandZugehoerigkeit;
	}

	public ProzessDto getProzess() {
		return prozess;
	}

	public void setProzess(ProzessDto prozess) {
		this.prozess = prozess;
	}

	public boolean isVerbandFak() {
		return verbandFak;
	}

	public void setVerbandFak(boolean verbandFak) {
		this.verbandFak = verbandFak;
	}

	public AnmeldungHRBefundEnum getHrRegistrationStatus() {
		return hrRegistrationStatus;
	}

	public void setHrRegistrationStatus(AnmeldungHRBefundEnum hrRegistrationStatus) {
		this.hrRegistrationStatus = hrRegistrationStatus;
	}

	public CompanyDetailedInfoDto getImportData() {
		return importData;
	}

	public void setImportData(CompanyDetailedInfoDto importData) {
		this.importData = importData;
	}

	public String getZefixCompanyName() {
		return zefixCompanyName;
	}

	public void setZefixCompanyName(String zefixCompanyName) {
		this.zefixCompanyName = zefixCompanyName;
	}

	public String getZefixPolGemeinde() {
		return zefixPolGemeinde;
	}

	public void setZefixPolGemeinde(String zefixPolGemeinde) {
		this.zefixPolGemeinde = zefixPolGemeinde;
	}

	public String getZefixChNr() {
		return zefixChNr;
	}

	public void setZefixChNr(String zefixChNr) {
		this.zefixChNr = zefixChNr;
	}

	public String getZefixShabNr() {
		return zefixShabNr;
	}

	public void setZefixShabNr(String zefixShabNr) {
		this.zefixShabNr = zefixShabNr;
	}

	public Date getZefixShabDate() {
		return zefixShabDate;
	}

	public void setZefixShabDate(Date zefixShabDate) {
		this.zefixShabDate = zefixShabDate;
	}

	public HRStatusEnum getZefixStatus() {
		return zefixStatus;
	}

	public void setZefixStatus(HRStatusEnum zefixStatus) {
		this.zefixStatus = zefixStatus;
	}

	public String getZefixUid() {
		return zefixUid;
	}

	public void setZefixUid(String zefixUid) {
		this.zefixUid = zefixUid;
	}

	public String getGruendAlteBezeichnung() {
		return gruendAlteBezeichnung;
	}

	public void setGruendAlteBezeichnung(String gruendAlteBezeichnung) {
		this.gruendAlteBezeichnung = gruendAlteBezeichnung;
	}

	public AhvGruendungsartEnum getGruendArt() {
		return gruendArt;
	}

	public void setGruendArt(AhvGruendungsartEnum gruendArt) {
		this.gruendArt = gruendArt;
	}

	public AhvUebernahmeEnum getGruendUebernameArt() {
		return gruendUebernameArt;
	}

	public void setGruendUebernameArt(AhvUebernahmeEnum gruendUebernameArt) {
		this.gruendUebernameArt = gruendUebernameArt;
	}

	public String getGruendUebernameName() {
		return gruendUebernameName;
	}

	public void setGruendUebernameName(String gruendUebernameName) {
		this.gruendUebernameName = gruendUebernameName;
	}

	public String getGruendUebernameNummer() {
		return gruendUebernameNummer;
	}

	public void setGruendUebernameNummer(String gruendUebernameNummer) {
		this.gruendUebernameNummer = gruendUebernameNummer;
	}

	public BigDecimal getKapitalEigen() {
		return kapitalEigen;
	}

	public void setKapitalEigen(BigDecimal kapitalEigen) {
		this.kapitalEigen = kapitalEigen;
	}

	public BigDecimal getKapitalDarlehen() {
		return kapitalDarlehen;
	}

	public void setKapitalDarlehen(BigDecimal kapitalDarlehen) {
		this.kapitalDarlehen = kapitalDarlehen;
	}

	public BigDecimal getInvestWerkzeugKauf() {
		return investWerkzeugKauf;
	}

	public void setInvestWerkzeugKauf(BigDecimal investWerkzeugKauf) {
		this.investWerkzeugKauf = investWerkzeugKauf;
	}

	public BigDecimal getInvestFahrzeugKauf() {
		return investFahrzeugKauf;
	}

	public void setInvestFahrzeugKauf(BigDecimal investFahrzeugKauf) {
		this.investFahrzeugKauf = investFahrzeugKauf;
	}

	public BigDecimal getInvestWarenInvKauf() {
		return investWarenInvKauf;
	}

	public void setInvestWarenInvKauf(BigDecimal investWarenInvKauf) {
		this.investWarenInvKauf = investWarenInvKauf;
	}

	public String getInvestWeitereKaufArt() {
		return investWeitereKaufArt;
	}

	public void setInvestWeitereKaufArt(String investWeitereKaufArt) {
		this.investWeitereKaufArt = investWeitereKaufArt;
	}

	public BigDecimal getInvestWeitereKauf() {
		return investWeitereKauf;
	}

	public void setInvestWeitereKauf(BigDecimal investWeitereKauf) {
		this.investWeitereKauf = investWeitereKauf;
	}

	public BigDecimal getInvestBueroMiete() {
		return investBueroMiete;
	}

	public void setInvestBueroMiete(BigDecimal investBueroMiete) {
		this.investBueroMiete = investBueroMiete;
	}

	public BigDecimal getInvestLadenMiete() {
		return investLadenMiete;
	}

	public void setInvestLadenMiete(BigDecimal investLadenMiete) {
		this.investLadenMiete = investLadenMiete;
	}

	public BigDecimal getInvestWerkstattMiete() {
		return investWerkstattMiete;
	}

	public void setInvestWerkstattMiete(BigDecimal investWerkstattMiete) {
		this.investWerkstattMiete = investWerkstattMiete;
	}

	public BigDecimal getInvestLagerMiete() {
		return investLagerMiete;
	}

	public void setInvestLagerMiete(BigDecimal investLagerMiete) {
		this.investLagerMiete = investLagerMiete;
	}

	public BigDecimal getInvestFahrzeugMiete() {
		return investFahrzeugMiete;
	}

	public void setInvestFahrzeugMiete(BigDecimal investFahrzeugMiete) {
		this.investFahrzeugMiete = investFahrzeugMiete;
	}

	public String getInvestWeitereMieteArt() {
		return investWeitereMieteArt;
	}

	public void setInvestWeitereMieteArt(String investWeitereMieteArt) {
		this.investWeitereMieteArt = investWeitereMieteArt;
	}

	public BigDecimal getInvestWeitereMiete() {
		return investWeitereMiete;
	}

	public void setInvestWeitereMiete(BigDecimal investWeitereMiete) {
		this.investWeitereMiete = investWeitereMiete;
	}

	public Boolean getRaumKeine() {
		return raumKeine;
	}

	public void setRaumKeine(Boolean raumKeine) {
		this.raumKeine = raumKeine;
	}

	public Boolean getRaumEigene() {
		return raumEigene;
	}

	public void setRaumEigene(Boolean raumEigene) {
		this.raumEigene = raumEigene;
	}

	public Boolean getRaumWohnung() {
		return raumWohnung;
	}

	public void setRaumWohnung(Boolean raumWohnung) {
		this.raumWohnung = raumWohnung;
	}

	public Boolean getRaumKunde() {
		return raumKunde;
	}

	public void setRaumKunde(Boolean raumKunde) {
		this.raumKunde = raumKunde;
	}

	public Integer getTaetigAnzKunden() {
		return taetigAnzKunden;
	}

	public void setTaetigAnzKunden(Integer taetigAnzKunden) {
		this.taetigAnzKunden = taetigAnzKunden;
	}

	public String getTaetigKunde1() {
		return taetigKunde1;
	}

	public void setTaetigKunde1(String taetigKunde1) {
		this.taetigKunde1 = taetigKunde1;
	}

	public String getTaetigKunde2() {
		return taetigKunde2;
	}

	public void setTaetigKunde2(String taetigKunde2) {
		this.taetigKunde2 = taetigKunde2;
	}

	public String getTaetigKunde3() {
		return taetigKunde3;
	}

	public void setTaetigKunde3(String taetigKunde3) {
		this.taetigKunde3 = taetigKunde3;
	}

	public String getTaetigArtAuftraege() {
		return taetigArtAuftraege;
	}

	public void setTaetigArtAuftraege(String taetigArtAuftraege) {
		this.taetigArtAuftraege = taetigArtAuftraege;
	}

	public Date getTaetigDatumLetzterAuftrag() {
		return taetigDatumLetzterAuftrag;
	}

	public void setTaetigDatumLetzterAuftrag(Date taetigDatumLetzterAuftrag) {
		this.taetigDatumLetzterAuftrag = taetigDatumLetzterAuftrag;
	}

	public Boolean getTaetigAgent() {
		return taetigAgent;
	}

	public void setTaetigAgent(Boolean taetigAgent) {
		this.taetigAgent = taetigAgent;
	}

	public String getTaetigAuftraggeber() {
		return taetigAuftraggeber;
	}

	public void setTaetigAuftraggeber(String taetigAuftraggeber) {
		this.taetigAuftraggeber = taetigAuftraggeber;
	}

	public Boolean getTaetigGemeinsameKunden() {
		return taetigGemeinsameKunden;
	}

	public void setTaetigGemeinsameKunden(Boolean taetigGemeinsameKunden) {
		this.taetigGemeinsameKunden = taetigGemeinsameKunden;
	}

	public BigDecimal getAngestellteVrHonorare() {
		return angestellteVrHonorare;
	}

	public void setAngestellteVrHonorare(BigDecimal angestellteVrHonorare) {
		this.angestellteVrHonorare = angestellteVrHonorare;
	}

	public Date getAngestellteGiLohnSeit() {
		return angestellteGiLohnSeit;
	}

	public void setAngestellteGiLohnSeit(Date angestellteGiLohnSeit) {
		this.angestellteGiLohnSeit = angestellteGiLohnSeit;
	}

	public Boolean getAngestellteGiHatKinder() {
		return angestellteGiHatKinder;
	}

	public void setAngestellteGiHatKinder(Boolean angestellteGiHatKinder) {
		this.angestellteGiHatKinder = angestellteGiHatKinder;
	}

	public Integer getAngestellteAngAnz() {
		return angestellteAngAnz;
	}

	public void setAngestellteAngAnz(Integer angestellteAngAnz) {
		this.angestellteAngAnz = angestellteAngAnz;
	}

	public BigDecimal getAngestellteAngLohnSumme() {
		return angestellteAngLohnSumme;
	}

	public void setAngestellteAngLohnSumme(BigDecimal angestellteAngLohnSumme) {
		this.angestellteAngLohnSumme = angestellteAngLohnSumme;
	}

	public Date getAngestellteAngLohnSeit() {
		return angestellteAngLohnSeit;
	}

	public void setAngestellteAngLohnSeit(Date angestellteAngLohnSeit) {
		this.angestellteAngLohnSeit = angestellteAngLohnSeit;
	}

	public Boolean getAngestellteAngHatKinder() {
		return angestellteAngHatKinder;
	}

	public void setAngestellteAngHatKinder(Boolean angestellteAngHatKinder) {
		this.angestellteAngHatKinder = angestellteAngHatKinder;
	}

	public Integer getAngestellteUebAnz() {
		return angestellteUebAnz;
	}

	public void setAngestellteUebAnz(Integer angestellteUebAnz) {
		this.angestellteUebAnz = angestellteUebAnz;
	}

	public BigDecimal getAngestellteUebLohnSumme() {
		return angestellteUebLohnSumme;
	}

	public void setAngestellteUebLohnSumme(BigDecimal angestellteUebLohnSumme) {
		this.angestellteUebLohnSumme = angestellteUebLohnSumme;
	}

	public Date getAngestellteUebLohnSeit() {
		return angestellteUebLohnSeit;
	}

	public void setAngestellteUebLohnSeit(Date angestellteUebLohnSeit) {
		this.angestellteUebLohnSeit = angestellteUebLohnSeit;
	}

	public Boolean getAngestellteUebHatKinder() {
		return angestellteUebHatKinder;
	}

	public void setAngestellteUebHatKinder(Boolean angestellteUebHatKinder) {
		this.angestellteUebHatKinder = angestellteUebHatKinder;
	}

	public List<AhvFilialeDto> getAhvFiliales() {
		return ahvFiliales;
	}

	public void setAhvFiliales(List<AhvFilialeDto> ahvFiliales) {
		this.ahvFiliales = ahvFiliales;
	}

	public List<AhvTeilhaberDto> getAhvTeilhabers() {
		return ahvTeilhabers;
	}

	public void setAhvTeilhabers(List<AhvTeilhaberDto> ahvTeilhabers) {
		this.ahvTeilhabers = ahvTeilhabers;
	}
	
	public AhvTeilhaberDto getTeilhaberSelected() {
		return teilhaberSelected;
	}

	public void setTeilhaberSelected(AhvTeilhaberDto teilhaberSelected) {
		this.teilhaberSelected = teilhaberSelected;
	}

	public String getSozialversUvg() {
		return sozialversUvg;
	}

	public void setSozialversUvg(String sozialversUvg) {
		this.sozialversUvg = sozialversUvg;
	}

	public Boolean getSozialversBvg() {
		return sozialversBvg;
	}

	public void setSozialversBvg(Boolean sozialversBvg) {
		this.sozialversBvg = sozialversBvg;
	}

	public String getSozialversBvgName() {
		return sozialversBvgName;
	}

	public void setSozialversBvgName(String sozialversBvgName) {
		this.sozialversBvgName = sozialversBvgName;
	}

	public String getSozialversBvgGrund() {
		return sozialversBvgGrund;
	}

	public void setSozialversBvgGrund(String sozialversBvgGrund) {
		this.sozialversBvgGrund = sozialversBvgGrund;
	}

	public Boolean getLohnbuchPapier() {
		return lohnbuchPapier;
	}

	public void setLohnbuchPapier(Boolean lohnbuchPapier) {
		this.lohnbuchPapier = lohnbuchPapier;
	}

	public Boolean getLohnbuchComputer() {
		return lohnbuchComputer;
	}

	public void setLohnbuchComputer(Boolean lohnbuchComputer) {
		this.lohnbuchComputer = lohnbuchComputer;
	}

	public Boolean getLohnbuchSuva() {
		return lohnbuchSuva;
	}

	public void setLohnbuchSuva(Boolean lohnbuchSuva) {
		this.lohnbuchSuva = lohnbuchSuva;
	}

	public Boolean getLohnbuchTreuhaender() {
		return lohnbuchTreuhaender;
	}

	public void setLohnbuchTreuhaender(Boolean lohnbuchTreuhaender) {
		this.lohnbuchTreuhaender = lohnbuchTreuhaender;
	}

	public AdresseDto getAdresseTreuhand() {
		return adresseTreuhand;
	}

	public void setAdresseTreuhand(AdresseDto adresseTreuhand) {
		this.adresseTreuhand = adresseTreuhand;
	}

	public String getKontaktVorname() {
		return kontaktVorname;
	}

	public void setKontaktVorname(String kontaktVorname) {
		this.kontaktVorname = kontaktVorname;
	}

	public String getKontaktFamilienname() {
		return kontaktFamilienname;
	}

	public void setKontaktFamilienname(String kontaktFamilienname) {
		this.kontaktFamilienname = kontaktFamilienname;
	}

	public String getKontaktTelefon() {
		return kontaktTelefon;
	}

	public void setKontaktTelefon(String kontaktTelefon) {
		this.kontaktTelefon = kontaktTelefon;
	}

	public String getKontaktMobile() {
		return kontaktMobile;
	}

	public void setKontaktMobile(String kontaktMobile) {
		this.kontaktMobile = kontaktMobile;
	}

	public String getKontaktEmail() {
		return kontaktEmail;
	}

	public void setKontaktEmail(String kontaktEmail) {
		this.kontaktEmail = kontaktEmail;
	}

	public String getKontaktBemerkungen() {
		return kontaktBemerkungen;
	}

	public void setKontaktBemerkungen(String kontaktBemerkungen) {
		this.kontaktBemerkungen = kontaktBemerkungen;
	}

	public AdresseDto getAdresseKontakt() {
		return adresseKontakt;
	}

	public void setAdresseKontakt(AdresseDto adresseKontakt) {
		this.adresseKontakt = adresseKontakt;
	}

	public Boolean getSonderPartnerWeb() {
		return sonderPartnerWeb;
	}

	public void setSonderPartnerWeb(Boolean sonderPartnerWeb) {
		this.sonderPartnerWeb = sonderPartnerWeb;
	}

	public Boolean getSonderVerband() {
		return sonderVerband;
	}

	public void setSonderVerband(Boolean sonderVerband) {
		this.sonderVerband = sonderVerband;
	}

	public Boolean getSonderBvg() {
		return sonderBvg;
	}

	public void setSonderBvg(Boolean sonderBvg) {
		this.sonderBvg = sonderBvg;
	}

	public Boolean getSonderUvg() {
		return sonderUvg;
	}

	public void setSonderUvg(Boolean sonderUvg) {
		this.sonderUvg = sonderUvg;
	}

	public Boolean getSonderKkv() {
		return sonderKkv;
	}

	public void setSonderKkv(Boolean sonderKkv) {
		this.sonderKkv = sonderKkv;
	}

	public Boolean getSonderWeitere() {
		return sonderWeitere;
	}

	public void setSonderWeitere(Boolean sonderWeitere) {
		this.sonderWeitere = sonderWeitere;
	}

	public VerbandDto getVerbandDto() {
		return verbandDto;
	}

	public void setVerbandDto(VerbandDto verbandDto) {
		this.verbandDto = verbandDto;
	}

	public AusgleichskasseDto getAusgleichskasseDto() {
		return ausgleichskasseDto;
	}

	public void setAusgleichskasseDto(AusgleichskasseDto ausgleichskasseDto) {
		this.ausgleichskasseDto = ausgleichskasseDto;
	}

	public Integer getSonderFormulare() {
		return sonderFormulare;
	}

	public void setSonderFormulare(Integer sonderFormulare) {
		this.sonderFormulare = sonderFormulare;
	}

	public Integer getAngestellteGiAnz() {
		return angestellteGiAnz;
	}

	public void setAngestellteGiAnz(Integer angestellteGiAnz) {
		this.angestellteGiAnz = angestellteGiAnz;
	}

	public BigDecimal getAngestellteGiLohnSumme() {
		return angestellteGiLohnSumme;
	}

	public void setAngestellteGiLohnSumme(BigDecimal angestellteGiLohnSumme) {
		this.angestellteGiLohnSumme = angestellteGiLohnSumme;
	}

	public EditingState getEditingState() {
		return editingState;
	}

	public void setEditingState(EditingState editingState) {
		this.editingState = editingState;
	}
}
