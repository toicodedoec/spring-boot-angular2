package ch.admin.oss.admin.criteria;

import ch.admin.oss.common.enums.AktivFilterEnum;

/**
 * @author xdg
 */
public class BranchenCriteria extends AbstractPaginationCriteria {
	private AktivFilterEnum status;

	public AktivFilterEnum getStatus() {
		return status;
	}

	public void setStatus(AktivFilterEnum status) {
		this.status = status;
	}

	
}
