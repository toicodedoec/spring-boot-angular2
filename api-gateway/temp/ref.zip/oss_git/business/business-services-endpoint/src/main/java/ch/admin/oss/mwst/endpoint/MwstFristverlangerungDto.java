package ch.admin.oss.mwst.endpoint;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.ProzessDto;
import ch.admin.oss.common.enums.QuarSemEnum;

/**
 * 
 * @author hhu
 *
 */
public class MwstFristverlangerungDto extends AbstractOSSDto {
	private ProzessDto prozess;
	
	@NotNull
	private String nr1;
	
	@NotNull
	private String nr2;
	
	@NotNull
	private String nr3;
	
	@NotNull
	private QuarSemEnum quarSem;
	
	@NotNull
	private String frist;
	
	@NotNull
	private String name;
	
	@NotNull
	private String ort;
	
	@NotNull
	private String kontakt;
	
	@NotNull
	private String email;
	
	private List<MwstFristverlangerungOptionDto> options = new ArrayList<MwstFristverlangerungOptionDto>();
	
	public void setNr1(String nr1) {
		this.nr1 = nr1;
	}

	public void setNr2(String nr2) {
		this.nr2 = nr2;
	}

	public void setNr3(String nr3) {
		this.nr3 = nr3;
	}

	public String getNr1() {
		return nr1;
	}

	public String getNr2() {
		return nr2;
	}

	public String getNr3() {
		return nr3;
	}

	public ProzessDto getProzess() {
		return prozess;
	}

	public void setProzess(ProzessDto prozess) {
		this.prozess = prozess;
	}

	public String getMwstNr() {
		return nr1 + nr2 + nr3;
	}

	public void setMwstNr(String mwstNr) {
		if (mwstNr != null) {
			nr1 = StringUtils.substring(mwstNr, 0, 3);
			nr2 = StringUtils.substring(mwstNr, 3, 6);
			nr3 = StringUtils.substring(mwstNr, 6, 9);
		}
	}

	public QuarSemEnum getQuarSem() {
		return quarSem;
	}

	public void setQuarSem(QuarSemEnum quarSem) {
		this.quarSem = quarSem;
	}

	public String getFrist() {
		return frist;
	}

	public void setFrist(String frist) {
		this.frist = frist;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getKontakt() {
		return kontakt;
	}

	public void setKontakt(String kontakt) {
		this.kontakt = kontakt;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<MwstFristverlangerungOptionDto> getOptions() {
		return options;
	}

	public void setOptions(List<MwstFristverlangerungOptionDto> options) {
		this.options = options;
	}
}
