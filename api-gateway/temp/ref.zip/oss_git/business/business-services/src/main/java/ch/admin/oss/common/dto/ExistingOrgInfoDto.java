package ch.admin.oss.common.dto;

import java.io.Serializable;

import ch.admin.oss.common.enums.PlaceToFindEnum;

public class ExistingOrgInfoDto implements Serializable {

	private static final long serialVersionUID = 1890066290422490603L;
	
	private Long startBizDataId;
	private String uid;
	private String name;
	private String city;
	private PlaceToFindEnum place;

	public ExistingOrgInfoDto() {}

	public ExistingOrgInfoDto(String uid, String name, String city, PlaceToFindEnum place) {
		this.name = name;
		this.uid = uid;
		this.city = city;
		this.place = place;
	}
	
	public ExistingOrgInfoDto(Long startBizDataId, String uid, String name, String city, PlaceToFindEnum place) {
		this.startBizDataId = startBizDataId;
		this.uid = uid;
		this.name = name;
		this.city = city;
		this.place = place;
	}

	public Long getStartBizDataId() {
		return startBizDataId;
	}

	public void setStartBizDataId(Long startBizDataId) {
		this.startBizDataId = startBizDataId;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public PlaceToFindEnum getPlace() {
		return place;
	}

	public void setPlace(PlaceToFindEnum place) {
		this.place = place;
	}

}
