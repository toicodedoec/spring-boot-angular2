package ch.admin.oss.moa.endpoint;

import java.util.ArrayList;
import java.util.List;

public class MwstMoaUserDataDto {

	private final boolean chDomicile = true;

	private final boolean chBetrieb = true;

	private String chId;

	private String uid;

	private String commercialRegisterEntryDate; // shabDatum

	private String uidStreet;

	private MwstMoaUserDataAddressDto address;

	private MwstMoaUserDataAddressDto addressPrivate;

	private final boolean chRegistered = true;

	private boolean uidRegistered;

	private boolean hrRegistered;

	private MwstMoaUserDataLegalFormDto legalForm;

	private final boolean chForData = true;

	private final boolean ch = true;

	private String communityNumber; // bfsNbr

	private List<MwstMoaUserDataCorporatorDto> corporators;

	private String financialYearEnd;

	private String start;

	private MwstMoaUserDataContactDto owner;

	private boolean ownerAddressSameAsFirmAddress;

	public MwstMoaUserDataDto() {
		corporators = new ArrayList<>();
	}
	
	public String getChId() {
		return chId;
	}

	public void setChId(String chId) {
		this.chId = chId;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getCommercialRegisterEntryDate() {
		return commercialRegisterEntryDate;
	}

	public void setCommercialRegisterEntryDate(String commercialRegisterEntryDate) {
		this.commercialRegisterEntryDate = commercialRegisterEntryDate;
	}

	public String getUidStreet() {
		return uidStreet;
	}

	public void setUidStreet(String uidStreet) {
		this.uidStreet = uidStreet;
	}

	public MwstMoaUserDataAddressDto getAddress() {
		return address;
	}

	public void setAddress(MwstMoaUserDataAddressDto address) {
		this.address = address;
	}

	public MwstMoaUserDataAddressDto getAddressPrivate() {
		return addressPrivate;
	}

	public void setAddressPrivate(MwstMoaUserDataAddressDto addressPrivate) {
		this.addressPrivate = addressPrivate;
	}

	public boolean isUidRegistered() {
		return uidRegistered;
	}

	public void setUidRegistered(boolean uidRegistered) {
		this.uidRegistered = uidRegistered;
	}

	public boolean isHrRegistered() {
		return hrRegistered;
	}

	public void setHrRegistered(boolean hrRegistered) {
		this.hrRegistered = hrRegistered;
	}

	public MwstMoaUserDataLegalFormDto getLegalForm() {
		return legalForm;
	}

	public void setLegalForm(MwstMoaUserDataLegalFormDto legalForm) {
		this.legalForm = legalForm;
	}

	public String getCommunityNumber() {
		return communityNumber;
	}

	public void setCommunityNumber(String communityNumber) {
		this.communityNumber = communityNumber;
	}

	public List<MwstMoaUserDataCorporatorDto> getCorporators() {
		return corporators;
	}

	public void setCorporators(List<MwstMoaUserDataCorporatorDto> corporators) {
		this.corporators = corporators;
	}

	public String getFinancialYearEnd() {
		return financialYearEnd;
	}

	public void setFinancialYearEnd(String financialYearEnd) {
		this.financialYearEnd = financialYearEnd;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public MwstMoaUserDataContactDto getOwner() {
		return owner;
	}

	public void setOwner(MwstMoaUserDataContactDto owner) {
		this.owner = owner;
	}

	public boolean isOwnerAddressSameAsFirmAddress() {
		return ownerAddressSameAsFirmAddress;
	}

	public void setOwnerAddressSameAsFirmAddress(boolean ownerAddressSameAsFirmAddress) {
		this.ownerAddressSameAsFirmAddress = ownerAddressSameAsFirmAddress;
	}

	public boolean isChDomicile() {
		return chDomicile;
	}

	public boolean isChBetrieb() {
		return chBetrieb;
	}

	public boolean isChRegistered() {
		return chRegistered;
	}

	public boolean isChForData() {
		return chForData;
	}

	public boolean isCh() {
		return ch;
	}

}
