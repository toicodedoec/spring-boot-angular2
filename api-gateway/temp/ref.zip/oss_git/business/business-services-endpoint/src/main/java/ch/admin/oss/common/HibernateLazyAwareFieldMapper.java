/*
 * HibernateLazyAwareFieldMapper
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import org.dozer.CustomFieldMapper;
import org.dozer.classmap.ClassMap;
import org.dozer.fieldmap.FieldMap;
import org.hibernate.Hibernate;

/**
 * {@link CustomFieldMapper} that is aware of un-initialized Hibernate fields and simply ignores them to avoid the
 * massive number of queries resulted from the un-controlled lazy initialization.
 * 
 * @author phd
 */
public class HibernateLazyAwareFieldMapper implements CustomFieldMapper {

	@Override
	public boolean mapField(Object source, Object destination, Object sourceFieldValue, ClassMap classMap,
		FieldMap fieldMapping) {
		if (Hibernate.isInitialized(sourceFieldValue)) {
			// Lets Dozer map the field as normal.
			return false;
		}
		return true;
	}
}
