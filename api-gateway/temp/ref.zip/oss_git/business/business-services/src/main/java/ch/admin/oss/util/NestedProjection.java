/*
 * NestedProjection
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import com.querydsl.core.Tuple;
import com.querydsl.core.types.MappingProjection;
import com.querydsl.core.types.Path;

import ch.admin.oss.common.OssTechnicalException;


/**
 * Nested projection support for QueryDSL.
 * 
 * @author Phuong Hoang DO (PHD)
 * @param <T>
 *            expression type
 */
public final class NestedProjection<T> extends MappingProjection<T> {

	private static final long serialVersionUID = 3747221119704933875L;
	
	private static final String DOT_PROPERTY_SPLIT_STR = ".";
	private static final String UNDERLINE_PROPERTY_SPLIT_STR = "_";

	private List<Path<?>> others = new ArrayList<>();
	private List<Path<?>> roots = new ArrayList<>();

	private NestedProjection(Class<T> clazz, Path<?>... args) {
		super(clazz, args);
		for (Path<?> path : args) {
			if (path.getRoot().getType().equals(clazz)) {
				roots.add(path);
			} else {
				others.add(path);
			}
		}
	}
	
	private NestedProjection(Class<T> clazz, String rootAlias, Path<?>... args) {
		super(clazz, args);
		for (Path<?> path : args) {
			if (path.getRoot().toString().equals(rootAlias)) {
				roots.add(path);
			} else {
				others.add(path);
			}
		}
	}

	/**
	 * Create nested projection of the clazz parameter with arguments parameter.
	 * 
	 * @param clazz
	 *            Is the class
	 * @param args
	 *            Is the path arguments.
	 * @param <T>
	 *            expression type
	 * @return nested projection
	 */
	public static <T> NestedProjection<T> of(Class<T> clazz, Path<?>... args) {
		return new NestedProjection<T>(clazz, args);
	}

	/**
	 * Create nested projection of the clazz parameter with arguments parameter.
	 * 
	 * @param clazz
	 *            Is the class
	 * @param rootAlias
	 *            Is the alias of the root path.
	 * @param args
	 *            Is the path arguments.
	 * @param <T>
	 *            expression type
	 * @return nested projection
	 */
	public static <T> NestedProjection<T> of(Class<T> clazz, String rootAlias, Path<?>... args) {
		return new NestedProjection<T>(clazz, rootAlias, args);
	}

	@Override
	protected T map(Tuple row) {
		try {
			T result = getType().newInstance();
			String propertyPath = null;
			for (Path<?> arg : roots) {
				String string = arg.toString();
				if (string.contains(UNDERLINE_PROPERTY_SPLIT_STR)) {
					propertyPath = StringUtils.join(ArrayUtils.remove(StringUtils.split(string, UNDERLINE_PROPERTY_SPLIT_STR), 0), ".");
				} else { 
					propertyPath = StringUtils.join(ArrayUtils.remove(StringUtils.split(string, DOT_PROPERTY_SPLIT_STR), 0), ".");
				}
				PropertyUtils.setNestedProperty(result, propertyPath, row.get(arg));
			}
			for (Path<?> arg : others) {
				String string = arg.toString();
				if (string.contains(UNDERLINE_PROPERTY_SPLIT_STR)) {
					propertyPath = StringUtils.join(StringUtils.split(string, UNDERLINE_PROPERTY_SPLIT_STR), ".");
				} else {
					propertyPath = StringUtils.join(StringUtils.split(string, DOT_PROPERTY_SPLIT_STR), ".");
				}
				instantiateNestedProperties(result, propertyPath);
				PropertyUtils.setNestedProperty(result, propertyPath, row.get(arg));
			}
			return result;
		} catch (InstantiationException | IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
			throw new OssTechnicalException(e);
		}
	}

	private void instantiateNestedProperties(Object obj, String fieldName) {
		try {
			String[] fieldNames = fieldName.split("\\.");
			if (fieldNames.length > 1) {
				StringBuilder nestedProperty = new StringBuilder();
				for (int i = 0; i < fieldNames.length - 1; i++) {
					String fn = fieldNames[i];
					if (i != 0) {
						nestedProperty.append(".");
					}
					nestedProperty.append(fn);
					Object value = PropertyUtils.getProperty(obj, nestedProperty.toString());

					if (value == null) {
						PropertyDescriptor propertyDescriptor = PropertyUtils.getPropertyDescriptor(obj,
							nestedProperty.toString());
						Class<?> propertyType = propertyDescriptor.getPropertyType();
						Object newInstance = propertyType.newInstance();
						PropertyUtils.setProperty(obj, nestedProperty.toString(), newInstance);
					}
				}
			}
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException | InstantiationException e) {
			throw new OssTechnicalException(e);
		}
	}
}
