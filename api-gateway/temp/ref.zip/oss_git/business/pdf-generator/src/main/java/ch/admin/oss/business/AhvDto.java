/*
 * OssPdfAhvProcessDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.util.List;

/**
 * @author hhg
 *
 */
public class AhvDto {

	private AhvHeaderDto h;
	private AusgleichskasseDto ak;
	private BetriebDto b;
	private BetriebsgrundungDto bg;
	private BetriebsAdressenDto ba;
	private ZahlungsverbindungDto z;
	private AngestellteBuchhaltungBVGDto abb;
	private AuftrageKundenDto cust;
	private InvestitionenDto capital;
	private WunschtInformationenDto i;
	private BemerkungenDto bem;
	private KontaktpersonDto k;
	private SelbsteinschatzungDto sb;
	private ErwerbstatigkeitDto oc;
	private PersonlicheAngabenDto pi;
	private EhePartnerInDto partner;
	private ErwerbsUndSelbstkostenDto cost;
	private VrHonorareTantiemenDto vr;
	private ArbeitsorganisationDto org;
	private OrtderTatigkeitDto ort;
	private List<GeschaftslokaleDto> gl;
	private List<GesellschafterDto> owners;
	private List<AhvTeilhaberDetailDto> ahvTeilhabers;
	private String date;

	public AusgleichskasseDto getAk() {
		return ak;
	}
	public void setAk(AusgleichskasseDto ak) {
		this.ak = ak;
	}
	public BetriebDto getB() {
		return b;
	}
	public void setB(BetriebDto b) {
		this.b = b;
	}
	public BetriebsgrundungDto getBg() {
		return bg;
	}
	public void setBg(BetriebsgrundungDto bg) {
		this.bg = bg;
	}
	public BetriebsAdressenDto getBa() {
		return ba;
	}
	public void setBa(BetriebsAdressenDto ba) {
		this.ba = ba;
	}
	public ZahlungsverbindungDto getZ() {
		return z;
	}
	public void setZ(ZahlungsverbindungDto z) {
		this.z = z;
	}
	public List<GeschaftslokaleDto> getGl() {
		return gl;
	}
	public void setGl(List<GeschaftslokaleDto> gl) {
		this.gl = gl;
	}
	public AngestellteBuchhaltungBVGDto getAbb() {
		return abb;
	}
	public void setAbb(AngestellteBuchhaltungBVGDto abb) {
		this.abb = abb;
	}
	public InvestitionenDto getCapital() {
		return capital;
	}
	public void setCapital(InvestitionenDto capital) {
		this.capital = capital;
	}
	public WunschtInformationenDto getI() {
		return i;
	}
	public void setI(WunschtInformationenDto i) {
		this.i = i;
	}
	public BemerkungenDto getBem() {
		return bem;
	}
	public void setBem(BemerkungenDto bem) {
		this.bem = bem;
	}
	public AhvHeaderDto getH() {
		return h;
	}
	public void setH(AhvHeaderDto h) {
		this.h = h;
	}
	public KontaktpersonDto getK() {
		return k;
	}
	public void setK(KontaktpersonDto k) {
		this.k = k;
	}
	public VrHonorareTantiemenDto getVr() {
		return vr;
	}
	public void setVr(VrHonorareTantiemenDto vr) {
		this.vr = vr;
	}
	public AuftrageKundenDto getCust() {
		return cust;
	}
	public void setCust(AuftrageKundenDto cust) {
		this.cust = cust;
	}
	public List<GesellschafterDto> getOwners() {
		return owners;
	}
	public void setOwners(List<GesellschafterDto> owners) {
		this.owners = owners;
	}
	public List<AhvTeilhaberDetailDto> getAhvTeilhabers() {
		return ahvTeilhabers;
	}
	public void setAhvTeilhabers(List<AhvTeilhaberDetailDto> ahvTeilhabers) {
		this.ahvTeilhabers = ahvTeilhabers;
	}
	public ErwerbstatigkeitDto getOc() {
		return oc;
	}
	public void setOc(ErwerbstatigkeitDto oc) {
		this.oc = oc;
	}
	public PersonlicheAngabenDto getPi() {
		return pi;
	}
	public void setPi(PersonlicheAngabenDto pi) {
		this.pi = pi;
	}
	public ErwerbsUndSelbstkostenDto getCost() {
		return cost;
	}
	public void setCost(ErwerbsUndSelbstkostenDto cost) {
		this.cost = cost;
	}
	public OrtderTatigkeitDto getOrt() {
		return ort;
	}
	public void setOrt(OrtderTatigkeitDto ort) {
		this.ort = ort;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getDate() {
		return date;
	}
	public SelbsteinschatzungDto getSb() {
		return sb;
	}
	public void setSb(SelbsteinschatzungDto sb) {
		this.sb = sb;
	}
	public ArbeitsorganisationDto getOrg() {
		return org;
	}
	public void setOrg(ArbeitsorganisationDto org) {
		this.org = org;
	}
	public EhePartnerInDto getPartner() {
		return partner;
	}
	public void setPartner(EhePartnerInDto partner) {
		this.partner = partner;
	}
}
