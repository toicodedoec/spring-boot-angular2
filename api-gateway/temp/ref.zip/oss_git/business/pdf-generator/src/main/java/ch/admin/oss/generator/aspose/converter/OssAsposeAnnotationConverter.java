/*
 * OssAsposeAnnotationConverter
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.generator.aspose.converter;

import java.lang.annotation.Annotation;

import ch.admin.oss.generator.aspose.OssAsposeContext;

/**
 * @author hha
 */
public interface OssAsposeAnnotationConverter<T extends Annotation> {

	Object convert(OssAsposeContext context, Object originalValue, Object value, T annotation);
	
	@SuppressWarnings("unchecked")
	default Object convertObject(OssAsposeContext context, Object originalValue, Object value, Annotation annotation) {
		return convert(context, originalValue, value, (T) annotation);
	}

}