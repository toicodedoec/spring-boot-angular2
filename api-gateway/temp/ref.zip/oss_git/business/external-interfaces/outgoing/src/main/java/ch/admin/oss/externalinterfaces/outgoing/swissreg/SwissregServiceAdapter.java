/*
 * SwissregServiceAdapter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.swissreg;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.stream.XMLInputFactory;
import javax.xml.ws.soap.SOAPFaultException;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.common.jaxb.JAXBUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import https.www_swissreg_ch.services.SwissregWebService;

/**
 * @author hhg
 *
 */
@Component
public class SwissregServiceAdapter implements ISwissregServiceAdapter, InitializingBean {

	@Autowired
	@Qualifier("outgoingInterfaceMapper")
	private DozerBeanMapper mapper;

	@Autowired
	private SwissregWebService swissregWebService;

	@Value("${swissreg.maxEntries}")
	private int maxEntries;

	// TODO [COH / S9] Should consider introduce only 1 single JAXBContext for OSS across the project.
	private JAXBContext jaxbContext;

	@Override
	public TmtransDto checkCompanyTrademark(String trademark) throws SwissregBusinessException {
		try {
			TmtransDto result = new TmtransDto();

			String keyString = swissregWebService.searchIpRight("CH-TM", "tmStateCdList=1,3;tmText=" + trademark);
			// take the first 'maxEntries' keys into getIpRightXML if too many keys returned 
			boolean filtered = false;
			String[] keys = StringUtils.split(keyString, ",");
			if (keys != null && keys.length > maxEntries) {
				filtered = true;
				keyString = StringUtils.join(keys, ",", 0, maxEntries);
			}

			String tmtransXml = swissregWebService.getIpRightXML("CH-TM", keyString);
			if (tmtransXml != null) {
				JAXBElement<ch.admin.oss.externalinterfaces.outgoing.generated.Tmtrans> tmtransElement =
					JAXBUtils.unmarshall(
						jaxbContext,
						XMLInputFactory.newInstance().createXMLStreamReader(new StringReader(tmtransXml)),
						ch.admin.oss.externalinterfaces.outgoing.generated.Tmtrans.class
					);
				result = mapper.map(tmtransElement.getValue(), TmtransDto.class);
				result.setFiltered(filtered);
			}
			return result;
		} catch (SOAPFaultException fault) {
			if (ch.ige.srwebservice11.exception.EmptyResultException.class.getName().equals(fault.getFault().getFaultString())) {
				// no trademark found
				return new TmtransDto();
			}
			throw new SwissregBusinessException("An error occurred when calling SwissReg WS", fault);
		} catch (Exception e) {
			// SECOOSS-742: any type of error when calling SwissReg will be transformed to business exception since
			// we don't want the system treat it as an technical error. We will handle this error manually.
			throw new SwissregBusinessException("An error occurred when calling SwissReg WS", e);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void afterPropertiesSet() throws Exception {
		String contextPath = ch.admin.oss.externalinterfaces.outgoing.generated.Tmtrans.class.getPackage().getName();
		jaxbContext = JAXBContext.newInstance(contextPath);
	}
}
