/*
 * UvgDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import ch.admin.oss.OssCurrencyFormatter;

/**
 * @author hha
 */
public class UvgDto {

	private CompanyDto org;
	private boolean suvaResponsible;
	private boolean anmeldung;
	private String hrEintragDone;

	private GeschaftsrolleDto owner;

	private boolean uvgInhaberFreiwillig;

	private String kontaktName;
	private String kontaktVorname;
	private AddressDto kontaktAdresse;

	private String partnerName;
	@OssCurrencyFormatter
	private BigDecimal partnerLohnsumme;
	private boolean partnerFreiwillig;

	@OssCurrencyFormatter
	private BigDecimal angehoerigeLohnsumme;
	private BigDecimal angehoerigeAnzahl;
	private boolean angehoerigeFreiwillig;

	private boolean angestellteLehrling;
	private boolean angestellteOhneLohn;
	private boolean angestellteAushilfe;
	private boolean angestellteGesellschafter;

	private boolean showGesellschafter;
	private boolean showLohnsummeGeschaftsleitung;
	private boolean showVerwaltungsratshonorare;

	@OssCurrencyFormatter
	private BigDecimal lohnsumme;
	@OssCurrencyFormatter
	private BigDecimal lohnsummeFolgejahr;

	private Integer glAnzahl;
	private BigDecimal glLohnsumme;
	private BigDecimal vrLohnsumme;

	private String zahlungsmodus;
	private KontoDto konto;

	private LocalDateTime uvgDate;

	private String ahvName;
	private String ahvNummer;
	private String versicherungName;
	private String versicherungNummer;
	private String bemerkungen;

	private LocalDate ersteAnstellung;
	private LocalDate currDatePlus6Months = LocalDate.now().plusMonths(6);

	private BigDecimal angestellteZukunft;
	private LocalDate ersteAnstellungZukunft;
	private BigDecimal angestellteHeute;

	private List<UvgGesellschafterDto> gesellschafters = new ArrayList<>();

	public CompanyDto getOrg() {
		return org;
	}

	public void setOrg(CompanyDto org) {
		this.org = org;
	}

	public boolean isSuvaResponsible() {
		return suvaResponsible;
	}

	public void setSuvaResponsible(boolean suvaResponsible) {
		this.suvaResponsible = suvaResponsible;
	}

	public boolean isAnmeldung() {
		return anmeldung;
	}

	public void setAnmeldung(boolean anmeldung) {
		this.anmeldung = anmeldung;
	}

	public String getHrEintragDone() {
		return hrEintragDone;
	}

	public void setHrEintragDone(String hrEintragDone) {
		this.hrEintragDone = hrEintragDone;
	}

	public GeschaftsrolleDto getOwner() {
		return owner;
	}

	public void setOwner(GeschaftsrolleDto owner) {
		this.owner = owner;
	}

	public AddressDto getKontaktAdresse() {
		return kontaktAdresse;
	}

	public void setKontaktAdresse(AddressDto kontaktAdresse) {
		this.kontaktAdresse = kontaktAdresse;
	}

	public boolean isUvgInhaberFreiwillig() {
		return uvgInhaberFreiwillig;
	}

	public void setUvgInhaberFreiwillig(boolean uvgInhaberFreiwillig) {
		this.uvgInhaberFreiwillig = uvgInhaberFreiwillig;
	}

	public String getKontaktName() {
		return kontaktName;
	}

	public void setKontaktName(String kontaktName) {
		this.kontaktName = kontaktName;
	}

	public String getKontaktVorname() {
		return kontaktVorname;
	}

	public void setKontaktVorname(String kontaktVorname) {
		this.kontaktVorname = kontaktVorname;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public BigDecimal getPartnerLohnsumme() {
		return partnerLohnsumme;
	}

	public void setPartnerLohnsumme(BigDecimal partnerLohnsumme) {
		this.partnerLohnsumme = partnerLohnsumme;
	}

	public boolean isPartnerFreiwillig() {
		return partnerFreiwillig;
	}

	public void setPartnerFreiwillig(boolean partnerFreiwillig) {
		this.partnerFreiwillig = partnerFreiwillig;
	}

	public BigDecimal getAngehoerigeLohnsumme() {
		return angehoerigeLohnsumme;
	}

	public void setAngehoerigeLohnsumme(BigDecimal angehoerigeLohnsumme) {
		this.angehoerigeLohnsumme = angehoerigeLohnsumme;
	}

	public BigDecimal getAngehoerigeAnzahl() {
		return angehoerigeAnzahl;
	}

	public void setAngehoerigeAnzahl(BigDecimal angehoerigeAnzahl) {
		this.angehoerigeAnzahl = angehoerigeAnzahl;
	}

	public boolean isAngehoerigeFreiwillig() {
		return angehoerigeFreiwillig;
	}

	public void setAngehoerigeFreiwillig(boolean angehoerigeFreiwillig) {
		this.angehoerigeFreiwillig = angehoerigeFreiwillig;
	}

	public boolean isAngestellteLehrling() {
		return angestellteLehrling;
	}

	public void setAngestellteLehrling(boolean angestellteLehrling) {
		this.angestellteLehrling = angestellteLehrling;
	}

	public boolean isAngestellteOhneLohn() {
		return angestellteOhneLohn;
	}

	public void setAngestellteOhneLohn(boolean angestellteOhneLohn) {
		this.angestellteOhneLohn = angestellteOhneLohn;
	}

	public boolean isAngestellteAushilfe() {
		return angestellteAushilfe;
	}

	public void setAngestellteAushilfe(boolean angestellteAushilfe) {
		this.angestellteAushilfe = angestellteAushilfe;
	}

	public boolean isAngestellteGesellschafter() {
		return angestellteGesellschafter;
	}

	public void setAngestellteGesellschafter(boolean angestellteGesellschafter) {
		this.angestellteGesellschafter = angestellteGesellschafter;
	}

	public boolean isShowGesellschafter() {
		return showGesellschafter;
	}

	public void setShowGesellschafter(boolean showGesellschafter) {
		this.showGesellschafter = showGesellschafter;
	}

	public boolean isShowLohnsummeGeschaftsleitung() {
		return showLohnsummeGeschaftsleitung;
	}

	public void setShowLohnsummeGeschaftsleitung(boolean showLohnsummeGeschaftsleitung) {
		this.showLohnsummeGeschaftsleitung = showLohnsummeGeschaftsleitung;
	}

	public boolean isShowVerwaltungsratshonorare() {
		return showVerwaltungsratshonorare;
	}

	public void setShowVerwaltungsratshonorare(boolean showVerwaltungsratshonorare) {
		this.showVerwaltungsratshonorare = showVerwaltungsratshonorare;
	}

	public BigDecimal getLohnsumme() {
		return lohnsumme;
	}

	public void setLohnsumme(BigDecimal lohnsumme) {
		this.lohnsumme = lohnsumme;
	}

	public BigDecimal getLohnsummeFolgejahr() {
		return lohnsummeFolgejahr;
	}

	public void setLohnsummeFolgejahr(BigDecimal lohnsummeFolgejahr) {
		this.lohnsummeFolgejahr = lohnsummeFolgejahr;
	}

	public Integer getGlAnzahl() {
		return glAnzahl;
	}

	public void setGlAnzahl(Integer glAnzahl) {
		this.glAnzahl = glAnzahl;
	}

	public BigDecimal getGlLohnsumme() {
		return glLohnsumme;
	}

	public void setGlLohnsumme(BigDecimal glLohnsumme) {
		this.glLohnsumme = glLohnsumme;
	}

	public BigDecimal getVrLohnsumme() {
		return vrLohnsumme;
	}

	public void setVrLohnsumme(BigDecimal vrLohnsumme) {
		this.vrLohnsumme = vrLohnsumme;
	}

	public List<UvgGesellschafterDto> getGesellschafters() {
		return gesellschafters;
	}

	public void setGesellschafters(List<UvgGesellschafterDto> gesellschafters) {
		this.gesellschafters = gesellschafters;
	}

	public String getZahlungsmodus() {
		return zahlungsmodus;
	}

	public void setZahlungsmodus(String zahlungsmodus) {
		this.zahlungsmodus = zahlungsmodus;
	}

	public KontoDto getKonto() {
		return konto;
	}

	public void setKonto(KontoDto konto) {
		this.konto = konto;
	}

	public LocalDateTime getUvgDate() {
		return uvgDate;
	}

	public void setUvgDate(LocalDateTime uvgDate) {
		this.uvgDate = uvgDate;
	}

	public String getAhvName() {
		return ahvName;
	}

	public void setAhvName(String ahvName) {
		this.ahvName = ahvName;
	}

	public String getAhvNummer() {
		return ahvNummer;
	}

	public void setAhvNummer(String ahvNummer) {
		this.ahvNummer = ahvNummer;
	}

	public String getVersicherungName() {
		return versicherungName;
	}

	public void setVersicherungName(String versicherungName) {
		this.versicherungName = versicherungName;
	}

	public String getVersicherungNummer() {
		return versicherungNummer;
	}

	public void setVersicherungNummer(String versicherungNummer) {
		this.versicherungNummer = versicherungNummer;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public BigDecimal getAngestellteHeute() {
		return angestellteHeute;
	}

	public void setAngestellteHeute(BigDecimal angestellteHeute) {
		this.angestellteHeute = angestellteHeute;
	}
	
	public LocalDate getErsteAnstellung() {
		return ersteAnstellung;
	}

	public void setErsteAnstellung(LocalDate ersteAnstellung) {
		this.ersteAnstellung = ersteAnstellung;
	}

	public LocalDate getCurrDatePlus6Months() {
		return currDatePlus6Months;
	}

	public void setCurrDatePlus6Months(LocalDate currDatePlus6Months) {
		this.currDatePlus6Months = currDatePlus6Months;
	}

	public BigDecimal getAngestellteZukunft() {
		return angestellteZukunft;
	}

	public void setAngestellteZukunft(BigDecimal angestellteZukunft) {
		this.angestellteZukunft = angestellteZukunft;
	}

	public LocalDate getErsteAnstellungZukunft() {
		return ersteAnstellungZukunft;
	}

	public void setErsteAnstellungZukunft(LocalDate ersteAnstellungZukunft) {
		this.ersteAnstellungZukunft = ersteAnstellungZukunft;
	}

}
