/*
 * ApplicationController
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dozer.Mapper;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ch.admin.oss.admin.endpoint.AusgleichskasseDto;
import ch.admin.oss.admin.endpoint.TextTranslationDto;
import ch.admin.oss.admin.endpoint.VerbandDto;
import ch.admin.oss.admin.endpoint.VersicherungDto;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.domain.AbstractOSSEntity;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.FlowHistoryEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.VerbandEntity;
import ch.admin.oss.exception.ValidationException;
import ch.admin.oss.hr.endpoint.HrAmtDto;
import ch.admin.oss.landing.service.ILandingPageService;
import ch.admin.oss.portal.endpoint.AbstractGroupDto;
import ch.admin.oss.portal.endpoint.BerufDto;
import ch.admin.oss.portal.endpoint.BrancheDto;
import ch.admin.oss.portal.endpoint.CHOrtDto;
import ch.admin.oss.portal.endpoint.ContactAddressInfoDto;
import ch.admin.oss.portal.service.IPortalService;
import ch.admin.oss.security.OssRole;
import ch.admin.oss.security.OssUser;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.DataUtil;
import ch.admin.oss.util.IMailUtil;
import ch.admin.oss.util.MailMessage;

/**
 * REST endpoint to provide application's information/services.
 * 
 * @author phd
 */
@CrossOrigin
@RestController
@RequestMapping("/public/application")
public class ApplicationServiceEndpoint extends AbstractOSSEndpoint {

	private static final String MITGLIEDSCHAFT_BALD = "2";

	private static final String MITGLIEDSCHAFT_JA = "1";

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ApplicationServiceEndpoint.class);

	@Value("${feedback.toEmailAddress}")
	private String toEmailAddress;
	
	@Value("${oss.portal.intervalOfRefreshingNumberOfOrg}")
	private int intervalOfRefreshingNumberOfOrg;

	@Value("${oss.gui.stats.userAccount12Months}")
	private boolean userAccount12Months;
	
	@Value("${oss.gui.stats.companies12Months}")
	private boolean companies12Months;
	
	@Value("${oss.hrMutation.taskTime}")
	private int timeForEachTaskHrMutation;
	
	@Value("${oss.security.eiam.loginURL}")
	private String eiamLoginURL;
	
	@Value("${oss.security.eiam.registerURL}")
	private String eiamRegisterURL;
	
	@Value("${oss.security.eiam.logoutURL}")
	private String eiamLogoutURL;

	@Autowired
	private IMailUtil mailUtil;

	@Autowired
	private IPortalService portalService;
	@Autowired
	private ILandingPageService landingPageService;

	@Autowired
	private Mapper mapper;

	@RequestMapping(value = "/userDetails", method = RequestMethod.GET)
	public ResponseEntity<OssUserDto> userDetails() {
		return ResponseEntity.ok(transformToOssUserDto(SecurityUtil.currentUser()));
	}

	@RequestMapping(value = "/translation/{language}", method = RequestMethod.GET)
	public ResponseEntity<Map<String, String>> getTranslation(@PathVariable SupportedLanguage language) {
		return ResponseEntity.ok(cacheService.getTranslationByLang(language));
	}

	@RequestMapping(value = "/userPreferenceLanguage/{language}", method = RequestMethod.PUT)
	public ResponseEntity<OssUserDto> userPreferenceLanguage(@PathVariable SupportedLanguage language) {
		OssUser ossUser = SecurityUtil.currentUser();
		ossUser.setLanguagePreference(language);
		SecurityUtil.updateCurrentUser(ossUser);
		UserEntity userEntity = portalService.findUserByName(ossUser.getUsername());
		if (userEntity != null) {
			userEntity.setLanguage(language);
			portalService.save(userEntity);
		}
		return ResponseEntity.ok(transformToOssUserDto(ossUser));
	}
	
	private OssUserDto transformToOssUserDto(OssUser ossUser) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug(new StringBuilder()
					.append("Authorities: ").append(
							StringUtils.join(ossUser.getAuthorities().stream()
							.map(authority -> authority.getAuthority()).collect(Collectors.toList()), ", "))
					.append(System.lineSeparator())
					.append("Username:    ").append(ossUser.getUsername()).append(System.lineSeparator())
					.toString());
		}

		Set<OssRole> roles = ossUser.getAuthorities()
		.stream().map(authority -> OssRole.valueOf(authority.getAuthority())).collect(Collectors.toSet());
		return new OssUserDto(
			ossUser.getUsername(), 
			ossUser.getFirstName(),
			ossUser.getLastName(),
			roles, 
			ossUser.getFunktions(),
			ossUser.getLanguagePreference(), 
			ossUser.getAuthorizedCompanies(),
			ossUser.isLoginSuisseId());
	}

	@RequestMapping(value = "/feedback", method = RequestMethod.POST)
	public void sendFeedback(@RequestBody @Valid FeedbackDto feedBackDto) {
		
		MailMessage message = new MailMessage();
		message.setSubject(applicationService.getTranslation("gui_labels.feedback.email.subject"));
		message.setFrom(feedBackDto.getEmail());
		message.setTo(toEmailAddress);
		message.setTemplateName("feedback-mail-template.ftl");
		message.setTemplateModel(new HashMap<String, Object>() {
			private static final long serialVersionUID = 4418867601687039927L;
			{
				put("emailAddress", feedBackDto.getEmail());
				put("content", feedBackDto.getContent());
			}

		});
		mailUtil.send(message);
	}
	
	@RequestMapping(value = "/countUser", method = RequestMethod.GET)
	public ResponseEntity<Long> countUser() {
		return ResponseEntity.ok(portalService.countUser());
	}
	
	@RequestMapping(value = "/codeWerts", method = RequestMethod.GET)
	public Map<KategorieEnum, List<CodeWertDto>> codeWerts(@RequestParam("kategories") List<Integer> kategories, @RequestParam(required = false, name = "language") SupportedLanguage language) {
		return getCodeWerts(kategories.stream().map(ordinal -> KategorieEnum.values()[ordinal]).collect(Collectors.toList()), language);
	}
	
	@RequestMapping(value = "/codeWerts", method = RequestMethod.POST)
	public Map<KategorieEnum, List<CodeWertDto>> codeWerts(@RequestBody List<Integer> kategories) {
		return getCodeWerts(kategories.stream().map(ordinal -> KategorieEnum.values()[ordinal]).collect(Collectors.toList()), null);
	}
	
	@RequestMapping(value = "/codeWertsWithCode", method = RequestMethod.POST)
	public Map<KategorieEnum, List<CodeWertDto>> codeWertsWithCode(@RequestBody List<CodeWertCriteriaDto> criterias) {
		Map<KategorieEnum, List<CodeWertDto>> codeWerts = getCodeWerts(
			criterias.stream().map(c -> c.getKategorie()).collect(Collectors.toList()), criterias.get(0).getLanguage());

		Map<KategorieEnum, List<CodeWertDto>> result = new HashMap<>();
		
		criterias.stream().forEach(criteria -> {
			KategorieEnum kategorie = criteria.getKategorie();
			if (CollectionUtils.isNotEmpty(criteria.getCodes()) && criteria.getCodes().size() > 0) {
				result.put(kategorie, codeWerts.get(kategorie).stream()
					.filter(c -> criteria.getCodes().contains(c.getCode())).collect(Collectors.toList()));
			} else {
				result.put(kategorie, codeWerts.get(kategorie).stream().collect(Collectors.toList()));
			}
		});

		return result;
	}
	
	private Map<KategorieEnum, List<CodeWertDto>> getCodeWerts(List<KategorieEnum> kategories,
		SupportedLanguage language) {
		Map<KategorieEnum, List<CodeWertDto>> results = new HashMap<KategorieEnum, List<CodeWertDto>>();
		applicationService.getCodeWerts(kategories).forEach((k, v) -> {
			
			List<CodeWertDto> value = v.stream().map(c -> {
				if (language != null) {
					return new CodeWertDto(c, language);
				}
				return new CodeWertDto(c, SecurityUtil.currentUser().getLanguagePreference());
			}).collect(Collectors.toList());
			
			if (k == KategorieEnum.LAND) {
				value = value.stream().sorted((l1, l2) -> l1.getText().compareTo(l2.getText()))
					.collect(Collectors.toList());
			}
			
			results.put(k, value);
		});
		return results;
	}
	
	@RequestMapping(value = "branches", method = RequestMethod.GET)
	public List<BrancheDto> branches(@RequestParam(required = false, name = "language") SupportedLanguage language) {
		SupportedLanguage lang = language != null ? language : SecurityUtil.currentUser().getLanguagePreference();

		List<BrancheEntity> branches = cacheService.getBranches();

		return buildParentChildRelationship(
			(Map<Long, BrancheDto>) branches.stream().map(e -> new BrancheDto(e, lang)).collect(Collectors.toList())
				.stream().collect(Collectors.toMap(BrancheDto::getId, b -> b)),
			branches.stream().filter(b -> b.getParent() != null)
				.collect(Collectors.groupingBy(BrancheEntity::getParent)));
	}	
	
	private <T extends AbstractGroupDto<T>, E extends AbstractOSSEntity> List<T> buildParentChildRelationship(
		Map<Long, T> mapOfDtos, Map<E, List<E>> mapOfEntitiesGroupedByParent) {

		List<T> dtos = new ArrayList<T>();

		for (Map.Entry<E, List<E>> entry : mapOfEntitiesGroupedByParent.entrySet()) {
			T parent = mapOfDtos.get(entry.getKey().getId());

			List<T> children = new ArrayList<>();
			entry.getValue().forEach(v -> {
				children.add(mapOfDtos.get(v.getId()));
			});
			children.sort((a, b) -> a.getPos() - b.getPos());
			
			parent.getChildren().addAll(children);
			
			dtos.add(parent);
		}

		return dtos.stream().sorted((a, b) -> a.getPos() - b.getPos()).collect(Collectors.toList());
	}
	
	@RequestMapping(value ="verbands", method = RequestMethod.GET)
	public List<VerbandDto> getVerbands() {
		return cacheService.getVerbands()
				.stream()
				.map(verband -> mapper.map(verband, VerbandDto.class))
				.collect(Collectors.toList());
	}	

	@RequestMapping(value = "berufs", method = RequestMethod.GET)
	public List<BerufDto> berufs(@RequestParam(required = false, name = "language") SupportedLanguage language) {
		SupportedLanguage lang = language != null ? language : SecurityUtil.currentUser().getLanguagePreference();

		List<BerufEntity> berufs = cacheService.getBerufs();

		return buildParentChildRelationship(
			(Map<Long, BerufDto>) berufs.stream().map(e -> new BerufDto(e, lang)).collect(Collectors.toList()).stream()
				.collect(Collectors.toMap(BerufDto::getId, b -> b)),
			berufs.stream().filter(b -> b.getParent() != null).collect(Collectors.groupingBy(BerufEntity::getParent)));
	}

	@RequestMapping(value = "heimatorts", method = RequestMethod.GET)
	public List<CHOrtDto> heimatorts(@RequestParam(name = "ort") String ort) {
		return this.portalService.getCHOrts(DataUtil.removeDiacritic(ort)).stream()
			.map(ent -> mapper.map(ent, CHOrtDto.class))
			.collect(Collectors.toList());
	}
	
	@RequestMapping(value ="kantons", method = RequestMethod.GET)
	public List<String> kantons() {
		return this.applicationService.getKantons();
	}

	@RequestMapping(value ="flowHistory", method = RequestMethod.PUT)
	public FlowHistoryDto saveFlowHistory(@RequestBody FlowHistoryDto dto) {
		FlowHistoryEntity flowHistory = new FlowHistoryEntity();
		flowHistory.setId(dto.getId());
		
		mapper.map(dto, flowHistory);
		
		return mapper.map(applicationService.saveFlowHistory(flowHistory), FlowHistoryDto.class);
	}
	
	@RequestMapping(value ="contactAddressInfo", method = RequestMethod.POST)
	public ContactAddressInfoDto getContactAddressInfo(@RequestBody ContactAddressInfoDto dto) {
		dto.setHrAmt(mapper.map(applicationService.getHrAmtByDomizilBfsnr(dto.getPlace().getBfsnr()), HrAmtDto.class));
		if (MITGLIEDSCHAFT_JA.equals(dto.getMitgliedschaft()) || MITGLIEDSCHAFT_BALD.equals(dto.getMitgliedschaft())) {
			VerbandEntity verband = cacheService.getVerbands().stream().filter(v -> v.getId() == dto.getBerufId())
				.findFirst().get();
			dto.setVerbandDto(mapper.map(verband, VerbandDto.class));
		} else {
			dto.setAusgleichskasseDto(
				mapper.map(applicationService.findDefaultAusleichskasseInKanton(dto.getPlace().getKanton(),
					dto.getPlace().getOrt(), dto.getPlace().getPlz()), AusgleichskasseDto.class));
		}
		return dto;
	}
	
	@RequestMapping(value = "landing", method = RequestMethod.GET)
	public ResponseEntity<?> landingPage(HttpServletResponse response, HttpSession session,
		@RequestParam("u") String code, @RequestParam("c") String campaign) throws IOException {
		if (StringUtils.isAnyEmpty(code, campaign)) {
			throw new ValidationException("Parameter u (code) and c (campaign) are required.");
		}
		landingPageService.trackLandingPage(code, campaign);
		session.setAttribute(CommonConstants.SESSION_LANDING_PAGE_CODE_KEY, code);
		session.setAttribute(CommonConstants.SESSION_LANDING_PAGE_CAMPAIGN_KEY, campaign);

		return ResponseEntity.ok(new HashMap<String, String>() {
			private static final long serialVersionUID = 1L; 
			{
				put("redirectUrl", "/");
			}
		});
	}
	
	@RequestMapping(value = "versicherungs", method = RequestMethod.GET)
	public List<VersicherungDto> getVersicherungs(
		@RequestParam(required = false, name = "language") SupportedLanguage language) {
		return cacheService.getVersicherungs().stream().map(ver -> {
			VersicherungDto versicherung = mapper.map(ver, VersicherungDto.class);
			versicherung.getStandardText()
				.setTranslations(filterTextTranslation(versicherung.getStandardText().getTranslations(), language));
			return versicherung;
		}).sorted((ver1, ver2) -> {
			return ver1.getStandardText().getTranslations().get(0).getText()
				.compareTo(ver2.getStandardText().getTranslations().get(0).getText());
		}).collect(Collectors.toList());
	}
	
	private List<TextTranslationDto> filterTextTranslation(List<TextTranslationDto> textTranslation,
		SupportedLanguage language) {
		return textTranslation.stream().filter(trans -> trans.getLanguage() == language).collect(Collectors.toList());
	}
	
	@RequestMapping(value = "numberOfOrgs", method = RequestMethod.GET)
	public Long getNumberOfOrgs() {
		return applicationService.countAllOrgs();
	}
	
	@RequestMapping(value = "ossRefParameters", method = RequestMethod.GET)
	public Map<String, String> getOssRefParameters() {
		return new HashMap<String, String>() {
			private static final long serialVersionUID = -6124834933838540374L;
			{
				put("intervalOfRefreshingNumberOfOrg", String.valueOf(intervalOfRefreshingNumberOfOrg));
				put("isDisplayUserAccount12Months", String.valueOf(userAccount12Months));
				put("isDisplayCompanies12Months", String.valueOf(companies12Months));
				put("timeForEachTaskHrMutation", String.valueOf(timeForEachTaskHrMutation));
				put("eiamLoginURL", eiamLoginURL);
				put("eiamRegisterURL", eiamRegisterURL);
				put("eiamLogoutURL", eiamLogoutURL);
			}
		};
	}
	
	@RequestMapping(value = "nutzungsstatistik", method = RequestMethod.GET)
	public List<Long> getNutzungsstatistik() {		
		long countUsersInLastYear = userAccount12Months ? applicationService.countUsersInLastYear() : 0;
		long countOrgsInLastYear = companies12Months ? applicationService.countOrgsInLastYear() : 0;
		return Arrays.asList(
			applicationService.countAllUsers(), 
			countUsersInLastYear,
			applicationService.countAllOrgs(), 
			countOrgsInLastYear
			);
	}
}
