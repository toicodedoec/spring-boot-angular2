/*
 * AusgleichskassenCriteria
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.criteria;

import ch.admin.oss.common.enums.AktivFilterEnum;

/**
 * @author tdm
 *
 */
public class AusgleichskasseCriteria extends AbstractPaginationCriteria {
	
	private AktivFilterEnum status;
	private String code;
	private String text;
	
	public AktivFilterEnum getStatus() {
		return status;
	}
	public void setStatus(AktivFilterEnum status) {
		this.status = status;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	
}
