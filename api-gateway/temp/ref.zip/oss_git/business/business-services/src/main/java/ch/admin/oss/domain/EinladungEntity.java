/*
 * Einladung
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.envers.Audited;

import ch.admin.oss.common.enums.AccessLevelEnum;
import ch.admin.oss.util.OSSConstants;

/**
 * @author coh
 *
 */
@Audited
@Entity
@Table(name = "T_EINLADUNG")
public class EinladungEntity extends AbstractOSSEntity {

	@NotNull
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name = "FK_EINLADUNG_ORGANISATION"))
	private OrganisationEntity organisation; 
	
	@NotNull
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "LN_EINLADENDER", foreignKey = @ForeignKey(name = "FK_EINLADUNG_USER"))
	private UserEntity einladender;
	
	@NotNull
	@Column(name = "EINLADUNGS_CODE")
	private String einladungsCode;
	
	@NotNull
	@Column(name = "AUSGESTELLT")
	private LocalDate ausgestellt;
	
	@NotNull
	@Column(name = "ABLAUF")
	private LocalDate ablauf;
	
	@Column(name = "ZUGRIFFVON")
	private LocalDate zugriffVon;
	
	@Column(name = "ZUGRIFFBIS")
	private LocalDate zugriffBis;
	
	@NotNull
	@Column(name = "ZUGRIFFSSTUFE")
	@Enumerated(EnumType.STRING)
	private AccessLevelEnum zugriffsstufe;
	
	@NotNull
	/**
	 * Regex allowing email addresses permitted by RFC 5322
	 */
	@Pattern(regexp = OSSConstants.EMAIL_REGEX_PATTERN)
	@Column(name = "EMAIL")
	private String email;
	
	@AssertTrue
	public boolean isEndDateAfterStartDate() {
		if (this.ablauf.isBefore(this.ausgestellt)) {
			return false;
		}
		return true;
	}
	
	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public UserEntity getEinladender() {
		return einladender;
	}

	public void setEinladender(UserEntity einladender) {
		this.einladender = einladender;
	}

	public String getEinladungsCode() {
		return einladungsCode;
	}

	public void setEinladungsCode(String einladungsCode) {
		this.einladungsCode = einladungsCode;
	}

	public LocalDate getAusgestellt() {
		return ausgestellt;
	}

	public void setAusgestellt(LocalDate ausgestellt) {
		this.ausgestellt = ausgestellt;
	}

	public LocalDate getAblauf() {
		return ablauf;
	}

	public void setAblauf(LocalDate ablauf) {
		this.ablauf = ablauf;
	}

	public LocalDate getZugriffVon() {
		return zugriffVon;
	}

	public void setZugriffVon(LocalDate zugriffVon) {
		this.zugriffVon = zugriffVon;
	}

	public LocalDate getZugriffBis() {
		return zugriffBis;
	}

	public void setZugriffBis(LocalDate zugriffBis) {
		this.zugriffBis = zugriffBis;
	}

	public AccessLevelEnum getZugriffsstufe() {
		return zugriffsstufe;
	}

	public void setZugriffsstufe(AccessLevelEnum zugriffsstufe) {
		this.zugriffsstufe = zugriffsstufe;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	@Transient
	public String getEid() {
		return this.einladender.getEid();
	}
	
	@Transient
	public long getOrgId() {
		return this.organisation.getId();
	}

	@Transient
	public String getOrgName() {
		return this.organisation.getNamens().stream().filter(namens -> namens.isDefault()).findFirst().get()
			.getBezeichnung();
	}
	
	@Transient
	public String getDateVonAndBis() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(OSSConstants.DATE_FORMAT);
		String fromDate = this.ausgestellt.format(formatter).toString();
		String toDate = this.ablauf.format(formatter).toString();
		return fromDate + " - " + toDate;
	}
}
