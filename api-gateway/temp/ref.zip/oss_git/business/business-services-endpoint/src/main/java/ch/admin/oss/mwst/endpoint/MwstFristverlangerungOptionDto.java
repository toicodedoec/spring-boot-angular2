package ch.admin.oss.mwst.endpoint;

/**
 * 
 * @author hhu
 *
 */
public class MwstFristverlangerungOptionDto {
	private String text;
	private String value;
	
	public MwstFristverlangerungOptionDto() {
	}
	
	public MwstFristverlangerungOptionDto(String text, String value) {
		super();
		this.text = text;
		this.value = value;
	}
	public String getText() {
		return text;
	}
	public String getValue() {
		return value;
	}
}
