/*
 * IHRService
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.service;

import java.util.List;

import javax.validation.Valid;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;

import com.querydsl.core.types.Path;

import ch.admin.oss.admin.criteria.AusgleichskasseCriteria;
import ch.admin.oss.admin.criteria.BerufsverbandeCriteria;
import ch.admin.oss.admin.criteria.BranchenCriteria;
import ch.admin.oss.admin.criteria.FunktionRechteCriteria;
import ch.admin.oss.admin.criteria.PrivatversichererCriteria;
import ch.admin.oss.admin.criteria.StandardTextCriteria;
import ch.admin.oss.admin.criteria.WertelistenCriteria;
import ch.admin.oss.admin.dto.ListResultDto;
import ch.admin.oss.admin.dto.NewsletterResultDto;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.domain.AbgeschlossenerProzesseStatistikDto;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.BenutzerkontoBerechtigungenStatistikDto;
import ch.admin.oss.domain.BenutzerregistrierungenStatistikDto;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.FunktionRechteEntity;
import ch.admin.oss.domain.GrundungenStatistikDto;
import ch.admin.oss.domain.StandardTextEntity;
import ch.admin.oss.domain.VerbandEntity;
import ch.admin.oss.domain.VerbundenerUnternehmenStatistikDto;
import ch.admin.oss.domain.VersicherungEntity;

/**
 * Interface for Admin's services.
 * 
 * @author hha
 */
@Validated
public interface IAdminService {
	
	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<AbgeschlossenerProzesseStatistikDto> statistikAbgeschlossenerProzesse();
	
	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<GrundungenStatistikDto> statistikGrundungen();
	
	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<BenutzerregistrierungenStatistikDto> statistikBenutzerregistrierungen();
	
	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<VerbundenerUnternehmenStatistikDto> statistikVerbundenerUnternehmen();
	
	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<BenutzerkontoBerechtigungenStatistikDto> statistikBenutzerkontoBerechtigungen();

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_PERMISSIONS)")
	ListResultDto<FunktionRechteEntity> getPaginationFunktionRechtes(FunktionRechteCriteria criteria);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_PERMISSIONS)")
	FunktionRechteEntity getFunktionRechte(long id);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_PERMISSIONS)")
	FunktionRechteEntity saveFunktionRechte(FunktionRechteEntity entity);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	ListResultDto<StandardTextEntity> getPaginationStandardTexts(StandardTextCriteria criteria);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	StandardTextEntity getStandardText(long id);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	StandardTextEntity saveStandardText(StandardTextEntity entity);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	ListResultDto<CodeWertEntity> getPaginationCodeWertListen(WertelistenCriteria criteria);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	CodeWertEntity saveCodeWertEntity(CodeWertEntity entity);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	CodeWertEntity getCodeWertEntity(long id);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	ListResultDto<BrancheEntity> getPaginationBranchen(BranchenCriteria criteria);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<BrancheEntity> getBrancheGroup();

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BrancheEntity getBranche(long id, int... version);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BrancheEntity saveBranche(@Valid BrancheEntity ent);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	ListResultDto<VerbandEntity> getPaginationVerbandListen(BerufsverbandeCriteria criteria);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	int getMinPosInBrancheGroup(Long brancheGroupId);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	VerbandEntity getVerband(long id);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	VerbandEntity saveVerband(VerbandEntity verbandEntity);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	AusgleichskasseEntity getAusgleichskasse(long id, Path<?>... associations);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<AusgleichskasseEntity> getActivAusgleichskasse();

	ListResultDto<AusgleichskasseEntity> getPaginationAusgleichskasseListen(AusgleichskasseCriteria criteria);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BrancheEntity getParentBrancheToSwap(int currentPos, boolean isUp);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BrancheEntity getSubBrancheToSwap(int currentPos, long parentId, boolean isUp);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<Integer> getMaxAndMinPosOfParentBranche();

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	void saveBranches(@Valid BrancheEntity... ent);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_PERMISSIONS)")
	ListResultDto<VersicherungEntity> getPaginationPrivatversichererListen(PrivatversichererCriteria criteria);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BrancheEntity getBranche(String code);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	int getMaxPosInBrancheGroup(Long brancheGroupId);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_PERMISSIONS)")
	VersicherungEntity getVersicherungEntity(long id);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_PERMISSIONS)")
	VersicherungEntity saveVersicherungEntity(VersicherungEntity ent);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	AusgleichskasseEntity saveAusgleichskasse(AusgleichskasseEntity ent);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	ListResultDto<BerufEntity> getPaginationBerufe(BranchenCriteria criteria);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<BerufEntity> getBerufGroup();

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BerufEntity getBeruf(long id, int... version);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BerufEntity saveBeruf(@Valid BerufEntity ent);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BerufEntity getBeruf(String code);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	int getMaxPosInBerufGroup(Long berufGroupId);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	int getMinPosInBerufGroup(Long berufGroupId);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BerufEntity getParentBerufToSwap(int currentPos, boolean isUp);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	BerufEntity getSubBerufToSwap(int currentPos, long parentId, boolean isUp);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<Integer> getMaxAndMinPosOfParentBeruf();

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	void saveBerufe(@Valid BerufEntity... ent);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<BrancheEntity> getSubBranchen();
	
	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	List<String> getCampaigns();
	
	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	NewsletterResultDto getCampaignInfo(String campaign);

	@PreAuthorize("hasPermission(null, T(ch.admin.oss.enums.SecuredEntityEnum).ADMIN, T(ch.admin.oss.common.enums.FunktionEnum).F_ADMIN)")
	FileDto generateStatistikCSV();
}
