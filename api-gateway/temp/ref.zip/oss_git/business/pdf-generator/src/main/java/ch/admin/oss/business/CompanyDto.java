/*
 * CompanyDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import ch.admin.oss.OssDateFormatter;

/**
 * @author hhg
 */
public class CompanyDto {

	private String companyName;
	private String givenName;
	private String name;

	private AddressDto domizil;
	private String zweck;
	private LocalDate eroeffnungsdatum;
	@OssDateFormatter(hideYear = true)
	private LocalDate geschaeftsjahrEnde;
	private String rechtsform;
	private String rechtsformType;
	private boolean digital;

	private FirmennameDto defaultFirmenname;
	private List<FirmennameDto> firmennames = new ArrayList<>();
	private String combinedFirmenname;

	private String chNr;
	private String uid;
	private String combinedBranch;

	private List<GeschaeftsstelleDto> geschaeftsstellens = new ArrayList<>();
	private List<GeschaftsrolleDto> limitedPersons = new ArrayList<>();
	private List<GeschaftsrolleDto> unlimitedPersons = new ArrayList<>();
	private List<GeschaftsrolleDto> naturalPersons = new ArrayList<>();
	private List<KommFirmaDto> kommFirmas = new ArrayList<>();

	private boolean ag;

	public CompanyDto() {
		// Default constructor.
	}

	public CompanyDto(String companyName, String givenName, String name) {
		this.companyName = companyName;
		this.givenName = givenName;
		this.name = name;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getGivenName() {
		return givenName;
	}

	public void setGivenName(String givenName) {
		this.givenName = givenName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AddressDto getDomizil() {
		return domizil;
	}

	public void setDomizil(AddressDto domizil) {
		this.domizil = domizil;
	}

	public String getZweck() {
		return zweck;
	}

	public void setZweck(String zweck) {
		this.zweck = zweck;
	}

	public LocalDate getEroeffnungsdatum() {
		return eroeffnungsdatum;
	}

	public void setEroeffnungsdatum(LocalDate eroeffnungsdatum) {
		this.eroeffnungsdatum = eroeffnungsdatum;
	}

	public LocalDate getGeschaeftsjahrEnde() {
		return geschaeftsjahrEnde;
	}

	public void setGeschaeftsjahrEnde(LocalDate geschaeftsjahrEnde) {
		this.geschaeftsjahrEnde = geschaeftsjahrEnde;
	}

	public String getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(String rechtsform) {
		this.rechtsform = rechtsform;
	}
	
	public String getRechtsformType() {
		return rechtsformType;
	}

	public void setRechtsformType(String rechtsformType) {
		this.rechtsformType = rechtsformType;
	}

	public boolean isDigital() {
		return digital;
	}

	public void setDigital(boolean digital) {
		this.digital = digital;
	}

	public FirmennameDto getDefaultFirmenname() {
		return defaultFirmenname;
	}

	public void setDefaultFirmenname(FirmennameDto defaultFirmenname) {
		this.defaultFirmenname = defaultFirmenname;
	}

	public List<FirmennameDto> getFirmennames() {
		return firmennames;
	}

	public void setFirmennames(List<FirmennameDto> firmennames) {
		this.firmennames = firmennames;
	}

	public String getChNr() {
		return chNr;
	}

	public void setChNr(String chNr) {
		this.chNr = chNr;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getCombinedBranch() {
		return combinedBranch;
	}

	public void setCombinedBranch(String combinedBranch) {
		this.combinedBranch = combinedBranch;
	}

	public List<GeschaeftsstelleDto> getGeschaeftsstellens() {
		return geschaeftsstellens;
	}

	public void setGeschaeftsstellens(List<GeschaeftsstelleDto> geschaeftsstellens) {
		this.geschaeftsstellens = geschaeftsstellens;
	}

	public List<GeschaftsrolleDto> getLimitedPersons() {
		return limitedPersons;
	}

	public void setLimitedPersons(List<GeschaftsrolleDto> limitedPersons) {
		this.limitedPersons = limitedPersons;
	}

	public List<GeschaftsrolleDto> getUnlimitedPersons() {
		return unlimitedPersons;
	}

	public void setUnlimitedPersons(List<GeschaftsrolleDto> unlimitedPersons) {
		this.unlimitedPersons = unlimitedPersons;
	}

	public List<GeschaftsrolleDto> getNaturalPersons() {
		return naturalPersons;
	}

	public void setNaturalPersons(List<GeschaftsrolleDto> naturalPersons) {
		this.naturalPersons = naturalPersons;
	}

	public List<KommFirmaDto> getKommFirmas() {
		return kommFirmas;
	}

	public void setKommFirmas(List<KommFirmaDto> kommFirmas) {
		this.kommFirmas = kommFirmas;
	}

	public String getCombinedFirmenname() {
		return combinedFirmenname;
	}

	public void setCombinedFirmenname(String combinedFirmenname) {
		this.combinedFirmenname = combinedFirmenname;
	}

	public boolean isAg() {
		return ag;
	}

	public void setAg(boolean ag) {
		this.ag = ag;
	}

}
