/*
 * KommFirmaDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author coh
 */
public class KommFirmaDto extends AbstractOSSDto {
	
	private Long orgId;
	private AdresseDto domizil;
	private Long haftung;
	private CodeWertDto einlage;
	private RechtsformEnum rechtsformCH;
	private String rechtsformAusland;
	private String name;
	private String hrNummer;
	private boolean complete;
	private boolean delete;

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public AdresseDto getDomizil() {
		return domizil;
	}

	public void setDomizil(AdresseDto domizil) {
		this.domizil = domizil;
	}

	public Long getHaftung() {
		return haftung;
	}

	public void setHaftung(Long haftung) {
		this.haftung = haftung;
	}

	public CodeWertDto getEinlage() {
		return einlage;
	}

	public void setEinlage(CodeWertDto einlage) {
		this.einlage = einlage;
	}

	public RechtsformEnum getRechtsformCH() {
		return rechtsformCH;
	}

	public void setRechtsformCH(RechtsformEnum rechtsformCH) {
		this.rechtsformCH = rechtsformCH;
	}

	public String getRechtsformAusland() {
		return rechtsformAusland;
	}

	public void setRechtsformAusland(String rechtsformAusland) {
		this.rechtsformAusland = rechtsformAusland;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHrNummer() {
		return hrNummer;
	}

	public void setHrNummer(String hrNummer) {
		this.hrNummer = hrNummer;
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	public String getHrNummerFormatted() {
		return OssNumberFormatUtil.formatUid(hrNummer);
	}

	public void setHrNummerFormatted(String hrNummerFormatted) {
		// does nothing
	}

	public boolean isDelete() {
		return delete;
	}

	public void setDelete(boolean delete) {
		this.delete = delete;
	}

}
