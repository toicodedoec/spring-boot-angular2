package ch.admin.oss.admin.query;

import javax.persistence.EntityManager;

import com.querydsl.core.types.dsl.CaseBuilder;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.admin.criteria.BranchenCriteria;
import ch.admin.oss.common.enums.AktivFilterEnum;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.QBrancheEntity;

/**
 * @author xdg
 */
public class BranchenTextTranslationQuery extends AbstractTextTranslationQuery<BranchenCriteria, BrancheEntity> {	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public JPAQuery<BrancheEntity> buildQuery(BranchenCriteria criteria, EntityManager em) {
		QBrancheEntity qBranche = QBrancheEntity.brancheEntity;
		QBrancheEntity qParentBranche = new QBrancheEntity("parent");
		
		JPAQuery<BrancheEntity> query = new JPAQuery<BrancheEntity>(em)
			.from(qBranche)
			.leftJoin(qBranche.parent, qParentBranche).fetchJoin()
			.leftJoin(qBranche.standardText).fetchJoin()
			.orderBy(
				new CaseBuilder()
				.when(qParentBranche.id.isNotNull()).then(qParentBranche.pos)
				.otherwise(qBranche.pos).asc()
				)
			.orderBy(qParentBranche.id.asc().nullsFirst())
			.orderBy(qBranche.pos.asc());

		if (criteria.getStatus() == AktivFilterEnum.Unaktiv) {
			query.where(QBrancheEntity.brancheEntity.aktiv.eq(false));
		} else if (criteria.getStatus() == AktivFilterEnum.Aktiv) {
			query.where(QBrancheEntity.brancheEntity.aktiv.eq(true));
		}
		
		return query;
	}
}
