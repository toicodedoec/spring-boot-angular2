/*
 * AhvBeitraegeAlsEnum
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.ahv.endpoint;

/**
 * @author hhg
 *
 */
public enum AhvBeitraegeAlsEnum {

    ARBEITNEHMER("arbeitnehmer"),
    ARBEITGEBER("arbeitgeber"),
    TEILHABER("teilhaber"),
    SELBSTAENDIGERWERBENDER("selbstaendigerwerbender"),
    NICHT_ERWERBSTAETIGER("nichtErwerbstaetiger"),
    BEZUEGER_ERSATZEINKOMMEN("bezuegerErsatzeinkommen"),
    AUSLANDAUFENTHALT("auslandaufenthalt"),
    KEINE_BEITRAEGE("keineBeitraege");

	private final String value;

    private AhvBeitraegeAlsEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }
}
