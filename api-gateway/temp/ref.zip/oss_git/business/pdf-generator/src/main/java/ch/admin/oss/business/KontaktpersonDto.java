/*
 * KontaktpersonDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

/**
 * @author hhg
 *
 */
public class KontaktpersonDto {
	
	private String vorname;
	private String name;
	private String telefon;
	private String mobil;
	private String email;
	
	public KontaktpersonDto(String vorname, String name, String telefon, String mobil, String email) {
		this.vorname = vorname;
		this.name = name;
		this.telefon = telefon;
		this.mobil = mobil;
		this.email = email;
	}

	public String getVorname() {
		return vorname;
	}

	public String getName() {
		return name;
	}

	public String getTelefon() {
		return telefon;
	}

	public String getMobil() {
		return mobil;
	}

	public String getEmail() {
		return email;
	}
}
