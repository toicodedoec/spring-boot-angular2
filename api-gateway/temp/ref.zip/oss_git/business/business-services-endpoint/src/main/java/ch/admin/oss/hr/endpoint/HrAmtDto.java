/*
 * HrAmtDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hr.endpoint;

import ch.admin.oss.admin.endpoint.StandardTextDto;
import ch.admin.oss.common.AbstractOSSDto;

/**
 * @author xdg
 */
public class HrAmtDto extends AbstractOSSDto {

	private Integer nr;

	private String kanton;

	private String amtsbezeichnung;

	private String amtssprachen;

	private String strasse;

	private String zusatz;

	private String postfach;

	private String plz;

	private String ort;

	private String pubTel1;

	private String pubTel2;

	private String pubFax;

	private String pubMail;

	private String homepage;

	private StandardTextDto pubTel1Bemerkungen;

	private StandardTextDto pubTel2Bemerkungen;

	private StandardTextDto pubFaxBemerkungen;

	private StandardTextDto pubMailBemerkungen;

	private StandardTextDto unterschriftsbeglaubigung;

	private StandardTextDto oeffnungszeitenSchalter;

	public Integer getNr() {
		return nr;
	}

	public void setNr(Integer nr) {
		this.nr = nr;
	}

	public String getKanton() {
		return kanton;
	}

	public void setKanton(String kanton) {
		this.kanton = kanton;
	}

	public String getAmtsbezeichnung() {
		return amtsbezeichnung;
	}

	public void setAmtsbezeichnung(String amtsbezeichnung) {
		this.amtsbezeichnung = amtsbezeichnung;
	}

	public String getAmtssprachen() {
		return amtssprachen;
	}

	public void setAmtssprachen(String amtssprachen) {
		this.amtssprachen = amtssprachen;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getZusatz() {
		return zusatz;
	}

	public void setZusatz(String zusatz) {
		this.zusatz = zusatz;
	}

	public String getPostfach() {
		return postfach;
	}

	public void setPostfach(String postfach) {
		this.postfach = postfach;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getPubTel1() {
		return pubTel1;
	}

	public void setPubTel1(String pubTel1) {
		this.pubTel1 = pubTel1;
	}

	public String getPubTel2() {
		return pubTel2;
	}

	public void setPubTel2(String pubTel2) {
		this.pubTel2 = pubTel2;
	}

	public String getPubFax() {
		return pubFax;
	}

	public void setPubFax(String pubFax) {
		this.pubFax = pubFax;
	}

	public String getPubMail() {
		return pubMail;
	}

	public void setPubMail(String pubMail) {
		this.pubMail = pubMail;
	}

	public String getHomepage() {
		return homepage;
	}

	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}

	public StandardTextDto getUnterschriftsbeglaubigung() {
		return unterschriftsbeglaubigung;
	}

	public void setUnterschriftsbeglaubigung(StandardTextDto unterschriftsbeglaubigung) {
		this.unterschriftsbeglaubigung = unterschriftsbeglaubigung;
	}

	public StandardTextDto getPubTel1Bemerkungen() {
		return pubTel1Bemerkungen;
	}

	public void setPubTel1Bemerkungen(StandardTextDto pubTel1Bemerkungen) {
		this.pubTel1Bemerkungen = pubTel1Bemerkungen;
	}

	public StandardTextDto getPubTel2Bemerkungen() {
		return pubTel2Bemerkungen;
	}

	public void setPubTel2Bemerkungen(StandardTextDto pubTel2Bemerkungen) {
		this.pubTel2Bemerkungen = pubTel2Bemerkungen;
	}

	public StandardTextDto getPubFaxBemerkungen() {
		return pubFaxBemerkungen;
	}

	public void setPubFaxBemerkungen(StandardTextDto pubFaxBemerkungen) {
		this.pubFaxBemerkungen = pubFaxBemerkungen;
	}

	public StandardTextDto getPubMailBemerkungen() {
		return pubMailBemerkungen;
	}

	public void setPubMailBemerkungen(StandardTextDto pubMailBemerkungen) {
		this.pubMailBemerkungen = pubMailBemerkungen;
	}

	public StandardTextDto getOeffnungszeitenSchalter() {
		return oeffnungszeitenSchalter;
	}

	public void setOeffnungszeitenSchalter(StandardTextDto oeffnungszeitenSchalter) {
		this.oeffnungszeitenSchalter = oeffnungszeitenSchalter;
	}

}
