/*
 * OssAsposeRegion
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.generator.aspose;

import com.aspose.words.IMailMergeDataSource;
import com.aspose.words.IMailMergeDataSourceRoot;

/**
 * @author hha
 */
public class OssAsposeRegion extends OssAbstractAsposeBean implements IMailMergeDataSourceRoot {

	private Object object;

	public OssAsposeRegion(OssAsposeContext context, Object object) {
		super(context);
		this.object = object;
	}

	@Override
	public IMailMergeDataSource getDataSource(String regionName) throws Exception {
		return new OssAsposeBean(context, getValueAsCollection(object, regionName), regionName);
	}

}