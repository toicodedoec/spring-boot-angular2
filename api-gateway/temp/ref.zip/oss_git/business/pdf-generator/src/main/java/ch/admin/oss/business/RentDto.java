/*
 * RentDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;

import ch.admin.oss.OssCurrencyFormatter;

/**
 * @author hhg
 *
 */
public class RentDto {

	@OssCurrencyFormatter(integer = true)
	private BigDecimal buero;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal lager;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal werkstatt;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal laden;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal weitere;
	private String weitereArt;
	
	public RentDto(BigDecimal buero, BigDecimal lager, BigDecimal werkstatt, BigDecimal laden, BigDecimal weitere, String weitereArt) {
		this.buero = buero;
		this.lager = lager;
		this.werkstatt = werkstatt;
		this.laden = laden;
		this.weitere = weitere;
		this.weitereArt = weitereArt;
	}

	public BigDecimal getBuero() {
		return buero;
	}

	public BigDecimal getLager() {
		return lager;
	}

	public BigDecimal getWerkstatt() {
		return werkstatt;
	}

	public BigDecimal getLaden() {
		return laden;
	}

	public BigDecimal getWeitere() {
		return weitere;
	}

	public String getWeitereArt() {
		return weitereArt;
	}
}
