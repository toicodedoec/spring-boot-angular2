/*
 * HRServiceEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hr.endpoint;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ch.admin.oss.common.AbstractProzessEndpoint;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.ExceptionHandlingController;
import ch.admin.oss.common.GeschaftsrolleDto;
import ch.admin.oss.common.OssTechnicalException;
import ch.admin.oss.common.OwnerInfoDto;
import ch.admin.oss.common.PersonDto;
import ch.admin.oss.common.ProcessAccessStatus;
import ch.admin.oss.common.ProzessDto;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.dto.PersonResultDto;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.FirmennameEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrAmtEntity;
import ch.admin.oss.domain.HrAnmeldungEntity;
import ch.admin.oss.domain.HrGruenderEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PersonHeimatortEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.enums.SupportedFileTypeDownload;
import ch.admin.oss.externalinterfaces.outgoing.hr.IUPRegServiceAdapter;
import ch.admin.oss.externalinterfaces.outgoing.hr.NotaryDto;
import ch.admin.oss.externalinterfaces.outgoing.hr.NotaryFunctionDto;
import ch.admin.oss.externalinterfaces.outgoing.hr.NotaryOrganisationDto;
import ch.admin.oss.externalinterfaces.outgoing.juspace.JuspaceServiceAdapter;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.AddressInformationType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.AuthenticationTypeEnum;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.ContentType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.CrDataContainerType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.DeliveryTypeEnum;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.HeaderType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.IdentificationType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.NewEntryType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.OrganisationMailAddressInfoType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.OrganisationMailAddressType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.PlatformEnum;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.ProcessType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.ResponseChannelType;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.TaskTypeEnum;
import ch.admin.oss.externalinterfaces.outgoing.juspace.generated.TestDataType;
import ch.admin.oss.organisation.endpoint.FirmennameDto;
import ch.admin.oss.organisation.endpoint.OrganisationDto;
import ch.admin.oss.portal.endpoint.BrancheDto;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSConstants;

/**
 * @author phd
 */
@CrossOrigin
@RestController
@RequestMapping("/private/ext/hr")
public class HRServiceEndpoint extends AbstractProzessEndpoint<HRDto> {
	
	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(HRServiceEndpoint.class);

	public static final String HR_ANMELDUNG = "HrAnmeldung";

	@Autowired
	private IUPRegServiceAdapter upRegServiceAdapter;
	
	@Autowired
	private JuspaceServiceAdapter juspaceServiceAdapter;

	@Override
	protected boolean isProcessDoneExternal(PflichtenabklaerungenEntity pflich) {
		return pflich != null && pflich.isAnmeldungHR();
	}

	@Override
	protected boolean skipCheckHrStatus() {
		return true;
	}

	@Override
	public HRDto getProcessByOrgId(@PathVariable long orgId) {
		HrAnmeldungEntity hrAnmeldungEntity = hrService.getByOrganisationId(orgId);
		HRDto hrAnmeldungDto = mapEntityToDto(hrAnmeldungEntity);
		
		HrAmtEntity hrAmtEntity = applicationService
			.getHrAmtByDomizilBfsnr(hrAnmeldungDto.getProzess().getOrganisation().getDomizil().getBfsNr());
		hrAnmeldungDto.setHrAmt(mapper.map(hrAmtEntity, HrAmtDto.class));
		hrAnmeldungDto.getProzess().getOrganisation().setAccessFromOutsideFlow(true);
		
		return hrAnmeldungDto;
	}

	private HRDto mapEntityToDto(HrAnmeldungEntity hrAnmeldungEntity) {
		HRDto result = mapper.map(hrAnmeldungEntity, HRDto.class);
		if (result.getProzess().getOrganisation() != null && CollectionUtils.isNotEmpty(result.getProzess().getOrganisation().getBranches())) {
			result.getProzess().getOrganisation().setBranches(
				hrAnmeldungEntity.getProzess().getOrganisation().getBranches()
					.stream()
					.map(b -> new BrancheDto(b, SecurityUtil.currentUser().getLanguagePreference()))
					.collect(Collectors.toList())
				);
		}
		return result;
	}

	@Override
	public ResponseEntity<?> update(@RequestBody HRDto dto) {
		return saveOrUpdate(dto, HrSaveType.SAVE);
	}

	@Override
	public ResponseEntity<?> complete(@RequestBody HRDto dto) {
		return saveOrUpdate(dto, HrSaveType.COMPLETE);
	}
	
	@Override
	public ResponseEntity<?> lock(@PathVariable long orgId) {
		return saveOrUpdate(createDummyDto(orgId), HrSaveType.LOCK);
	}

	@Override
	public ResponseEntity<?> sign(@PathVariable long orgId) {
		return saveOrUpdate(createDummyDto(orgId), HrSaveType.SIGN);
	}

	@Override
	public ResponseEntity<?> relock(@PathVariable long orgId) {
		return saveOrUpdate(createDummyDto(orgId), HrSaveType.RELOCK);
	}

	private HRDto createDummyDto(long orgId) {
		HRDto dto = new HRDto();
		ProzessDto prozess = new ProzessDto();
		OrganisationDto organisation = new OrganisationDto();
		organisation.setId(orgId);
		prozess.setOrganisation(organisation);
		dto.setProzess(prozess);
		return dto;
	}

	private ResponseEntity<?> saveOrUpdate(HRDto dto, HrSaveType saveType) {
		Long orgId = dto.getProzess().getOrganisation().getId();
		ProcessAccessStatus accessStatus = canAccessProcess(orgId);
		if (accessStatus != ProcessAccessStatus.OK) {
			return ResponseEntity
				.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("The HR cannot be accessed with error code: " + accessStatus));
		}
	
		HrAnmeldungEntity entity = hrService.getByOrganisationId(orgId);
		if (saveType.isUpdateData()) {
			mapData(dto, entity);
		}
	
		if (saveType == HrSaveType.SAVE) {
			entity = hrService.updateProcess(entity);
		} else if (saveType == HrSaveType.COMPLETE) {
			entity = hrService.completeProcess(entity);
		} else if (saveType == HrSaveType.LOCK) {
			entity = hrService.lockProcess(entity);
		} else if (saveType == HrSaveType.SIGN) {
			entity = hrService.signProcess(entity);
		} else if (saveType == HrSaveType.RELOCK) {
			entity = hrService.relockProcess(entity);
		}

		return ResponseEntity.ok(getProcessByOrgId(orgId));
	}

	private void mapData(HRDto dto, HrAnmeldungEntity entity) {
		mapper.map(dto, entity, HR_ANMELDUNG);

		// Capital share AG / GmbH
		RechtsformEnum rechtsform = entity.getProzess().getOrganisation().getRechtsform();
		entity.getProzess().getOrganisation().getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)
			.stream().forEach(item -> {
				for (GeschaftsrolleDto gruender : dto.getProzess().getOrganisation().getGeschaeftsrollens()) {
					if (item.getId().equals(gruender.getId())) {
						if (rechtsform == RechtsformEnum.AG) {
							item.setAnzInhaberaktien(gruender.getAnzInhaberaktien());
							item.setAnzNamensaktien(gruender.getAnzNamensaktien());
						} else if (rechtsform == RechtsformEnum.GMBH) {
							item.setAnzStammanteile(gruender.getAnzStammanteile());
						}
						break;
					}
				}
			});
		entity.getGruenders().forEach(item -> {
			for (HrGruenderDto gruender : dto.getGruenders()) {
				if (item.getId().equals(gruender.getId())) {
					if (rechtsform == RechtsformEnum.AG) {
						item.setAnzInhaberaktien(gruender.getAnzInhaberaktien());
						item.setAnzNamensaktien(gruender.getAnzNamensaktien());
					} else if (rechtsform == RechtsformEnum.GMBH) {
						item.setAnzStammanteile(gruender.getAnzStammanteile());
					}
					break;
				}
			}
		});
		
		// Save inHR for HrDiv
		if (CollectionUtils.isNotEmpty(dto.getProzess().getOrganisation().getGeschaeftsstellens())) {
			dto.getProzess().getOrganisation().getGeschaeftsstellens().stream().forEach(gesDto -> {
				entity.getProzess().getOrganisation().getGeschaeftsstellens().stream().forEach(gesEntity -> {
					if (gesDto.getId().equals(gesEntity.getId())) {
						gesEntity.setInHR(gesDto.isInHR());
					}
				});
			});
		}

		// TranslateName Screen
		entity.getProzess().getOrganisation().getNamens().clear();
		OrganisationEntity organisation = entity.getProzess().getOrganisation();
		dto.getProzess().getOrganisation().getNamens().stream().forEach(namenDto -> {
			FirmennameEntity namen = mapper.map(namenDto, FirmennameEntity.class);
			namen.setOrganisation(organisation);
			entity.getProzess().getOrganisation().getNamens().add(namen);
		});

		// Offline Notary
		entity.setNotarAnrede(getCodeWert(KategorieEnum.ANREDE, dto.getNotarAnrede()));

		// Empty is not a valid email.
		if (StringUtils.isBlank(entity.getNotarEmail())) {
			entity.setNotarEmail(null);
		}
	}

	@RequestMapping(value = "/notary", method = RequestMethod.GET)
	public List<HrNotaryDto> findNotaries(@RequestParam String kanton,
			@RequestParam String familienname, @RequestParam String vorname) {
		List<NotaryDto> notaryDtos = upRegServiceAdapter.searchNotaries(kanton, familienname, vorname);
		final List<HrNotaryDto> notaries = new ArrayList<HrNotaryDto>(notaryDtos.size());
		notaryDtos.forEach(item -> {
			HrNotaryDto notary = new HrNotaryDto();
			NotaryFunctionDto function = CollectionUtils.isNotEmpty(item.getFunctions()) ? item.getFunctions().get(0) : null;
			NotaryOrganisationDto organisation = function != null ? function.getOrganisation() : null;

			notary.setNotarVorname(item.getCallName());
			notary.setNotarName(item.getName());
			notary.setNotarTitel(item.getPersonTitle());
			notary.setNotarUpRegUUID(item.getUuid());

			String anredeCode = null;
			if (OSSConstants.GESCHLECHT_MR_CODE.equals(item.getPersonGender())) {
				anredeCode = OSSConstants.ANDERE_MR_CODE;
			} else if (OSSConstants.GESCHLECHT_MRS_CODE.equals(item.getPersonGender())) {
				anredeCode = OSSConstants.ANDERE_MRS_CODE;
			}
			if (StringUtils.isNotEmpty(anredeCode)) {
				notary.setNotarAnrede(mapper.map(getCodeWert(KategorieEnum.ANREDE, anredeCode), CodeWertDto.class));
			}

			if (function != null) {
				notary.setNotarKanton(function.getCanton());
				notary.setNotarFunktion(function.getName());
			}
			if (organisation != null) {
				notary.setNotarEmail(organisation.getOrganizationContactEMail());
				notary.setNotarTelefon(StringUtils.remove(organisation.getOrganizationContactPhone(), " "));
				notary.setNotarPostadresse(organisation.getOrganizationAddress());
				notary.setNotarFax(organisation.getOrganizationContactFax());
			}
			notaries.add(notary);
		});
		return notaries;
	}

	@RequestMapping(value = "/founderOwnerInfo", method = RequestMethod.PUT)
	public PersonResultDto<OwnerInfoDto<HrGruenderDto>, HRDto> founderOwnerInfo(@RequestBody OwnerInfoDto<HrGruenderDto> ownerInfoDto) {
		PersonResultDto<HrGruenderEntity, HrAnmeldungEntity> result
			= hrService.saveUnvalidatedHrGruender(ownerInfoDto.getSourceId(), convertHrGruenderFromDto2Entity(ownerInfoDto.getSourceId(), ownerInfoDto));
		ownerInfoDto.setRole(mapper.map(result.getPerson(), HrGruenderDto.class));
		return new PersonResultDto<>(ownerInfoDto, mapEntityToDto(result.getEntity()));
	}

	@RequestMapping(value = "/founderOwnerInfoWithValidated", method = RequestMethod.PUT)
	public PersonResultDto<OwnerInfoDto<HrGruenderDto>, HRDto> founderOwnerInfoWithValidated(
		@RequestBody OwnerInfoDto<HrGruenderDto> ownerInfoDto) {
		PersonResultDto<HrGruenderEntity, HrAnmeldungEntity> result
			= hrService.saveValidatedHrGruender(ownerInfoDto.getSourceId(), convertHrGruenderFromDto2Entity(ownerInfoDto.getSourceId(), ownerInfoDto));
		ownerInfoDto.setRole(mapper.map(result.getPerson(), HrGruenderDto.class));
		return new PersonResultDto<>(ownerInfoDto, mapEntityToDto(result.getEntity()));
	}

	@RequestMapping(value = "/founderOwnerInfo", method = RequestMethod.DELETE)
	public ResponseEntity<?> founderOwnerInfo(@RequestParam("orgId") long orgId,
		@RequestParam("founderVer") int version, @RequestParam("founderId") long id) {
		HrGruenderEntity hrEnt = hrService.getHrGruenderById(orgId, id, version);
		if (hrEnt == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Can not find founder"));
		}

		PersonResultDto<HrGruenderEntity, HrAnmeldungEntity> result = hrService.deleteHrGruender(orgId, hrEnt);
		return ResponseEntity.ok(new PersonResultDto<>(null, mapEntityToDto(result.getEntity())));
	}

	@RequestMapping(value = "/signatoryOwnerInfo", method = RequestMethod.PUT)
	public PersonResultDto<OwnerInfoDto<GeschaftsrolleDto>, HRDto> signatoryOwnerInfo(
		@RequestBody OwnerInfoDto<GeschaftsrolleDto> ownerInfoDto) {
		GeschaftsrolleEntity rolleEnt = convertRolleDto2RolleEntity(ownerInfoDto);
		PersonResultDto<GeschaftsrolleEntity, HrAnmeldungEntity> result
			= hrService.saveUnvalidatedGeschaftsrolle(ownerInfoDto.getSourceId(), rolleEnt);
		ownerInfoDto.setRole(mapper.map(result.getPerson(), GeschaftsrolleDto.class));
		return new PersonResultDto<>(ownerInfoDto, mapEntityToDto(result.getEntity()));
	}

	@RequestMapping(value = "/signatoryOwnerInfoWithValidated", method = RequestMethod.PUT)
	public PersonResultDto<OwnerInfoDto<GeschaftsrolleDto>, HRDto> signatoryOwnerInfoWithValidated(
		@RequestBody OwnerInfoDto<GeschaftsrolleDto> ownerInfoDto) {
		GeschaftsrolleEntity rolleEnt = convertRolleDto2RolleEntity(ownerInfoDto);
		PersonResultDto<GeschaftsrolleEntity, HrAnmeldungEntity> result
			= hrService.saveValidatedGeschaftsrolle(ownerInfoDto.getSourceId(), rolleEnt);
		ownerInfoDto.setRole(mapper.map(result.getPerson(), GeschaftsrolleDto.class));
		return new PersonResultDto<>(ownerInfoDto, mapEntityToDto(result.getEntity()));
	}

	@RequestMapping(value = "/signatoryOwnerInfo", method = RequestMethod.DELETE)
	public ResponseEntity<?> signatoryOwnerInfo(@RequestParam("orgId") long orgId,
		@RequestParam("sigVer") int version, @RequestParam("sigId") long id) {
		GeschaftsrolleEntity geschaftsrolleEntity = organisationService.findGeschaftsrolleByIdAndOrgId(orgId, id, version);
		if (geschaftsrolleEntity == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Can not find role"));
		}
		PersonResultDto<GeschaftsrolleEntity, HrAnmeldungEntity> result = hrService.deleteGeschaftsrolle(orgId, geschaftsrolleEntity);
		return ResponseEntity.ok(new PersonResultDto<>(null, mapEntityToDto(result.getEntity())));
	}

	/**
	 * @param ownerInfoDto
	 * @return
	 */
	private HrGruenderEntity convertHrGruenderFromDto2Entity(long orgId, OwnerInfoDto<HrGruenderDto> ownerInfoDto) {
		HrGruenderDto hrDto = ownerInfoDto.getRole();
		HrGruenderEntity hrEnt = new HrGruenderEntity();

		if (hrDto.getId() != null) {
			hrEnt = hrService.getHrGruenderById(orgId, hrDto.getId(), hrDto.getVersion());
		}

		hrEnt.setHrAnmeldung(hrService.getByOrganisationId(ownerInfoDto.getSourceId()));
		hrEnt.setPerson(convertPersonFromDto2Entity(ownerInfoDto.getRole().getPerson()));

		if (hrDto.getFunktion() != null) {
			hrEnt.setFunktion(getCodeWert(KategorieEnum.FUNKTION, hrDto.getFunktion().getCode()));
		}

		if (hrDto.getZeichnung() != null) {
			hrEnt.setZeichnung(getCodeWert(KategorieEnum.ZEICHNUNG, hrDto.getZeichnung().getCode()));
		}

		hrEnt.setNurHauptsitz(hrDto.isNurHauptsitz());
		
		return hrEnt;
	}

	/**
	 * @param personDto
	 * @param personEnt
	 * @return
	 */
	private PersonEntity convertPersonFromDto2Entity(PersonDto personDto) {
		PersonEntity personEnt = new PersonEntity();

		if (personDto.getId() != null) {
			personEnt = organisationService.getPerson(personDto.getId());
		}

		mapper.map(personDto, personEnt);

		if (personDto.getZivilstand() != null) {
			personEnt.setZivilstand(getCodeWert(KategorieEnum.ZIVILSTAND, personDto.getZivilstand().getCode()));
		}

		if (personDto.getAuslaenderAusweis() != null) {
			personEnt.setAuslaenderAusweis(
				getCodeWert(KategorieEnum.AUSLAUSWEIS, personDto.getAuslaenderAusweis().getCode()));
		}

		if (personDto.getAnrede() != null) {
			String geschlechtCd = OSSConstants.ANDERE_MR_CODE.equals(personDto.getAnrede().getCode())
				? OSSConstants.GESCHLECHT_MR_CODE : OSSConstants.GESCHLECHT_MRS_CODE;
			personEnt.setGeschlecht(getCodeWert(KategorieEnum.GESCHLECHT, geschlechtCd));
			personEnt.setAnrede(getCodeWert(KategorieEnum.ANREDE, personDto.getAnrede().getCode()));
		}

		personEnt.getNationalitaetens().clear();
		if (CollectionUtils.isNotEmpty(personDto.getNationalitaetens())) {
			List<String> codes = personDto.getNationalitaetens().stream().map(n -> n.getCode())
				.collect(Collectors.toList());
			personEnt.getNationalitaetens().addAll(getCodeWerts(KategorieEnum.LAND, codes));
		}

		if (CollectionUtils.isNotEmpty(personDto.getHeimatortes())) {
			List<Long> existedHemators = personDto.getHeimatortes().stream().map(h -> h.getId())
				.collect(Collectors.toList());
			List<PersonHeimatortEntity> removedHematorts = personEnt.getHeimatortes().stream()
				.filter(h -> !existedHemators.contains(h.getId())).collect(Collectors.toList());
			personEnt.getHeimatortes().removeAll(removedHematorts);

			List<PersonHeimatortEntity> newHeimatorts = personEnt.getHeimatortes().stream()
				.filter(h -> h.getId() == null).collect(Collectors.toList());
			for (PersonHeimatortEntity personHeimatort : newHeimatorts) {
				personHeimatort.setPerson(personEnt);
			}
		} else {
			personEnt.getHeimatortes().clear();
		}

		if (personDto.getWohnadresse() != null) {
			AdresseEntity domizil = new AdresseEntity();
			if (personDto.getWohnadresse().getId() != null) {
				domizil = organisationService.getAdresse(personDto.getWohnadresse().getId().longValue());
			}
			mapper.map(personDto.getWohnadresse(), domizil);
			if (personDto.getWohnadresse().getLand() != null) {
				domizil.setLand(getCodeWert(KategorieEnum.LAND, personDto.getWohnadresse().getLand().getCode()));
			}
			personEnt.setWohnadresse(domizil);
		}
		return personEnt;
	}

	/**
	 * @param ownerInfoDto
	 * @return
	 */
	private GeschaftsrolleEntity convertRolleDto2RolleEntity(OwnerInfoDto<GeschaftsrolleDto> ownerInfoDto) {
		GeschaftsrolleDto rolleDto = ownerInfoDto.getRole();
		GeschaftsrolleEntity rolleEnt = new GeschaftsrolleEntity();

		if (rolleDto.getId() != null) {
			rolleEnt = organisationService.findGeschaftsrolleByIdAndOrgId(ownerInfoDto.getSourceId(), rolleDto.getId(),
				rolleDto.getVersion());
		}

		rolleEnt.setPerson(convertPersonFromDto2Entity(ownerInfoDto.getRole().getPerson()));
		rolleEnt.setOrganisation(organisationService.getOrganisation(ownerInfoDto.getSourceId()));
		rolleEnt.setTyp(GeschaeftsrolleTypEnum.SIGNATORY);

		if (rolleDto.getFunktion() != null) {
			rolleEnt.setFunktion(getCodeWert(KategorieEnum.FUNKTION, rolleDto.getFunktion().getCode()));
		}

		if (rolleDto.getZeichnung() != null) {
			rolleEnt.setZeichnung(getCodeWert(KategorieEnum.ZEICHNUNG, rolleDto.getZeichnung().getCode()));
		}

		rolleEnt.setNurHauptsitz(rolleDto.isNurHauptsitz());

		if (rolleDto.getHaftung() != null) {
			rolleEnt.setHaftung(getCodeWert(KategorieEnum.HAFTUNG, rolleDto.getHaftung().getCode()));
		}

		rolleEnt.setHaftungCHF(rolleDto.getHaftungCHF());

		if (rolleDto.getEinlage() != null) {
			rolleEnt.setEinlage(getCodeWert(KategorieEnum.EINLAGE, rolleDto.getEinlage().getCode()));
		} else {
			rolleEnt.setEinlage(null);
		}
		return rolleEnt;
	}

	@PutMapping("firmenname")
	public ResponseEntity<?> changeDefaultLanguage(@RequestBody @Valid FirmennameDto firmennameDto) {
		FirmennameEntity firmennameEntity = hrService.findFirmennameById(firmennameDto.getOrgId(), firmennameDto.getId());
		mapper.map(firmennameDto, firmennameEntity);
		return ResponseEntity.ok(mapper.map(hrService.saveFirmenname(firmennameDto.getOrgId(), firmennameEntity), FirmennameDto.class));
	}

	@RequestMapping(value = "/document/{orgId}", method = RequestMethod.GET)
	public ResponseEntity<?> downloadDocument(@PathVariable long orgId) {
		return download(hrService.downloadDocument(orgId));
	}

	@RequestMapping(value = "/juspaceTemplate/{bfsNr}", method = RequestMethod.GET)
	public ResponseEntity<?> downloadJuspaceTemplate(@PathVariable int bfsNr) {
		List<String> supportedLangs = getSupportedLanguagesByBfsNr(bfsNr);
		String lang = supportedLangs
			.stream()
			.filter(l -> l.equalsIgnoreCase(SecurityUtil.currentUser().getLanguagePreference().name()))
			.findFirst()
			.orElse(supportedLangs.get(0));
		return download(findJuspaceTemplate(lang));
	}

	private FileDto findJuspaceTemplate(String lang) {
		String filename = String.format("self_certification_%s.pdf", lang.toLowerCase());
		try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("juspaceTemplate/" + filename)) {
			if (is == null) {
				if (!SupportedLanguage.DE.name().equalsIgnoreCase(lang)) {
					return findJuspaceTemplate(SupportedLanguage.DE.name());
				}
				throw new OssTechnicalException("No Juspace document template was found for language " + lang);
			}
			LOGGER.info("input stream from filePath : " + is);
			return new FileDto(filename, SupportedFileTypeDownload.PDF, IOUtils.toByteArray(is));
		} catch (IOException e) {
			throw new OssTechnicalException("A technical error occurred while finding Juspace template document", e);
		}
	}
	
	private List<String> getSupportedLanguagesByBfsNr(int bfsNr) {
		return Arrays.asList(applicationService.getHrAmtByDomizilBfsnr(bfsNr).getAmtssprachen().split(OSSConstants.SEMI_COLON_CHARACTER));
	}

	@GetMapping("juspace/sso/{orgId}")
	public HrJuspaceDto createSAMLResponse(@PathVariable long orgId) {
		OrganisationEntity org = organisationService.getOrganisation(orgId,
			QOrganisationEntity.organisationEntity.domizil.land,
			QOrganisationEntity.organisationEntity.namens);
		
		CrDataContainerType data = new CrDataContainerType();
		HeaderType header = new HeaderType();
		data.setCrHeader(header);
		ContentType content = new ContentType();
		data.setCrContent(content);
		
		ProcessType process = new ProcessType();
		header.setProcess(process);
		process.setProcessId(UUID.randomUUID().toString());
		process.setProcessName(org.defaultName());
		ResponseChannelType responseChannel = new ResponseChannelType();
		process.setResponseChannel(responseChannel);
		responseChannel.setDeliverType(DeliveryTypeEnum.JUSPACE);
		process.setTask(TaskTypeEnum.NEW_ENTRY);
		
		IdentificationType identification = new IdentificationType();
		header.setIdentification(identification);
		identification.setFirstName(SecurityUtil.currentUser().getFirstName());
		identification.setLastName(SecurityUtil.currentUser().getLastName());
		identification.setPlatform(PlatformEnum.JUSPACE);
		if (SecurityUtil.currentUser().isLoginSuisseId()) {
			identification.setAuthenticationLevel(4);
			identification.setLoginType(AuthenticationTypeEnum.SUISSE_ID);
			identification.setAuthenticatonAttribute(SecurityUtil.currentUser().getSuisseId());
		} else {
			identification.setAuthenticationLevel(3);
			identification.setLoginType(AuthenticationTypeEnum.USERNAME_PASSWORD);
			identification.setAuthenticatonAttribute(SecurityUtil.currentUser().getEmail());
			TestDataType testData = new TestDataType();
			header.setTestData(testData);
			testData.getEmails().add(SecurityUtil.currentUser().getEmail());
		}
		
		NewEntryType newEntry = new NewEntryType();
		content.setNewEntry(newEntry);
		newEntry.setOrgName(process.getProcessName());
		// TODO [HHG, S9]: Check with DKE how to map the legal form !!!!
		newEntry.setLegalForm(1);
		newEntry.setPurpose(org.getZweck());
		
		OrganisationMailAddressType domizilAddress = new OrganisationMailAddressType();
		newEntry.setDomicileAddress(domizilAddress);
		OrganisationMailAddressInfoType organisationInfo = new OrganisationMailAddressInfoType();
		domizilAddress.setOrganisation(organisationInfo);
		organisationInfo.setOrganisationName(newEntry.getOrgName());
		AddressInformationType addressInfo = new AddressInformationType();
		domizilAddress.setAddressInformation(addressInfo);
		addressInfo.setTown(org.getDomizil().getOrt());
		addressInfo.setCountry(org.getDomizil().getLand().getCode());
		
		String samlResponse = juspaceServiceAdapter.createSAMLResponse(data);
		String address = juspaceServiceAdapter.getJuspaceURL();
		return new HrJuspaceDto(samlResponse, address);
	}

	@Override
	public ResponseEntity<?> interrupt(@RequestBody HRDto dto) {
		return saveOrUpdate(dto, HrSaveType.SAVE);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected ProzessStatusEnum getProcessStatus(long orgId) {
		return hrService.getProcessStatusByOrgId(orgId);
	}
}
