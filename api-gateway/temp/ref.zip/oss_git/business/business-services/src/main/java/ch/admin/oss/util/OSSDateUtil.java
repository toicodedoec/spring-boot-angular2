/*
 * OSSDateUtil
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.time.FastDateFormat;

import ch.admin.oss.common.OssTechnicalException;

/**
 * @author hhg
 *
 */
public abstract class OSSDateUtil {
	
	private static final FastDateFormat DATE_FORMATTER = FastDateFormat.getInstance(OSSConstants.DATE_FORMAT);
	
	private static final DateTimeFormatter DATE_FOR_UID_FORMATTER = new DateTimeFormatterBuilder()
		.appendPattern(OSSConstants.DATE_FOR_UID_FORMAT)
		.toFormatter();
	
	private static DatatypeFactory datatypeFactory;

	static {
		try {
			datatypeFactory = DatatypeFactory.newInstance();
		} catch (DatatypeConfigurationException e) {
			throw new OssTechnicalException(e);
		}
	}
	
	public static LocalDate toLocalDate(Date date) {
		if (date == null) {
			return null;
		}
		return LocalDate.parse(format(date), OSSConstants.LOCAL_DATE_FORMATTER);
	}

	public static Date toDate(LocalDate localDate) {
		if (localDate == null) {
			return null;
		}
		return toDate(localDate.atStartOfDay());
	}

	public static Date toDate(LocalDateTime locaDateTime) {
		if (locaDateTime == null) {
			return null;
		}
		return Date.from(locaDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}
	
	public static LocalDateTime toLocalDateTime(Date date) {
		if(date == null) {
			return null;
		}
		return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
	}
	
	/**
	 * Format the input date with the default pattern dd.MM.yyyy.
	 * 
	 * @param date
	 * @return
	 */
	public static String format(Date date) {
		if (date == null) {
			return null;
		}
		return DATE_FORMATTER.format(date);
	}
	
	/**
	 * Format the input date with the input pattern.
	 * 
	 * @param date
	 * @param pattern
	 * @return
	 */
	public static String format(Date date, String pattern) {
		if (date == null) {
			return null;
		}
		return FastDateFormat.getInstance(pattern).format(date);
	}

	public static String formatForUID(LocalDateTime date) {
		return DATE_FOR_UID_FORMATTER.format(date);
	}

	public static XMLGregorianCalendar convertToXMLDate(LocalDate date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar gcal = GregorianCalendar.from(date.atStartOfDay(ZoneId.systemDefault()));
		return datatypeFactory.newXMLGregorianCalendar(gcal);
	}

	public static XMLGregorianCalendar getCurrentXMLDate() {
		return datatypeFactory.newXMLGregorianCalendar((GregorianCalendar) GregorianCalendar.getInstance());
	}
	
	public static LocalDateTime toLocalDateTime(Calendar date) {
		if(date == null) {
			return null;
		}
		return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
	}
	
	public static LocalDate toLocalDate(Calendar date) {
		if(date == null) {
			return null;
		}
		return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}
}
