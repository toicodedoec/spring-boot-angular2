/*
 * MWSTService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.mwst.service.impl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Strings;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.common.AbstractProcessService;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.AnmeldungMWSTBefundEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.MwstAbmeldungEntity;
import ch.admin.oss.domain.MwstAdressaenderungEntity;
import ch.admin.oss.domain.MwstAnmeldungEntity;
import ch.admin.oss.domain.MwstEintrBestEntity;
import ch.admin.oss.domain.MwstFristverlangerungEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QGeschaftsrolleEntity;
import ch.admin.oss.domain.QMwstAbmeldungEntity;
import ch.admin.oss.domain.QMwstAdressaenderungEntity;
import ch.admin.oss.domain.QMwstAnmeldungEntity;
import ch.admin.oss.domain.QMwstEintrBestEntity;
import ch.admin.oss.domain.QMwstFristverlangerungEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QPersonEntity;
import ch.admin.oss.mwst.repository.IMwstAbmeldungRepository;
import ch.admin.oss.mwst.repository.IMwstAdressaenderungRepository;
import ch.admin.oss.mwst.repository.IMwstAnmeldungRepository;
import ch.admin.oss.mwst.repository.IMwstEintrBestRepository;
import ch.admin.oss.mwst.repository.IMwstFristverlangerungRepository;
import ch.admin.oss.mwst.service.IMWSTService;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.MailMessage;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OSSDateUtil;

/**
 * @author hha
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class MWSTService extends AbstractProcessService<MwstAnmeldungEntity> implements IMWSTService {

	private static final String MWST_ABMELD_GRUND_WEGFALL_BEDINGUNGEN_STEUERPFLICHT = "WegfallBedingungenSteuerpflicht";

	private static final String MWST_ABMELD_GRUND_LIQUIDATION = "Liquidation";

	private static final String MWST_ABMELD_GRUND_UEBERGABE_NACHFOLGER = "UebergabeNachfolger";

	private static final String MWST_ABMELD_GRUND_ENDE_TATIGKEIT = "EndeTatigkeit";

	@Autowired
	private IMwstAnmeldungRepository mwstAnmeldungRepository;
	
	@Autowired
	private IMwstFristverlangerungRepository mwstFristverlangerungRepository;
	
	@Autowired
	private IMwstAdressaenderungRepository mwstAdressaenderungRepository;
	
	@Autowired
	private IMwstAbmeldungRepository mwstAbmeldungRepository;
	
	@Autowired
	private IMwstEintrBestRepository mwstEintrBestRepository;
	
	@Value("${oss.mwst.adressaenderung.mail}")
	private String mwstAdressaenderungMail;

	@Value("${oss.mwst.abmeldung.mail}")
	private String mwstAbmeldungMail;

	@Value("${oss.mwst.eintrbest.mail}")
	private String mwstEintrbestMail;
	
	@Override
	public MwstAnmeldungEntity createProcess(OrganisationEntity organisation) {
		MwstAnmeldungEntity entity = new MwstAnmeldungEntity();
		entity.getProzess().setOrganisation(organisation);
		if (organisation.getPflichtenabklaerungen().isAnmeldungMWST()
			|| organisation.getPflichtenabklaerungen()
				.getAnmeldungMWSTBefund() == AnmeldungMWSTBefundEnum.MWST_FREIWILLIG_EXTERN_DATUM
			|| organisation.getPflichtenabklaerungen()
				.getAnmeldungMWSTBefund() == AnmeldungMWSTBefundEnum.MWST_ZWINGEND_EXTERN_DATUM) {
			entity.getProzess().setStatus(ProzessStatusEnum.EXTERN);
		}
		recordProcessStatusChange(entity.getProzess());
		return mwstAnmeldungRepository.save(entity);
	}
	
	@Override
	public MwstAnmeldungEntity getByOrganisationId(long orgId) {
		MwstAnmeldungEntity mwstAnmeldung = new JPAQuery<MwstAnmeldungEntity>(em)
				.from(QMwstAnmeldungEntity.mwstAnmeldungEntity)
				.where(QMwstAnmeldungEntity.mwstAnmeldungEntity.prozess.organisation.id.eq(orgId))
				.fetchOne();
		if (mwstAnmeldung == null) {
			return null;
		}
		jpaUtil.initialize(mwstAnmeldung, 
				QMwstAnmeldungEntity.mwstAnmeldungEntity.prozess.organisation,
				QMwstAnmeldungEntity.mwstAnmeldungEntity.prozess.statuswechsels,
				QMwstAnmeldungEntity.mwstAnmeldungEntity.prozess.flowHistory.items.any().data);
		return mwstAnmeldung;
	}

	@Override
	public MwstAnmeldungEntity updateProcess(MwstAnmeldungEntity entity) {
		processUpdated(entity.getProzess());
		return mwstAnmeldungRepository.save(entity);
	}

	@Override
	public MwstAnmeldungEntity completeProcess(MwstAnmeldungEntity entity) {
		processCompleted(entity);
		return mwstAnmeldungRepository.save(entity);
	}

	@Override
	public MwstAnmeldungEntity lockProcess(MwstAnmeldungEntity entity) {
		throw new UnsupportedOperationException("This operation process is not supported !");
	}
	
	@Override
	public MwstAnmeldungEntity signProcess(MwstAnmeldungEntity entity) {
		return signProcessFromMOA(null, entity);
	}

	@Override
	public MwstAnmeldungEntity relockProcess(MwstAnmeldungEntity entity) {
		throw new UnsupportedOperationException("This operation process is not supported!");
	}

	@Override
	public void markProcessExternal(ProzessEntity prozess, boolean external) {
		processExternIntern(prozess, external);
	}

	@Override
	public MwstFristverlangerungEntity createMwstFirstverlangerung(MwstFristverlangerungEntity entity, long orgId) {
		createQuickwinProzess(entity.getProzess(), orgId);
		return mwstFristverlangerungRepository.save(entity);
	}
	
	@Override
	public byte[] generateDocument(MwstAnmeldungEntity entity, boolean draft) {
		throw new UnsupportedOperationException("This operation process is not supported!");
	}

	private void createQuickwinProzess(ProzessEntity prozess, long orgId) {
		OrganisationEntity orgEntity = new JPAQuery<OrganisationEntity>(em)
				.from(QOrganisationEntity.organisationEntity)
				.where(QOrganisationEntity.organisationEntity.id.eq(orgId))
				.fetchOne();
		
		prozess.setOrganisation(orgEntity);
		prozess.setStatus(ProzessStatusEnum.GESENDET);
		prozess.setLocked(true);
		prozess.setCompleted(true);
		recordProcessStatusChange(prozess);
	}

	@Override
	public List<AdresseEntity> getMwstAdressaenderungAdresseKorrespondenzByOrgId(long orgId) {
		return new JPAQuery<MwstAdressaenderungEntity>(em)
			.from(QMwstAdressaenderungEntity.mwstAdressaenderungEntity)
			.join(QMwstAdressaenderungEntity.mwstAdressaenderungEntity.adresseKorrespondenz).fetchJoin()
			.where(QMwstAdressaenderungEntity.mwstAdressaenderungEntity.prozess.organisation.id.eq(orgId)
				.and(QMwstAdressaenderungEntity.mwstAdressaenderungEntity.adresseKorrespondenz.land.code.eq(OSSConstants.SWISS_CODE_WERT)))
			.fetch()
			.stream().map(a -> a.getAdresseKorrespondenz()).collect(Collectors.toList());
	}

	@Override
	public List<AdresseEntity> getMwstEintrBestAdresseByOrgId(long orgId) {
		return new JPAQuery<MwstEintrBestEntity>(em)
			.from(QMwstEintrBestEntity.mwstEintrBestEntity)
			.join(QMwstEintrBestEntity.mwstEintrBestEntity.adresse).fetchJoin()
			.where(QMwstEintrBestEntity.mwstEintrBestEntity.prozess.organisation.id.eq(orgId)
				.and(QMwstEintrBestEntity.mwstEintrBestEntity.adresse.land.code.eq(OSSConstants.SWISS_CODE_WERT)))
			.fetch()
			.stream().map(a -> a.getAdresse()).collect(Collectors.toList());
	}

	@Override
	public MwstAdressaenderungEntity createMwstAdressaenderung(MwstAdressaenderungEntity entity, long orgId) {
		createQuickwinProzess(entity.getProzess(), orgId);
		sendAdressaenderungEmail(entity);
		return mwstAdressaenderungRepository.save(entity);
	}

	@Override
	public MwstFristverlangerungEntity getMwstFristverlangerung(long prozessId, long orgId) {
		MwstFristverlangerungEntity entity = new JPAQuery<MwstFristverlangerungEntity>(em)
				.from(QMwstFristverlangerungEntity.mwstFristverlangerungEntity)
				.where(QMwstFristverlangerungEntity.mwstFristverlangerungEntity.prozess.id.eq(prozessId))
				.fetchOne();
		jpaUtil.initialize(entity, QMwstFristverlangerungEntity.mwstFristverlangerungEntity.prozess.organisation);
		return entity;
	}

	@Override
	public MwstAdressaenderungEntity getMwstAdressaenderungByProzessId(long prozessId, long orgId) {
		return jpaUtil.initialize(
			new JPAQuery<MwstAdressaenderungEntity>(em)
				.from(QMwstAdressaenderungEntity.mwstAdressaenderungEntity)
				.where(QMwstAdressaenderungEntity.mwstAdressaenderungEntity.prozess.id.eq(prozessId))
				.fetchOne(),
			QMwstAdressaenderungEntity.mwstAdressaenderungEntity.adresseBisher.land,
			QMwstAdressaenderungEntity.mwstAdressaenderungEntity.adresseKorrespondenz.land,
			QMwstAdressaenderungEntity.mwstAdressaenderungEntity.adresseNeu.land,
			QMwstAdressaenderungEntity.mwstAdressaenderungEntity.adresseOwner.land);
	}
	
	private void sendAdressaenderungEmail(MwstAdressaenderungEntity entity) {
		SupportedLanguage language = SecurityUtil.currentUser().getLanguagePreference();
		MailMessage message = new MailMessage();

		message.setSubject(applicationService.getTranslation("gui_labels.mwst.quickwin.pqw09.email.subject", language));
		message.setFrom(helpdeskEmail);
		message.setTo(mwstAdressaenderungMail);
		message.setTemplateName("mwst-quickwin-pqw09-mail-template.ftl");	
		
		Map<String, String> templateModelData = new HashMap<String, String>() {
			private static final long serialVersionUID = 8930639167921075989L;
			{
				put("mwstNr", entity.getMwstNr());

				put("bisherName", entity.getNameBisher());
				put("bisherStrasse", entity.getAdresseBisher().getStrasse());
				put("bisherHausnummer", entity.getAdresseBisher().getHausnummer());
				put("bisherAdresseZusatz", entity.getAdresseBisher().getZusatz());
				put("bisherPostfach", entity.getAdresseBisher().getPostfach());
				put("bisherPlz", entity.getAdresseBisher().getPlz());
				put("bisherOrt", entity.getAdresseBisher().getOrt());

				put("gultigAb", OSSDateUtil.format(OSSDateUtil.toDate(entity.getGueltigAb())));

				put("neuName", entity.getNameNeu());
				put("neuStrasse", entity.getAdresseNeu().getStrasse());
				put("neuHausnummer", entity.getAdresseNeu().getHausnummer());
				put("neuAdresseZusatz", entity.getAdresseNeu().getZusatz());
				put("neuPostfach", entity.getAdresseNeu().getPostfach());
				put("neuPlz", entity.getAdresseNeu().getPlz());
				put("neuOrt", entity.getAdresseNeu().getOrt());
				
				AdresseEntity korrespondenz = entity.getAdresseKorrespondenz();
				if (korrespondenz == null) {
					korrespondenz = new AdresseEntity();
				}
				put("korrespondenzName", korrespondenz.getEmpfaenger());
				put("korrespondenzTelefon", korrespondenz.getTelefon());
				put("korrespondenzEmail", korrespondenz.getEmail());
				put("korrespondenzStrasse", korrespondenz.getStrasse());
				put("korrespondenzHausnummer", korrespondenz.getHausnummer());
				put("korrespondenzAdresseZusatz", korrespondenz.getZusatz());
				put("korrespondenzPostfach", korrespondenz.getPostfach());
				put("korrespondenzPlz", korrespondenz.getPlz());
				put("korrespondenzOrt", korrespondenz.getOrt());
				
				AdresseEntity owner = entity.getAdresseOwner();
				if (owner == null) {
					owner = new AdresseEntity();
				}
				put("wohnadresseName", entity.getNameOwner());
				put("wohnadresseStrasse", owner.getStrasse());
				put("wohnadresseHausnummer", owner.getHausnummer());
				put("wohnadresseAdresseZusatz", owner.getZusatz());
				put("wohnadressePostfach", owner.getPostfach());
				put("wohnadressePlz", owner.getPlz());
				put("wohnadresseOrt", owner.getOrt());				
			}
		};
		replaceNullByDefaultValue(templateModelData);

		message.getTemplateModel().putAll(templateModelData);

		mailUtil.send(message);
	}

	private void replaceNullByDefaultValue(Map<String, String> templateModelData) {
		templateModelData.forEach((k, v) -> {
			if (Strings.isNullOrEmpty(v)) {
				templateModelData.put(k, OSSConstants.EMPTY_STRING);
			}
		});
	}

	@Override
	public MwstAbmeldungEntity createMwstAbmeldung(MwstAbmeldungEntity entity, long orgId) {
		createQuickwinProzess(entity.getProzess(), orgId);
		sendAbmeldungEmail(entity);
		return mwstAbmeldungRepository.save(entity);
	}
	
	private void sendAbmeldungEmail(MwstAbmeldungEntity entity) {
		SupportedLanguage language = SecurityUtil.currentUser().getLanguagePreference();
		MailMessage message = new MailMessage();

		message.setSubject(applicationService.getTranslation("gui_labels.mwst.quickwin.pqw10.email.subject", language));
		message.setFrom(helpdeskEmail);
		message.setTo(mwstAbmeldungMail);
		message.setTemplateName("mwst-quickwin-pqw10-mail-template.ftl");
				
		Map<String, String> templateModelData = new HashMap<String, String>() {			
			private static final long serialVersionUID = 4333343235208501656L;
			{
				put("mwstNr", entity.getMwstNr());
				put("name", entity.getName());
				
				put("strasse", entity.getAdresse().getStrasse());
				put("hausnummer", entity.getAdresse().getHausnummer());
				put("adresseZusatz", entity.getAdresse().getZusatz());
				put("postfach", entity.getAdresse().getPostfach());
				put("plz", entity.getAdresse().getPlz());
				put("ort", entity.getAdresse().getOrt());
				put("telefon", entity.getAdresse().getTelefon());
				put("fax", entity.getAdresse().getFax());
				put("email", entity.getAdresse().getEmail());
				
				put("kontaktPersonName", entity.getKontaktPerson());
				
				put("perDatumEnde", null);
				put("perDatumUbergabe", null);
				put("perDatumLiquidation", null);
				put("perDatumWegfall", null);
				put("begruendung", null);
				
				if (entity.getGrund() != null) {
					CodeWertEntity begruendung = applicationService.getCodeWerts(Arrays.asList(KategorieEnum.MWST_ABMELD_GRUND))
						.get(KategorieEnum.MWST_ABMELD_GRUND)
						.stream()
						.filter(c -> c.getId().equals(entity.getGrund()))
						.findFirst()
						.get();
				
					put("begruendung", begruendung.getStandardText().textTranslation(language));

					if (entity.getPerDatum() != null) {
						if (MWST_ABMELD_GRUND_ENDE_TATIGKEIT.equals(begruendung.getCode())) {
							put("perDatumEnde", OSSDateUtil.format(OSSDateUtil.toDate(entity.getPerDatum())));
						} else if (MWST_ABMELD_GRUND_UEBERGABE_NACHFOLGER.equals(begruendung.getCode())) {
							put("perDatumUbergabe", OSSDateUtil.format(OSSDateUtil.toDate(entity.getPerDatum())));
						} else if (MWST_ABMELD_GRUND_LIQUIDATION.equals(begruendung.getCode())) {
							put("perDatumLiquidation", OSSDateUtil.format(OSSDateUtil.toDate(entity.getPerDatum())));
						} else if (MWST_ABMELD_GRUND_WEGFALL_BEDINGUNGEN_STEUERPFLICHT.equals(begruendung.getCode())) {
							put("perDatumWegfall", OSSDateUtil.format(OSSDateUtil.toDate(entity.getPerDatum())));
						}
					}
				}
				
				put("nachfolgerName", entity.getNachfolgerName());		
				put("nachfolgerMwstNr", entity.getNachfolgerMwstNr());
							
				put("bemerkungen", entity.getBemerkungen());								
			}
		};
		replaceNullByDefaultValue(templateModelData);

		message.getTemplateModel().putAll(templateModelData);

		mailUtil.send(message);
	}

	@Override
	public MwstAbmeldungEntity getMwstAbmeldungByProzessId(long prozessId, long orgId) {
		return new JPAQuery<MwstAbmeldungEntity>(em)
			.from(QMwstAbmeldungEntity.mwstAbmeldungEntity)
			.join(QMwstAbmeldungEntity.mwstAbmeldungEntity.adresse).fetchJoin()
			.where(QMwstAbmeldungEntity.mwstAbmeldungEntity.prozess.id.eq(prozessId))
			.fetchOne();
	}

	@Override
	public OrganisationEntity getOrganisation(long orgId) {
		OrganisationEntity entity = new JPAQuery<OrganisationEntity>(em)
		.from(QOrganisationEntity.organisationEntity)
		.where(QOrganisationEntity.organisationEntity.id.eq(orgId)).fetchOne();
		
		jpaUtil.initialize(entity, QOrganisationEntity.organisationEntity.domizil.land, 
			QOrganisationEntity.organisationEntity.kommGes.kommFirmas.any().domizil.land,
			QOrganisationEntity.organisationEntity.geschaeftsrollens,
			QOrganisationEntity.organisationEntity.namens
		);
		
		entity.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).forEach(ges -> {
			jpaUtil.initialize(ges, QGeschaftsrolleEntity.geschaftsrolleEntity.person);
			jpaUtil.initialize(ges.getPerson(), QPersonEntity.personEntity.wohnadresse.land);
			jpaUtil.initialize(ges.getPerson(), QPersonEntity.personEntity.anrede);
			jpaUtil.initialize(ges.getPerson(), QPersonEntity.personEntity.nationalitaetens);
			jpaUtil.initialize(ges.getPerson(), QPersonEntity.personEntity.heimatortes);
		});
		
		return entity;
	}

	@Override
	public MwstEintrBestEntity createMwstEintrBest(MwstEintrBestEntity entity, long orgId) {
		createQuickwinProzess(entity.getProzess(), orgId);
		sendEintrBestEmail(entity);
		return mwstEintrBestRepository.save(entity);
	}
	
	private void sendEintrBestEmail(MwstEintrBestEntity entity) {
		SupportedLanguage language = SecurityUtil.currentUser().getLanguagePreference();
		MailMessage message = new MailMessage();

		message.setSubject(applicationService.getTranslation("gui_labels.mwst.quickwin.pqw11.email.subject", language));
		message.setFrom(helpdeskEmail);
		message.setTo(mwstEintrbestMail);
		message.setTemplateName("mwst-quickwin-pqw11-mail-template.ftl");		
		
		Map<String, String> templateModelData = new HashMap<String, String>() {			
			private static final long serialVersionUID = -4974250709611500509L;
			{
				put("mwstNr", entity.getMwstNr());
				put("name", entity.getName());
				
				put("strasse", entity.getAdresse().getStrasse());
				put("hausnummer", entity.getAdresse().getHausnummer());
				put("adresseZusatz", entity.getAdresse().getZusatz());
				put("postfach", entity.getAdresse().getPostfach());
				put("plz", entity.getAdresse().getPlz());
				put("ort", entity.getAdresse().getOrt());
				put("telefon", entity.getAdresse().getTelefon());				
				put("email", entity.getAdresse().getEmail());
				
				put("jahr", entity.getJahr() != null ? String.valueOf(entity.getJahr()) : null);
				
				put("brancheGenaueBezeichnung", entity.getBranche());
				
				put("apostille", entity.getApostille() ? OSSConstants.JA_STRING : OSSConstants.NEIN_STRING);

				put("zustelladresse", null);
				
				if (entity.getZustellAdresse() != null) {
					put("zustelladresse",
						String.format("%s %s %s %s %s %s %s",
							entity.getZustellAdresse().getEmpfaenger() != null ? entity.getZustellAdresse().getEmpfaenger() : OSSConstants.EMPTY_STRING,
							entity.getZustellAdresse().getStrasse(),
							entity.getZustellAdresse().getHausnummer() != null ? entity.getZustellAdresse().getStrasse() : OSSConstants.EMPTY_STRING, 
							entity.getZustellAdresse().getZusatz() != null ? entity.getZustellAdresse().getZusatz() : OSSConstants.EMPTY_STRING,
							entity.getZustellAdresse().getPostfach() != null ? entity.getZustellAdresse().getPostfach()	: OSSConstants.EMPTY_STRING, 
							entity.getZustellAdresse().getPlz(),
							entity.getZustellAdresse().getOrt())
						);
				}
							
				put("bemerkungen", entity.getBemerkungen());								
			}
		};
		replaceNullByDefaultValue(templateModelData);
		
		message.getTemplateModel().putAll(templateModelData);

		mailUtil.send(message);
	}

	@Override
	public MwstEintrBestEntity getMwstEintrBestByProzessId(long prozessId, long orgId) {
		return jpaUtil.initialize(
			new JPAQuery<MwstEintrBestEntity>(em).from(QMwstEintrBestEntity.mwstEintrBestEntity)
				.where(QMwstEintrBestEntity.mwstEintrBestEntity.prozess.id.eq(prozessId))
				.fetchOne(),
			QMwstEintrBestEntity.mwstEintrBestEntity.adresse.land,
			QMwstEintrBestEntity.mwstEintrBestEntity.zustellAdresse.land);
	}

	@Override
	public MwstAnmeldungEntity signProcessFromMOA(Long userId, MwstAnmeldungEntity mwstAnmeldung) {
		processSigned(mwstAnmeldung.getProzess(), userId);
		return mwstAnmeldungRepository.save(mwstAnmeldung);
	}

	@Override
	public MwstAnmeldungEntity getMwstAnmeldungFromMOA(Long orgId) {
		return getByOrganisationId(orgId);
	}
	
	@Override
	protected boolean isSupportedDocument() {
		return false;
	}

	@Override
	protected ProzessTypEnum getProcessType() {
		return ProzessTypEnum.MWST;
	}

	@Override
	public MwstAnmeldungEntity updateProcess(long orgId, MwstAnmeldungEntity entity) {
		throw new UnsupportedOperationException("Not use in UVG process");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ProzessStatusEnum getProcessStatusByOrgId(long orgId) {
		return getProcessStatus(orgId);
	}

}
