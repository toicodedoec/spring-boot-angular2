/*
 * OrganisationServiceTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hr.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.business.AbstractOSSTest;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.HrAnmeldungEntity;
import ch.admin.oss.domain.HrGruenderEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.exception.ValidationException;
import ch.admin.oss.hr.repository.IHrGruenderRepository;
import ch.admin.oss.organisation.repository.ICodeWertRepository;
import ch.admin.oss.organisation.repository.IOrganisationRepository;
import ch.admin.oss.organisation.repository.IPersonRepository;
import ch.admin.oss.organisation.repository.IPflichtenabklaerungenRepository;
import ch.admin.oss.organisation.service.IOrganisationService;

/**
 * @author hha
 */
@ActiveProfiles(CommonConstants.PROFILE_TEST)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Transactional
public class HrServiceTest extends AbstractOSSTest {
	
	@Autowired
	private IPflichtenabklaerungenRepository pflichtenRepo;
	@Autowired
	private IPersonRepository personRepository;
	@Autowired
	private IHrGruenderRepository gruenderRepository;
	@Autowired
	private ICodeWertRepository codeWertRepository;
	@Autowired
	private IOrganisationRepository organisationRepository;
	@Autowired
	private IHRService hrService;
	@Autowired
	private IOrganisationService orgService;

	@Test
	public void testValidateHRCapitalShareAG() {
		HrAnmeldungEntity entity = createHrEntity(RechtsformEnum.AG);
		prepareFullDataOfflineNotary(entity);

		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Aktienkapital must be >= 100'000 CHF", e.getMessage());
		}
		entity.setAktienkapital(99_999);
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Aktienkapital must be >= 100'000 CHF", e.getMessage());
		}
		entity.setAktienkapital(1_000_000);
		
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Liberierungsumfang must be >= 50'000 CHF", e.getMessage());
		}
		entity.setLiberierungsumfang(49_999);
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Liberierungsumfang must be >= 50'000 CHF", e.getMessage());
		}
		entity.setLiberierungsumfang(1_000_001);
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Liberierungsumfang must be <= Aktienkapital", e.getMessage());
		}
		entity.setLiberierungsumfang(199_999);
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Liberierungsumfang must be >= 20 % of Aktienkapital", e.getMessage());
		}
		entity.setLiberierungsumfang(200_000);
		
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Sum of Namensaktien and Inhaberaktien must be > 0", e.getMessage());
		}
		entity.setNamensaktien(100);
		entity.setInhaberaktien(200);
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("The value of share must not has more than 2 decimal places. (E.g 1.23 is OK, 1.234 is NOT)", e.getMessage());
		}
		entity.setNamensaktien(100);
		entity.setInhaberaktien(400);
		
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("All nominal shares and all transferrable shares must be distributed among the shareholders", e.getMessage());
		}
		
		List<HrGruenderEntity> people = new ArrayList<>(entity.getGruenders());
		HrGruenderEntity person = people.get(0);
		person.setAnzNamensaktien(20);
		person.setAnzInhaberaktien(150);
		
		person = people.get(1);
		person.setAnzNamensaktien(80);
		person.setAnzInhaberaktien(250);
		entity = hrService.completeProcess(entity);
	}
	
	@Test
	public void testValidateHRCapitalShareGmbH() {
		HrAnmeldungEntity entity = createHrEntity(RechtsformEnum.GMBH);
		prepareFullDataOfflineNotary(entity);
		
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Stammkapital must be >= 20'000 CHF", e.getMessage());
		}
		entity.setStammkapital(19_999);
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Stammkapital must be >= 20'000 CHF", e.getMessage());
		}
		entity.setStammkapital(100_000);
		
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Stammanteile must be > 0", e.getMessage());
		}
		entity.setStammanteile(300);
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Value of share must be an Integer", e.getMessage());
		}
		entity.setStammanteile(5000);
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Value of share must be at least 100 CHF", e.getMessage());
		}
		entity.setStammanteile(1000);
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("All shares must be distributed among the shareholders", e.getMessage());
		}
		
		List<HrGruenderEntity> people = new ArrayList<>(entity.getGruenders());
		HrGruenderEntity person = people.get(0);
		person.setAnzStammanteile(600);
		
		person = people.get(1);
		person.setAnzStammanteile(400);
		entity = hrService.completeProcess(entity);
	}
	
	@Test
	public void testValidateOfflineNotary() {
		HrAnmeldungEntity entity = createHrEntity(RechtsformEnum.GMBH);
		prepareFullDataGMBH(entity);

		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Notar Anrede is required", e.getMessage());
		}
		entity.setNotarAnrede(codeWertRepository.findOne(1L));
		
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Notar Name is required", e.getMessage());
		}
		entity.setNotarName("Test");
		
		try {
			entity = hrService.completeProcess(entity);
			Assert.fail();
		} catch (ValidationException e) {
			Assert.assertEquals("Notar Address is required", e.getMessage());
		}
		entity.setNotarPostadresse("Test");
		entity = hrService.completeProcess(entity);

		entity.setNotarEmail("hha@elca.vn");
		entity = hrService.completeProcess(entity);
	}

	private HrAnmeldungEntity createHrEntity(RechtsformEnum form) {
		UserEntity userEnt = getCurrentLoginUser();
		
		PflichtenabklaerungenEntity pflichtenEnt = new PflichtenabklaerungenEntity();
		pflichtenEnt.setRechtsform(form);
		pflichtenEnt.setUser(userEnt);
		pflichtenEnt = pflichtenRepo.saveAndFlush(pflichtenEnt);

		userEnt.setPflichten(pflichtenEnt);
		userEnt = userRepo.saveAndFlush(userEnt);

		OrganisationEntity organisationEntity = orgService.createOrganisationFromScratch("TEST_ELCA_0001", true);
		organisationEntity.setRechtsform(form);
		organisationEntity = organisationRepository.save(organisationEntity);

		addUserAuthorizedCompany("TEST_ELCA_0001", organisationEntity);
		
		HrAnmeldungEntity entity = new HrAnmeldungEntity();
		entity.getProzess().setOrganisation(organisationEntity);
		entity = hrService.updateProcess(entity);

		createPerson(entity);
		createPerson(entity);

		return hrService.getByOrganisationId(organisationEntity.getId());
	}

	private void prepareFullDataGMBH(HrAnmeldungEntity entity) {
		List<HrGruenderEntity> people = new ArrayList<>(entity.getGruenders());
		HrGruenderEntity person;

		entity.setStammkapital(100_000);
		entity.setStammanteile(1000);
		person = people.get(0);
		person.setAnzStammanteile(600);
		person = people.get(1);
		person.setAnzStammanteile(400);
	}

	@SuppressWarnings("unused")
	private void prepareFullDataAG(HrAnmeldungEntity entity) {
		List<HrGruenderEntity> people = new ArrayList<>(entity.getGruenders());
		HrGruenderEntity person;

		entity.setAktienkapital(1_000_000);
		entity.setLiberierungsumfang(200_000);
		entity.setNamensaktien(100);
		entity.setInhaberaktien(400);
		person = people.get(0);
		person.setAnzNamensaktien(20);
		person.setAnzInhaberaktien(150);

		person = people.get(1);
		person.setAnzNamensaktien(80);
		person.setAnzInhaberaktien(250);
	}
	
	private void prepareFullDataOfflineNotary(HrAnmeldungEntity entity) {
		entity.setNotarAnrede(codeWertRepository.findOne(1L));
		entity.setNotarName("Test");
		entity.setNotarPostadresse("Test");
	}
	
	private HrGruenderEntity createPerson(HrAnmeldungEntity hrAnmeldung) {
		HrGruenderEntity entity = new HrGruenderEntity();
		entity.setHrAnmeldung(hrAnmeldung);

		PersonEntity person = new PersonEntity();
		entity.setPerson(person);

		person.setFamilienname("HHA " + (int) (Math.random() * 100));
		person.setVorname("Dang");
		person.setZivilstand(codeWertRepository.getOne(5L));
		AdresseEntity swissAddress = new AdresseEntity();
		swissAddress.setLand(getSwissLand());
		person.setWohnadresse(swissAddress);

		person = personRepository.save(person);
		entity = gruenderRepository.save(entity);

		hrAnmeldung.getGruenders().add(entity);
		return entity;
	}
}
