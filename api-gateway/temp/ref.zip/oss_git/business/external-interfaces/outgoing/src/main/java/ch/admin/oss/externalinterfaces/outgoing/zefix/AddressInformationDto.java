/*
 * AddressInformationDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

import java.io.Serializable;

/**
 * @author hhg
 *
 */
public class AddressInformationDto implements Serializable {

	private static final long serialVersionUID = -443380731124105166L;

	private String street;
	private String houseNumber;
	private String town;
	private Long swissZipCode;
	
	public AddressInformationDto() {
	}

	public AddressInformationDto(String street, String houseNumber, String town, Long swissZipCode) {
		this.street = street;
		this.houseNumber = houseNumber;
		this.town = town;
		this.swissZipCode = swissZipCode;
	}

	public String getStreet() {
		return street;
	}
	
	public void setStreet(String street) {
		this.street = street;
	}
	
	public String getHouseNumber() {
		return houseNumber;
	}
	
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	
	public String getTown() {
		return town;
	}
	
	public void setTown(String town) {
		this.town = town;
	}
	
	public Long getSwissZipCode() {
		return swissZipCode;
	}
	
	public void setSwissZipCode(Long swissZipCode) {
		this.swissZipCode = swissZipCode;
	}
}
