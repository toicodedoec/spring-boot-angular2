/*
 * LandEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.ISO2Enum;
import ch.admin.oss.common.enums.ISO3Enum;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_LAND")
public class LandEntity extends AbstractOSSEntity {

	@NotNull
	@Column(name = "BFSCODE", nullable = false)
	private String bfscode;

	@Column(name = "ISO2")
	@Enumerated(EnumType.STRING)
	private ISO2Enum iso2;

	@Column(name = "ISO3")
	@Enumerated(EnumType.STRING)
	private ISO3Enum iso3;

	public String getBfscode() {
		return bfscode;
	}
	
	public void setBfscode(String bfscode) {
		this.bfscode = bfscode;
	}

	public ISO2Enum getIso2() {
		return iso2;
	}

	public void setIso2(ISO2Enum iso2) {
		this.iso2 = iso2;
	}

	public ISO3Enum getIso3() {
		return iso3;
	}

	public void setIso3(ISO3Enum iso3) {
		this.iso3 = iso3;
	}
}
