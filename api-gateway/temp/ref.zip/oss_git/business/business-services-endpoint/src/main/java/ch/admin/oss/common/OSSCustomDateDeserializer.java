/*
 * OSSCustomDateDeserializer
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.time.FastDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdScalarDeserializer;

import ch.admin.oss.util.OSSConstants;

/**
 * @author coh
 *
 */
@SuppressWarnings("serial") // we don't serialise json *mappers*
public class OSSCustomDateDeserializer extends StdScalarDeserializer<Date> {

    private final static Logger LOGGER = LoggerFactory.getLogger(OSSCustomDateDeserializer.class);

    protected OSSCustomDateDeserializer() {
        super(Date.class);
    }

    @SuppressWarnings("deprecation")
	@Override
    public Date deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException, JsonProcessingException {
        JsonToken t = jp.getCurrentToken();
        if (t == JsonToken.VALUE_NUMBER_INT) {
            return new Date(jp.getLongValue());
        }
        if (t == JsonToken.VALUE_NULL) {
            return getNullValue();
        }
        if (t == JsonToken.VALUE_STRING) {
            try {
                String str = jp.getText().trim();
                if (str.length() == 0) {
                    return getEmptyValue();
                }
                FastDateFormat df = FastDateFormat.getInstance(OSSConstants.DATE_FORMAT);
                return df.parse(str);
            } catch (ParseException e) {
                LOGGER.warn("The date value is null due to parse date exception", e);
                return null;
            }
        }
        throw ctxt.mappingException(_valueClass, t);
    }
}
