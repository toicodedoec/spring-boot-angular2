/*
 * IQuickwinProcessService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import javax.validation.Valid;

import org.springframework.security.access.prepost.PreAuthorize;

import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.enums.ProzessStatusEnum;

/**
 * @author hhg
 *
 */
public interface IQuickwinProcessService<T> {

	/**
	 * Create a new process with status {@link ProzessStatusEnum#INITIAL}.
	 * 
	 * @param orgId Organization ID which the new created process belongs to.
	 * @return New created process
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	T createProcess(long orgId);

	/**
	 * Update the process. The process now will be mark to uncompleted and under status {@link ProzessStatusEnum#BEARBEITUNG}.
	 * 
	 * @param orgId Organization ID which the new created process belongs to.
	 * @param entity Process entity
	 * @return Updated process entity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	T updateProcess(long orgId, T entity);

	/**
	 * Complete the ongoing process. Validation at service level will be turn on. Process mark to complete and under status {@link ProzessStatusEnum#KOMPLETT}.
	 * 
	 * @param orgId Organization ID which the new created process belongs to.
	 * @param entity Process entity
	 * @return Updated process entity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	T completeProcess(long orgId, @Valid T entity);

	/**
	 * Lock the complete process. Process and its corresponding organisation data will be marked to locked and under status 
	 * {@link ProzessStatusEnum#GESCHLOSSEN}.
	 * 
	 * @param orgId Organization ID which the new created process belongs to.
	 * @param entity Process entity
	 * @return Updated process entity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE_SEND)")
	T lockProcess(long orgId, T entity);

	/**
	 * Sign the complete process. Process and its corresponding organization data will be marked to locked and under status 
	 * {@link ProzessStatusEnum#SIGNIERT}.
	 * 
	 * @param orgId Organization ID which the new created process belongs to.
	 * @param entity Process entity
	 * @return Updated process entity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE_SEND)")
	T signProcess(long orgId, T entity);

	/**
	 * Re lock the process after Sign. It just simply change the status of the process back to {@link ProzessStatusEnum#GESCHLOSSEN}.
	 * 
	 * @param orgId Organization ID which the new created process belongs to.
	 * @param entity Process entity
	 * @return Updated process entity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE_SEND)")
	T relockProcess(long orgId, T entity);
	
	/**
	 * Download pdf file in table prozess.
	 * 
	 * @param orgId Organization ID which the new created process belongs to.
	 * @param prozessId Process ID which the document belong to.
	 * @return FileDto
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	FileDto downloadDocument(long orgId, long prozessId);
}
