/*
 * AbstractPersonRoleDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.util.List;

/**
 * @author hha
 */
public class PersonHeimatortDto {

	private String anrede;
	private String vorname;
	private String name;
	private String familienname;
	private String strasse;
	private String hausnummer;
	private String plz;
	private String ort;
	private String adresseCombined;

	private String polGemeinde;
	private String geburtstag;
	private List<String> heimatortes;

	private Integer anzInhaberaktien;
	private Integer anzNamensaktien;
	private Integer anzStammanteile;

	public String getAnrede() {
		return anrede;
	}

	public void setAnrede(String anrede) {
		this.anrede = anrede;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFamilienname() {
		return familienname;
	}

	public void setFamilienname(String familienname) {
		this.familienname = familienname;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getHausnummer() {
		return hausnummer;
	}

	public void setHausnummer(String hausnummer) {
		this.hausnummer = hausnummer;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getAdresseCombined() {
		return adresseCombined;
	}

	public void setAdresseCombined(String adresseCombined) {
		this.adresseCombined = adresseCombined;
	}

	public String getPolGemeinde() {
		return polGemeinde;
	}

	public void setPolGemeinde(String polGemeinde) {
		this.polGemeinde = polGemeinde;
	}

	public String getGeburtstag() {
		return geburtstag;
	}

	public void setGeburtstag(String geburtstag) {
		this.geburtstag = geburtstag;
	}

	public List<String> getHeimatortes() {
		return heimatortes;
	}

	public void setHeimatortes(List<String> heimatortes) {
		this.heimatortes = heimatortes;
	}

	public Integer getAnzInhaberaktien() {
		return anzInhaberaktien;
	}

	public void setAnzInhaberaktien(Integer anzInhaberaktien) {
		this.anzInhaberaktien = anzInhaberaktien;
	}

	public Integer getAnzNamensaktien() {
		return anzNamensaktien;
	}

	public void setAnzNamensaktien(Integer anzNamensaktien) {
		this.anzNamensaktien = anzNamensaktien;
	}

	public Integer getAnzStammanteile() {
		return anzStammanteile;
	}

	public void setAnzStammanteile(Integer anzStammanteile) {
		this.anzStammanteile = anzStammanteile;
	}

}
