package ch.admin.oss.moa.endpoint;

import ch.admin.oss.common.enums.RechtsformEnum;

public class MwstMoaUserDataLegalFormDto {
	private int id;

	public MwstMoaUserDataLegalFormDto() {
	}

	public MwstMoaUserDataLegalFormDto(RechtsformEnum rechtsform) {
		switch (rechtsform) {
		case EINZELFIRMA:
			id = 1;
			break;
		case AG:
			id = 3;
			break;
		case GMBH:
			id = 4;
			break;
		case KOLLGES:
			id = 2;
			break;
		case KOMMGES:
			id = 10;
			break;
		default:
			throw new IllegalArgumentException("Unknown rechtform " + rechtsform);
		}
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
}
