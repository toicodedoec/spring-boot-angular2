/*
 * MwstAdressaenderungDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.mwst.endpoint;

import java.util.Date;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.CommonAddress;
import ch.admin.oss.common.ProzessDto;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author xdg
 */
public class MwstAdressaenderungDto extends AbstractOSSDto {
	
	private ProzessDto prozess;
	
	@NotNull
	private String mwstNr;
	
	@NotNull
	private String nameBisher;

	@Valid
	@NotNull(groups = CommonAddress.class)
	private AdresseDto adresseBisher;

	@NotNull
	private Date gueltigAb;

	@NotNull
	private String nameNeu;

	@Valid
	@NotNull(groups = CommonAddress.class)
	private AdresseDto adresseNeu;

	private AdresseDto adresseKorrespondenz;

	@NotNull
	private String nameOwner;

	private AdresseDto adresseOwner;

	private MwstDomizilCollectionDto refDomizilData;

	private RechtsformEnum rechtsForm;

	public MwstAdressaenderungDto() {
		// default constructor
	}

	public MwstAdressaenderungDto(RechtsformEnum rechtsForm) {
		this.rechtsForm = rechtsForm;
	}

	public ProzessDto getProzess() {
		return prozess;
	}

	public void setProzess(ProzessDto prozess) {
		this.prozess = prozess;
	}

	public String getMwstNr() {
		return mwstNr;
	}

	public void setMwstNr(String mwstNr) {
		this.mwstNr = mwstNr;
	}

	public String getNameBisher() {
		return nameBisher;
	}

	public void setNameBisher(String nameBisher) {
		this.nameBisher = nameBisher;
	}

	public AdresseDto getAdresseBisher() {
		return adresseBisher;
	}

	public void setAdresseBisher(AdresseDto adresseBisher) {
		this.adresseBisher = adresseBisher;
	}

	public Date getGueltigAb() {
		return gueltigAb;
	}

	public void setGueltigAb(Date gueltigAb) {
		this.gueltigAb = gueltigAb;
	}

	public String getNameNeu() {
		return nameNeu;
	}

	public void setNameNeu(String nameNeu) {
		this.nameNeu = nameNeu;
	}

	public AdresseDto getAdresseNeu() {
		return adresseNeu;
	}

	public void setAdresseNeu(AdresseDto adresseNeu) {
		this.adresseNeu = adresseNeu;
	}

	public AdresseDto getAdresseKorrespondenz() {
		return adresseKorrespondenz;
	}

	public void setAdresseKorrespondenz(AdresseDto adresseKorrespondenz) {
		this.adresseKorrespondenz = adresseKorrespondenz;
	}

	public String getNameOwner() {
		return nameOwner;
	}

	public void setNameOwner(String nameOwner) {
		this.nameOwner = nameOwner;
	}

	public AdresseDto getAdresseOwner() {
		return adresseOwner;
	}

	public void setAdresseOwner(AdresseDto adresseOwner) {
		this.adresseOwner = adresseOwner;
	}

	public MwstDomizilCollectionDto getRefDomizilData() {
		return refDomizilData;
	}

	public void setRefDomizilData(MwstDomizilCollectionDto refDomizilData) {
		this.refDomizilData = refDomizilData;
	}

	public RechtsformEnum getRechtsForm() {
		return rechtsForm;
	}

}
