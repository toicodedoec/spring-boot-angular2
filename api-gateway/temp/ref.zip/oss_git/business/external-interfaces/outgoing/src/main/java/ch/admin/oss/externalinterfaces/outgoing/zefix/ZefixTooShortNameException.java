/*
 * ZefixTooShortNameException
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

/**
 * This exception is thrown when searching company via Zefix webservice 
 * and Zefix returns an error code which represents the company name to search is too short.
 * 
 * @author hhg
 *
 */
public class ZefixTooShortNameException extends Exception {
	
	private static final long serialVersionUID = 6024430802085735905L;

	public ZefixTooShortNameException(String string) {
		super(string);
	}
}
