/*
 * CoreServiceTest
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.util.IMailUtil;
import ch.admin.oss.util.MailMessage;

/**
 * @author phd
 */
@ActiveProfiles(CommonConstants.PROFILE_TEST)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Transactional
public class CoreServiceTest extends AbstractOSSTest {

	@Autowired
	private IMailUtil mailUtil;

	@PersistenceContext
	private EntityManager em;

	@Test
	public void testMail() {
		MailMessage message = new MailMessage();
		message.setSubject("A mail from OSS");
		message.setFrom("phd@elca.vn");
		message.setTo("phd@elca.vn");
		message.setTemplateName("unittest-freemarker-template.ftl");
		message.setTemplateModel(new HashMap<String, Object>() {
			private static final long serialVersionUID = -5521258463529269444L;

			{
				put("userName", "PHD");
				put("emailAddress", "phd@elca.vn");
			}
		});
		mailUtil.send(message);
		Assert.assertTrue(true);
	}
}
