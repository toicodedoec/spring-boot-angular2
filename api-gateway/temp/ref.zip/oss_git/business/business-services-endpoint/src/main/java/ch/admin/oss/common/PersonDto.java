/*
 * PersonDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ch.admin.oss.common.enums.NatTypEnum;
import ch.admin.oss.portal.endpoint.PersonHeimatortDto;

/**
 * @author hhg
 */
public class PersonDto extends AbstractOSSDto {

	private CodeWertDto zivilstand;
	private CodeWertDto anrede;
	private CodeWertDto geschlecht;
	private CodeWertDto auslaenderAusweis;

	private String titel;
	private String familienname;
	private String ledigname;
	private String vorname;
	private String rufname;
	private String vornamenliste;
	private String ahvNummer;

	private NatTypEnum natType;

	private boolean steuernUSA;

	private AdresseDto wohnadresse;

	private List<PersonHeimatortDto> heimatortes = new ArrayList<PersonHeimatortDto>();
	private List<CodeWertDto> nationalitaetens = new ArrayList<CodeWertDto>();

	private Date geburtsdatum;
	private Date einreisedatum;

	public CodeWertDto getZivilstand() {
		return zivilstand;
	}

	public void setZivilstand(CodeWertDto zivilstand) {
		this.zivilstand = zivilstand;
	}

	public CodeWertDto getAnrede() {
		return anrede;
	}

	public void setAnrede(CodeWertDto anrede) {
		this.anrede = anrede;
	}

	public CodeWertDto getAuslaenderAusweis() {
		return auslaenderAusweis;
	}

	public void setAuslaenderAusweis(CodeWertDto auslaenderAusweis) {
		this.auslaenderAusweis = auslaenderAusweis;
	}

	public String getTitel() {
		return titel;
	}

	public void setTitel(String titel) {
		this.titel = titel;
	}

	public String getFamilienname() {
		return familienname;
	}

	public void setFamilienname(String familienname) {
		this.familienname = familienname;
	}

	public String getLedigname() {
		return ledigname;
	}

	public void setLedigname(String ledigname) {
		this.ledigname = ledigname;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getRufname() {
		return rufname;
	}

	public void setRufname(String rufname) {
		this.rufname = rufname;
	}

	public String getVornamenliste() {
		return vornamenliste;
	}

	public void setVornamenliste(String vornamenliste) {
		this.vornamenliste = vornamenliste;
	}

	public String getAhvNummer() {
		return ahvNummer;
	}

	public void setAhvNummer(String ahvNummer) {
		this.ahvNummer = ahvNummer;
	}

	public AdresseDto getWohnadresse() {
		return wohnadresse;
	}

	public void setWohnadresse(AdresseDto wohnadresse) {
		this.wohnadresse = wohnadresse;
	}

	public List<PersonHeimatortDto> getHeimatortes() {
		return heimatortes;
	}

	public void setHeimatortes(List<PersonHeimatortDto> heimatortes) {
		this.heimatortes = heimatortes;
	}

	public List<CodeWertDto> getNationalitaetens() {
		return nationalitaetens;
	}

	public void setNationalitaetens(List<CodeWertDto> nationalitaetens) {
		this.nationalitaetens = nationalitaetens;
	}

	public Date getGeburtsdatum() {
		return geburtsdatum;
	}

	public void setGeburtsdatum(Date geburtsdatum) {
		this.geburtsdatum = geburtsdatum;
	}

	public Date getEinreisedatum() {
		return einreisedatum;
	}

	public void setEinreisedatum(Date einreisedatum) {
		this.einreisedatum = einreisedatum;
	}

	public CodeWertDto getGeschlecht() {
		return geschlecht;
	}

	public void setGeschlecht(CodeWertDto geschlecht) {
		this.geschlecht = geschlecht;
	}

	public NatTypEnum getNatType() {
		return natType;
	}

	public void setNatType(NatTypEnum natType) {
		this.natType = natType;
	}

	public boolean isSteuernUSA() {
		return steuernUSA;
	}

	public void setSteuernUSA(boolean steuernUSA) {
		this.steuernUSA = steuernUSA;
	}

}
