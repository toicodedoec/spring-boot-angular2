/*
 * OSSConstants
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import static java.time.temporal.ChronoField.DAY_OF_MONTH;
import static java.time.temporal.ChronoField.MONTH_OF_YEAR;
import static java.time.temporal.ChronoField.YEAR;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.SignStyle;

/**
 * @author coh
 */
public interface OSSConstants {
	public static final String MOA_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public static final String MOA_HOMETOWN_SEPARATED = ",";
	public static final int MOA_CORPORATOR_NATURAL_PERSON = 3;
	public static final int MOA_CORPORATOR_LEGAL_PERSON = 4;

	public static final String MWST_FRIST_SERVICE_ERROR_DE = "<h1> Fehlermeldung </h1>";
	public static final String MWST_FRIST_SERVICE_ERROR_FR = "<h1> Message derreur  </h1>";
	public static final String MWST_FRIST_SERVICE_ERROR_IT = "<h1> Messaggio derrore   </h1>";
	public static final String MWST_FRIST_SERVICE_DUPLICATED_DE = "<b>Frist wurde bereits beantragt</b>";
	public static final String MWST_FRIST_SERVICE_SUCCESS_DE = "Ihre Fristverlängerung ist bei uns eingegangen";

	// TODO [COH / S9] To declare sequence per table ????
	public static final String OSS_ID_SEQUENCE = "OSS_ID_SEQ";
	public static final String DATE_FORMAT = "dd.MM.yyyy";

	public static final String DATE_FOR_UID_FORMAT = "yyyy.MM.dd-H:mm:ss:SSS";

	// DateTimeFormatter for dd.MM.yyyy
	public static final DateTimeFormatter LOCAL_DATE_FORMATTER = new DateTimeFormatterBuilder()
		.appendValue(DAY_OF_MONTH, 2).appendLiteral('.').appendValue(MONTH_OF_YEAR, 2).appendLiteral('.')
		.appendValue(YEAR, 4, 10, SignStyle.EXCEEDS_PAD).toFormatter();

	public static final String SWISS_CODE_WERT = "8100";

	public static final String ANDERE_MR_CODE = "MR";
	public static final String ANDERE_MRS_CODE = "MRS";
	
	public static final String HAFTUNG_CODE_BESCHRAENKT = "BESCHRAENKT";

	public static final String GESCHLECHT_MR_CODE = "1";

	public static final String GESCHLECHT_MRS_CODE = "2";

	public static final int DEFAULT_MAX_POS = 1;

	public static final int DEFAULT_MIN_POS = 1;

	public static final String EMAIL_REGEX_PATTERN = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";

	public static final long HR_AMT_CH_ID = 7;

	public static final String EMPTY_STRING = "";
	public static final String JA_STRING = "Ja";
	public static final String NEIN_STRING = "Nein";
	public static final String SEMI_COLON_CHARACTER = ";";
	public static final String SPACE = " ";
	public static final String COMMA_DISPLAY = ", ";
	public static final String DELETE_ACTION_NAME = "delete";
	public static final String EDIT_ACTION_NAME = "edit";
	public static final int MIN_LENGTH_NAME = 3;
}
