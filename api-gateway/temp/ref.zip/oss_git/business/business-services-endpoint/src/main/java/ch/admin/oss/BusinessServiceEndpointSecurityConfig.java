/*
 * BusinessServiceEndpointSecurityConfig
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.access.AccessDeniedHandler;

import ch.admin.oss.security.CommonWebSecurityConfig;
import ch.admin.oss.security.OssRole;

/**
 * Security configuration for business endpoint. Should customize "authorization" mechanism only.
 * @author phd
 *
 */
@Configuration
@EnableWebSecurity
public class BusinessServiceEndpointSecurityConfig extends CommonWebSecurityConfig {

	@Override
	protected void configureAuthorization(HttpSecurity http) throws Exception {
		http.authorizeRequests()
			.antMatchers("/public/**").permitAll()
			.antMatchers("/private/ext/**").hasAnyAuthority(OssRole.EasyGov_EXT.name(), OssRole.EasyGov_DSKU.name(), OssRole.EasyGov_ADMIN.name())
			.antMatchers("/private/int/**").hasAnyAuthority(OssRole.EasyGov_DSKU.name(), OssRole.EasyGov_ADMIN.name())
			.antMatchers("/private/adm/**").hasAnyAuthority(OssRole.EasyGov_ADMIN.name())
			.anyRequest().authenticated()			
			.and()
		.exceptionHandling()
			.accessDeniedHandler(new AccessDeniedHandler() {
				
				@Override
				public void handle(HttpServletRequest request, HttpServletResponse response,
					AccessDeniedException accessDeniedException) throws IOException, ServletException {
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
				}
			})
			.and()
		.cors()
			.configurationSource(corsConfigurationSource());			
    }
}
