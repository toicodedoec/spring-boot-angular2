/*
 * AbstractOSSEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.util.List;
import java.util.stream.Collectors;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.google.common.collect.Lists;

import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.application.service.ICacheService;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.enums.SupportedFileTypeDownload;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyDetailedInfoDto;

/**
 * @author xdg
 */
public class AbstractOSSEndpoint {	

	@Autowired
	protected IApplicationService applicationService;
	
	@Autowired
	protected DozerBeanMapper mapper;
	
	@Autowired
	protected ICacheService cacheService;
	
	@Value(value="${profile.dev.name}")
	private String devProfile;
	
	@Value(value="${profile.dev.frontend.port}")
	private int devProfilePort;

	@Value(value="${oss.serviceRootUrl}")
	private String ossServiceRootUrl;
	
	@Value(value="${oss.frontendRootUrl}")
	private String ossFrontendRootUrl;
	
	protected CodeWertEntity getCodeWert(KategorieEnum kategorie, CodeWertDto code) {
		if (code == null) {
			return null;
		}
		return getCodeWert(kategorie, code.getCode());
	}

	protected CodeWertEntity getCodeWert(KategorieEnum kategorie, String code) {
		return getCodeWerts(kategorie, Lists.newArrayList(code)).get(0);
	}

	protected List<CodeWertEntity> getCodeWerts(KategorieEnum kategorie, List<String> codes) {
		List<CodeWertEntity> result = applicationService.getCodeWerts(kategorie);
		return result.stream().filter(codeWert -> codes.contains(codeWert.getCode())).collect(Collectors.toList());
	}
	
	protected ResponseEntity<byte[]> download(FileDto file) {
		return download(file.getData(), file.getFilename(), file.getFileType());
	}

	@SuppressWarnings({"unchecked", "rawtypes"})
	protected ResponseEntity<byte[]> download(byte[] data, String filename, SupportedFileTypeDownload fileType) {
		MediaType mediaType = null;
		switch (fileType) {
			case PDF:
				mediaType = MediaType.APPLICATION_PDF;
				break;
			case DOC:
				mediaType = MediaType.valueOf("application/msword");
				break;
			case DOCX:
				mediaType = MediaType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
				break;
			case CSV:
				mediaType = MediaType.valueOf("text/csv;charset=utf-8;");
				break;
			default:
				throw new IllegalArgumentException("Unsupported file type download " + fileType);
		}
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment;filename=" + filename);
		headers.setContentType(mediaType);
		return new ResponseEntity(data, headers, HttpStatus.OK);
	}
	
	protected CompanyDetailedInfoDto importHRRegistrationFromZefix(OrganisationEntity organisation, 
			String defaultName, String uid, String chNr, String polGemeinde, RechtsformEnum rechtsform) {
		
		if (organisation.getHrStatus() != HRStatusEnum.REGISTERED) {
			return null;
		}
		
		CompanyDetailedInfoDto importData = new CompanyDetailedInfoDto();
		importData.setName(defaultName);
		importData.setUid(Integer.parseInt(uid));
		importData.setChid(chNr);
		importData.setLegalSeat(polGemeinde);
		importData.setRechtsform(rechtsform);
		return importData;
	}
	
	protected CompanyDetailedInfoDto importHRRegistrationFromZefix(OrganisationEntity organisation) {
		return importHRRegistrationFromZefix(organisation, organisation.defaultName(), organisation.getUid(), 
			organisation.getChNr(), organisation.getDomizil().getPolGemeinde(), organisation.getRechtsform());
	}
	
	protected String getServiceRootUrl() {
		return ossServiceRootUrl;
	}
	
	protected String getFrontendRootUrl() {
		return ossFrontendRootUrl;
	}
}
