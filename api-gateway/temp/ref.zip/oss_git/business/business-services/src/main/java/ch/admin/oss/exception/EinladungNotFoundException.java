/*
 * EinladungNotFound
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.exception;

/**
 * @author tdm
 *
 */
public class EinladungNotFoundException extends Exception {

	private static final long serialVersionUID = -8972796508540878043L;
	
	public EinladungNotFoundException(String message) {
		super(message);
	}

}
