package ch.admin.oss.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.pdfbox.pdmodel.interactive.form.PDSignatureField;
import org.junit.Assert;
import org.junit.Test;


public class PdfBoxUtilTest {	

	private static final Path PDF_PATH_1 = Paths.get("src//test//resources//anmeldung (1).pdf");
	private static final Path PDF_PATH_2 = Paths.get("src//test//resources//anmeldung (1)_suissesigner1.pdf");
	private static final Path PDF_PATH_3 = Paths.get("src//test//resources//hr_pdf.pdf");
	private static final Path PDF_PATH_4 = Paths.get("src//test//resources//hr_pdf_singed.pdf");
	private static final Path PDF_PATH_5 = Paths.get("src//test//resources//hr_pdf_singed_3.pdf");

	@Test
	public void testCompareContentPdf() throws IOException {	
		Assert.assertTrue(PdfBoxUtil.compareContentPdf(Files.readAllBytes(PDF_PATH_1), Files.readAllBytes(PDF_PATH_2)));
		Assert.assertFalse(PdfBoxUtil.compareContentPdf(Files.readAllBytes(PDF_PATH_3), Files.readAllBytes(PDF_PATH_2)));		
	}
	
	@Test
	public void testExtractSignees() throws IOException {
		byte[] bytes = Files.readAllBytes(PDF_PATH_2);
		List<PDSignatureField> signatureFields = PdfBoxUtil.getSignatureFields(bytes);
		List<String> extractSignees = PdfBoxUtil.extractSignees(signatureFields);
		Assert.assertEquals(1, extractSignees.size());
		Assert.assertEquals("Tobias Loew (Qualified Signature)", extractSignees.get(0));
		
		bytes = Files.readAllBytes(PDF_PATH_5);
		signatureFields = PdfBoxUtil.getSignatureFields(bytes);
		extractSignees = PdfBoxUtil.extractSignees(signatureFields);
		Assert.assertEquals(3, extractSignees.size());
		Assert.assertEquals("Donflamingo", extractSignees.get(0));
		Assert.assertEquals("Ryns", extractSignees.get(1));
		Assert.assertEquals("Hai", extractSignees.get(2));
	}
	
	@Test
	public void testValidateSignatures() throws IOException {
		byte[] bytes = Files.readAllBytes(PDF_PATH_1);
		byte[] bytes2 = Files.readAllBytes(PDF_PATH_2);
		byte[] bytes3 = Files.readAllBytes(PDF_PATH_4);
		byte[] bytes4 = Files.readAllBytes(PDF_PATH_5);
		Assert.assertTrue(PdfBoxUtil.validateSignatures(bytes, bytes2));
		Assert.assertFalse(PdfBoxUtil.validateSignatures(bytes3, bytes2));		
		Assert.assertTrue(PdfBoxUtil.validateSignatures(bytes3, bytes4));
	}
}
