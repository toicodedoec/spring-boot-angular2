/*
 * StartBizDataEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 * @author coh
 */
@Entity
@Table(name = "T_STARTBIZ_DATA", 
	uniqueConstraints = {
		@UniqueConstraint(name="UK_STARTBIZ_ORGANISATION", columnNames = {"LN_ORGANISATION"})
	})
public class StartBizDataEntity extends AbstractOSSEntity {

	@Lob
	@Column(name = "STARTBIZ_DATA", columnDefinition = "CLOB")
	private String data;

	@Column(name = "COMPANY_NAME")
	private String companyName;
	
	@Column(name = "STARTBIZ_UID")
	private String uid;
	
	@Column(name = "PASSWORD_HASH")
	private String passwordHash;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name="FK_STARTBIZ_ORGANISATION"))
	private OrganisationEntity organisation;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "PASSWORD_SALT")
	private String passwordSalt;
	
	@Column(name = "CITY")
	private String city;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPasswordSalt() {
		return passwordSalt;
	}

	public void setPasswordSalt(String passwordSalt) {
		this.passwordSalt = passwordSalt;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
}
