/*
 * IncomingServiceEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.incoming;

import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/**
 * Centralized point for exposing all web services produced by OSS via SOAP, ...
 * 
 * @author phd
 */
@Configuration
public class IncomingInterfaceConfig {

	@Bean
	public ServletRegistrationBean incomingInterfaceServlet() {
		return new ServletRegistrationBean(new CXFServlet(), "/services/*");
	}
}
