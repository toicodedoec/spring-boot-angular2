/*
 * LegalPartnerInfoDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyDetailedInfoDto;

/**
 * @author xdg
 */
public class LegalPartnerInfoDto {
	private long orgId;
	private KommFirmaDto legalPartner;
	private boolean atSwiss;
	private CompanyDetailedInfoDto importData;
	
	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public KommFirmaDto getLegalPartner() {
		return legalPartner;
	}

	public void setLegalPartner(KommFirmaDto legalPartner) {
		this.legalPartner = legalPartner;
	}

	public boolean isAtSwiss() {
		return atSwiss;
	}

	public void setAtSwiss(boolean atSwiss) {
		this.atSwiss = atSwiss;
	}

	public CompanyDetailedInfoDto getImportData() {
		return importData;
	}
}
