package ch.admin.oss.admin.query;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.admin.criteria.WertelistenCriteria;
import ch.admin.oss.common.enums.AktivFilterEnum;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.QCodeWertEntity;
import ch.admin.oss.domain.QStandardTextEntity;
import ch.admin.oss.domain.QTextTranslationEntity;

/**
 * @author hhu
 */
public class WertelistenTextTranslationQuery extends AbstractTextTranslationQuery<WertelistenCriteria, CodeWertEntity> {
	
	@Override
	public JPAQuery<CodeWertEntity> buildQuery(WertelistenCriteria criteria, EntityManager em) {
		JPAQuery<CodeWertEntity> query = new JPAQuery<CodeWertEntity>(em)
			.from(QCodeWertEntity.codeWertEntity)
			.leftJoin(QCodeWertEntity.codeWertEntity.standardText, QStandardTextEntity.standardTextEntity)
			.join(QStandardTextEntity.standardTextEntity.translations, QTextTranslationEntity.textTranslationEntity)
			.distinct();
		
		if (StringUtils.isNotBlank(criteria.getCode())) {
			query.where(QCodeWertEntity.codeWertEntity.code.eq(criteria.getCode().trim()));
		}

		if (StringUtils.isNotBlank(criteria.getText())) {
			query.where(QTextTranslationEntity.textTranslationEntity.text.containsIgnoreCase(criteria.getText()));
		}

		if (criteria.getStatus() == AktivFilterEnum.Unaktiv) {
			query.where(QCodeWertEntity.codeWertEntity.aktiv.eq(false));
		}

		if (criteria.getStatus() == AktivFilterEnum.Aktiv) {
			query.where(QCodeWertEntity.codeWertEntity.aktiv.eq(true));
		}
		
		query.where(QCodeWertEntity.codeWertEntity.kategorie.eq(criteria.getKategorie()));
		
		return query;
	}	
}
