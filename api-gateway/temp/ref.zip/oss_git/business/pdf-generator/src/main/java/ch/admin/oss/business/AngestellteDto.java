/*
 * AngestellteDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;
import java.time.LocalDate;

import ch.admin.oss.OssCurrencyFormatter;

/**
 * @author hhg
 *
 */
public class AngestellteDto {
	
	private Integer num;
	@OssCurrencyFormatter
	private BigDecimal lohn;
	private String kinder;
	private LocalDate seit;

	public AngestellteDto(Integer num, BigDecimal lohn, String kinder, LocalDate seit) {
		this.num = num;
		this.lohn = lohn;
		this.kinder = kinder;
		this.seit = seit;
	}

	public Integer getNum() {
		return num;
	}

	public BigDecimal getLohn() {
		return lohn;
	}

	public String getKinder() {
		return kinder;
	}

	public LocalDate getSeit() {
		return seit;
	}
}
