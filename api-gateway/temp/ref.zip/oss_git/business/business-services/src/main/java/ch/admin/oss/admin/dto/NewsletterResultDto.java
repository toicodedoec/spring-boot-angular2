/*
 * NewsletterResultDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.dto;

/**
 * @author hha
 */
public class NewsletterResultDto {

	private long numberOfHit;
	private long numberOfRegistration;
	private long numberOfAdministrativeApplication;

	public long getNumberOfHit() {
		return numberOfHit;
	}

	public void setNumberOfHit(long numberOfHit) {
		this.numberOfHit = numberOfHit;
	}

	public long getNumberOfRegistration() {
		return numberOfRegistration;
	}

	public void setNumberOfRegistration(long numberOfRegistration) {
		this.numberOfRegistration = numberOfRegistration;
	}

	public long getNumberOfAdministrativeApplication() {
		return numberOfAdministrativeApplication;
	}

	public void setNumberOfAdministrativeApplication(long numberOfAdministrativeApplication) {
		this.numberOfAdministrativeApplication = numberOfAdministrativeApplication;
	}

}
