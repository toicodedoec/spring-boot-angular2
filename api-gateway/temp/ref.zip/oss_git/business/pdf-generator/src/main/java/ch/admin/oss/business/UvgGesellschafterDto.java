/*
 * UvgGesellschafterDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;

import ch.admin.oss.OssCurrencyFormatter;

/**
 * @author hha
 */
public class UvgGesellschafterDto {

	private int index;
	private GeschaftsrolleDto person;

	@OssCurrencyFormatter(integer = true)
	private BigDecimal lohnsumme;

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public GeschaftsrolleDto getPerson() {
		return person;
	}

	public void setPerson(GeschaftsrolleDto person) {
		this.person = person;
	}

	public BigDecimal getLohnsumme() {
		return lohnsumme;
	}

	public void setLohnsumme(BigDecimal lohnsumme) {
		this.lohnsumme = lohnsumme;
	}

}
