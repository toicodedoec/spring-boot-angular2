/*
 * AusgleichskasseQueryCriteria
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.query;

import javax.persistence.EntityManager;

import org.apache.commons.lang3.StringUtils;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.admin.criteria.AusgleichskasseCriteria;
import ch.admin.oss.common.enums.AktivFilterEnum;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.QAusgleichskasseEntity;
import ch.admin.oss.domain.QStandardTextEntity;
import ch.admin.oss.domain.QTextTranslationEntity;

/**
 * @author tdm
 */
public class AusgleichskasseTextTranslationQuery extends AbstractTextTranslationQuery<AusgleichskasseCriteria, AusgleichskasseEntity> {

	@Override
	public JPAQuery<AusgleichskasseEntity> buildQuery(AusgleichskasseCriteria criteria, EntityManager em) {
		JPAQuery<AusgleichskasseEntity> jpaQuery = new JPAQuery<AusgleichskasseEntity>(em)
			.from(QAusgleichskasseEntity.ausgleichskasseEntity)
			.leftJoin(QAusgleichskasseEntity.ausgleichskasseEntity.standardText, QStandardTextEntity.standardTextEntity)
			.join(QStandardTextEntity.standardTextEntity.translations, QTextTranslationEntity.textTranslationEntity)
			.orderBy(QAusgleichskasseEntity.ausgleichskasseEntity.id.asc())
			.distinct();
		
		if (StringUtils.isNotBlank(criteria.getText())) {
			jpaQuery.where(QTextTranslationEntity.textTranslationEntity.text
				.containsIgnoreCase(StringUtils.trim(criteria.getText())));
		}
		
		if(criteria.getStatus() == AktivFilterEnum.Unaktiv) {
			jpaQuery.where(QAusgleichskasseEntity.ausgleichskasseEntity.aktiv.eq(false));
		} else if (criteria.getStatus() == AktivFilterEnum.Aktiv) {
			jpaQuery.where(QAusgleichskasseEntity.ausgleichskasseEntity.aktiv.eq(true));
		}

		return jpaQuery;
	}
}
