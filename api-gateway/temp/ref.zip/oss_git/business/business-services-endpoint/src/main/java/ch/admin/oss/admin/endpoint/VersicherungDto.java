/*
 * VersicherungDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.util.OSSConstants;

public class VersicherungDto extends AbstractOSSDto {

	@NotNull
	private boolean aktiv;

	@NotNull
	private StandardTextDto standardText;
	
	private String postfach;

	@NotNull
	private String strasse;

	private String hausnummer;

	@NotNull
	private String plz;

	@NotNull
	private String ort;

	@NotNull
	private String telefon;
	
	private String fax;
	
	private String homepage;

	@NotNull
	@Pattern(regexp = OSSConstants.EMAIL_REGEX_PATTERN)
	private String emailKundenanfragen;

	@NotNull
	@Pattern(regexp = OSSConstants.EMAIL_REGEX_PATTERN)
	private String emailDatenversand;

	@NotNull
	private boolean mitgliedVerband;

	@NotNull
	private boolean anmeldungMoeglich;

	@NotNull
	private String sprache;

	@NotNull
	private String kanton;

	public VersicherungDto() {
	}

	public boolean isAktiv() {
		return aktiv;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}

	public StandardTextDto getStandardText() {
		return standardText;
	}

	public void setStandardText(StandardTextDto standardText) {
		this.standardText = standardText;
	}

	public String getPostfach() {
		return postfach;
	}

	public void setPostfach(String postfach) {
		this.postfach = postfach;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getHausnummer() {
		return hausnummer;
	}

	public void setHausnummer(String hausnummer) {
		this.hausnummer = hausnummer;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getHomepage() {
		return homepage;
	}

	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}

	public String getEmailKundenanfragen() {
		return emailKundenanfragen;
	}

	public void setEmailKundenanfragen(String emailKundenanfragen) {
		this.emailKundenanfragen = emailKundenanfragen;
	}

	public String getEmailDatenversand() {
		return emailDatenversand;
	}

	public void setEmailDatenversand(String emailDatenversand) {
		this.emailDatenversand = emailDatenversand;
	}

	public boolean isMitgliedVerband() {
		return mitgliedVerband;
	}

	public void setMitgliedVerband(boolean mitgliedVerband) {
		this.mitgliedVerband = mitgliedVerband;
	}

	public boolean isAnmeldungMoeglich() {
		return anmeldungMoeglich;
	}

	public void setAnmeldungMoeglich(boolean anmeldungMoeglich) {
		this.anmeldungMoeglich = anmeldungMoeglich;
	}

	public String getSprache() {
		return sprache;
	}

	public void setSprache(String sprache) {
		this.sprache = sprache;
	}

	public String getKanton() {
		return kanton;
	}

	public void setKanton(String kanton) {
		this.kanton = kanton;
	}	
}
