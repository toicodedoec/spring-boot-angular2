/*
 * AdminServiceTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.admin.criteria.AusgleichskasseCriteria;
import ch.admin.oss.admin.criteria.BranchenCriteria;
import ch.admin.oss.admin.criteria.PrivatversichererCriteria;
import ch.admin.oss.admin.dto.ListResultDto;
import ch.admin.oss.admin.repository.IAusgleichskasseRepository;
import ch.admin.oss.admin.service.impl.AdminService;
import ch.admin.oss.business.AbstractOSSTest;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.enums.AccessLevelEnum;
import ch.admin.oss.common.enums.AccessStatusEnum;
import ch.admin.oss.common.enums.AktivFilterEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.OrganisationCreationTypeEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AbgeschlossenerProzesseStatistikDto;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.BenutzerkontoBerechtigungenStatistikDto;
import ch.admin.oss.domain.BenutzerregistrierungenStatistikDto;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.FirmennameEntity;
import ch.admin.oss.domain.GrundungenStatistikDto;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QUserEntity;
import ch.admin.oss.domain.StandardTextEntity;
import ch.admin.oss.domain.StatuswechselEntity;
import ch.admin.oss.domain.TextTranslationEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.VerbandEntity;
import ch.admin.oss.domain.VerbundenerUnternehmenStatistikDto;
import ch.admin.oss.domain.VersicherungEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.organisation.repository.IOrganisationRepository;
import ch.admin.oss.organisation.service.IOrganisationService;
import ch.admin.oss.portal.repository.IProzessRepository;
import ch.admin.oss.portal.repository.IStatuswechselRepository;
import ch.admin.oss.portal.repository.IVerbandRepository;
import ch.admin.oss.util.OSSDateUtil;

/**
 * @author xdg
 *
 */
@ActiveProfiles(CommonConstants.PROFILE_TEST)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Transactional
public class AdminServiceTest extends AbstractOSSTest {
	
	@Autowired
	IOrganisationService orgService;
	
	@Autowired
	IAdminService admService;
	
	@Autowired
	IAusgleichskasseRepository ausRepo;
	
	@Autowired
	IVerbandRepository verbandRepo;
	
	@Autowired
	IOrganisationRepository orgRepo;
	
	@Autowired
	IProzessRepository prozessRepo;
	
	@Autowired
	IStatuswechselRepository statusRepo;
	
	private static final int LIMIT_PAGE = 25;
	/**
	 * @author hhu
	 * 
	 * Test get list versicherung and create versicherung
	 */
	@Test
	public void testGetVersicherungs() {
		PrivatversichererCriteria criteria = new PrivatversichererCriteria();
		criteria.setName("DE_TEST_TEXT");
		criteria.setStatus(AktivFilterEnum.Aktiv);
		criteria.setOffset(0);
		criteria.setLimit(LIMIT_PAGE);
		
		VersicherungEntity versi = new VersicherungEntity();
		versi.setAktiv(true);
		versi.setStandardText(initDummyStandardTextEntity());
		versi = admService.saveVersicherungEntity(versi);
		
		List<VersicherungEntity> ents = admService.getPaginationPrivatversichererListen(criteria).getItems();
		for(VersicherungEntity ent : ents) {
			Assert.assertTrue(ent.isAktiv());
			boolean result = false;
			for(TextTranslationEntity t : ent.getStandardText().getTranslations()) {
				if(StringUtils.containsIgnoreCase(t.getText(), "DE_TEST_TEXT")) {
					result = true;
				}
			}
			Assert.assertTrue(result);
		}
	}
	
	/**
	 * Test: edit versicherung and create
	 */
	@Test
	public void testEditVersicherung() {
		VersicherungEntity versi = new VersicherungEntity("postfach", "strasse", "hausnummer", "plz", "ort", "homepage", "test@elca.vn", "fone", "fax", "test@elca.vn", true, true, "CH", "de, fr", true);
		versi.setStandardText(initDummyStandardTextEntity());
		
		versi.setAktiv(false);
		versi.setPostfach("TEST_postfach");
		versi.setStrasse("Test_strasse");
		versi.getStandardText().getTranslations().forEach(t-> {
			t.setText(t.getLanguage().name().concat("EDIT_VERSICHERUNG"));
		});
		
		versi = admService.saveVersicherungEntity(versi);
		
		versi.getStandardText().getTranslations().forEach(t->{
			Assert.assertTrue(t.getText().equals(t.getLanguage().name().concat("EDIT_VERSICHERUNG")));
		});
		
		Assert.assertTrue(!versi.isAktiv());
		Assert.assertTrue(versi.getPostfach().equals("TEST_postfach"));
		Assert.assertTrue(versi.getStrasse().equals("Test_strasse"));
	}
	
	
	/**
	 * @author hhu
	 * Test edit codeWert
	 * @return
	 */
	@Test
	public void testEditCodeWert() {
		CodeWertEntity ent = new CodeWertEntity(KategorieEnum.ANREDE, "Code_Wert_TEST", true, 100);		
		StandardTextEntity standard = initDummyStandardTextEntity();		
		ent.setStandardText(standard);
		
		// Create a new CodeWert
		ent = admService.saveCodeWertEntity(ent);
		
		ent.setAktiv(false);
		ent.setPos(200);
		ent.getStandardText().getTranslations().forEach(t->{
			t.setText(t.getLanguage().name().concat("EDIT_TEXT"));
		});
		
		// Save after edit CodeWert
		ent = admService.saveCodeWertEntity(ent);
		
		// Compare text translations
		ent.getStandardText().getTranslations().forEach(t->{
			Assert.assertTrue(t.getText().equals(t.getLanguage().name().concat("EDIT_TEXT")));
		});
		
		// Compare aktive and position
		Assert.assertTrue(!ent.isAktiv());
		Assert.assertTrue(ent.getPos() == 200);
	}
	
	/**
	 * @author hhu
	 * Init Dummy standard text for testing
	 * @return StandardTextEntity
	 */
	private StandardTextEntity initDummyStandardTextEntity() {
		TextTranslationEntity de = new TextTranslationEntity(SupportedLanguage.DE, "DE_TEST_TEXT");
		TextTranslationEntity fr = new TextTranslationEntity(SupportedLanguage.FR, "FR_TEST_TEXT");
		TextTranslationEntity it = new TextTranslationEntity(SupportedLanguage.IT, "IT_TEST_TEXT");
		TextTranslationEntity ne = new TextTranslationEntity(SupportedLanguage.EN, "EN_TEST_TEXT");
		
		Set<TextTranslationEntity> set = new HashSet<>();
		set.add(fr);
		set.add(it);
		set.add(ne);
		set.add(de);
		
		StandardTextEntity standard = new StandardTextEntity(false, set);	
		
		fr.setStandardText(standard);
		ne.setStandardText(standard);
		de.setStandardText(standard);
		it.setStandardText(standard);
		return standard;
	}
	
	@Test
	public void getBranches() {
		BranchenCriteria criteria = new BranchenCriteria();
		criteria.setStatus(AktivFilterEnum.Aktiv);
		criteria.setLimit(LIMIT_PAGE);
		criteria.setOffset(0);
		ListResultDto<BrancheEntity> branchen = admService.getPaginationBranchen(criteria);
		Assert.assertEquals(criteria.getLimit(), branchen.getItems().size());
	}
	
	@Test
	public void saveBranche_add() {
		BrancheEntity ent = prepareBrancheEnt();

		ent = admService.saveBranche(ent);

		Assert.assertNotNull(ent);
		Assert.assertNotNull(ent.getId());
		Assert.assertEquals("9999", ent.getCode());
		Assert.assertTrue(ent.isAktiv());
		Assert.assertTrue(ent.isSuva());
	}

	/**
	 * @return
	 */
	private BrancheEntity prepareBrancheEnt() {
		BrancheEntity ent = new BrancheEntity();
		ent.setAktiv(true);
		ent.setCode("9999");
		ent.setPos(9999);
		ent.setSuva(true);
		
		StandardTextEntity standard = initDummyStandardTextEntity();
		
		ent.setStandardText(standard);
		return ent;
	}

	@Test
	public void saveBranche_edit() {
		BrancheEntity ent = prepareBrancheEnt();
		ent.setCode("8888");
		ent.setPos(8888);
		ent = admService.saveBranche(ent);
		
		Assert.assertNotNull(ent);
		Assert.assertNotNull(ent.getId());
		Assert.assertEquals("8888", ent.getCode());
		Assert.assertEquals(8888, ent.getPos());
		Assert.assertTrue(ent.isAktiv());
		Assert.assertTrue(ent.isSuva());
		
		ent.setAktiv(false);
		ent.setCode("1111");
		ent.setPos(1111);
		ent.setSuva(false);
		
		ent = admService.saveBranche(ent);
		
		Assert.assertNotNull(ent);
		Assert.assertNotNull(ent.getId());
		Assert.assertEquals("1111", ent.getCode());
		Assert.assertEquals(1111, ent.getPos());
		Assert.assertFalse(ent.isAktiv());
		Assert.assertFalse(ent.isSuva());
	}
	
	private VerbandEntity prepareVerbandEntity(AusgleichskasseEntity ausEntity) {
		TextTranslationEntity de = new TextTranslationEntity(SupportedLanguage.DE, "DE_TEST_TEXT");
		TextTranslationEntity fr = new TextTranslationEntity(SupportedLanguage.FR, "FR_TEST_TEXT");
		TextTranslationEntity it = new TextTranslationEntity(SupportedLanguage.IT, "IT_TEST_TEXT");
		TextTranslationEntity ne = new TextTranslationEntity(SupportedLanguage.EN, "EN_TEST_TEXT");
		
		Set<TextTranslationEntity> set = new HashSet<TextTranslationEntity>();

		set.add(de);
		set.add(fr);
		set.add(it);
		set.add(ne);
		
		StandardTextEntity standard = new StandardTextEntity(false, set);	
		
		fr.setStandardText(standard);
		ne.setStandardText(standard);
		de.setStandardText(standard);
		it.setStandardText(standard);
		
		VerbandEntity verbandEntity = new VerbandEntity();
		
		verbandEntity.setStandardText(standard);
		
		verbandEntity.setAusgleichskasse(ausEntity);
		
		return verbandEntity;
	}
	
	@Test
	public void testEditVerband() {
		// Prepare test data
		AusgleichskasseEntity ausEntity = new AusgleichskasseEntity();
		
		ausEntity.setAktiv(true);
		ausEntity.setLeistungfak(true);
		ausEntity = ausRepo.save(ausEntity);
		
		VerbandEntity verbandEntity = prepareVerbandEntity(ausEntity);
		
		//execute
		verbandEntity = admService.saveVerband(verbandEntity);
		
		AusgleichskasseEntity ausEntity1 = new AusgleichskasseEntity();
		
		ausEntity1.setAktiv(false);
		ausEntity1.setLeistungfak(false);
		ausEntity1 = ausRepo.save(ausEntity1);
		verbandEntity.setAusgleichskasse(ausEntity1);
		
		verbandEntity.getStandardText().getTranslations().stream().forEach(translate -> {
			if(translate.getLanguage() == SupportedLanguage.DE) {
				translate.setText("DE_TEST_TEXT_EDIT");
			}
			if(translate.getLanguage() == SupportedLanguage.FR) {
				translate.setText("FR_TEST_TEXT_EDIT");
			}
			if(translate.getLanguage() == SupportedLanguage.EN) {
				translate.setText("EN_TEST_TEXT_EDIT");
			}
			if(translate.getLanguage() == SupportedLanguage.IT) {
				translate.setText("IT_TEST_TEXT_EDIT");
			}
		});
		
		verbandEntity = admService.saveVerband(verbandEntity);
		// verify
		verbandEntity.getStandardText().getTranslations().stream().forEach( translate -> {
			if(translate.getLanguage() == SupportedLanguage.DE) {
				Assert.assertTrue(translate.getText().equals("DE_TEST_TEXT_EDIT"));
			}
			if(translate.getLanguage() == SupportedLanguage.FR) {
				Assert.assertTrue(translate.getText().equals("FR_TEST_TEXT_EDIT"));
			}
			if(translate.getLanguage() == SupportedLanguage.EN) {
				Assert.assertTrue(translate.getText().equals("EN_TEST_TEXT_EDIT"));
			}
			if(translate.getLanguage() == SupportedLanguage.IT) {
				Assert.assertTrue(translate.getText().equals("IT_TEST_TEXT_EDIT"));
			}
		});
		Assert.assertTrue(verbandEntity.getAusgleichskasse().getId() == ausEntity1.getId());
		Assert.assertTrue(!verbandEntity.getAusgleichskasse().isLeistungfak());
		Assert.assertTrue(!verbandEntity.getAusgleichskasse().isAktiv());
	}
	
	@Test
	public void testCreateVerband() {
		// Prepare test data
		AusgleichskasseEntity ausEntity = new AusgleichskasseEntity();
		
		ausEntity.setAktiv(true);
		ausEntity.setLeistungfak(true);
		ausEntity = ausRepo.save(ausEntity);
		
		VerbandEntity verbandEntity = prepareVerbandEntity(ausEntity);
		
		//execute
		verbandEntity = admService.saveVerband(verbandEntity);
		
		// verify
		verbandEntity.getStandardText().getTranslations().stream().forEach( translate -> {
			if(translate.getLanguage() == SupportedLanguage.DE) {
				Assert.assertTrue(translate.getText().equals("DE_TEST_TEXT"));
			}
			if(translate.getLanguage() == SupportedLanguage.FR) {
				Assert.assertTrue(translate.getText().equals("FR_TEST_TEXT"));
			}
			if(translate.getLanguage() == SupportedLanguage.EN) {
				Assert.assertTrue(translate.getText().equals("EN_TEST_TEXT"));
			}
			if(translate.getLanguage() == SupportedLanguage.IT) {
				Assert.assertTrue(translate.getText().equals("IT_TEST_TEXT"));
			}
		});
		Assert.assertTrue(verbandEntity.getAusgleichskasse().getId() == ausEntity.getId());
		Assert.assertTrue(verbandEntity.getAusgleichskasse().isLeistungfak());
		Assert.assertTrue(verbandEntity.getAusgleichskasse().isAktiv());
	}
	
	@Test
	public void testGetListAusgleichskasse() {
		// Prepare data
		//Create the first AusgleichskasseEntity
		StandardTextEntity standard = new StandardTextEntity();
		addTextTranslation("TEST_TEXT_DE", standard, SupportedLanguage.DE);
		addTextTranslation("TEST_TEXT_FR", standard, SupportedLanguage.FR);
		addTextTranslation("TEST_TEXT_EN", standard, SupportedLanguage.EN);
		addTextTranslation("TEST_TEXT_IT", standard, SupportedLanguage.IT);
		AusgleichskasseEntity ausgleichskasseEntity = new AusgleichskasseEntity();
		ausgleichskasseEntity.setAktiv(true);
		ausgleichskasseEntity.setLeistungfak(true);
		ausgleichskasseEntity.setStandardText(standard);
		ausRepo.save(ausgleichskasseEntity);
		//Create the second AusgleichskasseEntity
		StandardTextEntity standard1 = new StandardTextEntity();
		addTextTranslation("TEST_TEXT_DE_1", standard1, SupportedLanguage.DE);
		addTextTranslation("TEST_TEXT_FR_1", standard1, SupportedLanguage.FR);
		addTextTranslation("TEST_TEXT_EN_1", standard1, SupportedLanguage.EN);
		addTextTranslation("TEST_TEXT_IT_1", standard1, SupportedLanguage.IT);
		AusgleichskasseEntity ausgleichskasseEntity1 = new AusgleichskasseEntity();
		ausgleichskasseEntity1.setAktiv(true);
		ausgleichskasseEntity1.setLeistungfak(true);
		ausgleichskasseEntity1.setStandardText(standard1);
		ausRepo.save(ausgleichskasseEntity1);
		// get list Ausgleichskasse
		AusgleichskasseCriteria criteria = new AusgleichskasseCriteria();
		criteria.setText("TEST_TEXT");
		criteria.setStatus(AktivFilterEnum.Aktiv);
		criteria.setOffset(0);
		criteria.setLimit(LIMIT_PAGE);

		//verify
		List<AusgleichskasseEntity> ents = admService.getPaginationAusgleichskasseListen(criteria).getItems();
		if(ents.size() > 0) {
			for(AusgleichskasseEntity ent : ents) {
				Assert.assertTrue(ent.isAktiv());
				Assert.assertTrue(ent.isLeistungfak());
				boolean result = false;
				for(TextTranslationEntity t : ent.getStandardText().getTranslations()) {
					if(StringUtils.containsIgnoreCase(t.getText(), "TEST_TEXT")) {
						result = true;
					}
				}
				Assert.assertTrue(result);
			}
		} else {
			Assert.assertTrue(true);
		}
	}
	
	private AusgleichskasseEntity prepareAusgleichskasseEntity() {
		
		StandardTextEntity standard = new StandardTextEntity();	
		
		addTextTranslation("TEST_TEXT_DE", standard, SupportedLanguage.DE);
		addTextTranslation("TEST_TEXT_FR", standard, SupportedLanguage.FR);
		addTextTranslation("TEST_TEXT_EN", standard, SupportedLanguage.EN);
		addTextTranslation("TEST_TEXT_IT", standard, SupportedLanguage.IT);
		
		AusgleichskasseEntity ausEntity = new AusgleichskasseEntity();
		
		ausEntity.setStandardText(standard);
		ausEntity.setAktiv(true);
		ausEntity.setLeistungfak(true);
		ausEntity.setHausnummer("hausnummer");
		ausEntity.setHomepage("homepage");
		ausEntity.setPlz("plz");
		ausEntity.setEmail("email");
		return ausEntity;
	}
	
	@Test
	public void testEditAusgleichskasse() {
		// Prepare test data
		AusgleichskasseEntity ausEntity = prepareAusgleichskasseEntity();
		
		//execute
		ausEntity = admService.saveAusgleichskasse(ausEntity);
		
		ausEntity.setAktiv(false);
		ausEntity.setLeistungfak(false);
		ausEntity.setHausnummer("hausnummer_edit");
		ausEntity.setHomepage("homepage_edit");
		ausEntity.setPlz("plz_edit");
		ausEntity.setEmail("email_edit");
		
		ausEntity.getStandardText().getTranslations().stream().forEach(translate -> {
			if(translate.getLanguage() == SupportedLanguage.DE) {
				translate.setText("DE_TEST_TEXT_EDIT");
			}
			if(translate.getLanguage() == SupportedLanguage.FR) {
				translate.setText("FR_TEST_TEXT_EDIT");
			}
			if(translate.getLanguage() == SupportedLanguage.EN) {
				translate.setText("EN_TEST_TEXT_EDIT");
			}
			if(translate.getLanguage() == SupportedLanguage.IT) {
				translate.setText("IT_TEST_TEXT_EDIT");
			}
		});
		
		ausEntity = admService.saveAusgleichskasse(ausEntity);
		// verify
		ausEntity.getStandardText().getTranslations().stream().forEach( translate -> {
			if(translate.getLanguage() == SupportedLanguage.DE) {
				Assert.assertTrue(translate.getText().equals("DE_TEST_TEXT_EDIT"));
			}
			if(translate.getLanguage() == SupportedLanguage.FR) {
				Assert.assertTrue(translate.getText().equals("FR_TEST_TEXT_EDIT"));
			}
			if(translate.getLanguage() == SupportedLanguage.EN) {
				Assert.assertTrue(translate.getText().equals("EN_TEST_TEXT_EDIT"));
			}
			if(translate.getLanguage() == SupportedLanguage.IT) {
				Assert.assertTrue(translate.getText().equals("IT_TEST_TEXT_EDIT"));
			}
		});
		Assert.assertTrue(!ausEntity.isAktiv());
		Assert.assertTrue(!ausEntity.isLeistungfak());
		Assert.assertTrue(ausEntity.getHausnummer().equals("hausnummer_edit"));
		Assert.assertTrue(ausEntity.getHomepage().equals("homepage_edit"));
		Assert.assertTrue(ausEntity.getPlz().equals("plz_edit"));
		Assert.assertTrue(ausEntity.getEmail().equals("email_edit"));
	}
	
	@Test
	public void testCreateAusgleichskasse() {
		// Prepare test data
		AusgleichskasseEntity ausEntity = prepareAusgleichskasseEntity();
		
		//execute
		ausEntity = admService.saveAusgleichskasse(ausEntity);
		
		// verify
		ausEntity.getStandardText().getTranslations().stream().forEach( translate -> {
			if(translate.getLanguage() == SupportedLanguage.DE) {
				Assert.assertTrue(translate.getText().equals("TEST_TEXT_DE"));
			}
			if(translate.getLanguage() == SupportedLanguage.FR) {
				Assert.assertTrue(translate.getText().equals("TEST_TEXT_FR"));
			}
			if(translate.getLanguage() == SupportedLanguage.EN) {
				Assert.assertTrue(translate.getText().equals("TEST_TEXT_EN"));
			}
			if(translate.getLanguage() == SupportedLanguage.IT) {
				Assert.assertTrue(translate.getText().equals("TEST_TEXT_IT"));
			}
		});
		Assert.assertTrue(ausEntity.isLeistungfak());
		Assert.assertTrue(ausEntity.isAktiv());
		Assert.assertTrue(ausEntity.getHausnummer().equals("hausnummer"));
		Assert.assertTrue(ausEntity.getHomepage().equals("homepage"));
		Assert.assertTrue(ausEntity.getPlz().equals("plz"));
		Assert.assertTrue(ausEntity.getEmail().equals("email"));
	}
	
	private void addTextTranslation(String text, StandardTextEntity standardEntity, SupportedLanguage language) {
		TextTranslationEntity translation = new TextTranslationEntity();
		translation.setText(text);
		translation.setLanguage(language);
		translation.setStandardText(standardEntity);
		standardEntity.getTranslations().add(translation);
	}
	
	@Test
	public void testStatistikVerbundenerUnternehmen() {
		// Prepare data
		// Create company in JANUARY 2016
		createOrganisationsInMonthAndYear(3, Month.JANUARY, 2016, RechtsformEnum.EINZELFIRMA);
		createOrganisationsInMonthAndYear(2, Month.JANUARY, 2016, RechtsformEnum.KOLLGES);
		createOrganisationsInMonthAndYear(1, Month.JANUARY, 2016, RechtsformEnum.AG);
		// Create company in AUGUST 2016
		createOrganisationsInMonthAndYear(5, Month.AUGUST, 2016, RechtsformEnum.KOMMGES);
		createOrganisationsInMonthAndYear(5, Month.AUGUST, 2016, RechtsformEnum.AG);	
		createOrganisationsInMonthAndYear(5, Month.AUGUST, 2016, RechtsformEnum.GMBH);
		// Create company in FEBRUARY 2017
		createOrganisationsInMonthAndYear(2, Month.FEBRUARY, 2017, RechtsformEnum.EINZELFIRMA);
		createOrganisationsInMonthAndYear(3, Month.FEBRUARY, 2017, RechtsformEnum.KOLLGES);
		createOrganisationsInMonthAndYear(4, Month.FEBRUARY, 2017, RechtsformEnum.KOMMGES);
		// Create company in JANUARY 2018
		createOrganisationsInMonthAndYear(10, Month.JANUARY, 2018, RechtsformEnum.KOMMGES);
		createOrganisationsInMonthAndYear(10, Month.JANUARY, 2018, RechtsformEnum.AG);
		createOrganisationsInMonthAndYear(10, Month.JANUARY, 2018, RechtsformEnum.GMBH);

		// Execute
		List<VerbundenerUnternehmenStatistikDto> result = admService.statistikVerbundenerUnternehmen();
		
		// Verify
		Assert.assertEquals("The expected number of month is not equal", 4, result.size());
		
		List<VerbundenerUnternehmenStatistikDto> exptectedResult = Lists.newArrayList(
			new VerbundenerUnternehmenStatistikDto("01/2016", 3, 2, 0, 1, 0),
			new VerbundenerUnternehmenStatistikDto("08/2016", 0, 0, 5, 5, 5),
			new VerbundenerUnternehmenStatistikDto("02/2017", 2, 3, 4, 0, 0),
			new VerbundenerUnternehmenStatistikDto("01/2018", 0, 0, 10, 10, 10)
			);
		
		for (int i = 0; i < exptectedResult.size(); i++) {
			VerbundenerUnternehmenStatistikDto expected = exptectedResult.get(i);
			VerbundenerUnternehmenStatistikDto actual = result.get(i);
			Assert.assertEquals("Failed for result at index = " + i, expected, actual);
		}
	}
	
	private void createOrganisationsInMonthAndYear(int numOrg, Month month, int year, RechtsformEnum rechtsform) {
		for (int i = 0; i < numOrg; i++) {
			OrganisationEntity org = new OrganisationEntity();
			org.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
			org.setCreatedTimeStamp(LocalDateTime.of(year, month, 1, 0, 0));
			org.setRechtsform(rechtsform);
			orgRepo.save(org);
		}
	}
	
	@Test
	public void testStatistikBenutzerregistrierungen() {
		// Change created date of XDG user
		UserEntity user = userRepo.findOne(QUserEntity.userEntity.eid.eq("XDG"));
		user.setCreatedTimeStamp(LocalDateTime.of(2017, Month.FEBRUARY, 1, 0, 0));
		userRepo.save(user);
		
		// Prepare data
		createUsersInMonthAndYear(3, Month.FEBRUARY, 2016);
		createUsersInMonthAndYear(10, Month.APRIL, 2016);
		createUsersInMonthAndYear(10, Month.SEPTEMBER, 2017);
		createUsersInMonthAndYear(9, Month.OCTOBER, 2017);
		createUsersInMonthAndYear(7, Month.JUNE, 2018);
		createUsersInMonthAndYear(2, Month.DECEMBER, 2018);
		
		// Execute
		List<BenutzerregistrierungenStatistikDto> result = admService.statistikBenutzerregistrierungen();
		
		// Verify
		Assert.assertEquals("The expected number of month is not equal", 7, result.size());
		
		List<BenutzerregistrierungenStatistikDto> exptectedResult = Lists.newArrayList(
			new BenutzerregistrierungenStatistikDto("02/2016", 3),
			new BenutzerregistrierungenStatistikDto("04/2016", 10),
			new BenutzerregistrierungenStatistikDto("02/2017", 1),
			new BenutzerregistrierungenStatistikDto("09/2017", 10),
			new BenutzerregistrierungenStatistikDto("10/2017", 9),
			new BenutzerregistrierungenStatistikDto("06/2018", 7),
			new BenutzerregistrierungenStatistikDto("12/2018", 2));
		
		for (int i = 0; i < exptectedResult.size(); i++) {
			BenutzerregistrierungenStatistikDto expected = exptectedResult.get(i);
			BenutzerregistrierungenStatistikDto actual = result.get(i);
			Assert.assertEquals("Failed for result at index = " + i, expected, actual);
		}
	}

	private void createUsersInMonthAndYear(int numUser, Month month, int year) {
		for (int i = 0; i < numUser; i++) {
			UserEntity user = new UserEntity();
			user.setCreatedTimeStamp(LocalDateTime.of(year, month, 1, 0, 0));
			user.setEid("user" + month + year + i);
			user.setLanguage(SupportedLanguage.DE);
			userRepo.save(user);
		}
	}
	
	/**
	 * Scenario: 1 organization EF has 1 process.
	 * Process HR: has 2 statuses
	 * ------------| Status 1: GESENDET in 01/2017.
	 * ------------| Status 2: GESCHLOSSEN in 02/2017.
	 * Expectation:
	 * ------------| 01/2017: All legal forms is 0 => there is no record in query result.
	 */
	@Test
	public void testStatistikGrundungen001() {
		// prepare test data
		UserEntity user = new UserEntity();
		user.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		user.setEid("test");
		user.setLanguage(SupportedLanguage.DE);
		user = userRepo.save(user);
		
		OrganisationEntity org = new OrganisationEntity();
		org.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		org.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		org.setRechtsform(RechtsformEnum.EINZELFIRMA);
		org = orgRepo.save(org);

		ProzessEntity prozessHr = new ProzessEntity(ProzessTypEnum.HR, true);
		prozessHr.setBearbdatum(LocalDateTime.parse("2017-02-24T10:11:30"));
		prozessHr.setStatus(ProzessStatusEnum.GESENDET);
		prozessHr.setCompleted(true);
		prozessHr.setLocked(true);
		prozessHr.setOrganisation(org);
		
		prozessRepo.save(prozessHr);
		
		StatuswechselEntity status1 = new StatuswechselEntity();
		status1.setZeitstempel(LocalDateTime.parse("2017-01-26T10:11:30"));
		status1.setStatus(ProzessStatusEnum.GESENDET);
		status1.setProzess(prozessHr);
		status1.setUser(user);
		
		StatuswechselEntity status2 = new StatuswechselEntity();
		status2.setZeitstempel(LocalDateTime.parse("2017-02-26T10:11:30"));
		status2.setStatus(ProzessStatusEnum.GESCHLOSSEN);
		status2.setProzess(prozessHr);
		status2.setUser(user);
		
		statusRepo.save(Arrays.asList(status1, status2));
		
		List<GrundungenStatistikDto> res = admService.statistikGrundungen();
		
		Assert.assertEquals(0, res.size());
	}
	
	@Test
	public void testStatistikGrundungen002() {
		// prepare test data
		UserEntity user = new UserEntity();
		user.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		user.setEid("test");
		user.setLanguage(SupportedLanguage.DE);
		user = userRepo.save(user);
		
		OrganisationEntity org = new OrganisationEntity();
		org.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		org.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		org.setRechtsform(RechtsformEnum.EINZELFIRMA);
		org = orgRepo.save(org);

		ProzessEntity org1_proEnt1 = new ProzessEntity(ProzessTypEnum.HR, true);
		org1_proEnt1.setBearbdatum(LocalDateTime.parse("2017-01-26T10:11:30"));
		org1_proEnt1.setStatus(ProzessStatusEnum.KOMPLETT);
		org1_proEnt1.setTyp(ProzessTypEnum.AHV);
		org1_proEnt1.setCompleted(true);
		org1_proEnt1.setLocked(true);
		org1_proEnt1.setOrganisation(org);
		
		ProzessEntity org1_proEnt2 = new ProzessEntity(ProzessTypEnum.HR, true);
		org1_proEnt2.setBearbdatum(LocalDateTime.parse("2017-01-26T10:11:30"));
		org1_proEnt2.setStatus(ProzessStatusEnum.KOMPLETT);
		org1_proEnt2.setTyp(ProzessTypEnum.HR);
		org1_proEnt2.setCompleted(true);
		org1_proEnt2.setLocked(true);
		org1_proEnt2.setOrganisation(org);

		prozessRepo.save(Arrays.asList(org1_proEnt1, org1_proEnt2));
		
		StatuswechselEntity org1_process1_statusEnt1 = new StatuswechselEntity();
		org1_process1_statusEnt1.setZeitstempel(LocalDateTime.parse("2017-01-26T10:11:30"));
		org1_process1_statusEnt1.setStatus(ProzessStatusEnum.KOMPLETT);
		org1_process1_statusEnt1.setProzess(org1_proEnt1);
		org1_process1_statusEnt1.setUser(user);
		
		StatuswechselEntity org1_process1_statusEnt2 = new StatuswechselEntity();
		org1_process1_statusEnt2.setZeitstempel(LocalDateTime.parse("2017-01-26T10:11:30"));
		org1_process1_statusEnt2.setStatus(ProzessStatusEnum.KOMPLETT);
		org1_process1_statusEnt2.setProzess(org1_proEnt2);
		org1_process1_statusEnt2.setUser(user);
		
		statusRepo.save(Arrays.asList(org1_process1_statusEnt1, org1_process1_statusEnt2));
		
		List<GrundungenStatistikDto> res = admService.statistikGrundungen();
		Assert.assertEquals(0, res.size());
	}
	
	/**
	 * Scenario: 1 organization AG has 1 process.
	 * Process HR:
	 * ------------| Status 1: GESENDET in 02/2017.
	 * Expectation:
	 * ------------| 02/2017: AG 1, the rest: 0.
	 */
	@Test
	public void testStatistikGrundungen003() {
		// prepare test data
		UserEntity user = new UserEntity();
		user.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		user.setEid("test");
		user.setLanguage(SupportedLanguage.DE);
		user = userRepo.save(user);
		
		OrganisationEntity org = new OrganisationEntity();
		org.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		org.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		org.setRechtsform(RechtsformEnum.AG);
		org = orgRepo.save(org);

		ProzessEntity prozessHr = new ProzessEntity(ProzessTypEnum.HR, true);
		prozessHr.setBearbdatum(LocalDateTime.parse("2017-02-24T10:11:30"));
		prozessHr.setStatus(ProzessStatusEnum.GESENDET);
		prozessHr.setCompleted(true);
		prozessHr.setLocked(true);
		prozessHr.setOrganisation(org);
		
		prozessRepo.save(prozessHr);
		
		StatuswechselEntity status1 = new StatuswechselEntity();
		status1.setZeitstempel(LocalDateTime.parse("2017-02-26T10:11:30"));
		status1.setStatus(ProzessStatusEnum.GESENDET);
		status1.setProzess(prozessHr);
		status1.setUser(user);
		
		statusRepo.save(status1);
		
		List<GrundungenStatistikDto> res = admService.statistikGrundungen();
		
		Assert.assertEquals(1, res.size());
		
		Assert.assertEquals("2017/02", res.get(0).getMonat());
		Assert.assertEquals("02/2017", res.get(0).getMonYear());
		
		Assert.assertEquals(1L, res.get(0).getAg(), 0);
		Assert.assertEquals(0L, res.get(0).getGmbh(), 0);
		Assert.assertEquals(0L, res.get(0).getKoll(), 0);
		Assert.assertEquals(0L, res.get(0).getKom(), 0);
		Assert.assertEquals(0L, res.get(0).getEf(), 0);
	}
	
	@Test
	public void testStatistikAbgeschlossenerProzesse001() {
		// prepare test data
		UserEntity user = new UserEntity();
		user.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		user.setEid("test");
		user.setLanguage(SupportedLanguage.DE);
		user = userRepo.save(user);

		OrganisationEntity org = new OrganisationEntity();
		org.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		org.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		org.setRechtsform(RechtsformEnum.AG);
		org = orgRepo.save(org);

		ProzessEntity hrProzess = new ProzessEntity(ProzessTypEnum.HR, true);
		hrProzess.setBearbdatum(LocalDateTime.parse("2017-01-26T10:11:30"));
		hrProzess.setStatus(ProzessStatusEnum.GESENDET);
		hrProzess.setCompleted(true);
		hrProzess.setLocked(true);
		hrProzess.setOrganisation(org);

		prozessRepo.save(hrProzess);

		StatuswechselEntity status = new StatuswechselEntity();
		status.setZeitstempel(LocalDateTime.parse("2017-01-27T10:11:30"));
		status.setStatus(ProzessStatusEnum.GESENDET);
		status.setProzess(hrProzess);
		status.setUser(user);

		statusRepo.save(status);

		List<AbgeschlossenerProzesseStatistikDto> res = admService.statistikAbgeschlossenerProzesse();
		Assert.assertEquals("The expected number of month: 1 and the real number of month: " + res.size() + " is not equal", 1, res.size());
		checkNumberOfProzess(Long.valueOf(1), res.get(0).getHr(), ProzessTypEnum.HR);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getAhv(), ProzessTypEnum.AHV);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwst(), ProzessTypEnum.MWST);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getUvg(), ProzessTypEnum.UVG);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwstAbmeldung(), ProzessTypEnum.MWST_ABMELDUNG);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwstAdressaenderung(), ProzessTypEnum.MWST_ADRESSAENDERUNG);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwstEintrbest(), ProzessTypEnum.MWST_EINTRBEST);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwstFristverlaengerung(), ProzessTypEnum.MWST_FRISTVERLAENGERUNG);
	}
	
	@Test
	public void testStatistikAbgeschlossenerProzesse002() {
		// prepare test data
		UserEntity user = new UserEntity();
		user.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		user.setEid("test2");
		user.setLanguage(SupportedLanguage.DE);
		user = userRepo.save(user);
		
		OrganisationEntity org = new OrganisationEntity();
		org.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		org.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		org.setRechtsform(RechtsformEnum.GMBH);
		org = orgRepo.save(org);

		ProzessEntity hrProzess = new ProzessEntity(ProzessTypEnum.HR, true);
		hrProzess.setBearbdatum(LocalDateTime.parse("2017-01-26T10:11:30"));
		hrProzess.setStatus(ProzessStatusEnum.GESENDET);
		hrProzess.setCompleted(true);
		hrProzess.setLocked(true);
		hrProzess.setOrganisation(org);
		
		ProzessEntity ahvProzess = new ProzessEntity(ProzessTypEnum.AHV, true);
		ahvProzess.setBearbdatum(LocalDateTime.parse("2016-01-26T10:11:30"));
		ahvProzess.setStatus(ProzessStatusEnum.GESENDET);
		ahvProzess.setCompleted(true);
		ahvProzess.setLocked(true);
		ahvProzess.setOrganisation(org);

		prozessRepo.save(Arrays.asList(hrProzess, ahvProzess));
		
		StatuswechselEntity statusHrProzess = new StatuswechselEntity();
		statusHrProzess.setZeitstempel(LocalDateTime.parse("2017-01-27T10:11:30"));
		statusHrProzess.setStatus(ProzessStatusEnum.GESENDET);
		statusHrProzess.setProzess(hrProzess);
		statusHrProzess.setUser(user);
		
		StatuswechselEntity statusAhvProzess = new StatuswechselEntity();
		statusAhvProzess.setZeitstempel(LocalDateTime.parse("2016-01-28T10:11:30"));
		statusAhvProzess.setStatus(ProzessStatusEnum.GESENDET);
		statusAhvProzess.setProzess(ahvProzess);
		statusAhvProzess.setUser(user);
		
		statusRepo.save(Arrays.asList(statusHrProzess, statusAhvProzess));
		// Execute
		List<AbgeschlossenerProzesseStatistikDto> res = admService.statistikAbgeschlossenerProzesse();
		// Verify
		Assert.assertEquals("The expected number of month: 2 and the real number of month: " + res.size() + " is not equal", 2, res.size());
		// JANUARY 2016
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getHr(), ProzessTypEnum.HR);
		checkNumberOfProzess(Long.valueOf(1), res.get(0).getAhv(), ProzessTypEnum.AHV);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwst(), ProzessTypEnum.MWST);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getUvg(), ProzessTypEnum.UVG);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwstAbmeldung(), ProzessTypEnum.MWST_ABMELDUNG);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwstAdressaenderung(), ProzessTypEnum.MWST_ADRESSAENDERUNG);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwstEintrbest(), ProzessTypEnum.MWST_EINTRBEST);
		checkNumberOfProzess(Long.valueOf(0), res.get(0).getMwstFristverlaengerung(), ProzessTypEnum.MWST_FRISTVERLAENGERUNG);
		// JANUARY 2017
		checkNumberOfProzess(Long.valueOf(1), res.get(1).getHr(), ProzessTypEnum.HR);
		checkNumberOfProzess(Long.valueOf(0), res.get(1).getAhv(), ProzessTypEnum.AHV);
		checkNumberOfProzess(Long.valueOf(0), res.get(1).getMwst(), ProzessTypEnum.MWST);
		checkNumberOfProzess(Long.valueOf(0), res.get(1).getUvg(), ProzessTypEnum.UVG);
		checkNumberOfProzess(Long.valueOf(0), res.get(1).getMwstAbmeldung(), ProzessTypEnum.MWST_ABMELDUNG);
		checkNumberOfProzess(Long.valueOf(0), res.get(1).getMwstAdressaenderung(), ProzessTypEnum.MWST_ADRESSAENDERUNG);
		checkNumberOfProzess(Long.valueOf(0), res.get(1).getMwstEintrbest(), ProzessTypEnum.MWST_EINTRBEST);
		checkNumberOfProzess(Long.valueOf(0), res.get(1).getMwstFristverlaengerung(), ProzessTypEnum.MWST_FRISTVERLAENGERUNG);
	}
	
	private void checkNumberOfProzess(Long expectedNumber, Long realNumber, ProzessTypEnum prozessType) {
		Assert.assertEquals("The expected number of prozess " + prozessType + " is wrong", expectedNumber, realNumber);
	}	

	@Test
	public void testStatistikBenutzerkontoBerechtigungen() {
		
		OrganisationEntity org = new OrganisationEntity();
		org.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		org.setCreatedTimeStamp(LocalDateTime.parse("2017-01-26T10:11:30"));
		org.setRechtsform(RechtsformEnum.EINZELFIRMA);
		
		ZugriffEntity zugriff = new ZugriffEntity();
		zugriff.setUser(getCurrentLoginUser());
		zugriff.setAccessLevel(AccessLevelEnum.FULL);
		zugriff.setOrganisation(org);
		zugriff.setStatus(AccessStatusEnum.GRANTED);
		zugriff.setFromDate(LocalDate.now());
		org.getZugrrifs().add(zugriff);
		
		org = orgRepo.save(org);
		
		List<BenutzerkontoBerechtigungenStatistikDto> res = admService.statistikBenutzerkontoBerechtigungen();
		Assert.assertEquals(1, res.size());
		Assert.assertEquals("1", res.get(0).getGroupName());
		Assert.assertEquals(1, res.get(0).getQuantity(), 0);
	}
	
	@Test
	public void testStatistikCSVgenerated() throws IOException {
		// Prepare data.
		Map<String, StatisticCSVDto> data = new HashMap<>();
		String recordName1 = "firmenname1";
		data.put(recordName1, new StatisticCSVDto(LocalDateTime.parse("2007-12-03T10:15:30"), 
			"empfaenger", "strasse", "hausnummer", "plz", "ort", 1200, "kanton", recordName1, RechtsformEnum.EINZELFIRMA, null, 
			true, LocalDateTime.parse("2007-12-03T10:15:30"), "OAI HA",
			true, LocalDateTime.parse("2007-12-03T10:15:30"), 
			true, LocalDateTime.parse("2007-12-03T10:15:30"), 
			true, LocalDateTime.parse("2007-12-03T10:15:30"), 
			false, null, applicationService.getBranches(Lists.newArrayList(13l, 14l))));
		
		String recordName2 = "firmenname2";
		data.put(recordName2, new StatisticCSVDto(LocalDateTime.parse("2007-12-03T10:15:30"), 
			"empfaenger", "strasse", "hausnummer", "plz", "ort", 1200, "kanton", recordName2, RechtsformEnum.KOLLGES, null, 
			false, null, null,
			false, null, 
			false, null, 
			false, null, 
			true, LocalDateTime.parse("2007-12-03T10:15:30"), applicationService.getBranches(Lists.newArrayList(13l, 14l, 18l, 29l))));
		
		String recordName3 = "firmenname3";
		data.put(recordName3, new StatisticCSVDto(LocalDateTime.parse("2018-01-03T10:15:30"), 
			"empfaenger", "strasse", null, null, "ort1", 1500, "kanton", recordName3, RechtsformEnum.KOMMGES, null, 
			false, null, null,
			true, LocalDateTime.parse("2018-01-06T10:15:30"), 
			false, null, 
			false, null, 
			true, LocalDateTime.parse("2007-12-03T10:15:30"), applicationService.getBranches(Lists.newArrayList(32l))));
		
		for (Entry<String, StatisticCSVDto> dataEntry : data.entrySet()) {
			createCSVStatistikOrganisation(dataEntry.getValue());
		}
		
		// Execute.
		FileDto file = admService.generateStatistikCSV();
			
		// Verify.
		Reader reader = new InputStreamReader(new ByteArrayInputStream(file.getData()), "UTF-8");
		CSVParser parser = new CSVParser(reader, CSVFormat.EXCEL.withHeader());

		try {
			List<CSVRecord> records = parser.getRecords();
			Assert.assertEquals("Invalid number of CSV records", data.keySet().size(), records.size());
			for (final CSVRecord record : records) {
				String name = record.get(applicationService.getTranslation(AdminService.GUI_LABELS_STATISTIK_CSV_FIRMENNAME));
				
				StatisticCSVDto csvDto = data.get(name);
				
				boolean mainProcessSent = csvDto.isHRSent() || csvDto.isAHVSent() || csvDto.isMWSTSent() || csvDto.isUVGSent();
				List<LocalDateTime> mainProcessSentDates = Lists.newArrayList();
				CollectionUtils.addIgnoreNull(mainProcessSentDates, csvDto.getHRSentDate());
				CollectionUtils.addIgnoreNull(mainProcessSentDates, csvDto.getAHVSentDate());
				CollectionUtils.addIgnoreNull(mainProcessSentDates, csvDto.getMWSTSentDate());
				CollectionUtils.addIgnoreNull(mainProcessSentDates, csvDto.getUVGSentDate());
				
				List<LocalDateTime> allProcessSentDates = new ArrayList<>(mainProcessSentDates);
				CollectionUtils.addIgnoreNull(allProcessSentDates, csvDto.getAnotherProcessSentDate());
				
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_ERSTELL_DATUM, 
					StringUtils.defaultString(OSSDateUtil.format(OSSDateUtil.toDate(csvDto.getCreatedTimeStamp()))));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_EMPFANGER, StringUtils.defaultString(csvDto.getEmpfaenger()));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_STRASSE, StringUtils.defaultString(csvDto.getStrasse()));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_NUMMER, StringUtils.defaultString(csvDto.getHausnummer()));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_PLZ, StringUtils.defaultString(csvDto.getPlz()));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_ORT, StringUtils.defaultString(csvDto.getOrt()));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_BFSNR, String.valueOf(csvDto.getBfsNr()));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_KANTON, StringUtils.defaultString(csvDto.getKanton()));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_FIRMENNAME, StringUtils.defaultString(csvDto.getFirmenname()));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_RECHTSFORM, StringUtils.defaultString(csvDto.getRechtsform().toString()));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_BERUFSBEZEICHNUNG, (csvDto.getBeruf() == null) ? "" : 
					csvDto.getBeruf().getStandardText().getTranslations()
					.stream().filter(t -> t.getLanguage() == getCurrentLoginUser().getLanguage()).findFirst().get().getText());
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_HR, BooleanUtils.toIntegerObject(csvDto.isHRSent()).toString());
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_HR_DATUM, StringUtils.defaultString(OSSDateUtil.format(OSSDateUtil.toDate(csvDto.getHRSentDate()))));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_HR_DIGITAL, csvDto.getHRDigitalSign() != null ? "1" : "0");
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_AHV, BooleanUtils.toIntegerObject(csvDto.isAHVSent()).toString());
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_AHV_DATUM, StringUtils.defaultString(OSSDateUtil.format(OSSDateUtil.toDate(csvDto.getAHVSentDate()))));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_MWST, BooleanUtils.toIntegerObject(csvDto.isMWSTSent()).toString());
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_MWST_DATUM, StringUtils.defaultString(OSSDateUtil.format(OSSDateUtil.toDate(csvDto.getMWSTSentDate()))));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_UVG, BooleanUtils.toIntegerObject(csvDto.isUVGSent()).toString());
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_UVG_DATUM, StringUtils.defaultString(OSSDateUtil.format(OSSDateUtil.toDate(csvDto.getUVGSentDate()))));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_MINDESTENS_DIENST, BooleanUtils.toIntegerObject(mainProcessSent).toString());
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_MINDESTENS_DIENST_DATUM, mainProcessSentDates.isEmpty() ? "" :
					StringUtils.defaultString(OSSDateUtil.format(OSSDateUtil.toDate(Collections.min(mainProcessSentDates)), "yyyy")));
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_MINDESTENS_PROZESS, 
					BooleanUtils.toIntegerObject(mainProcessSent || csvDto.isAnotherProcessSent()).toString());
				assertCSVRecordColumnValue(record, AdminService.GUI_LABELS_STATISTIK_CSV_MINDESTENS_PROZESS_DATUM, allProcessSentDates.isEmpty() ? "" :
					StringUtils.defaultString(OSSDateUtil.format(OSSDateUtil.toDate(Collections.min(allProcessSentDates)), "yyyy")));
		        
	        	List<BrancheEntity> childBranches = cacheService.getBranches().stream().filter(b -> b.getParent() != null).collect(Collectors.toList());
				for (BrancheEntity branche : childBranches) {
	        		String actual = record.get(branche.getStandardText().getTranslations().stream()
	        			.filter(t -> t.getLanguage() == getCurrentLoginUser().getLanguage()).findFirst().get().getText());
	        		if (csvDto.getBranches().contains(branche)) {
						Assert.assertEquals("Invalid value for branch id = " + branche.getId(), "1", actual);
	        		} else {
	        			Assert.assertEquals("Invalid value for branch id = " + branche.getId(), "0", actual);
	        		}
	        	}
		    }
		} finally {
			parser.close();
			reader.close();
		}
	}
	
	private void assertCSVRecordColumnValue(CSVRecord record, String column, String expected) {
		String translation = applicationService.getTranslation(column);
		Assert.assertEquals("Invalid value for column : " + translation, expected, record.get(translation));
	}
	
	private void createCSVStatistikOrganisation(StatisticCSVDto csvDto) {
		
		OrganisationEntity org = new OrganisationEntity();
		org.setCreatedTimeStamp(csvDto.getCreatedTimeStamp());
		org.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		org.getBranches().addAll(csvDto.getBranches());
		org.setRechtsform(csvDto.getRechtsform());
		
		FirmennameEntity name = new FirmennameEntity();
		name.setBezeichnung(csvDto.getFirmenname());
		name.setSprache(applicationService.getCodeWerts(KategorieEnum.SPRACHE).get(0));
		name.setOrganisation(org);
		org.getNamens().add(name);
		
		AdresseEntity domizil = new AdresseEntity();
		org.setDomizil(domizil);
		domizil.setEmpfaenger(csvDto.getEmpfaenger());
		domizil.setStrasse(csvDto.getStrasse());
		domizil.setHausnummer(csvDto.getHausnummer());
		domizil.setPlz(csvDto.getPlz());
		domizil.setOrt(csvDto.getOrt());
		domizil.setBfsNr(csvDto.getBfsNr());
		domizil.setKanton(csvDto.getKanton());
		
		PflichtenabklaerungenEntity pflichtenabklaerungen = new PflichtenabklaerungenEntity();
		pflichtenabklaerungen.setRechtsform(csvDto.getRechtsform());
		if (csvDto.getBeruf() != null && csvDto.getRechtsform() == RechtsformEnum.EINZELFIRMA) {
			pflichtenabklaerungen.setBeruf(csvDto.getBeruf());
		}
		org.setPflichtenabklaerungen(pflichtenabklaerungen);
		
		org = orgRepo.save(org);
		
		ProzessEntity hrProcess = createCSVOrgProccess(csvDto.isHRSent(), csvDto.getHRSentDate(), org, ProzessTypEnum.HR);
		hrProcess.setDigitalSignees(csvDto.getHRDigitalSign());
		createCSVOrgProccess(csvDto.isAHVSent(), csvDto.getAHVSentDate(), org, ProzessTypEnum.AHV);
		createCSVOrgProccess(csvDto.isMWSTSent(), csvDto.getMWSTSentDate(), org, ProzessTypEnum.MWST);
		createCSVOrgProccess(csvDto.isUVGSent(), csvDto.getUVGSentDate(), org, ProzessTypEnum.UVG);
		createCSVOrgProccess(csvDto.isAnotherProcessSent(), csvDto.getAnotherProcessSentDate(), org, ProzessTypEnum.HR_MUTATION);
	}

	private ProzessEntity createCSVOrgProccess(boolean sent, LocalDateTime sentDate, OrganisationEntity org, ProzessTypEnum prozessTypEnum) {
		ProzessEntity prozess = new ProzessEntity();
		prozess.setTyp(prozessTypEnum);
		if (sent) {
			prozess.setStatus(ProzessStatusEnum.GESENDET);
		} else {
			prozess.setStatus(ProzessStatusEnum.BEARBEITUNG);
		}
		prozess.setUid(UUID.randomUUID().toString());
		prozess.setOrganisation(org);
		
		// Original status
		StatuswechselEntity status = new StatuswechselEntity();
		status.setUser(getCurrentLoginUser());
		status.setProzess(prozess);
		status.setStatus(ProzessStatusEnum.INITIAL);
		status.setZeitstempel(sentDate);
		prozess.getStatuswechsels().add(status);
		
		// Change status
		status = new StatuswechselEntity();
		status.setProzess(prozess);
		status.setUser(getCurrentLoginUser());
		if (sent) {
			status.setStatus(ProzessStatusEnum.GESENDET);
			status.setZeitstempel(sentDate);
		} else {
			status.setStatus(ProzessStatusEnum.BEARBEITUNG);
		}
		prozess.getStatuswechsels().add(status);
		return prozessRepo.save(prozess);
	}
	
	private class StatisticCSVDto {
		private LocalDateTime createdTimeStamp; 
		private String empfaenger; 
		private String strasse; 
		private String hausnummer; 
		private String plz; 
		private String ort; 
		private int bfsNr; 
		private String kanton;
		private String firmenname; 
		private RechtsformEnum rechtsform; 
		private BerufEntity beruf; 
		private boolean HRSent; 
		private LocalDateTime HRSentDate;
		private String HRDigitalSign; 
		private boolean AHVSent; 
		private LocalDateTime AHVSentDate; 
		private boolean MWSTSent; 
		private LocalDateTime MWSTSentDate; 
		private boolean UVGSent; 
		private LocalDateTime UVGSentDate;
		private boolean anotherProcessSent; 
		private LocalDateTime anotherProcessSentDate;
		private List<BrancheEntity> branches;
		
		public StatisticCSVDto(LocalDateTime createdTimeStamp, String empfaenger, String strasse, String hausnummer,
			String plz, String ort, int bfsNr, String kanton, String firmenname, RechtsformEnum rechtsform,
			BerufEntity beruf, boolean HRSent, LocalDateTime HRSentDate, String HRDigitalSign, boolean AHVSent, LocalDateTime AHVSentDate,
			boolean MWSTSent, LocalDateTime MWSTSentDate, boolean UVGSent, LocalDateTime UVGSentDate,
			boolean anotherProcessSent, LocalDateTime anotherProcessSentDate, List<BrancheEntity> branches) {
			super();
			this.createdTimeStamp = createdTimeStamp;
			this.empfaenger = empfaenger;
			this.strasse = strasse;
			this.hausnummer = hausnummer;
			this.plz = plz;
			this.ort = ort;
			this.bfsNr = bfsNr;
			this.kanton = kanton;
			this.firmenname = firmenname;
			this.rechtsform = rechtsform;
			this.beruf = beruf;
			this.HRSent = HRSent;
			this.HRSentDate = HRSentDate;
			this.HRDigitalSign = HRDigitalSign; 
			this.AHVSent = AHVSent;
			this.AHVSentDate = AHVSentDate;
			this.MWSTSent = MWSTSent;
			this.MWSTSentDate = MWSTSentDate;
			this.UVGSent = UVGSent;
			this.UVGSentDate = UVGSentDate;
			this.anotherProcessSent = anotherProcessSent;
			this.anotherProcessSentDate = anotherProcessSentDate;
			this.branches = branches;
		}

		public LocalDateTime getCreatedTimeStamp() {
			return createdTimeStamp;
		}

		public String getEmpfaenger() {
			return empfaenger;
		}

		public String getStrasse() {
			return strasse;
		}

		public String getHausnummer() {
			return hausnummer;
		}

		public String getPlz() {
			return plz;
		}

		public String getOrt() {
			return ort;
		}

		public int getBfsNr() {
			return bfsNr;
		}

		public String getKanton() {
			return kanton;
		}

		public String getFirmenname() {
			return firmenname;
		}

		public RechtsformEnum getRechtsform() {
			return rechtsform;
		}

		public BerufEntity getBeruf() {
			return beruf;
		}

		public boolean isHRSent() {
			return HRSent;
		}

		public LocalDateTime getHRSentDate() {
			return HRSentDate;
		}

		public String getHRDigitalSign() {
			return HRDigitalSign;
		}

		public boolean isAHVSent() {
			return AHVSent;
		}

		public LocalDateTime getAHVSentDate() {
			return AHVSentDate;
		}

		public boolean isMWSTSent() {
			return MWSTSent;
		}

		public LocalDateTime getMWSTSentDate() {
			return MWSTSentDate;
		}

		public boolean isUVGSent() {
			return UVGSent;
		}

		public LocalDateTime getUVGSentDate() {
			return UVGSentDate;
		}

		public boolean isAnotherProcessSent() {
			return anotherProcessSent;
		}

		public LocalDateTime getAnotherProcessSentDate() {
			return anotherProcessSentDate;
		}

		public List<BrancheEntity> getBranches() {
			return branches;
		}
	}
}