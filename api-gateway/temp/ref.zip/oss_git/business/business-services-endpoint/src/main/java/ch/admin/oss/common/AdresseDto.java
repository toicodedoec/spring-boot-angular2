/*
 * AdresseDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import javax.validation.constraints.NotNull;

import ch.admin.oss.mwst.endpoint.MwstAbmeldungAddress;
import ch.admin.oss.mwst.endpoint.MwstEintrBestAddress;
import ch.admin.oss.organisation.endpoint.OrganisationDomizilAddress;
import ch.admin.oss.util.OSSConstants;

/**
 * @author tdm
 */
public class AdresseDto extends AbstractOSSDto {

	@NotNull(groups = {CommonAddress.class})
	private String strasse;

	@NotNull(groups = {CommonAddress.class})
	private String plz;

	@NotNull(groups = {CommonAddress.class})
	private String ort;

	@NotNull(groups={MwstEintrBestAddress.class, MwstAbmeldungAddress.class, OrganisationDomizilAddress.class})
	private String telefon;

	@NotNull(groups={MwstAbmeldungAddress.class})
	private String email;

	@NotNull(groups={UvgKontaktAdresse.class})
	private String empfaenger;

	private String hausnummer;
	private String postfach;
	private String postfachPlz;
	private String postfachOrt;
	private String mobile;
	private String fax;
	private String zusatz;
	private String polGemeinde;
	private Long organisationId;
	private String kanton;
	private CodeWertDto land;
	private Long landId;
	private int bfsNr;
	private String kontaktPerson;

	public AdresseDto() {}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getHausnummer() {
		return hausnummer;
	}

	public void setHausnummer(String hausnummer) {
		this.hausnummer = hausnummer;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getPostfach() {
		return postfach;
	}

	public void setPostfach(String postfach) {
		this.postfach = postfach;
	}

	public String getPostfachPlz() {
		return postfachPlz;
	}

	public void setPostfachPlz(String postfachPlz) {
		this.postfachPlz = postfachPlz;
	}

	public String getPostfachOrt() {
		return postfachOrt;
	}

	public void setPostfachOrt(String postfachOrt) {
		this.postfachOrt = postfachOrt;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getZusatz() {
		return zusatz;
	}

	public void setZusatz(String zusatz) {
		this.zusatz = zusatz;
	}

	public String getPolGemeinde() {
		return polGemeinde;
	}

	public void setPolGemeinde(String polGemeinde) {
		this.polGemeinde = polGemeinde;
	}

	public Long getOrganisationId() {
		return organisationId;
	}

	public void setOrganisationId(Long organisationId) {
		this.organisationId = organisationId;
	}

	public String getKanton() {
		return kanton;
	}

	public void setKanton(String kanton) {
		this.kanton = kanton;
	}

	public CodeWertDto getLand() {
		return land;
	}

	public void setLand(CodeWertDto land) {
		this.land = land;
	}

	public int getBfsNr() {
		return bfsNr;
	}

	public void setBfsNr(int bfsNr) {
		this.bfsNr = bfsNr;
	}

	public void setSwissAddress(boolean value) {
		// does nothing;
	}

	public boolean isSwissAddress() {
		if (land != null) {
			return OSSConstants.SWISS_CODE_WERT.equals(land.getCode());
		}
		return false;
	}

	public String getEmpfaenger() {
		return empfaenger;
	}

	public void setEmpfaenger(String empfaenger) {
		this.empfaenger = empfaenger;
	}

	public String getKontaktPerson() {
		return kontaktPerson;
	}

	public void setKontaktPerson(String kontaktPerson) {
		this.kontaktPerson = kontaktPerson;
	}

	public Long getLandId() {
		return landId;
	}

	public void setLandId(Long landId) {
		this.landId = landId;
	}

}
