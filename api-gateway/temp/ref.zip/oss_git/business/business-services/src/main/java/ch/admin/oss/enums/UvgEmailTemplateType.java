/*
 * UvgEmailTemplateType
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.enums;

import ch.admin.oss.common.SupportedLanguage;

/**
 * @author hha
 */
public enum UvgEmailTemplateType {

	SUVA("suva-mail-template"),
	OFFER("private-offer-mail-template"),
	CONTRACT("private-contract-mail-template");

	private String filename;

	private UvgEmailTemplateType(String filename) {
		this.filename = filename;
	}

	public String getFilePath(SupportedLanguage language) {
		return "uvg/" + filename + "_" + language.name().toLowerCase() + ".ftl";
	}

}
