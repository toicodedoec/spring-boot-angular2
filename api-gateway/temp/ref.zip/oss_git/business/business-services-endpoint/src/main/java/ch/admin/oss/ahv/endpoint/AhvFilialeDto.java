/*
 * AhvFilialeDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.ahv.endpoint;

import java.math.BigDecimal;
import java.util.Date;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.organisation.endpoint.GeschaeftsstellenDto;

/**
 * @author hhg
 *
 */
public class AhvFilialeDto extends AbstractOSSDto {

	private Long angestellte;
	private BigDecimal lohnSumme;
	private Date seit;
	private GeschaeftsstellenDto geschaeftsstelle;

	public Long getAngestellte() {
		return angestellte;
	}

	public void setAngestellte(Long angestellte) {
		this.angestellte = angestellte;
	}

	public BigDecimal getLohnSumme() {
		return lohnSumme;
	}
	
	public void setLohnSumme(BigDecimal lohnSumme) {
		this.lohnSumme = lohnSumme;
	}
	
	public Date getSeit() {
		return seit;
	}

	public void setSeit(Date seit) {
		this.seit = seit;
	}

	public GeschaeftsstellenDto getGeschaeftsstelle() {
		return geschaeftsstelle;
	}

	public void setGeschaeftsstelle(GeschaeftsstellenDto geschaeftsstelle) {
		this.geschaeftsstelle = geschaeftsstelle;
	}
}