/*
 * ZugriffEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import ch.admin.oss.common.enums.AccessLevelEnum;
import ch.admin.oss.common.enums.AccessStatusEnum;

/**
 * @author coh
 */
@Audited
@Entity
@Table(name = "T_ZUGRIFF", 
	uniqueConstraints = {
		@UniqueConstraint(name = "UK_ZUGRIFF_USER_ORG", columnNames = {"LN_USER", "LN_ORGANISATION"}) 
	})
public class ZugriffEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_USER", foreignKey = @ForeignKey(name = "FK_ZUGRIFF_USER"))
	private UserEntity user;

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name = "FK_ZUGRIFF_ORGANISATION"))
	private OrganisationEntity organisation;

	@NotNull
	@Column(name = "ACCESS_LEVEL")
	@Enumerated(EnumType.STRING)
	private AccessLevelEnum accessLevel;

	@NotNull
	@Column(name = "STATUS")
	@Enumerated(EnumType.STRING)
	private AccessStatusEnum status;
	
	@Column(name = "FROM_DATE")
	private LocalDate fromDate;

	@Column(name = "TO_DATE")
	private LocalDate toDate;

	@AssertTrue
	public boolean isEndDateAfterStartDate() {
		if(this.toDate != null && this.fromDate != null) {
			if(this.toDate.isBefore(this.fromDate)) {
				return false;
			}
			return true;
		}
		return true;
	}
	
	public UserEntity getUser() {
		return user;
	}

	public void setUser(UserEntity user) {
		this.user = user;
	}

	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public AccessLevelEnum getAccessLevel() {
		return accessLevel;
	}

	public void setAccessLevel(AccessLevelEnum accessLevel) {
		this.accessLevel = accessLevel;
	}

	public AccessStatusEnum getStatus() {
		return status;
	}

	public void setStatus(AccessStatusEnum status) {
		this.status = status;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	@Transient
	public String getEid() {
		return user.getEid();
	}

	public long getOrgId(){
		return this.organisation.getId();
	}

	@AssertTrue
	public boolean toDateInTheFuture() {
		return getToDate() == null || getToDate().isAfter(LocalDate.now());
	}
}
