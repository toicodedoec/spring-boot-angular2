/*
 * AbstractOSSTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.stream.Collectors;

import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.application.service.ICacheService;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.FunktionEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.QUserEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.portal.repository.IUserRepository;
import ch.admin.oss.security.AuthorizedOrganisation;
import ch.admin.oss.security.AuthorizedPermission;
import ch.admin.oss.security.OssRole;
import ch.admin.oss.security.OssUser;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OSSDateUtil;

/**
 * @author coh
 *
 */
public class AbstractOSSTest {
	
	private static final String TEST_USER_EID = "XDG";
	
	@Autowired
	protected IApplicationService applicationService;
	
	@Autowired
	protected ICacheService cacheService;
	
	@Autowired
	protected IUserRepository userRepo;

	@Before
	public void beforeMethod() {
		UserEntity userEnt = new UserEntity();
		userEnt.setEid(TEST_USER_EID);
		userEnt.setLanguage(SupportedLanguage.EN);
		userEnt.setCreatedTimeStamp(LocalDateTime.now());
		userEnt = userRepo.saveAndFlush(userEnt);
		
		OssUser user = new OssUser(userEnt.getId(), userEnt.getEid(), Arrays.asList(OssRole.values()).stream()
			.map(role -> new SimpleGrantedAuthority(role.name())).collect(Collectors.toList()), SupportedLanguage.EN,
			new HashSet<>(), new HashSet<>(Arrays.asList(FunktionEnum.values())), "xdg@elca.vn", false, "Doan", "Nguyen");
		SecurityContextHolder.getContext()
			.setAuthentication(new PreAuthenticatedAuthenticationToken(user, "N/A", user.getAuthorities()));
	}
	
	protected UserEntity getCurrentLoginUser() {
		return userRepo.findOne(QUserEntity.userEntity.eid.eq(TEST_USER_EID));
	}
	
	protected CodeWertEntity getSwissLand() {
		return applicationService.getCodeWerts(KategorieEnum.LAND).stream()
			.filter(c -> ((CodeWertEntity)c).getCode().equals(OSSConstants.SWISS_CODE_WERT)).findFirst().get();
	}
	
	protected void addUserAuthorizedCompany(String defaultOrgName, OrganisationEntity organisationEntity) {
		OssUser user = SecurityUtil.currentUser();
		ZugriffEntity zugriff = organisationEntity.getZugrrifs().iterator().next();
		user.addAuthorizedCompany(
			new AuthorizedOrganisation(zugriff.getUser().getEid(), 
					zugriff.getOrganisation().getId(),
					organisationEntity.getDomizil().getId(),
					defaultOrgName,
				new AuthorizedPermission(zugriff.getAccessLevel(), zugriff.getStatus(),
					OSSDateUtil.toDate(zugriff.getFromDate()),
					OSSDateUtil.toDate(zugriff.getToDate()))));
		SecurityUtil.updateCurrentUser(user);
	}
}
