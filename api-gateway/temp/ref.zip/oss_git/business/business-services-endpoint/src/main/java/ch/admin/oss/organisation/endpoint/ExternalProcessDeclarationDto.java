/*
 * ExternalProcessDeclarationDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import ch.admin.oss.common.AbstractOSSDto;

/**
 * @author tdm
 */
public class ExternalProcessDeclarationDto extends AbstractOSSDto {

	private long orgId;
	private boolean anmeldungHR;
	private boolean anmeldungMWST;
	private boolean anmeldungAHV;
	private boolean anmeldungUVG;

	private boolean hrFinish = false;
	private boolean mwstFinish = false;
	private boolean ahvFinish = false;
	private boolean uvgFinish = false;

	public boolean isAnmeldungHR() {
		return anmeldungHR;
	}

	public void setAnmeldungHR(boolean anmeldungHR) {
		this.anmeldungHR = anmeldungHR;
	}

	public boolean isAnmeldungMWST() {
		return anmeldungMWST;
	}

	public void setAnmeldungMWST(boolean anmeldungMWST) {
		this.anmeldungMWST = anmeldungMWST;
	}

	public boolean isAnmeldungAHV() {
		return anmeldungAHV;
	}

	public void setAnmeldungAHV(boolean anmeldungAHV) {
		this.anmeldungAHV = anmeldungAHV;
	}

	public boolean isAnmeldungUVG() {
		return anmeldungUVG;
	}

	public void setAnmeldungUVG(boolean anmeldungUVG) {
		this.anmeldungUVG = anmeldungUVG;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public boolean isHrFinish() {
		return hrFinish;
	}

	public void setHrFinish(boolean hrFinish) {
		this.hrFinish = hrFinish;
	}

	public boolean isMwstFinish() {
		return mwstFinish;
	}

	public void setMwstFinish(boolean mwstFinish) {
		this.mwstFinish = mwstFinish;
	}

	public boolean isAhvFinish() {
		return ahvFinish;
	}

	public void setAhvFinish(boolean ahvFinish) {
		this.ahvFinish = ahvFinish;
	}

	public boolean isUvgFinish() {
		return uvgFinish;
	}

	public void setUvgFinish(boolean uvgFinish) {
		this.uvgFinish = uvgFinish;
	}

}
