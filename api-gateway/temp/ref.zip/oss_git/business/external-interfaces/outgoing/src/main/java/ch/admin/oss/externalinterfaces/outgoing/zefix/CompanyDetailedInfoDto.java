/*
 * CompanyDetailedInfoDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

import java.io.Serializable;

import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author hhg
 *
 */
public class CompanyDetailedInfoDto implements Serializable {

	private static final long serialVersionUID = 8849988355656208878L;

	private String name;
	private String chid;
	private Integer uid;
	private int legalSeatId;
	private String legalSeat;
	private String purpose;
	private AddressInformationDto address;
	private ShabPubDto shabPub;
	private RechtsformEnum rechtsform;
	
	public CompanyDetailedInfoDto() {
		// default constructor
	}
	
	public CompanyDetailedInfoDto(String name, String chid, String uid, String legalSeat) {
		this.name = name;
		this.chid = chid;
		this.uid = Integer.parseInt(uid);
		this.legalSeat = legalSeat;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getChid() {
		return chid;
	}
	
	public void setChid(String chid) {
		this.chid = chid;
	}
	
	public Integer getUid() {
		return uid;
	}
	
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	
	public int getLegalSeatId() {
		return legalSeatId;
	}
	
	public void setLegalSeatId(int legalSeatId) {
		this.legalSeatId = legalSeatId;
	}
	
	public String getLegalSeat() {
		return legalSeat;
	}
	
	public void setLegalSeat(String legalSeat) {
		this.legalSeat = legalSeat;
	}
	
	public String getPurpose() {
		return purpose;
	}
	
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	
	public AddressInformationDto getAddress() {
		return address;
	}
	
	public void setAddress(AddressInformationDto address) {
		this.address = address;
	}
	
	public ShabPubDto getShabPub() {
		return shabPub;
	}

	public void setShabPub(ShabPubDto shabPub) {
		this.shabPub = shabPub;
	}
	
	public void setChidFormatted(String value) {
	}
	
	public void setUidFormatted(String value) {
	}
	
	public String getChidFormatted() {
		return OssNumberFormatUtil.formatChid(chid);
	}
	
	public String getUidFormatted() {
		return OssNumberFormatUtil.formatUid(uid);
	}

	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}
}
