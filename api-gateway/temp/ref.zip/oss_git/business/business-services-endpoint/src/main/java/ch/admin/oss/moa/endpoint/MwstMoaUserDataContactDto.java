package ch.admin.oss.moa.endpoint;

public class MwstMoaUserDataContactDto {

	private MwstMoaUserDataCorporatorPersonDto person;

	private MwstMoaUserDataCorporatorAddressDto address;

	public MwstMoaUserDataContactDto() {
	}

	public MwstMoaUserDataCorporatorPersonDto getPerson() {
		return person;
	}

	public void setPerson(MwstMoaUserDataCorporatorPersonDto person) {
		this.person = person;
	}

	public MwstMoaUserDataCorporatorAddressDto getAddress() {
		return address;
	}

	public void setAddress(MwstMoaUserDataCorporatorAddressDto address) {
		this.address = address;
	}

}
