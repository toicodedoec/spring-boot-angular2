/*
 * OrganisationServiceEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.groups.Default;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ch.admin.oss.ahv.endpoint.KontoDto;
import ch.admin.oss.application.service.IMigrationService;
import ch.admin.oss.common.AbstractOSSEndpoint;
import ch.admin.oss.common.CommonAddress;
import ch.admin.oss.common.ExceptionHandlingController;
import ch.admin.oss.common.GeschaftsrolleDto;
import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.OwnerInfoDto;
import ch.admin.oss.common.PersonDto;
import ch.admin.oss.common.ZefixErrorEnum;
import ch.admin.oss.common.dto.DigitalSignatureDto;
import ch.admin.oss.common.dto.ExistingOrgSearchResultDto;
import ch.admin.oss.common.dto.PersonResultDto;
import ch.admin.oss.common.enums.CheckCompanyNameSourceEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.KontotypEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.EinladungEntity;
import ch.admin.oss.domain.GeschaeftsstelleEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.KommGesEntity;
import ch.admin.oss.domain.KontoEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PersonHeimatortEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.QKommFirmaEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.StartBizDataEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.exception.EinladungNotFoundException;
import ch.admin.oss.externalinterfaces.outgoing.swissreg.ISwissregServiceAdapter;
import ch.admin.oss.externalinterfaces.outgoing.swissreg.SwissregBusinessException;
import ch.admin.oss.externalinterfaces.outgoing.swissreg.TmtransDto;
import ch.admin.oss.externalinterfaces.outgoing.whois.IWHOISWebservice;
import ch.admin.oss.externalinterfaces.outgoing.whois.WHOISCheckResultEnum;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyDetailedInfoDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyShortInfoDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.DetailledResponseDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.IZefixServiceAdapter;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ShortResponseDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixBusinessException;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixInvalidCHIdException;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixInvalidUIDException;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixTooManyResultsException;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixTooShortNameException;
import ch.admin.oss.hr.endpoint.HrAmtDto;
import ch.admin.oss.organisation.service.CheckNameResult;
import ch.admin.oss.organisation.service.IOrganisationService;
import ch.admin.oss.portal.endpoint.BerufDto;
import ch.admin.oss.portal.endpoint.BrancheDto;
import ch.admin.oss.portal.endpoint.PflichtenabklaerungenDto;
import ch.admin.oss.portal.service.IPortalService;
import ch.admin.oss.security.AuthorizedOrganisation;
import ch.admin.oss.security.AuthorizedPermission;
import ch.admin.oss.security.OssUser;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OSSDateUtil;
import ch.admin.oss.util.ValidationUtil;

/**
 * @author xdg
 */
@CrossOrigin("*")
@RestController
@RequestMapping("/private/ext/organisation")
public class OrganisationServiceEndpoint extends AbstractOSSEndpoint {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(OrganisationServiceEndpoint.class);
	
	// Dozer map ID
	public static final String PORTAL_PFLICHTENABKLAERUNGEN = "PFLICHTENABKLAERUNGEN";
	public static final String ORG_ORGANISATION = "ORGANISATION";
	public static final String ORGANISATION_PFLICHTENABKLAERUNGEN = "ORGANISATION_PFLICHTENABKLAERUNGEN";
	public static final String ENTERPRISE_ZUGRIFF = "EDIT_ZUGRIFF";

	@Autowired
	private IOrganisationService organisationService;

	@Autowired
	private IPortalService portalService;
	
	@Autowired
	private IMigrationService migrationService;

	@Autowired
	private IWHOISWebservice whoisWebservice;
	
	@Autowired
	private ISwissregServiceAdapter swissregServiceAdapter;
	
	@Autowired
	private IZefixServiceAdapter zefixServiceAdapter;
	
	@Value("${invitation.fromEmailAddress}")
	private String fromEmailAddress;
	
	@Value("${oss.security.eiam.loginURL}")
	private String eiamLoginURL;

	@Value("${oss.invitation.periodDateValid}")
	private int periodDateValid;
	
	@Value("${oss.dashboard.pageSize.company}")
	private Long pageSizeCompany;
	
	@RequestMapping(value = "validAhvNumber", method = RequestMethod.GET)
	public boolean validAhvNumber(@RequestParam String ahvNumber, @RequestParam String geburtsdatum, @RequestParam String anrede) {
		LocalDate geburtsdatumObj = LocalDate.parse(geburtsdatum,
			DateTimeFormatter.ofPattern(OSSConstants.DATE_FORMAT));
		return ValidationUtil.isValidAhvNumber(ahvNumber, geburtsdatumObj, OSSConstants.ANDERE_MR_CODE.equals(anrede));
	}
	
	@RequestMapping(value = "/saveOrganisationFromCratch", method = RequestMethod.POST)
	public Long saveOrganisationFromCratch(@RequestBody OrganisationCratchDto dto) {
		Validate.notNull(dto.getOrgName(), "The organisation name must not be NULL");
		
		OrganisationEntity organization = organisationService.createOrganisationFromScratch(dto.getOrgName(), dto.isConnectToDuty());
		
		ZugriffEntity zugriff = organization.getZugrrifs().iterator().next();
		
		OssUser user = SecurityUtil.currentUser();
		user.addAuthorizedCompany(
			new AuthorizedOrganisation(zugriff.getUser().getEid(), 
					zugriff.getOrganisation().getId(),
					organization.getDomizil().getId(),
					dto.getOrgName(),
				new AuthorizedPermission(zugriff.getAccessLevel(), zugriff.getStatus(),
					OSSDateUtil.toDate(zugriff.getFromDate()),
					OSSDateUtil.toDate(zugriff.getToDate()))));
		SecurityUtil.updateCurrentUser(user);
		return zugriff.getOrganisation().getId();
	}
	
	@RequestMapping(value = "/existedCod", method = RequestMethod.GET)
	public boolean checkCodExist() {
		return organisationService.countCodOfUser() > 0;
	}

	@RequestMapping(value = "/invitationEmail/{orgId}", method = RequestMethod.GET)
	public ResponseEntity<List<EinladungDto>> getInvitationEmail(@PathVariable("orgId") Long orgId) {
		return ResponseEntity.ok(organisationService.getAllEinladungOfOrganisation(orgId).stream()
			.map(einladung -> mapper.map(einladung, EinladungDto.class)).collect(Collectors.toList()));
	}

	@RequestMapping(value = "/invitationEmail", method = RequestMethod.PUT)
	public ResponseEntity<?> sendInvitationEmail(@RequestBody @Valid EinladungDto einladunDto) {
		OrganisationEntity organisation = organisationService.getOrganisation(einladunDto.getOrgId());
		
		UserEntity userEntity = portalService.findUserByName(SecurityUtil.currentUser().getUsername());
		
		// mapping dto to entity
		EinladungEntity einladungEntity = new EinladungEntity();
		mapper.map(einladunDto, einladungEntity);
		
		einladungEntity.setAusgestellt(OSSDateUtil.toLocalDate(new Date()));
		einladungEntity.setAblauf(OSSDateUtil.toLocalDate(DateUtils.addDays(new Date(), periodDateValid)));
		einladungEntity.setEinladungsCode(UUID.randomUUID().toString());
		einladungEntity.setOrganisation(organisation);
		einladungEntity.setEinladender(userEntity);
		
		einladungEntity = organisationService.saveEinladung(einladunDto.getOrgId(), einladungEntity, fromEmailAddress,
			getServiceRootUrl() + "/" + eiamLoginURL);
		
		return ResponseEntity.ok(mapper.map(einladungEntity, EinladungDto.class));
	}

	@RequestMapping(value = "invitation/{einladungId}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteInvitation(@RequestParam("orgId") int orgId, @RequestParam("einladungVer") int version,
		@PathVariable("einladungId") long id) {
		EinladungEntity einladung = organisationService.findEinladungByIdAndOrgId(orgId, id);
		if (einladung == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor(EinladungNotFoundException.class.getSimpleName()));
		}
		einladung.setVersion(version);
		organisationService.deleteEinladung(einladung);
		return ResponseEntity.ok("{ \"message\": \"ok\"}");
	}

	@RequestMapping(value = "userAccesses", method = RequestMethod.PUT)
	public ResponseEntity<?> updateZugriff(@RequestBody @Valid ZugriffDto zugriffDto) {
		ZugriffEntity zugriffEntity = organisationService.findZugriffByIdAndOrgId(zugriffDto.getOrgId(),
			zugriffDto.getId());
		if (zugriffEntity == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Can not find user"));
		}
		mapper.map(zugriffDto, zugriffEntity, ENTERPRISE_ZUGRIFF);
		organisationService.updateZugriff(zugriffEntity);
		return ResponseEntity.ok(zugriffDto);
	}

	@RequestMapping(value = "userAccesses/{orgId}", method = RequestMethod.GET)
	public ResponseEntity<List<ZugriffDto>> getAllZugriffOfOrganisation(@PathVariable("orgId") Long orgId) {

		return ResponseEntity.ok(organisationService.getAllZugriffOfOrganisation(orgId).stream()
			.map(zugriff -> mapper.map(zugriff, ZugriffDto.class)).collect(Collectors.toList()));
	}

	@RequestMapping(value = "userAccesses/{zugriffId}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteUserOfOrganisation(@RequestParam("orgId") int orgId,
		@RequestParam("zugriffVer") int version, @PathVariable("zugriffId") long id) {
		ZugriffEntity zugriffEntity = organisationService.findZugriffByIdAndOrgId(orgId, id);
		if (zugriffEntity == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Can not find user"));
		}
		zugriffEntity.setVersion(version);
		organisationService.deleteUserOforganisation(zugriffEntity);
		return ResponseEntity.ok("{ \"message\": \"ok\"}");
	}
	
	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public OrganisationDto organisation(@PathVariable long id) {
		OrganisationDto result = new OrganisationDto();

		OrganisationEntity organisation = organisationService.loadOrganisationForEDC(id);
		organisation.setGeschaeftsrollens(organisationService.loadEDCRollen(id));
		if (RechtsformEnum.KOMMGES == organisation.getRechtsform()) {
			organisation.setKommGes(organisationService.loadEDCKommGes(id));
		}
		mapper.map(organisation, result);
		
		if (result.getGeschaeftsjahrEnd() == null) {
			final int lastDateOfDecember = 31;
			result.setGeschaeftsjahrEnd(new Date(new Date().getYear(), Calendar.DECEMBER, lastDateOfDecember));
		}
		if (CollectionUtils.isNotEmpty(organisation.getBranches())) {
			result.setBranches(organisation.getBranches().stream()
				.map(b -> new BrancheDto(b, SecurityUtil.currentUser().getLanguagePreference()))
				.collect(Collectors.toList()));
		}
		
		if (result.getPflichtenabklaerungen() == null) {
			PflichtenabklaerungenEntity userPflichtenabklaerungen = portalService
				.findPflichtenabklaerungenByUsername(SecurityUtil.currentUser().getUsername());
			if (userPflichtenabklaerungen != null) {
				result.setUserPflichtenabklaerungen(
					mapper.map(userPflichtenabklaerungen, PflichtenabklaerungenDto.class));
				result.getUserPflichtenabklaerungen()
					.setBranches(userPflichtenabklaerungen.getBranches().stream()
						.map(b -> new BrancheDto(b, SecurityUtil.currentUser().getLanguagePreference()))
						.collect(Collectors.toList()));
			}
		}
		
		if(organisation.getPflichtenabklaerungen() != null) {
			if (organisation.getPflichtenabklaerungen().getBeruf() != null) {
				result.getPflichtenabklaerungen().setBeruf(new BerufDto(organisation.getPflichtenabklaerungen().getBeruf(), SecurityUtil.currentUser().getLanguagePreference()));
			}
			
			if (CollectionUtils.isNotEmpty(organisation.getPflichtenabklaerungen().getBranches())) {
				result.getPflichtenabklaerungen().setBranches(organisation.getPflichtenabklaerungen().getBranches().stream()
					.map(b -> new BrancheDto(b, SecurityUtil.currentUser().getLanguagePreference()))
					.collect(Collectors.toList()));
			}
		}
		
		result.setImportData(importHRRegistrationFromZefix(organisation, getDefaultName(result).getBezeichnung(),
			result.getUid(), result.getChNr(), result.getDomizil() == null ? null : result.getDomizil().getPolGemeinde(), 
				organisation.getRechtsform()));
		return result;
	}
	
	private FirmennameDto getDefaultName(OrganisationDto organisation) {
		Optional<FirmennameDto> name = organisation.getNamens().stream()
			.filter(item -> item.isDefault())
			.findFirst();
		return name.isPresent() ? name.get() : new FirmennameDto(); 
	}
	
	@RequestMapping(value = "pflichtenabklaerungen", method = RequestMethod.PUT)
	public ResponseEntity<?> pflichtenabklaerungen(@RequestBody PflichtenabklaerungenDto pflich) {
		PflichtenabklaerungenEntity pflichtenabklaerungenEntity = portalService
			.findPflichtenabklaerungenByUsername(SecurityUtil.currentUser().getUsername());
		return linkPflichToOrg(pflich, pflichtenabklaerungenEntity);
	}
	
	@RequestMapping(value = "pflichtenabklaerungenCreation", method = RequestMethod.PUT)
	public ResponseEntity<?> createPflichtenabklaerungen(@RequestBody PflichtenabklaerungenDto pflich) {
		PflichtenabklaerungenEntity pflichtenabklaerungenEntity = new PflichtenabklaerungenEntity();
		mapper.map(pflich, pflichtenabklaerungenEntity, PORTAL_PFLICHTENABKLAERUNGEN);
		return linkPflichToOrg(pflich, pflichtenabklaerungenEntity);
	}
	
	private ResponseEntity<?> linkPflichToOrg(PflichtenabklaerungenDto pflich,
		PflichtenabklaerungenEntity pflichtenabklaerungenEntity) {
		Validate.notNull(pflich.getOrgId());
		OrganisationEntity organisationEntity = organisationService
			.getOrganisationForPflichtenabklaerungen(pflich.getOrgId());

		pflichtenabklaerungenEntity.setOrganisation(organisationEntity);
		pflichtenabklaerungenEntity.setUser(null);
		organisationEntity.setPflichtenabklaerungen(pflichtenabklaerungenEntity);

		return ResponseEntity
			.ok(mapper.map(organisationService.updateOrganisation(organisationEntity), OrganisationDto.class));
	}
	
	@RequestMapping(value = "rechtsform", method = RequestMethod.PUT)
	public ResponseEntity<?> rechtsform(@RequestBody PflichtenabklaerungenDto pflich) {
		Validate.notNull(pflich.getOrgId());
		OrganisationEntity organisationEntity = organisationService.getOrganisation(pflich.getOrgId());

		PflichtenabklaerungenEntity pflichtenabklaerungenEntity = portalService
			.findPflichtenabklaerungenByOrganisation(pflich.getOrgId());
		
		organisationEntity.setRechtsform(pflichtenabklaerungenEntity.getRechtsform());
		Set<BrancheEntity> branches = pflichtenabklaerungenEntity.getBranches();
		organisationEntity.setBranches(new HashSet<>(branches));
		
		if (pflichtenabklaerungenEntity.getRechtsform() == RechtsformEnum.KOMMGES) {
			KommGesEntity kommGesEntity = new KommGesEntity();
			kommGesEntity.setOrganisation(organisationEntity);
			organisationEntity.setKommGes(kommGesEntity);
		}
		
		OrganisationDto dto = mapper.map(organisationService.confirmRechsform(organisationEntity), OrganisationDto.class);
		
		dto.setBranches(organisationEntity.getBranches().stream()
			.map(b -> new BrancheDto(b, SecurityUtil.currentUser().getLanguagePreference()))
			.collect(Collectors.toList()));
		
		return ResponseEntity.ok(dto);
	}
	
	@RequestMapping(method = RequestMethod.PUT)
	public ResponseEntity<OrganisationDto> organisation(@RequestBody OrganisationDto dto) {
		OrganisationEntity entity = updateOrganisation(dto);
		entity = organisationService.updateOrganisation(entity);
		mapper.map(entity, dto);

		updateAuthorizedOrganisation(dto);

		return ResponseEntity.ok(dto);
	}
	
	@RequestMapping(value="ecd/interrupt", method = RequestMethod.PUT)
	public ResponseEntity<OrganisationDto> interruptEcdFlow(@RequestBody OrganisationDto dto) {
		OrganisationEntity entity = updateOrganisation(dto);
		entity = organisationService.updateOrganisation(entity);
		mapper.map(entity, dto);

		updateAuthorizedOrganisation(dto);

		return ResponseEntity.ok(dto);
	}

	private void updateAuthorizedOrganisation(OrganisationDto dto) {
		OssUser ossUser = SecurityUtil.currentUser();
		for (AuthorizedOrganisation authorizedOrganisation : ossUser.getAuthorizedCompanies()) {
			if (authorizedOrganisation.getOrgId().equals(dto.getId())) {
				authorizedOrganisation.setDefaultOrgName(getDefaultName(dto).getBezeichnung());
				authorizedOrganisation.setUidFormatted(OssNumberFormatUtil.formatUid(dto.getUid()));
			}
		}
		SecurityUtil.updateCurrentUser(ossUser);
	}

	public OrganisationEntity updateOrganisation(OrganisationDto dto) {
		OrganisationEntity entity = new OrganisationEntity();
		entity = organisationService.getOrganisation(dto.getId(), 
			QOrganisationEntity.organisationEntity.branches, 
			QOrganisationEntity.organisationEntity.domizil,
			QOrganisationEntity.organisationEntity.namens,
			QOrganisationEntity.organisationEntity.flowHistory.items.any().data
		);
		
		mapper.map(dto, entity, ORG_ORGANISATION);
		
		if(dto.getDomizil() != null) {
			entity.getDomizil().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
			entity.getDomizil().setKanton(findKanton(dto.getDomizil().getBfsNr(), dto.getDomizil().getOrt(), dto.getDomizil().getPolGemeinde()));
		}
		// TODO [COH / S9] To refactor.
		entity.getBranches().clear();
		if (CollectionUtils.isNotEmpty(dto.getBranches())) {
			List<Long> brancheIds = dto.getBranches().stream().mapToLong(b -> b.getId()).boxed()
				.collect(Collectors.toList());
			entity.getBranches().addAll(applicationService.getBranches(brancheIds));
		}
		entity.updateDefaultName(getDefaultName(dto).getBezeichnung());
		return entity;
	}

	private String findKanton(int bfsNr, String ort, String polGemeinde) {
		Optional<CHOrtEntity> chOrt = cacheService.getCHOrts().stream()
			.filter(o -> (bfsNr == o.getBfsnr() || o.getOrt().equals(ort)) && o.getPolGemeinde().equals(polGemeinde))
			.findFirst();
		if (chOrt.isPresent()) {
			return chOrt.get().getKanton();
		}
		return null;
	}

	@PutMapping("validation")
	public ResponseEntity<OrganisationDto> saveOrganisationWithValidation(@RequestBody
		@Validated({CommonAddress.class, OrganisationDomizilAddress.class, Default.class})
		OrganisationDto dto) {
		OrganisationEntity entity = updateOrganisation(dto);
		entity.setBaseDataComplete(true);
		entity = organisationService.saveCompletedOrganisationWithValidation(entity);
		mapper.map(entity, dto);
		return ResponseEntity.ok(dto);
	}

	@PutMapping("geschaeftsstellen")
	public ResponseEntity<GeschaeftsstellenDto> geschaeftsstellen(@RequestBody
		@Validated(CommonAddress.class)
		GeschaeftsstellenDto geschaeftsstellenDto) {

		GeschaeftsstelleEntity geschaeftsstellenEntity = new GeschaeftsstelleEntity();
		if (geschaeftsstellenDto.getId() != null) {
			geschaeftsstellenEntity = organisationService
				.findGeschaeftsstellenByIdAndOrgId(geschaeftsstellenDto.getOrgId(), geschaeftsstellenDto.getId());
		}
		mapper.map(geschaeftsstellenDto, geschaeftsstellenEntity);
		geschaeftsstellenEntity.getAdresse().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
		OrganisationEntity organisation = organisationService.getOrganisation(geschaeftsstellenDto.getOrgId());
		geschaeftsstellenEntity = organisationService.saveGeschaeftsstellen(organisation, geschaeftsstellenEntity);
		return ResponseEntity.ok(mapper.map(geschaeftsstellenEntity, GeschaeftsstellenDto.class));
	}
	
	@RequestMapping(value = "geschaeftsstellen", method = RequestMethod.DELETE)
	public ResponseEntity<?> geschaeftsstellen(@RequestParam("orgId") int orgId,
		@RequestParam("geschaeftsstellenVer") int version, @RequestParam("geschaeftsstellenId") long id) {
		GeschaeftsstelleEntity geschaeftsstelleEntity = organisationService.findGeschaeftsstellenByIdAndOrgId(orgId, id, version);
		if (geschaeftsstelleEntity == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Can not find geschaeftsstelle"));
		}
		organisationService.deleteGeschaeftsstellen(orgId, geschaeftsstelleEntity);
		return ResponseEntity.ok("{ \"message\": \"ok\"}");
	}
	
	@RequestMapping(value = "/legalPartnerInfo", method = RequestMethod.PUT)
	public PersonResultDto<LegalPartnerInfoDto, OrganisationDto> saveLegalPartnerInfo(@RequestBody LegalPartnerInfoDto legalPartnerInfoDto) {
		KommFirmaDto kommFirmaDto = legalPartnerInfoDto.getLegalPartner();

		KommFirmaEntity kommFirmaEntity = new KommFirmaEntity();
		if (kommFirmaDto.getId() != null) {
			kommFirmaEntity = organisationService.getKommFirma(kommFirmaDto.getId(), QKommFirmaEntity.kommFirmaEntity.domizil);
		} else {
			kommFirmaEntity.setKommges(organisationService.loadEDCKommGes(legalPartnerInfoDto.getOrgId()));
		}
		mapper.map(kommFirmaDto, kommFirmaEntity);
		if (kommFirmaDto.getDomizil() != null) {
			if (StringUtils.isNotBlank(kommFirmaDto.getRechtsformAusland())) {
				kommFirmaEntity.getDomizil()
					.setLand(getCodeWert(KategorieEnum.LAND, kommFirmaDto.getDomizil().getLand().getCode()));
			} else {
				kommFirmaEntity.getDomizil().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
			}
		}
		kommFirmaEntity = organisationService.saveKommFirma(legalPartnerInfoDto.getOrgId(), kommFirmaEntity);
		
		mapper.map(kommFirmaEntity, legalPartnerInfoDto.getLegalPartner());
		OrganisationDto orgDto = new OrganisationDto();
		orgDto.setVersion(kommFirmaEntity.getKommges().getOrganisation().getVersion());
		return new PersonResultDto<>(legalPartnerInfoDto, orgDto);
	}
	
	@RequestMapping(value = "/legalPartnerInfo", method = RequestMethod.DELETE)
	public ResponseEntity<?> legalPartnerInfo(@RequestParam("orgId") int orgId,
		@RequestParam("legalPartnerVer") int version, @RequestParam("legalPartnerId") long id) {
		KommFirmaEntity kommFirmaEntity = organisationService.findKommFirmaByIdAndOrgId(orgId, id, version);
		if (kommFirmaEntity == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Can not find kommFirma"));
		}
		OrganisationEntity result = organisationService.deleteKommFirma(orgId, kommFirmaEntity);
		OrganisationDto orgDto = new OrganisationDto();
		orgDto.setVersion(result.getVersion());
		return ResponseEntity.ok(new PersonResultDto<>(null, orgDto));
	}
	
	@RequestMapping(value = "/ownerInfo", method = RequestMethod.PUT)
	public PersonResultDto<OwnerInfoDto<GeschaftsrolleDto>, OrganisationDto> ownerInfo(@RequestBody OwnerInfoDto<GeschaftsrolleDto> ownerInfoDto) {
		GeschaftsrolleEntity rolleEnt = convertToRolleEntity(ownerInfoDto);
		rolleEnt = organisationService.saveUnvalidatedGeschaftsrolle(rolleEnt, ownerInfoDto.getRechtsform());
		ownerInfoDto.setRole(mapper.map(rolleEnt, GeschaftsrolleDto.class));
		OrganisationDto orgDto = new OrganisationDto();
		orgDto.setVersion(rolleEnt.getOrganisation().getVersion());
		return new PersonResultDto<>(ownerInfoDto, orgDto);
	}

	@RequestMapping(value = "/ownerInfoWithValidated", method = RequestMethod.PUT)
	public PersonResultDto<OwnerInfoDto<GeschaftsrolleDto>, Void> ownerInfoWithValidated(@RequestBody OwnerInfoDto<GeschaftsrolleDto> ownerInfoDto) {
		GeschaftsrolleEntity rolleEnt = convertToRolleEntity(ownerInfoDto);
		rolleEnt = organisationService.saveValidatedGeschaftsrolle(rolleEnt);
		ownerInfoDto.setRole(mapper.map(rolleEnt, GeschaftsrolleDto.class));
		return new PersonResultDto<>(ownerInfoDto, null);
	}
	
	@RequestMapping(value = "/ownerInfoEdit", method = RequestMethod.PUT)
	public PersonResultDto<OwnerInfoDto<GeschaftsrolleDto>, OrganisationDto> editOwnerInfo(@RequestBody OwnerInfoDto<GeschaftsrolleDto> ownerInfoDto) {
		GeschaftsrolleEntity rolleEnt = convertToRolleEntity(ownerInfoDto);
		OrganisationDto orgDto = new OrganisationDto();
		orgDto.setVersion(rolleEnt.getOrganisation().getVersion());
		rolleEnt = organisationService.editUnvalidatedGeschaftsrolle(rolleEnt);
		ownerInfoDto.setRole(mapper.map(rolleEnt, GeschaftsrolleDto.class));
		return new PersonResultDto<>(ownerInfoDto, orgDto);
	}
	
	@RequestMapping(value = "/geschaftsrolles", method = RequestMethod.DELETE)
	public ResponseEntity<?> geschaftsrolles(@RequestParam("orgId") int orgId, @RequestParam("geschafVer") int version,
		@RequestParam("geschafId") long geschaId) {
		GeschaftsrolleEntity geschaftsrolleEntity = organisationService.findGeschaftsrolleByIdAndOrgId(orgId, geschaId, version);
		if (geschaftsrolleEntity == null) {
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("Can not find role"));
		}
		OrganisationEntity result = organisationService.deleteGeschaftsrolle(geschaftsrolleEntity);
		OrganisationDto orgDto = new OrganisationDto();
		orgDto.setVersion(result.getVersion());
		return ResponseEntity.ok(new PersonResultDto<>(null, orgDto));
	}

	/**
	 * @param ownerInfoDto
	 * @return
	 */
	private GeschaftsrolleEntity convertToRolleEntity(OwnerInfoDto<GeschaftsrolleDto> ownerInfoDto) {
		GeschaftsrolleDto rolleDto = ownerInfoDto.getRole();
		PersonDto personDto = ownerInfoDto.getRole().getPerson();
		
		PersonEntity personEnt = new PersonEntity();
		GeschaftsrolleEntity rolleEnt = new GeschaftsrolleEntity();
		
		if (rolleDto.getId() != null) {
			rolleEnt = organisationService.findGeschaftsrolleByIdAndOrgId(ownerInfoDto.getSourceId(), rolleDto.getId(), rolleDto.getVersion());
		}
		
		if (personDto.getId() != null) {
			personEnt = organisationService.getPerson(personDto.getId());
		}

		mapper.map(personDto, personEnt);
		
		if (personDto.getZivilstand() != null) {
			personEnt.setZivilstand(getCodeWert(KategorieEnum.ZIVILSTAND, personDto.getZivilstand().getCode()));
		}
		
		if (personDto.getAuslaenderAusweis() != null) {
			personEnt.setAuslaenderAusweis(getCodeWert(KategorieEnum.AUSLAUSWEIS, personDto.getAuslaenderAusweis().getCode()));
		}
		
		if (personDto.getAnrede() != null) {
			String geschlechtCd = OSSConstants.ANDERE_MR_CODE.equals(personDto.getAnrede().getCode())
				? OSSConstants.GESCHLECHT_MR_CODE : OSSConstants.GESCHLECHT_MRS_CODE;
			personEnt.setGeschlecht(getCodeWert(KategorieEnum.GESCHLECHT, geschlechtCd));
			personEnt.setAnrede(getCodeWert(KategorieEnum.ANREDE, personDto.getAnrede().getCode()));
		}
		
		personEnt.getNationalitaetens().clear();
		if (CollectionUtils.isNotEmpty(personDto.getNationalitaetens())) {
			List<String> codes = personDto.getNationalitaetens().stream().map(n -> n.getCode())
				.collect(Collectors.toList());
			personEnt.getNationalitaetens().addAll(getCodeWerts(KategorieEnum.LAND, codes));
		}
		
		if (CollectionUtils.isNotEmpty(personDto.getHeimatortes())) {
			List<Long> existedHemators = personDto.getHeimatortes().stream().map(h -> h.getId()).collect(Collectors.toList());
			List<PersonHeimatortEntity> removedHematorts = personEnt.getHeimatortes().stream().filter(h -> !existedHemators.contains(h.getId())).collect(Collectors.toList());
			personEnt.getHeimatortes().removeAll(removedHematorts);
			
			List<PersonHeimatortEntity> newHeimatorts = personEnt.getHeimatortes().stream().filter(h -> h.getId() == null).collect(Collectors.toList());
			for (PersonHeimatortEntity personHeimatort : newHeimatorts) {
				personHeimatort.setPerson(personEnt);
			}
		} else {
			personEnt.getHeimatortes().clear();
		}
		
		if (personDto.getWohnadresse() != null) {
			AdresseEntity domizil = new AdresseEntity();
			if (personDto.getWohnadresse().getId() != null) {
				domizil = organisationService.getAdresse(personDto.getWohnadresse().getId().longValue());
			}
			mapper.map(personDto.getWohnadresse(), domizil);
			if (personDto.getWohnadresse().getLand() != null) {
				domizil.setLand(getCodeWert(KategorieEnum.LAND, personDto.getWohnadresse().getLand().getCode()));
			}
			personEnt.setWohnadresse(domizil);
		}
		
		rolleEnt.setPerson(personEnt);
		rolleEnt.setOrganisation(organisationService.getOrganisation(ownerInfoDto.getSourceId()));
		rolleEnt.setTyp(GeschaeftsrolleTypEnum.EDC);
		
		if (rolleDto.getFunktion() != null) {
			rolleEnt
				.setFunktion(getCodeWert(KategorieEnum.FUNKTION, rolleDto.getFunktion().getCode()));
		}
		
		if (rolleDto.getZeichnung() != null) {
			rolleEnt.setZeichnung(getCodeWert(KategorieEnum.ZEICHNUNG, rolleDto.getZeichnung().getCode()));
		}

		rolleEnt.setNurHauptsitz(rolleDto.isNurHauptsitz());

		if (rolleDto.getHaftung() != null) {
			rolleEnt.setHaftung(getCodeWert(KategorieEnum.HAFTUNG, rolleDto.getHaftung().getCode()));
		}

		rolleEnt.setHaftungCHF(rolleDto.getHaftungCHF());

		if (rolleDto.getEinlage() != null) {
			rolleEnt.setEinlage(getCodeWert(KategorieEnum.EINLAGE, rolleDto.getEinlage().getCode()));
		} else {
			rolleEnt.setEinlage(null);
		}
		return rolleEnt;
	}

	@RequestMapping(value = "/domainName", method = RequestMethod.GET)
	public WHOISCheckResultEnum checkCompanyDomainName(@RequestParam("domainName") String domainName) {
		return whoisWebservice.checkDomain(domainName);
	}

	@RequestMapping(value = "/trademark", method = RequestMethod.GET)
	public CheckTrademarkResultDto checkCompanyTrademark(@RequestParam("trademark") String trademark) {
		try {
			TmtransDto result = swissregServiceAdapter.checkCompanyTrademark(trademark);
			return new CheckTrademarkResultDto(result);
		} catch (SwissregBusinessException e) {
			LOGGER.error("An error occurred when checking trademark via SwissReg: " + trademark, e);
			return new CheckTrademarkResultDto(e.getMessage());
		}
	}

	@RequestMapping(value = "/existingName", method = RequestMethod.GET)
	public CheckZefixNameResultDto checkCompanyNameViaZefix(@RequestParam("name") String name, @RequestParam("orgId") long orgId) {
		
		if (name != null && name.length() < OSSConstants.MIN_LENGTH_NAME) {
			throw new IllegalArgumentException("The company name must have at least 3 characters to search via Zefix");
		}
		
		OrganisationEntity organisation = organisationService.getOrganisation(orgId,
			QOrganisationEntity.organisationEntity.domizil,
			QOrganisationEntity.organisationEntity.geschaeftsrollens.any().person);
		switch (organisation.getRechtsform()) {
			case EINZELFIRMA:
				String firstName = organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)
					.stream().findFirst().get().getPerson().getVorname();
				name = name.replaceAll("(?i)" + firstName, "");
				break;
			case KOLLGES:
			case KOMMGES:
				for (GeschaftsrolleEntity ges : organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)) {
					if (StringUtils.containsIgnoreCase(name, ges.getPerson().getFamilienname())) {
						firstName = ges.getPerson().getVorname();
						name = name.replaceAll("(?i)" + firstName, "");
						break;
					}
				}
				break;
			case AG:
			case GMBH:
				break;
			default:
				throw new IllegalStateException("Unknown Rechtsform type:" + organisation.getRechtsform());
		}

		HrAmtDto hrAmt = getHrAmtByDomizilBfsnr(organisation.getDomizil().getBfsNr());

		try {
			CheckZefixNameResultDto result = new CheckZefixNameResultDto(hrAmt);

			// search all legal forms, but restricted to the BfsNr of the domizil address
			ShortResponseDto companies = zefixServiceAdapter.searchCompanyByName(name, null, organisation.getDomizil().getBfsNr());
			mergeZefixResult(result.getShortResponse(), companies);

			// search whole Switzerland for AG
			ShortResponseDto companiesAG = zefixServiceAdapter.searchCompanyByName(name, RechtsformEnum.AG, null);
			mergeZefixResult(result.getShortResponse(), companiesAG);

			// search whole Switzerland for GMBH
			ShortResponseDto companiesGMBH = zefixServiceAdapter.searchCompanyByName(name, RechtsformEnum.GMBH, null);
			mergeZefixResult(result.getShortResponse(), companiesGMBH);

			return result;
		} catch (ZefixTooManyResultsException e) {
			LOGGER.warn("Too many result found for the company name: " + name, e);
			return new CheckZefixNameResultDto(ZefixErrorEnum.TOO_MANY_RESULT, hrAmt);
		} catch (ZefixTooShortNameException e) {
			LOGGER.warn("The company name to search is too short: " + name, e);
			return new CheckZefixNameResultDto(ZefixErrorEnum.TOO_SHORT_NAME, hrAmt);
		} catch (ZefixBusinessException e) {
			LOGGER.warn("An error occurred when searching via Zefix", e);
			return new CheckZefixNameResultDto(ZefixErrorEnum.BUSINESS, hrAmt);
		}
	}
	
	private HrAmtDto getHrAmtByDomizilBfsnr(int bfsNr) {
		return mapper.map(applicationService.getHrAmtByDomizilBfsnr(bfsNr), HrAmtDto.class);
	}

	private void mergeZefixResult(ShortResponseDto destination, ShortResponseDto source) {
		Set<Integer> currentCompanyUids = destination.getCompanyShortInfo()
			.stream().map(c -> c.getUid()).collect(Collectors.toSet());
		List<CompanyShortInfoDto> companiesToAdd = source.getCompanyShortInfo()
			.stream().filter(c -> !currentCompanyUids.contains(c.getUid())).collect(Collectors.toList());
		destination.getCompanyShortInfo().addAll(companiesToAdd);
	}

	@RequestMapping(value = "/company", method = RequestMethod.GET)
	public CheckZefixNameResultDto searchCompanyViaZefix(@RequestParam("rechtsform") int ordinal,
		@RequestParam(name="uid", required=false) String uid,
		@RequestParam(name="name", required=false) String name) {
		if (uid != null) {
			try {
				ShortResponseDto shortDto = new ShortResponseDto();
				DetailledResponseDto detailDto = zefixServiceAdapter.getCompanyDetail(uid);
				for (CompanyDetailedInfoDto companyInfo : detailDto.getCompanyDetailedInfo()) {
					CompanyShortInfoDto companyInfoDto = mapper.map(companyInfo, CompanyShortInfoDto.class);
					companyInfoDto.setAddress(companyInfo.getAddress());
					shortDto.getCompanyShortInfo().add(companyInfoDto);
				}
				shortDto.getCompanyShortInfo().stream().sorted((a,b) -> a.getName().compareTo(b.getName()));
				return new CheckZefixNameResultDto(shortDto);
			} catch (ZefixInvalidCHIdException e) {
				LOGGER.warn("Invalid CHID: " + uid, e);
				return new CheckZefixNameResultDto(ZefixErrorEnum.INVALID_CHID);
			} catch (ZefixInvalidUIDException e) {
				LOGGER.warn("Invalid UID: " + uid, e);
				return new CheckZefixNameResultDto(ZefixErrorEnum.INVALID_UID);
			} catch (ZefixBusinessException e) {
				LOGGER.warn("An exception occurred when call Zefix", e);
				return new CheckZefixNameResultDto(ZefixErrorEnum.BUSINESS);
			}
		}

		if (name != null){
			if (name.length() < OSSConstants.MIN_LENGTH_NAME) {
				throw new IllegalArgumentException(
					"The company name must have at least 3 characters to search via Zefix");
			}
			ShortResponseDto shortDto = new ShortResponseDto();
			try {
				shortDto = zefixServiceAdapter.searchCompanyByName(name, RechtsformEnum.values()[ordinal], null);
				shortDto.getCompanyShortInfo().stream().sorted((a,b) -> a.getName().compareTo(b.getName()));
				return new CheckZefixNameResultDto(shortDto);
			} catch (ZefixTooShortNameException e) {
				LOGGER.warn("The company name is too short: " + name, e);
				return new CheckZefixNameResultDto(ZefixErrorEnum.TOO_SHORT_NAME);
			} catch (ZefixTooManyResultsException e) {
				LOGGER.warn("Too many result found for the company name: " + name, e);
				return new CheckZefixNameResultDto(ZefixErrorEnum.TOO_MANY_RESULT);
			} catch (ZefixBusinessException e) {
				LOGGER.warn("An exception occurred when call Zefix", e);
				return new CheckZefixNameResultDto(ZefixErrorEnum.BUSINESS);
			}
		}

		throw new IllegalArgumentException("The company name or UID must is required to search via Zefix");
	}

	@RequestMapping(value = "/companyDetail", method = RequestMethod.GET)
	public CompanyDetailResultDto getCompanyDetailViaZefix(@RequestParam("rechtsform") int ordinal,
		@RequestParam("uid") int uid) {
		try {		
			DetailledResponseDto response = zefixServiceAdapter.getCompanyDetailByUid(uid, RechtsformEnum.values()[ordinal]);
			CompanyDetailedInfoDto companyDetail = response.getCompanyDetailedInfo().get(0);
			// SECOOSS-763: check if the system can find the kanton match the zefix company's address 
			String kanton = findKanton(companyDetail.getLegalSeatId(), null, companyDetail.getLegalSeat());
			if (kanton == null) {
				LOGGER.warn("Cannot find the kanton for the company address with bfsnr: " + companyDetail.getLegalSeatId());
				return new CompanyDetailResultDto(ZefixErrorEnum.BUSINESS);
			}
			return new CompanyDetailResultDto(companyDetail);
		} catch (ZefixInvalidUIDException e) {
			LOGGER.warn("Invalid UID: " + uid, e);
			return new CompanyDetailResultDto(ZefixErrorEnum.INVALID_UID);
		} catch (ZefixBusinessException e) {
			LOGGER.warn("An exception occurred when calling Zefix", e);
			return new CompanyDetailResultDto(ZefixErrorEnum.BUSINESS);
		}
	}

	@RequestMapping(value = "/name", method = RequestMethod.GET)
	public CheckNameResultDto checkCompanyName(@RequestParam("orgId") long orgId,
		@RequestParam(name="hrMutationId", required=false) Long hrMutationId,
		@RequestParam("name") String name, @RequestParam("source") int sourceOrdinal) {
		CheckNameResult result = organisationService.validateOrganisationName(orgId, hrMutationId, name, 
			SecurityUtil.currentUser().getLanguagePreference(), CheckCompanyNameSourceEnum.values()[sourceOrdinal]);
		return mapper.map(result, CheckNameResultDto.class);
	}
	
	@RequestMapping(value = "/konten", method = RequestMethod.PUT)
	public ResponseEntity<?> konten(@RequestBody @Valid KontoDto dto) {
		if (dto.getTyp() == KontotypEnum.BANK) {
			if (dto.getInhaber() == null
				|| dto.getBankname() == null
				|| dto.getPlz() == null
				|| dto.getOrt() == null
				|| dto.getKontonummer() == null
				) {
				return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(ExceptionHandlingController.errorFor(
					"For bank account: inhaber, bankname, plz, ort, kontonumber are required."));
			}
		} else if (dto.getTyp() == KontotypEnum.POST) {
			if (dto.getInhaber() == null || dto.getKontonummer() == null) {
				return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(ExceptionHandlingController.errorFor(
					"For postal account: inhaber, kontonumber are required."));
			}
		}

		KontoEntity ent = new KontoEntity();
		if (dto.getId() != null) {
			ent = organisationService.getKontoById(dto.getId(), dto.getOrgId());
		}
		mapper.map(dto, ent);
		ent.setOrganisation(organisationService.getOrganisation(dto.getOrgId()));
		ent = organisationService.saveKonto(ent, dto.getOrgId());
		dto.setId(ent.getId());
		dto.setVersion(ent.getVersion());
		return ResponseEntity.ok(dto);
	}

	@RequestMapping(value = "/externErledigtes/{orgId}", method = RequestMethod.GET)
	public ExternalProcessDeclarationDto getExternalProcessOfCod(@PathVariable long orgId) {
		PflichtenabklaerungenEntity pflichEnt = organisationService.getPflichtenabklaerungenOfOganisation(orgId);
		ExternalProcessDeclarationDto dto = new ExternalProcessDeclarationDto();
		dto.setOrgId(orgId);
		mapper.map(pflichEnt, dto);
		Map<ProzessTypEnum, ProzessStatusEnum> statuOfAllProzess = organisationService
			.getStatuOfAllProzessByOrgId(orgId);
		statuOfAllProzess.entrySet().stream().forEach(e -> {
			if (e.getValue() == ProzessStatusEnum.GESENDET) {
				switch (e.getKey()) {
					case HR:
						dto.setHrFinish(true);
						break;
					case UVG:
						dto.setUvgFinish(true);
						break;
					case AHV:
						dto.setAhvFinish(true);
						break;
					case MWST:
						dto.setMwstFinish(true);
						break;
					default:
						break;
				}
			}
		});
		
		return dto;
	}
	
	@RequestMapping(value = "/externErledigtes", method = RequestMethod.PUT)
	public ResponseEntity<?> updateExternalProcessOfCod(@RequestBody @Valid ExternalProcessDeclarationDto dto) {
		PflichtenabklaerungenEntity pflichEnt = organisationService.getPflichtenabklaerungenOfOganisation(dto.getOrgId());
		mapper.map(dto, pflichEnt, ORGANISATION_PFLICHTENABKLAERUNGEN);
		organisationService.markProcessExternal(dto.getOrgId(), pflichEnt);
		return ResponseEntity.ok("{ \"message\": \"ok\"}");
	}
	
	@RequestMapping(value = "/digitalSignees", method = RequestMethod.GET)
	public DigitalSignatureDto getDigitalSignees(@RequestParam("prozessId") Long prozessId) {
		return organisationService.getDigitalSignees(prozessId);
	}
	
	@RequestMapping(value = "/upload/singedPdf", method = RequestMethod.POST)
	public DigitalSignatureDto uploadSingedPdf(@RequestParam("file") String fileString, @RequestParam("prozessId") Long prozessId) {
		return organisationService.updateSignedProzessPdf(Base64.getDecoder().decode(fileString), prozessId);
	}
	
	@RequestMapping(value = "download/prozessPdf/{prozessId}", method = RequestMethod.GET)
	public ResponseEntity<?> downloadProzessPdf(@PathVariable long prozessId) {
		return download(organisationService.downloadProzessPdf(prozessId));
	}
	
	@RequestMapping(value = "/existingOrgsByUid/{uid}", method = RequestMethod.GET)
	public ResponseEntity<?> getExistingOrgsByUid(@PathVariable String uid) {
		ExistingOrgSearchResultDto existingOrgsByUid = organisationService.getExistingOrgsByUid(uid);
		existingOrgsByUid.setPageSize(pageSizeCompany);
		return ResponseEntity.ok(existingOrgsByUid);
	}

	@RequestMapping(value = "/existingOrgsByNonUid/{criterion}", method = RequestMethod.GET)
	public ResponseEntity<?> getExistingOrgsByNonUid(@PathVariable String criterion) {
		ExistingOrgSearchResultDto existingOrgsByNonUid = organisationService.getExistingOrgsByNonUid(criterion);
		existingOrgsByNonUid.setPageSize(pageSizeCompany);
		return ResponseEntity.ok(existingOrgsByNonUid);
	}

	@RequestMapping(value = "/connectFromStartbizToEasyGov", method = RequestMethod.POST)
	public ResponseEntity<?> connectFromStartbizToEasyGov(@RequestBody List<String> params) {
		StartBizDataEntity entity = organisationService.getStartBizDataById(Long.valueOf(params.get(1)));
		// TODO [HHG / S9] Remove this code after skipping @hasPermission check
		List<Long> orgIds = SecurityUtil.currentUser().getAuthorizedCompanies().stream().map(org -> org.getOrgId()).collect(Collectors.toList());
		try {
			// validate the user provided password must match with the one in data base
			if (!ValidationUtil.isValidStartBizPassword(params.get(0), entity.getPasswordHash(), entity.getPasswordSalt())) {
				return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
					.body(ExceptionHandlingController.errorFor("gui_labels.orgBox.invalidPassword"));
			}

			// migrate company data
			ZugriffEntity zugriff = migrationService.migrateStartBizDataToEasyGov(entity);
			
			// add new migrated company to the user's authorized organisation list 
			OssUser user = SecurityUtil.currentUser();
			user.addAuthorizedCompany(new AuthorizedOrganisation(zugriff.getUser().getEid(),
				zugriff.getOrganisation().getId(), zugriff.getOrganisation().getDomizil().getId(),
				entity.getCompanyName(), new AuthorizedPermission(zugriff.getAccessLevel(), zugriff.getStatus(),
					OSSDateUtil.toDate(zugriff.getFromDate()), OSSDateUtil.toDate(zugriff.getToDate()))));
			SecurityUtil.updateCurrentUser(user);

			return ResponseEntity.ok(zugriff.getOrganisation().getId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			// TODO [HHG / S9] Remove this code after skipping @hasPermission check
			OssUser curUser = SecurityUtil.currentUser(); 
			Set<AuthorizedOrganisation> authorizedCompanies = curUser.getAuthorizedCompanies()
				.stream().filter(o -> orgIds.contains(o.getOrgId())).collect(Collectors.toSet());
			OssUser newUser = new OssUser(curUser.getUserId(), curUser.getUsername(),
				curUser.getAuthorities(), curUser.getLanguagePreference(), authorizedCompanies,
				curUser.getFunktions(), curUser.getEmail(), curUser.isLoginSuisseId(),
				curUser.getFirstName(), curUser.getLastName());
			SecurityUtil.updateCurrentUser(newUser);
			
			return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor("gui_labels.orgBox.connectNotOkMessage"));
		}
	}
}