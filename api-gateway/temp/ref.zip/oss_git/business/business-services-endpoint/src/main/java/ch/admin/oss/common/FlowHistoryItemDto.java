/*
 * FlowHistoryItemDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.util.HashMap;
import java.util.Map;

/**
 * @author phd
 */
public class FlowHistoryItemDto {

	private String name;

	private Map<String, String> data = new HashMap<String, String>();

	public FlowHistoryItemDto() {}

	public FlowHistoryItemDto(String name, Map<String, String> data) {
		this.name = name;
		this.data = data;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, String> getData() {
		return data;
	}

	public void setData(Map<String, String> data) {
		this.data = data;
	}
}
