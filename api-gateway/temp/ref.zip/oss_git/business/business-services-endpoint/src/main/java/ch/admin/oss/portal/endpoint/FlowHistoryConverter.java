/*
 * FlowHistoryConverter
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.endpoint;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.dozer.DozerConverter;

import ch.admin.oss.domain.FlowHistoryEntity;
import ch.admin.oss.domain.FlowHistoryItemDataEntity;
import ch.admin.oss.domain.FlowHistoryItemEntity;

/**
 * DOZER converter for translating {@link FlowHistoryEntity} to kind of a multi {@link Map} that is keyed respectively
 * by (1) the history item and (2) its item data's key.
 * 
 * @author phd
 */
@SuppressWarnings("rawtypes")
public class FlowHistoryConverter extends DozerConverter<FlowHistoryEntity, Map> {

	public FlowHistoryConverter() {
		super(FlowHistoryEntity.class, Map.class);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Map<String, Map<String, String>> convertTo(FlowHistoryEntity source, Map destination) {
		return source.getItems().stream().collect(Collectors.toMap(FlowHistoryItemEntity::getName,
			new Function<FlowHistoryItemEntity, Map<String, String>>() {

				@Override
				public Map<String, String> apply(FlowHistoryItemEntity t) {
					return t.getData().stream().collect(
						Collectors.toMap(FlowHistoryItemDataEntity::getKey, FlowHistoryItemDataEntity::getValue));
				}
			}, (u, v) -> {
				throw new IllegalStateException(String.format("Duplicate key %s", u));
				// To preserve the history item order.
			}, LinkedHashMap::new));
	}

	/**
	 * {@inheritDoc}
	 */
	@SuppressWarnings("unchecked")
	@Override
	public FlowHistoryEntity convertFrom(Map source, FlowHistoryEntity destination) {
		return new FlowHistoryEntity(((Map<String, Map<String, String>>) source).entrySet().stream()
			.map(item -> new FlowHistoryItemEntity(item.getKey(),
				item.getValue().entrySet().stream()
					.map(data -> new FlowHistoryItemDataEntity(data.getKey(), data.getValue()))
					.collect(Collectors.toSet())))
			.collect(Collectors.toList()));
	}
}
