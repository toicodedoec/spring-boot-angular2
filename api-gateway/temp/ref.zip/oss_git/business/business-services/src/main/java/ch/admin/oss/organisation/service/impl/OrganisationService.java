/*
 * OrganisationService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.organisation.service.impl;

import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.oro.text.perl.Perl5Util;
import org.apache.pdfbox.pdmodel.interactive.form.PDSignatureField;
import org.dozer.DozerBeanMapper;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.querydsl.core.types.Path;
import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.ahv.repository.IAhvFilialeRepository;
import ch.admin.oss.ahv.repository.IKontoRepository;
import ch.admin.oss.ahv.service.IAhvService;
import ch.admin.oss.application.repository.IFlowHistoryRepository;
import ch.admin.oss.application.repository.IStartBizDataRepository;
import ch.admin.oss.common.AbstractOrganisationService;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.common.OssTechnicalException;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.dto.DigitalSignatureDto;
import ch.admin.oss.common.dto.ExistingOrgInfoDto;
import ch.admin.oss.common.dto.ExistingOrgSearchResultDto;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.enums.AccessLevelEnum;
import ch.admin.oss.common.enums.AccessStatusEnum;
import ch.admin.oss.common.enums.CheckCompanyNameSourceEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.OrganisationCreationTypeEnum;
import ch.admin.oss.common.enums.PlaceToFindEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.AhvFilialeEntity;
import ch.admin.oss.domain.EinladungEntity;
import ch.admin.oss.domain.FirmennameEntity;
import ch.admin.oss.domain.FlowHistoryEntity;
import ch.admin.oss.domain.GeschaeftsstelleEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrMutationEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.KommGesEntity;
import ch.admin.oss.domain.KontoEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QAdresseEntity;
import ch.admin.oss.domain.QAhvFilialeEntity;
import ch.admin.oss.domain.QCodeWertEntity;
import ch.admin.oss.domain.QEinladungEntity;
import ch.admin.oss.domain.QGeschaeftsstelleEntity;
import ch.admin.oss.domain.QGeschaftsrolleEntity;
import ch.admin.oss.domain.QHrMutationEntity;
import ch.admin.oss.domain.QKommFirmaEntity;
import ch.admin.oss.domain.QKommGesEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QPersonEntity;
import ch.admin.oss.domain.QPflichtenabklaerungenEntity;
import ch.admin.oss.domain.QProzessEntity;
import ch.admin.oss.domain.QStartBizDataEntity;
import ch.admin.oss.domain.QUserEntity;
import ch.admin.oss.domain.QZugriffEntity;
import ch.admin.oss.domain.StartBizDataEntity;
import ch.admin.oss.domain.UserEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.enums.SignResultEnum;
import ch.admin.oss.enums.SupportedFileTypeDownload;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyDetailedInfoDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyShortInfoDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.DetailledResponseDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.IZefixServiceAdapter;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ShortResponseDto;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixBusinessException;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixInvalidCHIdException;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixInvalidUIDException;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixTooManyResultsException;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ZefixTooShortNameException;
import ch.admin.oss.hr.service.IHRService;
import ch.admin.oss.hrmutation.repository.IHrMutationRepository;
import ch.admin.oss.mwst.service.IMWSTService;
import ch.admin.oss.organisation.repository.IAdresseRepository;
import ch.admin.oss.organisation.repository.ICodeWertRepository;
import ch.admin.oss.organisation.repository.IEinladungRepository;
import ch.admin.oss.organisation.repository.IGeschaeftsstelleRepository;
import ch.admin.oss.organisation.repository.IKommFirmaRepository;
import ch.admin.oss.organisation.repository.IOrganisationRepository;
import ch.admin.oss.organisation.repository.IPersonRepository;
import ch.admin.oss.organisation.repository.IPflichtenabklaerungenRepository;
import ch.admin.oss.organisation.repository.IZugriffRepository;
import ch.admin.oss.organisation.service.CheckNameResult;
import ch.admin.oss.organisation.service.IOrganisationService;
import ch.admin.oss.portal.repository.IUserRepository;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.IMailUtil;
import ch.admin.oss.util.JpaUtil;
import ch.admin.oss.util.MailMessage;
import ch.admin.oss.util.NestedProjection;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.PdfBoxUtil;
import ch.admin.oss.uvg.service.IUVGService;

/**
 * @author xdg
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class OrganisationService extends AbstractOrganisationService implements IOrganisationService {
	
	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(OrganisationService.class);
	
	private static final String UID_SEPERATOR_CHARACTER = ".";

	private static final String SPLIT_UID_PATTERN = "(?<=\\G.{3})";

	private static final String PREFIX_UID_PATTERN = "CHE-";

	// AG company name patterns
	private static final String AG_MUST_HAVE_REGEX =
		"/(.* {1})*((ag)|(sa))(,? {1}.*)*|"
	  + "(.* {1})*(a\\.?\\s*g\\.|s\\.?\\s*a\\.)(,? {1}.*)*|"
	  + ".* {1}((aktiengesellschaft)|(actions)|(azioni)),? {1}.*/i";

	private static final String[] AG_MUST_NOT_HAVE_REGEXES = new String[] {
        "/\\b(beschränkte[r]?\\s+Haftung)\\b/i",
        "/\\b(responsabilité\\s+limitée)\\b/i",
        "/\\b(garanzia\\s+limitata)\\b/i",
        "/\\b(GmbH)|(Sàrl)|(sarl)|(sagl)\\b/i",
        "/\\b(S\\.à\\.r\\.l\\.)|(S\\.à\\s+r\\.l\\.)/i",
        "/\\b(S\\.à\\.r\\.l|S\\.à\\s+r\\.l)\\b/i",
        "/\\b(S\\.a\\.g\\.l\\.)|(S\\.a\\s+g\\.l\\.)/i",
        "/\\b(S\\.a\\.g\\.l|S\\.a\\s+g\\.l)\\b/i",
        "/\\b(Kollektivgesellschaft)|(nom\\s+collectif)|(nome\\s+collettivo)\\b/i",
        "/\\b(verein)\\b|(verein)\\b/i",
        "/\\b(association|asscociazione)\\b/i",
        "/\\b(stiftung)\\b|(stiftung)\\b/i", "/\\b(fondation|fondazione)\\b/i",
        "/(genossenschaft)|\\b(coopérative)\\b|\\b(cooperativa)\\b/i",
        "/(gesellschaft)\\b|\\b(gesellschaft|société|società)\\b/i"
    };
	
	// GMBH company name patterns
	private static final String GMBH_MUST_HAVE_REGEX =
        "/(.+ {1})*(gmbh|sàrl|sagl)(,? {1}.*)*|"
      + "(.+ {1})*(g\\.m\\.b\\.h\\.|s\\.à\\.r\\.l\\.|s\\.a\\.g\\.l\\.)(,? {1}.*)*|"
      + "((.+ {1})*(gesellschaft|société|società)(,? {1}.*)*"
      + "((mit beschränkter Haftung)|(à responsabilité limitée)|(a garanzia limitata)|"
      + "(mbh)|(arl)|(agl)(,? {1}.*)*))/i";

	private static final String[] GMBH_MUST_NOT_HAVE_REGEXES = new String[] {
        "/\\b(aktiengesellschaft)|(azioni)|(actions)\\b/i",
        "/\\b(Kollektivgesellschaft)|(nom\\s+collectif)|(nome\\s+collettivo)\\b/i",
        "/\\b(verein)\\b|(verein)\\b/i", "/\\b(stiftung)\\b|(stiftung)\\b/i",
        "/\\b(fondation|fondazione)\\b/i",
        "/(gesellschaft)\\b|\\b(gesellschaft|société|società)\\b/i",
        "/\\b(AG|SA)\\b/i",
        "/\\b(A\\.G\\.|A\\.\\s+G\\.|S\\.A\\.|S\\.\\s+A\\.)/i"
	};
	
	// EF company name patterns
    private static final String[] EF_MUST_NOT_HAVE_REGEXES = new String[] {
        "/\\b(beschränkte[r]?\\s+Haftung)\\b/i",
        "/\\b(responsabilité\\s+limitée)\\b/i",
        "/\\b(garanzia\\s+limitata)\\b/i",
        "/\\b(aktiengesellschaft)|(azioni)|(actions)\\b/i",
        "/\\b(GmbH)|(Sàrl)|(sarl)|(sagl)\\b/i",
        "/\\b(S\\.à\\.r\\.l\\.)|(S\\.à\\s+r\\.l\\.)/i",
        "/\\b(S\\.à\\.r\\.l|S\\.à\\s+r\\.l)\\b/i",
        "/\\b(S\\.a\\.g\\.l\\.)|(S\\.a\\s+g\\.l\\.)/i",
        "/\\b(S\\.a\\.g\\.l|S\\.a\\s+g\\.l)\\b/i",
        "/\\b(Gebrüder|frères|fratelli)\\b/i",
        "/\\b(und\\s+Sohn)|(und\\s+Söhne)|(e\\s+figlio)|(e\\s+figli)|(et\\s+fils)\\b/i",
        "/\\b(Partner|partenaire)\\b/i",
        "/\\b(Kollektivgesellschaft)|(nom\\s+collectif)|(nome\\s+collettivo)\\b/i",
        "/\\b(Kommanditgesellschaft)|(en\\s+commandite)|(in\\s+accommandita)\\b/i",
        "/\\b(verein)\\b|(verein)\\b/i",
        "/\\b(association|asscociazione)\\b/i",
        "/\\b(stiftung)\\b|(stiftung)\\b/i", "/\\b(fondation|fondazione)\\b/i",
        "/(genossenschaft)|\\b(coopérative)\\b|\\b(cooperativa)\\b/i",
        "/(gesellschaft)\\b|\\b(gesellschaft|société|società)\\b/i",
        "/\\b(AG|SA)\\b/i",
        "/\\b(A\\.G\\.|A\\.\\s+G\\.|S\\.A\\.|S\\.\\s+A\\.)/i"
    };

    // KollGes company name patterns
    private static final String[] KOLL_MUST_NOT_HAVE_REGEXES = new String[] {
        "/\\b(beschränkte[r]?\\s+Haftung)\\b/i",
        "/\\b(responsabilité\\s+limitée)\\b/i",
        "/\\b(garanzia\\s+limitata)\\b/i",
        "/\\b(aktiengesellschaft)|(azioni)|(actions)\\b/i",
        "/\\b(GmbH)|(Sàrl)|(sarl)|(sagl)\\b/i",
        "/\\b(S\\.à\\.r\\.l\\.)|(S\\.à\\s+r\\.l\\.)/i",
        "/\\b(S\\.à\\.r\\.l|S\\.à\\s+r\\.l)\\b/i",
        "/\\b(S\\.a\\.g\\.l\\.)|(S\\.a\\s+g\\.l\\.)/i",
        "/\\b(S\\.a\\.g\\.l|S\\.a\\s+g\\.l)\\b/i",
        "/\\b(Kommanditgesellschaft)|(en\\s+commandite)|(in\\s+accommandita)\\b/i",
        "/\\b(verein)\\b|(verein)\\b/i",
        "/\\b(association|asscociazione)\\b/i",
        "/\\b(stiftung)\\b|(stiftung)\\b/i", "/\\b(fondation|fondazione)\\b/i",
        "/(genossenschaft)|\\b(coopérative)\\b|\\b(cooperativa)\\b/i",
        "/(gesellschaft)\\b|\\b(gesellschaft|société|società)\\b/i",
        "/\\b(AG|SA)\\b/i",
        "/\\b(A\\.G\\.|A\\.\\s+G\\.|S\\.A\\.|S\\.\\s+A\\.)/i"
    };

    // KommGes company name patterns
    private static final String[] KOMM_MUST_NOT_HAVE_REGEXES = new String[] {
        "/\\b(beschränkte[r]?\\s+Haftung)\\b/i",
        "/\\b(responsabilité\\s+limitée)\\b/i",
        "/\\b(garanzia\\s+limitata)\\b/i",
        "/\\b(aktiengesellschaft)|(azioni)|(actions)\\b/i",
        "/\\b(GmbH)|(Sàrl)|(sarl)|(sagl)\\b/i",
        "/\\b(S\\.à\\.r\\.l\\.)|(S\\.à\\s+r\\.l\\.)/i",
        "/\\b(S\\.à\\.r\\.l|S\\.à\\s+r\\.l)\\b/i",
        "/\\b(S\\.a\\.g\\.l\\.)|(S\\.a\\s+g\\.l\\.)/i",
        "/\\b(S\\.a\\.g\\.l|S\\.a\\s+g\\.l)\\b/i",
        "/\\b(Kollektivgesellschaft)|(nom\\s+collectif)|(nome\\s+collettivo)\\b/i",
        "/\\b(verein)\\b|(verein)\\b/i",
        "/\\b(association|asscociazione)\\b/i",
        "/\\b(stiftung)\\b|(stiftung)\\b/i", "/\\b(fondation|fondazione)\\b/i",
        "/(genossenschaft)|\\b(coopérative)\\b|\\b(cooperativa)\\b/i",
        "/(gesellschaft)\\b|\\b(gesellschaft|société|società)\\b/i",
        "/\\b(AG|SA)\\b/i",
        "/\\b(A\\.G\\.|A\\.\\s+G\\.|S\\.A\\.|S\\.\\s+A\\.)/i"
    };
    
    private static final String[] HR_VALID_CHARS = new String[] {
        " ", "!", "\"", "&", "'", "(", ")", "+", "-", ",", UID_SEPERATOR_CHARACTER, "/",":", ";", "?", "[", "]", "ß",
        "0", "1", "2", "3", "4", "5",  "6",  "7",  "8",  "9",
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",
        "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z",
        "À", "Á", "Â", "Ã", "Ä", "Å", "Ç", "È", "É", "Ê", "Ë", "Ì", "Í", "Î", "Ï", "Ñ", "Ò", "Ó", "Ô", "Õ", "Ö", "Ø", "Ù", "Ú", "Û", "Ü", "Ý",
        "à", "á", "â", "ã", "ä", "å", "ç", "è", "é", "ê", "ë", "ì", "í", "î", "ï", "ñ", "ò", "ó", "ô", "õ", "ö", "ø", "ù", "ú", "û", "ü", "ý"
    };

	@PersistenceContext
	private EntityManager em;
		
	@Autowired
	private JpaUtil jpaUtil;
	
	@Autowired
	private IMailUtil mailUtil;

	@Autowired
	private IOrganisationRepository orgRepo;

	@Autowired
	private IZugriffRepository zugriffRepo;

	@Autowired
	private ICodeWertRepository codeWertRepo;

	@Autowired
	private IUserRepository userRepo;

	@Autowired
	private IEinladungRepository einladungRepo;

	@Autowired
	private IPersonRepository personRepo;
	
	@Autowired
	private IAdresseRepository addressRepo;

	@Autowired
	private IKommFirmaRepository kommFirmaRepo;
	
	@Autowired
	private IGeschaeftsstelleRepository geschaeftsstelleRepo;

	@Autowired
	private IFlowHistoryRepository flowHistoryRepo;
	
	@Autowired
	private IKontoRepository kontoRepo;
	
	@Autowired
	private IAhvFilialeRepository filialeRepository;
	
	@Autowired
	private IStartBizDataRepository startBizRepo;

	@Autowired
	private IAhvService ahvService;

	@Autowired
	private IHRService hrService;
	
	@Autowired
	private IMWSTService mwstService;
	
	@Autowired
	private IUVGService uvgService;
	
	@Autowired
	private IPflichtenabklaerungenRepository pflichRepo;
		
	@Autowired
	private IZefixServiceAdapter zefixServiceAdapter;
	
	@Autowired
	private IHrMutationRepository hrMutationRepo;

	@Autowired
	protected DozerBeanMapper mapper;

	@Override
	public OrganisationEntity createOrganisationFromScratch(String orgName, boolean isConnectToDuty) {
		OrganisationEntity organisation = new OrganisationEntity();

		// TODO [COH / S9] to consider grouping logic create flow history
		FlowHistoryEntity fhe = new FlowHistoryEntity();
		flowHistoryRepo.save(fhe);
		organisation.setFlowHistory(fhe);
		organisation.setCreationType(OrganisationCreationTypeEnum.SCRATCH);

		// get the current user entity
		UserEntity user = userRepo.findOne(QUserEntity.userEntity.eid.eq(SecurityUtil.currentUser().getUsername()));
		
		// set the name
		FirmennameEntity name = new FirmennameEntity();
		name.setOrganisation(organisation);
		name.setDefault(true);
		name.setBezeichnung(orgName);
		name.setSprache(codeWertRepo.findOne(QCodeWertEntity.codeWertEntity.kategorie.eq(KategorieEnum.SPRACHE)
			.and(QCodeWertEntity.codeWertEntity.code.equalsIgnoreCase(SecurityUtil.currentUser().getLanguagePreference().toString()))));
		organisation.getNamens().add(name);
		
		// grant the access right
		ZugriffEntity zugriff = new ZugriffEntity();
		zugriff.setUser(user);
		zugriff.setAccessLevel(AccessLevelEnum.FULL);
		zugriff.setOrganisation(organisation);
		zugriff.setStatus(AccessStatusEnum.GRANTED);
		zugriff.setFromDate(LocalDate.now());
		organisation.getZugrrifs().add(zugriff);
		
		if (isConnectToDuty && (user.getPflichten() != null)) {
			PflichtenabklaerungenEntity pflichtenEnt = user.getPflichten();
			pflichtenEnt.setOrganisation(organisation);
			pflichtenEnt.setUser(null);
			organisation.setPflichtenabklaerungen(pflichtenEnt);
		}
		
		return orgRepo.save(organisation);
	}

	@Override
	public EinladungEntity saveEinladung(long orgId, @Valid EinladungEntity einladungEntity, String fromEmailAddress,
		String invitationLinkPrefix) {
		EinladungEntity savedEnt = einladungRepo.save(einladungEntity);
		sendInvitationMail(savedEnt, fromEmailAddress, invitationLinkPrefix);
		return savedEnt;
	}
	
	private void sendInvitationMail(EinladungEntity einladungEntity, String fromEmailAddress, String invitationLinkPrefix) {
		// send invitation
		MailMessage message = new MailMessage();
		
		message.setSubject(applicationService.getTranslation("gui_labels.einladungInvitation.mail.subject",
			SecurityUtil.currentUser().getLanguagePreference()));
		message.setFrom(fromEmailAddress);
		message.setTo(einladungEntity.getEmail());
		message.setTemplateName("invitation-mail-template.ftl");
		
		Map<String, Object> emailData = new HashMap<String, Object>();
		String companyName = getOrganisation(einladungEntity.getOrgId(), QOrganisationEntity.organisationEntity.namens)
			.getNamens().stream().filter(namens -> namens.isDefault()).findFirst().get().getBezeichnung();
		emailData.put("companyName", companyName);
		emailData.put("inviterGivenName", SecurityUtil.currentUser().getFirstName());
		emailData.put("inviterFamiliyName", SecurityUtil.currentUser().getLastName());
		// SECOOSS-514 - Link invite new user doesn't work
		emailData.put("invitationLink", invitationLinkPrefix + "?target=" + CommonConstants.LOGIN_INVITATION_TARGET 
				+ "&code=" + einladungEntity.getEinladungsCode());
		emailData.put("invitationCode", einladungEntity.getEinladungsCode());
		emailData.put("invitationExpirationDate", einladungEntity.getAblauf());
		message.setTemplateModel(emailData);

		mailUtil.send(message);
	}

	// TODO [COH / S9] To review this method.
	@Override
	public List<EinladungEntity> getAllEinladungOfOrganisation(long orgId) {
		JPAQuery<EinladungEntity> query = new JPAQuery<EinladungEntity>(em);
		return query.from(QEinladungEntity.einladungEntity)
			.innerJoin(QEinladungEntity.einladungEntity.organisation, QOrganisationEntity.organisationEntity)
			.fetchJoin().where(QOrganisationEntity.organisationEntity.id.eq(orgId))
			.orderBy(QEinladungEntity.einladungEntity.email.asc()).fetch();
	}
	
	@Override
	public List<EinladungEntity> getEinladung(long orgId) {
		QEinladungEntity qEinladung = QEinladungEntity.einladungEntity;
		QOrganisationEntity qOrganisation = new QOrganisationEntity("organisation");
		
		return new JPAQuery<EinladungEntity>(em)
			.from(qEinladung)
			.innerJoin(qEinladung.organisation, qOrganisation)
			.where(qOrganisation.id.eq(orgId))
			.orderBy(qEinladung.email.asc())
			.select(NestedProjection.of(EinladungEntity.class, 
				qEinladung.id,
				qEinladung.version,
				qEinladung.email,
				qEinladung.zugriffsstufe,
				qEinladung.ausgestellt,
				qEinladung.ablauf,
				qEinladung.zugriffVon,
				qEinladung.zugriffBis,
				qOrganisation.id))
			.fetch();
	}

	@Override
	public void deleteEinladung(EinladungEntity einladungEntity) {
		einladungRepo.delete(einladungEntity);
	}

	@Override
	public ZugriffEntity findZugriffByIdAndOrgId(long orgId, long id) {
		return new JPAQuery<ZugriffEntity>(em).from(QZugriffEntity.zugriffEntity)
			.innerJoin(QZugriffEntity.zugriffEntity.organisation, QOrganisationEntity.organisationEntity).fetchJoin()
			.where(QZugriffEntity.zugriffEntity.id.eq(id).and(QZugriffEntity.zugriffEntity.organisation.id.eq(orgId)))
			.fetchOne();
	}

	@Override
	public ZugriffEntity updateZugriff(@Valid ZugriffEntity zugriffEntity) {
		return zugriffRepo.save(zugriffEntity);
	}

	@Override
	// TODO [COH / S9] to review if this method is neccessary
	public List<ZugriffEntity> getAllZugriffOfOrganisation(long orgId) {
		JPAQuery<ZugriffEntity> query = new JPAQuery<ZugriffEntity>(em);
		return query.from(QZugriffEntity.zugriffEntity)
			.join(QZugriffEntity.zugriffEntity.organisation, QOrganisationEntity.organisationEntity).fetchJoin()
			.join(QZugriffEntity.zugriffEntity.user, QUserEntity.userEntity).fetchJoin()
			.where(QOrganisationEntity.organisationEntity.id.eq(orgId))
			.orderBy(QZugriffEntity.zugriffEntity.user.eid.asc()).fetch();
	}
	
	@Override
	public List<ZugriffEntity> getZugriff(long orgId) {
		QZugriffEntity qZugriff = QZugriffEntity.zugriffEntity;
		QOrganisationEntity qOrganisation = new QOrganisationEntity("organisation");
		QUserEntity qUser = new QUserEntity("user");
		
		return new JPAQuery<ZugriffEntity>(em)
			.from(qZugriff)
			.join(qZugriff.organisation, qOrganisation)
			.join(qZugriff.user, qUser)
			.where(qOrganisation.id.eq(orgId))
			.select(NestedProjection.of(ZugriffEntity.class, 
				qZugriff.id,
				qZugriff.version,
				qZugriff.accessLevel,
				qZugriff.fromDate,
				qZugriff.toDate,
				qOrganisation.id,
				qUser.eid,
				qUser.vorname,
				qUser.familienname,
				qUser.email))
			.orderBy(qZugriff.user.eid.asc())
			.fetch();
	}

	@Override
	public void deleteUserOforganisation(@Valid ZugriffEntity zugriffEntity) {
		zugriffRepo.delete(zugriffEntity);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public EinladungEntity findEinladungByIdAndOrgId(long orgId, long id) {
		return new JPAQuery<EinladungEntity>(em).from(QEinladungEntity.einladungEntity)
			.innerJoin(QEinladungEntity.einladungEntity.organisation, QOrganisationEntity.organisationEntity)
			.fetchJoin().where(QEinladungEntity.einladungEntity.id.eq(id)
				.and(QEinladungEntity.einladungEntity.organisation.id.eq(orgId)))
			.fetchOne();
	}	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public OrganisationEntity loadOrganisationForEDC(long orgId) {
		OrganisationEntity organisation = 
			new JPAQuery<OrganisationEntity>(em).from(QOrganisationEntity.organisationEntity)
				.leftJoin(QOrganisationEntity.organisationEntity.domizil).fetchJoin()
				.leftJoin(QOrganisationEntity.organisationEntity.pflichtenabklaerungen).fetchJoin()
				.leftJoin(QOrganisationEntity.organisationEntity.kommGes).fetchJoin()
				.leftJoin(QOrganisationEntity.organisationEntity.flowHistory).fetchJoin()
				.where(QOrganisationEntity.organisationEntity.id.eq(orgId)).fetchOne();

		jpaUtil.initialize(organisation, 
			QOrganisationEntity.organisationEntity.pflichtenabklaerungen.branches,
			QOrganisationEntity.organisationEntity.pflichtenabklaerungen.beruf,
			QOrganisationEntity.organisationEntity.branches.any().standardText.translations,
			QOrganisationEntity.organisationEntity.geschaeftsstellens.any().adresse,
			QOrganisationEntity.organisationEntity.namens,
			QOrganisationEntity.organisationEntity.flowHistory.items.any().data
		);
		
		jpaUtil.initialize(organisation.getPflichtenabklaerungen(), 
				QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.beruf.standardText.translations,
				QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.branches.any().standardText.translations);

		if (organisation.getRechtsform() == RechtsformEnum.KOMMGES) {
			jpaUtil.initialize(organisation, QOrganisationEntity.organisationEntity.kommGes.kommFirmas.any().einlage.standardText.translations);
		}
		return organisation;
	}

	@Override
	public Set<GeschaftsrolleEntity> loadEDCRollen(long orgId) {
		
		QGeschaftsrolleEntity qGeschaftsrolle = QGeschaftsrolleEntity.geschaftsrolleEntity;
		QPersonEntity qPerson = new QPersonEntity("person");
		
		List<GeschaftsrolleEntity> rollens = new JPAQuery<GeschaftsrolleEntity>(em)
			.from(qGeschaftsrolle)
			.join(QGeschaftsrolleEntity.geschaftsrolleEntity.person).fetchJoin()
			.where(qGeschaftsrolle.organisation.id.eq(orgId)
				.and(qGeschaftsrolle.typ.eq(GeschaeftsrolleTypEnum.EDC)))
				.fetch();
		
		// TODO [COH / S9] To find out another way to initialize this list better.
		for (GeschaftsrolleEntity rollen : rollens) {
			jpaUtil.initialize(rollen,
				qGeschaftsrolle.einlage.standardText.translations,
				qGeschaftsrolle.funktion.standardText.translations,
				qGeschaftsrolle.haftung.standardText.translations,
				qGeschaftsrolle.zeichnung.standardText.translations);
			
			jpaUtil.initialize(rollen.getPerson(), 
				qPerson.wohnadresse.land,
				qPerson.auslaenderAusweis.standardText.translations,
				qPerson.anrede.standardText.translations,
				qPerson.zivilstand.standardText.translations,
				qPerson.heimatortes,
				qPerson.nationalitaetens.any().standardText.translations);
		}
		
		return rollens.stream().collect(Collectors.toSet());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public OrganisationEntity updateOrganisation(OrganisationEntity organisationEntity) {
		return updateRelevantDataWhenOrgCompleted(organisationEntity);
	}

	@Override
	public OrganisationEntity saveCompletedOrganisationWithValidation(OrganisationEntity organisationEntity) {
		return orgRepo.save(organisationEntity);
	}

	@Override
	public OrganisationEntity confirmRechsform(OrganisationEntity organisationEntity) {
		
		List<ProzessTypEnum> autoCreatedProzessTypes = ProzessTypEnum.autoCreatedProzessType();
		
		long count = new JPAQuery<ProzessEntity>(em)
		.from(QProzessEntity.prozessEntity)
		.where(QProzessEntity.prozessEntity.organisation.id.eq(organisationEntity.getId())
			.and(QProzessEntity.prozessEntity.typ.in(autoCreatedProzessTypes)))
		.fetchCount();
		
		if (count > 0) {
			throw new OssTechnicalException("There's a problem with application logic. The auto created process is created twice which is not expected.");
		}
		
		OrganisationEntity organisation = updateOrganisation(organisationEntity);
		
		// TODO [COH / S9] TO check why we need this initialize query
		jpaUtil.initialize(organisation, QOrganisationEntity.organisationEntity.geschaeftsstellens.any().adresse);

		for (ProzessTypEnum prozessTypEnum : autoCreatedProzessTypes) {
			switch (prozessTypEnum) {
				case HR:
					hrService.createProcess(organisation);
					break;
				case AHV:
					ahvService.createProcess(organisation);
					break;
				case MWST:
					mwstService.createProcess(organisation);
					break;
				case UVG:
					uvgService.createProcess(organisation);
					break;
				default:
					throw new IllegalArgumentException("Unsupport create process for type : " + prozessTypEnum);
			}
		}

		return organisation;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public AdresseEntity getAdresse(long addressId) {
		return new JPAQuery<AdresseEntity>(em).from(QAdresseEntity.adresseEntity)
			.where(QAdresseEntity.adresseEntity.id.eq(addressId)).fetchOne();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PersonEntity getPerson(long personId) {
		return jpaUtil.initialize(personRepo.findOne(personId), QPersonEntity.personEntity.anrede,
			QPersonEntity.personEntity.zivilstand, QPersonEntity.personEntity.nationalitaetens.any().standardText.translations,
			QPersonEntity.personEntity.heimatortes, QPersonEntity.personEntity.wohnadresse,
			QPersonEntity.personEntity.auslaenderAusweis);
	}	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public GeschaftsrolleEntity findGeschaftsrolleByIdAndOrgId(long orgId, long id, int version) {
		return jpaUtil.initialize(new JPAQuery<GeschaftsrolleEntity>(em)
			.from(QGeschaftsrolleEntity.geschaftsrolleEntity)
			.join(QGeschaftsrolleEntity.geschaftsrolleEntity.organisation, QOrganisationEntity.organisationEntity).fetchJoin()
			.join(QGeschaftsrolleEntity.geschaftsrolleEntity.person, QPersonEntity.personEntity).fetchJoin()
			.where(
				QGeschaftsrolleEntity.geschaftsrolleEntity.id.eq(id)
				.and(QGeschaftsrolleEntity.geschaftsrolleEntity.organisation.id.eq(orgId)
				.and(QGeschaftsrolleEntity.geschaftsrolleEntity.version.eq(version)))
			)
			.fetchOne(),
			QGeschaftsrolleEntity.geschaftsrolleEntity.person.heimatortes,
			QGeschaftsrolleEntity.geschaftsrolleEntity.person.wohnadresse);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public AdresseEntity saveAdresse(AdresseEntity address) {
		return addressRepo.save(address);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public OrganisationEntity getOrganisation(long orgId, Path<?>... associations) {
		OrganisationEntity org = orgRepo.findOne(orgId);
		if (associations == null) {
			return org;
		}
		return jpaUtil.initialize(org, associations);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public KommGesEntity loadEDCKommGes(long orgId) {

		QKommGesEntity qKommGes = QKommGesEntity.kommGesEntity;
		QKommFirmaEntity qFirma = new QKommFirmaEntity("firma");

		KommGesEntity kommGes = new JPAQuery<KommGesEntity>(em)
			.from(qKommGes)
			.leftJoin(QKommGesEntity.kommGesEntity.kommFirmas).fetchJoin()
			.where(qKommGes.organisation.id.eq(orgId))
			.fetchOne();

		// TODO [COH / S9] To find out another way to initialize this list better.
		//kommGes.getKommFirmas().stream().map(firma -> jpaUtil.initialize(firma, qFirma.einlage.standardText.translations, qFirma.domizil.land));
		for (KommFirmaEntity firma : kommGes.getKommFirmas()) {
			jpaUtil.initialize(firma, qFirma.einlage.standardText.translations, qFirma.domizil.land);
		}
		return kommGes;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public KommFirmaEntity findKommFirmaByIdAndOrgId(long orgId, long id, int version) {
		return new JPAQuery<KommFirmaEntity>(em)
			.from(QKommFirmaEntity.kommFirmaEntity)
			.join(QKommFirmaEntity.kommFirmaEntity.kommges, QKommGesEntity.kommGesEntity)
			.join(QKommGesEntity.kommGesEntity.organisation, QOrganisationEntity.organisationEntity)
			.where(QKommGesEntity.kommGesEntity.organisation.id.eq(orgId)
				.and(QKommFirmaEntity.kommFirmaEntity.id.eq(id)
					.and(QKommFirmaEntity.kommFirmaEntity.version.eq(version))))
			.fetchOne();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public OrganisationEntity deleteKommFirma(long orgId, KommFirmaEntity kommFirmaEntity) {
		OrganisationEntity orgEntity = getOrganisation(orgId);
		orgEntity = updateRelevantDataWhenOrgCompleted(orgEntity);
		kommFirmaRepo.delete(kommFirmaEntity);
		return orgEntity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public KommFirmaEntity saveKommFirma(long orgId, KommFirmaEntity kommFirmaEntity) {
		OrganisationEntity orgEnt = getOrganisation(orgId);
		orgEnt = updateRelevantDataWhenOrgCompleted(orgEnt);
		KommFirmaEntity updatedkommFirmaEntity = kommFirmaRepo.save(kommFirmaEntity);
		updatedkommFirmaEntity.getKommges().setOrganisation(orgEnt);
		return updatedkommFirmaEntity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public GeschaeftsstelleEntity findGeschaeftsstellenByIdAndOrgId(long orgId, long id) {
		return jpaUtil.initialize(
			new JPAQuery<GeschaeftsstelleEntity>(em).from(QGeschaeftsstelleEntity.geschaeftsstelleEntity)
				.where(QGeschaeftsstelleEntity.geschaeftsstelleEntity.id.eq(id)
					.and(QGeschaeftsstelleEntity.geschaeftsstelleEntity.organisation.id.eq(orgId)))
				.fetchOne(),
			QGeschaeftsstelleEntity.geschaeftsstelleEntity.adresse);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public GeschaeftsstelleEntity saveGeschaeftsstellen(OrganisationEntity org, GeschaeftsstelleEntity ges) {
		ges.setOrganisation(org);
		ges = geschaeftsstelleRepo.save(ges);
		ahvService.createAhvFiliale(ges);
		return ges;
	}

	@Override
	public void deleteGeschaeftsstellen(long orgId, GeschaeftsstelleEntity ges) {
		AhvFilialeEntity filiale = new JPAQuery<AhvFilialeEntity>(em)
				.from(QAhvFilialeEntity.ahvFilialeEntity)
				.where(QAhvFilialeEntity.ahvFilialeEntity.geschaeftsstelle.id.eq(ges.getId()))
				.fetchOne();
		filialeRepository.delete(filiale);
		geschaeftsstelleRepo.delete(ges);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public GeschaeftsstelleEntity findGeschaeftsstellenByIdAndOrgId(long orgId, long id, int version) {
		return new JPAQuery<GeschaeftsstelleEntity>(em).from(QGeschaeftsstelleEntity.geschaeftsstelleEntity)
			.where(QGeschaeftsstelleEntity.geschaeftsstelleEntity.id.eq(id)
				.and(QGeschaeftsstelleEntity.geschaeftsstelleEntity.organisation.id.eq(orgId)
					.and(QGeschaeftsstelleEntity.geschaeftsstelleEntity.version.eq(version))))
			.fetchOne();
	}

	@Override
	public GeschaftsrolleEntity saveUnvalidatedGeschaftsrolle(GeschaftsrolleEntity ent, RechtsformEnum rechtsform) {
		ent.setOrganisation(updateRelevantDataWhenOrgCompleted(ent.getOrganisation()));
		return internalSaveUnvalidatedGeschaftsrolle(ent, rechtsform);
	}

	@Override
	public GeschaftsrolleEntity saveValidatedGeschaftsrolle(GeschaftsrolleEntity ent) {
		return super.internalSaveValidatedGeschaftsrolle(ent);
	}
	
	@Override
	public GeschaftsrolleEntity editUnvalidatedGeschaftsrolle(GeschaftsrolleEntity ent) {
		return geschaftsrolleRepository.save(ent);
	}

	@Override
	public OrganisationEntity deleteGeschaftsrolle(GeschaftsrolleEntity geschaftsrolleEntity) {
		updateRelevantDataWhenOrgCompleted(geschaftsrolleEntity.getOrganisation());
		super.internalDeleteGeschaftsrolle(geschaftsrolleEntity);
		return getOrganisation(geschaftsrolleEntity.getOrganisation().getId());
	}

	// SECOOSS-285 : [EDC] Update related process status to "ON-GOING" + clear process flow history when update data company
	public OrganisationEntity updateRelevantDataWhenOrgCompleted(OrganisationEntity organisation) {
		if (!organisation.isBaseDataComplete() 
				|| (organisation.isBaseDataComplete() && organisation.isBaseDataLocked())) { 
			return orgRepo.save(organisation);
		}
		
		organisation.setBaseDataComplete(false);
		List<ProzessEntity> prozessEnts = new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity)
			.join(QProzessEntity.prozessEntity.flowHistory).fetchJoin()
			.where(QProzessEntity.prozessEntity.status.eq(ProzessStatusEnum.BEARBEITUNG)
				.or(QProzessEntity.prozessEntity.status.eq(ProzessStatusEnum.KOMPLETT))
				.and(QProzessEntity.prozessEntity.organisation.id.eq(organisation.getId())))
			.fetch();
		prozessEnts = jpaUtil.initialize(prozessEnts, QProzessEntity.prozessEntity.flowHistory.items);
		prozessEnts.stream().forEach(prozessEnt -> {
			prozessEnt.getFlowHistory().getItems().clear();
			processUpdated(prozessEnt);
		});
		return orgRepo.save(organisation);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public CheckNameResult validateOrganisationName(long orgId, Long hrMutationId, String name, SupportedLanguage language, 
		CheckCompanyNameSourceEnum source) {
		
		OrganisationEntity organisation = getOrganisation(orgId, QOrganisationEntity.organisationEntity.geschaeftsrollens.any().person);
		
		switch (organisation.getRechtsform()) {
			case AG:
				return validateOrganisationNamePattern(name, AG_MUST_HAVE_REGEX, AG_MUST_NOT_HAVE_REGEXES, language);
			case GMBH:
				return validateOrganisationNamePattern(name, GMBH_MUST_HAVE_REGEX, GMBH_MUST_NOT_HAVE_REGEXES, language);
			case KOMMGES:
			case KOLLGES:
				// SECOOSS-661 [HRMutation] First Finding in Sprint 9
				// BUG New company name is not checked according to the rules of an EF legal form company. 
				// Here we need to check that the new company name contains the family name of the new owner. 
				// Because in this use case we have just entered the name of the owner. 
				if (source == CheckCompanyNameSourceEnum.HR_MUTATION_DISOLUTION) {
					HrMutationEntity hrMutation = hrMutationRepo.findOne(QHrMutationEntity.hrMutationEntity.id.eq(hrMutationId));
					String ownerFamilyName = null;
					GeschaftsrolleEntity dissNewOwner = hrMutation.getDissNewOwner();
					if (dissNewOwner != null) {
						ownerFamilyName = dissNewOwner.getPerson().getFamilienname().trim();
					}
					if (!StringUtils.containsIgnoreCase(" " + name + " ", " " + ownerFamilyName + " ")) {
						return new CheckNameResult(null, applicationService.getTranslation("gui_messages.error.gdfName.companyName.Ef", language));
					}
				}
				String[] mustNotHaveRegexes = organisation.getRechtsform() == RechtsformEnum.KOLLGES ? KOLL_MUST_NOT_HAVE_REGEXES : KOMM_MUST_NOT_HAVE_REGEXES;
				return validateOrganisationNamePattern(name, null, mustNotHaveRegexes, language);
			case EINZELFIRMA:
				// SECOOSS-661 : [HRMutation] First Finding in Sprint 9
				// IMPROVEMENT EF legal form: in the "Grundregeln" check, please disable the check for the family name of the owner. 
				// Reason: it is very likely that we either don't know the owner or that the known owner data is not up-to-date
				if (source == CheckCompanyNameSourceEnum.EDC) {					
					String ownerFamilyName = organisation.getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)
						.stream().findFirst().get().getPerson().getFamilienname().trim();
					if (!StringUtils.containsIgnoreCase(" " + name + " ", " " + ownerFamilyName + " ")) {
						return new CheckNameResult(null, applicationService.getTranslation("gui_messages.error.gdfName.companyName.Ef", language));
					}
				}
				return validateOrganisationNamePattern(name, null, EF_MUST_NOT_HAVE_REGEXES, language);
			default:
				throw new IllegalStateException("Unknown Rechtsform type:" + organisation.getRechtsform());
		}
	}

	private CheckNameResult validateOrganisationNamePattern(String companyName, String mustHaveRegex, String[] mustNotHaveRegexes, SupportedLanguage language) {
		Perl5Util perl5Util = new Perl5Util();
		if (mustHaveRegex != null && !perl5Util.match(mustHaveRegex, companyName)) {
			String error = applicationService.getTranslation("gui_messages.error.gdfName.companyName.AgOrGmbh", language);
			return new CheckNameResult(null, error);
		}
		if (mustNotHaveRegexes != null) {
			for (String mustNotHaveRegex : mustNotHaveRegexes) {
				if (perl5Util.match(mustNotHaveRegex, companyName)) {
					String[] params = new String[] { "word" };
					String[] values = new String[] { StringUtils.remove(StringUtils.remove(companyName, perl5Util.preMatch()), perl5Util.postMatch()) };
					String warn = applicationService.getTranslation("gui_messages.warn.gdfName.companyName.conflictWord", params, values, language);
					return new CheckNameResult(warn, null);
				}
			}
		}
		String invalidCharacter = findInvalidCharacter(companyName);
		if (invalidCharacter != null) {
			String[] params = new String[] { "character" };
			String[] values = new String[] { invalidCharacter };
			String error = applicationService.getTranslation("gui_messages.error.gdfName.companyName.invalidCharacter", params, values, language);
			return new CheckNameResult(null, error);
		}
		return new CheckNameResult(); 
	}

	private String findInvalidCharacter(String organisationName) {
		for (char character : organisationName.toCharArray()) {
			String charToCheck = "" + character;
			if (!ArrayUtils.contains(HR_VALID_CHARS, charToCheck)) {
				return charToCheck;
			}
		}
		return null;
	}

	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public KommFirmaEntity getKommFirma(long id, Path<?>... associations) {
		KommFirmaEntity entity = new JPAQuery<KommFirmaEntity>(em)
			.from(QKommFirmaEntity.kommFirmaEntity)
			.where(QKommFirmaEntity.kommFirmaEntity.id.eq(id))
			.fetchOne();
		if (associations != null) {
			return jpaUtil.initialize(entity, associations);
		}
		return entity;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public OrganisationEntity getOrganisationForPflichtenabklaerungen(long orgId) {
		return jpaUtil.initialize(orgRepo.findOne(orgId),
			QOrganisationEntity.organisationEntity.flowHistory.items.any().data);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public KontoEntity saveKonto(KontoEntity ent, long orgId) {
		return kontoRepo.save(ent);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public KontoEntity getKontoById(long id, long orgId) {
		return kontoRepo.findOne(id);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public long countCodOfUser() {
		return new JPAQuery<QPflichtenabklaerungenEntity>(em)
			.from(QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity)
			.join(QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.user)
			.where(QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.user.eid.eq(SecurityUtil.currentUser().getUsername()))
			.fetchCount();
	}

	@Override
	protected IAhvService getAhvService() {
		return this.ahvService;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public PflichtenabklaerungenEntity getPflichtenabklaerungenOfOganisation(long orgId) {
		return new JPAQuery<PflichtenabklaerungenEntity>(em)
			.from(QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity)
			.where(QPflichtenabklaerungenEntity.pflichtenabklaerungenEntity.organisation.id.eq(orgId))
			.fetchOne();
	}
	
	@Override
	public void markProcessExternal(long orgId, PflichtenabklaerungenEntity pflichtenabklaerungen) {
		pflichRepo.save(pflichtenabklaerungen);
		List<ProzessEntity> prozesses = new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.organisation.id.eq(orgId)
				.and(QProzessEntity.prozessEntity.typ.ne(ProzessTypEnum.HR)))
			.fetch();
		Map<ProzessTypEnum, ProzessStatusEnum> statuOfAllProzess = getStatuOfAllProzessByOrgId(orgId);
		prozesses.stream().forEach(prozess -> {
			if (statuOfAllProzess.get(prozess.getTyp()) != ProzessStatusEnum.GESENDET) {
				markProcessExternal(prozess, pflichtenabklaerungen);
			}
		});
	}
	
	private void markProcessExternal(ProzessEntity prozess, PflichtenabklaerungenEntity pflichtenabklaerungen) {
		switch (prozess.getTyp()) {
			case AHV:
				ahvService.markProcessExternal(prozess, pflichtenabklaerungen.isAnmeldungAHV());
				break;
			case MWST:
				mwstService.markProcessExternal(prozess, pflichtenabklaerungen.isAnmeldungMWST());
				break;
			case UVG:
				uvgService.markProcessExternal(prozess, pflichtenabklaerungen.isAnmeldungUVG());
				break;
			case HR:
			default:
				throw new UnsupportedOperationException("Does not support to mark external process of type : " + prozess.getTyp());
		}
	}
	
	@Override
	public OrganisationEntity getDomizilOfAllPersons(long orgId) {
		jpaUtil.enableFetchProfile("organisation-with-geschaeftsrollens-and-domizil");
		jpaUtil.enableFetchProfile("geschaeftsrollen-with-person-and-funktion");
		jpaUtil.enableFetchProfile("person-with-wohnadresse");
		jpaUtil.enableFetchProfile("adresse-with-land");

		OrganisationEntity entity = orgRepo.findOne(orgId);

		jpaUtil.disableFetchProfile("organisation-with-geschaeftsrollens-and-domizil");
		jpaUtil.disableFetchProfile("geschaeftsrollen-with-person-and-funktion");
		jpaUtil.disableFetchProfile("person-with-wohnadresse");
		jpaUtil.disableFetchProfile("adresse-with-land");

		return entity;
	}

	@Override
	public AdresseEntity getOrgDomizil(long orgId) {
		return jpaUtil.initialize(orgRepo.findOne(orgId), QOrganisationEntity.organisationEntity.domizil.land)
			.getDomizil();
	}

	@Override
	public FileDto downloadProzessPdf(long prozessId) {
		return new FileDto("document.pdf", SupportedFileTypeDownload.PDF, getDocument(prozessId));
	}
	
	private byte[] getDocument(long prozessId) {
		return new JPAQuery<>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.id.eq(prozessId))
			.select(QProzessEntity.prozessEntity.pdf)
			.fetchFirst();
	}
	
	@Override
	public DigitalSignatureDto getDigitalSignees(long prozessId) {
		DigitalSignatureDto result = new DigitalSignatureDto();
		String digitalSignees = new JPAQuery<String>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.id.eq(prozessId))
			.select(QProzessEntity.prozessEntity.digitalSignees)
			.fetchFirst();
		result.setDigitalSignees(digitalSignees);
		return result;
	}

	@Override
	public DigitalSignatureDto updateSignedProzessPdf(byte[] signedPdf, long prozessId) {
		DigitalSignatureDto result = new DigitalSignatureDto();
		ProzessEntity prozessEnt = new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.id.eq(prozessId))
			.fetchOne();
		byte[] pdf = prozessEnt.getPdf();
		
		if (!PdfBoxUtil.compareContentPdf(pdf, signedPdf)) {
			result.setSignResult(SignResultEnum.MODIFIED);
			return result;
		}

		List<PDSignatureField> signaturesInRaw = null;
		List<PDSignatureField> signaturesInSubmit = null;

		try {
			signaturesInRaw = PdfBoxUtil.getSignatureFields(pdf);
			signaturesInSubmit = PdfBoxUtil.getSignatureFields(signedPdf);
			
			if (signaturesInSubmit.isEmpty() || signaturesInRaw.size() == signaturesInSubmit.size()) {
				result.setSignResult(SignResultEnum.UNSIGNED);
				return result;
			}
			
			if(!PdfBoxUtil.validateSignatures(pdf, signedPdf)) {
				result.setSignResult(SignResultEnum.OUTDATED);
				return result;
			}
			
		} catch (IOException e) {
			throw new OssTechnicalException("Could not validate the submit file", e);
		}
		
		result.setSignResult(SignResultEnum.SUCCESS);
		List<String> signees = PdfBoxUtil.extractSignees(signaturesInSubmit);
		String digitalSignees = StringUtils.join(signees, ", ");
		result.setDigitalSignees(digitalSignees);
		prozessEnt.setPdf(signedPdf);
		prozessEnt.setDigitalSignees(digitalSignees);
		prozessRepository.save(prozessEnt);
		
		return result;
	}
	
	@Override
	public ExistingOrgSearchResultDto getExistingOrgsByUid(String uid) {

		List<ExistingOrgInfoDto> zefixes = searchFromZefix(uid, true);

		if (zefixes.size() == 0) {
			List<ExistingOrgInfoDto> startbizes = searchFromStartBizData(uid, true, null);
			zefixes.addAll(startbizes);
		}

		ExistingOrgSearchResultDto result = new ExistingOrgSearchResultDto();
		result.getOrgs().addAll(
			zefixes.stream().sorted((o1, o2) -> o1.getName().compareTo(o2.getName())).collect(Collectors.toList()));
		result.setTotalCount(Long.valueOf(result.getOrgs().size()));

		return result;
	}

	@Override
	public ExistingOrgSearchResultDto getExistingOrgsByNonUid(String nameOrEmail) {

		List<ExistingOrgInfoDto> zefixes = searchFromZefix(nameOrEmail, false);

		List<String> foundUids = zefixes.stream().map(z -> z.getUid()).collect(Collectors.toList());

		List<ExistingOrgInfoDto> startbizes = searchFromStartBizData(nameOrEmail, false, foundUids);

		zefixes.addAll(startbizes);

		ExistingOrgSearchResultDto result = new ExistingOrgSearchResultDto();
		result.getOrgs().addAll(
			zefixes.stream().sorted((o1, o2) -> o1.getName().compareTo(o2.getName())).collect(Collectors.toList()));
		result.setTotalCount(Long.valueOf(result.getOrgs().size()));

		return result;
	}
	
	private List<ExistingOrgInfoDto> searchFromZefix(String criterion, boolean isUid) {
		ShortResponseDto shortDto = new ShortResponseDto();
		if (isUid) {
			try {
				DetailledResponseDto detailDto = zefixServiceAdapter.getCompanyDetail(criterion);
				for (CompanyDetailedInfoDto companyInfo : detailDto.getCompanyDetailedInfo()) {
					CompanyShortInfoDto companyInfoDto = mapper.map(companyInfo, CompanyShortInfoDto.class);
					companyInfoDto.setAddress(companyInfo.getAddress());
					shortDto.getCompanyShortInfo().add(companyInfoDto);
				}
			} catch (ZefixInvalidCHIdException | ZefixInvalidUIDException | ZefixBusinessException e) {
				LOGGER.warn("An exception occurred when calling Zefix", e);
			}
		} else {
			try {
				shortDto = zefixServiceAdapter.searchCompanyByName(criterion, null, null);
			} catch (ZefixTooShortNameException | ZefixTooManyResultsException | ZefixBusinessException e) {
				LOGGER.warn("An exception occurred when calling Zefix", e);
			}
		}

		List<ExistingOrgInfoDto> zefixes = shortDto.getCompanyShortInfo().stream()
			.map(z -> {
				ExistingOrgInfoDto dto = new ExistingOrgInfoDto(convertShortUidToFullUid(String.valueOf(z.getUid())), z.getName(),
					OSSConstants.EMPTY_STRING, PlaceToFindEnum.ZEFIX);
				dto.setCity((z.getAddress() != null ? z.getAddress().getTown() : OSSConstants.EMPTY_STRING));
				return dto;
			}).collect(Collectors.toList());
		return zefixes;
	}
	
	private List<ExistingOrgInfoDto> searchFromStartBizData(String criterion, boolean isUid,
		List<String> excludedUids) {
		List<StartBizDataEntity> resultFromStartbiz = isUid ? getOrgsByUidFromStartBizData(criterion)
			: getOrgsByNameOrEmailFromStartBizData(criterion, excludedUids);
		List<ExistingOrgInfoDto> startbizes = resultFromStartbiz.stream()
			.map(s -> new ExistingOrgInfoDto(s.getId(), s.getUid(),
				s.getCompanyName(), s.getCity(), PlaceToFindEnum.STARTBIZ)).collect(Collectors.toList());
		return startbizes;
	}
	
	private List<StartBizDataEntity> getOrgsByUidFromStartBizData(String uid) {
		return (List<StartBizDataEntity>) startBizRepo
			.findAll(QStartBizDataEntity.startBizDataEntity.uid.eq(convertShortUidToFullUid(uid)));
	}

	private String convertShortUidToFullUid(String uid) {
		String[] uidParts = uid.split(SPLIT_UID_PATTERN);
		String formattedUid = PREFIX_UID_PATTERN;
		for (int i = 0; i < uidParts.length; i++) {
			formattedUid += i == 0 ? uidParts[i] : UID_SEPERATOR_CHARACTER + uidParts[i];
		}
		return formattedUid;
	}
	
	private List<StartBizDataEntity> getOrgsByNameOrEmailFromStartBizData(String nameOrEmail, List<String> excludedUids) {
		String searchExpression = "%".concat(nameOrEmail.replaceAll("[\\s|'|-]", "%")).concat("%");
		
		JPAQuery<StartBizDataEntity> query = new JPAQuery<StartBizDataEntity>(em)
			.from(QStartBizDataEntity.startBizDataEntity)
			.where(
				(QStartBizDataEntity.startBizDataEntity.companyName.likeIgnoreCase(searchExpression)
					.or(QStartBizDataEntity.startBizDataEntity.email.likeIgnoreCase(searchExpression)))
				.and(QStartBizDataEntity.startBizDataEntity.organisation.isNull())
			);
		
		if (CollectionUtils.isNotEmpty(excludedUids)) {
			query.where(QStartBizDataEntity.startBizDataEntity.uid.isNull()
				.or(QStartBizDataEntity.startBizDataEntity.uid.notIn(excludedUids)));
		}
		
		return query.fetch();
	}	

	@Override
	public StartBizDataEntity getStartBizDataById(Long id) {
		return startBizRepo.findOne(id);
	}

	@Override
	public Map<ProzessTypEnum, ProzessStatusEnum> getStatuOfAllProzessByOrgId(Long orgId) {
		Map<ProzessTypEnum, ProzessStatusEnum> res = new HashMap<ProzessTypEnum, ProzessStatusEnum>();
		new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.organisation.id.eq(orgId))
			.select(QProzessEntity.prozessEntity.typ, QProzessEntity.prozessEntity.status)
			.fetch()
			.stream().forEach(r -> {
				res.put(r.get(QProzessEntity.prozessEntity.typ), r.get(QProzessEntity.prozessEntity.status));
			});
		return res;
	}
}