/*
 * GeschaeftsstellenDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.CommonAddress;

/**
 * @author tdm
 *
 */
public class GeschaeftsstellenDto extends AbstractOSSDto {
	
	private long orgId;

	@Valid
	@NotNull(groups = CommonAddress.class)
	private AdresseDto adresse;

	private boolean inHR;

	public AdresseDto getAdresse() {
		return adresse;
	}

	public void setAdresse(AdresseDto adresse) {
		this.adresse = adresse;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public boolean isInHR() {
		return inHR;
	}

	public void setInHR(boolean inHR) {
		this.inHR = inHR;
	}
}
