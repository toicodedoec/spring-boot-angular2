/*
 * ProzessEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.util.DataUtil;

/**
 * @author coh
 *
 */
@Audited
@Entity
@Table(name = "T_PROZESS")
public class ProzessEntity extends AbstractOSSEntity {

	@ManyToOne(fetch = FetchType.LAZY, cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name="FK_PROZESS_ORGANISATION"))
	private OrganisationEntity organisation;
	
	@Column(name = "START_DATUM")
	private LocalDateTime startDatum;
	
	@Column(name = "BEARB_DATUM")
	private LocalDateTime bearbdatum;
	
	@Column(name = "LOCKED", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean locked;
	
	@Column(name = "COMPLETED", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean completed;
	
	@NotNull
	@Column(name = "STATUS", nullable = false)
	@Enumerated(EnumType.STRING)
	private ProzessStatusEnum status;
	
	@NotNull
	@Column(name = "TYP", nullable = false)
	@Enumerated(EnumType.STRING)
	private ProzessTypEnum typ;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@OneToOne(fetch = FetchType.LAZY, optional = true, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_FLOW_HISTORY", foreignKey = @ForeignKey(name = "FK_PROZESS_HISTORY"))
	private FlowHistoryEntity flowHistory;

	@Column(name = "PDF", columnDefinition = "BLOB")
    @Lob
	private byte[] pdf;

	@NotNull
	@Column(name = "\"UID\"", nullable = false)
	private String uid;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "prozess", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<StatuswechselEntity> statuswechsels = new HashSet<>();
	
	@Column(name = "DIGITAL_SIGNEES")
	private String digitalSignees;

	public ProzessEntity() {
		// default constructor
	}

	public ProzessEntity(ProzessTypEnum typ, Boolean storeHistory) {
		if(storeHistory) {
			this.setFlowHistory(new FlowHistoryEntity());
		}		
		this.typ = typ;
		status = ProzessStatusEnum.INITIAL;
		startDatum = LocalDateTime.now();
		bearbdatum = LocalDateTime.now();
		uid = DataUtil.getUID(startDatum);
	}
	
	public ProzessEntity(ProzessTypEnum typ, Boolean storeHistory, OrganisationEntity organisation) {
		this(typ, storeHistory);
		this.organisation = organisation;
	}

	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public LocalDateTime getStartDatum() {
		return startDatum;
	}

	public void setStartDatum(LocalDateTime startDatum) {
		this.startDatum = startDatum;
	}

	public LocalDateTime getBearbdatum() {
		return bearbdatum;
	}

	public void setBearbdatum(LocalDateTime bearbdatum) {
		this.bearbdatum = bearbdatum;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public ProzessStatusEnum getStatus() {
		return status;
	}

	public void setStatus(ProzessStatusEnum status) {
		this.status = status;
	}

	public ProzessTypEnum getTyp() {
		return typ;
	}

	public void setTyp(ProzessTypEnum typ) {
		this.typ = typ;
	}

	public FlowHistoryEntity getFlowHistory() {
		return flowHistory;
	}

	public void setFlowHistory(FlowHistoryEntity flowHistory) {
		this.flowHistory = flowHistory;
	}

	public byte[] getPdf() {
		return pdf;
	}

	public void setPdf(byte[] pdf) {
		this.pdf = pdf;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public Set<StatuswechselEntity> getStatuswechsels() {
		return statuswechsels;
	}

	public void setStatuswechsels(Set<StatuswechselEntity> statuswechsels) {
		this.statuswechsels = statuswechsels;
	}

	public String getDigitalSignees() {
		return digitalSignees;
	}

	public void setDigitalSignees(String digitalSignees) {
		this.digitalSignees = digitalSignees;
	}
}
