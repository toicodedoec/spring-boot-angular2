/*
 * PublicPortalServiceTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.business.AbstractOSSTest;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.organisation.repository.ICodeWertRepository;
import ch.admin.oss.organisation.repository.IFirmennameRepository;
import ch.admin.oss.organisation.repository.IOrganisationRepository;
import ch.admin.oss.organisation.repository.IPflichtenabklaerungenRepository;
import ch.admin.oss.organisation.repository.IZugriffRepository;
import ch.admin.oss.portal.repository.IProzessRepository;
import ch.admin.oss.portal.repository.IStatuswechselRepository;
import ch.admin.oss.portal.repository.IUserRepository;

/**
 * @author xdg
 */
@Ignore
@ActiveProfiles(CommonConstants.PROFILE_TEST)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Transactional
public class PortalServiceTest extends AbstractOSSTest {

	@Autowired
	IPortalService portalService;

	@Autowired
	IOrganisationRepository orgRepo;

	@Autowired
	IUserRepository userRepo;

	@Autowired
	IFirmennameRepository firmenNameRepo;

	@Autowired
	IZugriffRepository zugriffRepo;

	@Autowired
	IPflichtenabklaerungenRepository pflichtenRepo;

	@Autowired
	ICodeWertRepository codeWertRepo;

	@Autowired
	IStatuswechselRepository statusRepo;

	@Autowired
	IProzessRepository prozessRepo;
	
	@Autowired
	IApplicationService appService;

	@PersistenceContext
	private EntityManager em;
	
}
