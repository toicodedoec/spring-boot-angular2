/*
 * HRServiceEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.ahv.endpoint;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ch.admin.oss.admin.endpoint.AusgleichskasseDto;
import ch.admin.oss.admin.endpoint.VerbandDto;
import ch.admin.oss.ahv.service.IAhvService;
import ch.admin.oss.common.AbstractProzessEndpoint;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.ExceptionHandlingController;
import ch.admin.oss.common.GeschaftsrolleDto;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.AhvVerbandszugehoerigkeitEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AhvAnmeldungEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyDetailedInfoDto;
import ch.admin.oss.portal.endpoint.BrancheDto;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OSSDateUtil;

/**
 * @author hhg
 */
@CrossOrigin
@RestController
@RequestMapping("/private/ext/ahv")
public class AHVServiceEndpoint extends AbstractProzessEndpoint<AhvAnmeldungDto> {
	
	/**
	 * Dozer map ID for AhvTeilhaberDto -> AhvTeilhaberEntity
	 */
	public static final String AHV_TEILHABER = "AHV_TEILHABER";
	
	/**
	 * Dozer map exclude Prozess for AhvAnmeldungDto -> AhvAnmeldungEntity
	 */
	public static final String AHV_PROZESS = "AHV_PROZESS";

	@Autowired
	private IAhvService ahvService;

	@Override
	protected boolean isProcessDoneExternal(PflichtenabklaerungenEntity pflich) {
		return pflich != null && pflich.isAnmeldungAHV();
	}

	@Override
	public AhvAnmeldungDto getProcessByOrgId(@PathVariable long orgId) {
		AhvAnmeldungEntity ahvAnmeldung = ahvService.getByOrganisationId(orgId);
		AhvAnmeldungDto result = mapper.map(ahvAnmeldung, AhvAnmeldungDto.class);
		mapAhvAdditionalInfo(result, ahvAnmeldung);
		if (CollectionUtils.isNotEmpty(result.getProzess().getOrganisation().getBranches())) {
			result.getProzess().getOrganisation().setBranches(
					ahvAnmeldung.getProzess().getOrganisation().getBranches()
					.stream()
					.map(b -> new BrancheDto(b, SecurityUtil.currentUser().getLanguagePreference()))
					.collect(Collectors.toList())
				);
		}
		result.getProzess().getOrganisation().setAccessFromOutsideFlow(true);
		return result;
	}

	@Override
	public ResponseEntity<?> update(@RequestBody AhvAnmeldungDto dto) {
		return updateProzess(dto);
	}

	private ResponseEntity<?> updateProzess(AhvAnmeldungDto dto) {
		AhvAnmeldungEntity entity = ahvService.getByOrganisationId(dto.getProzess().getOrganisation().getId());
		// TODO [HHG, S9]: quick fix for saving trust address. Refactor: map the land by ID instead of an object
		CodeWertEntity land = null;
		if (entity.getAdresseTreuhand() != null) {
			land = entity.getAdresseTreuhand().getLand();
		}
		mapAhvAnmeldung(dto, entity);
		if (land != null && entity.getAdresseTreuhand() != null && entity.getAdresseTreuhand().getLand().getId() == null) {
			entity.getAdresseTreuhand().setLand(land);
		}
		return ResponseEntity.ok(mapper.map(ahvService.updateProcess(entity), AhvAnmeldungDto.class));
	}

	@Override
	public ResponseEntity<?> complete(@RequestBody AhvAnmeldungDto dto) {
//		List<String> errors = validateBusiness(dto);
//		if (CollectionUtils.isNotEmpty(errors)) {
//			return ResponseEntity
//				.status(HttpStatus.PRECONDITION_FAILED)
//				.body(ExceptionHandlingController.errorFor(StringUtils.join(errors, ". ")));
//		}
		AhvAnmeldungEntity entity = ahvService.getByOrganisationId(dto.getProzess().getOrganisation().getId());
		mapAhvAnmeldung(dto, entity);
		return ResponseEntity.ok(mapper.map(ahvService.completeProcess(entity), AhvAnmeldungDto.class));
	}

	/*
	 * Validate AHV business before completing the process. Returns a list of error message if any.
	 */
	private List<String> validateBusiness(AhvAnmeldungDto dto) {
		List <String> errors = new ArrayList<>();
		RechtsformEnum rechtsform = dto.getProzess().getOrganisation().getRechtsform();
		validateAhvAnmeldung(rechtsform, dto, errors);
		if (CollectionUtils.isNotEmpty(dto.getAhvTeilhabers())) {
			for (AhvTeilhaberDto teihaber : dto.getAhvTeilhabers()) {
				validateAhvPbisher(errors, teihaber);
				validateAhvPmitarbeit(errors, teihaber);
				validateAhvPrisk(errors, teihaber);
				validateAhvAngestellte(errors, rechtsform, teihaber);
			}
		}
		return errors;
	}

	private void validateAhvPrisk(List<String> errors, AhvTeilhaberDto teihaber) {
		if (teihaber.getEinkommenEinkommen() == null
			|| teihaber.getEinkommenEinkommen().compareTo(BigDecimal.ZERO) <= 0) {
			errors.add("Betrag (in CHF) is invalid. Must be greater than 0");
		}
		if (teihaber.getLastenRisiko() == null) {
			errors.add("Lasten Risiko is required");
		}
	}

	private void validateAhvAnmeldung(RechtsformEnum rechtsform, AhvAnmeldungDto dto, List<String> errors) {
		if (dto.getVerbandZugehoerigkeit() == AhvVerbandszugehoerigkeitEnum.JA
			|| dto.getVerbandZugehoerigkeit() == AhvVerbandszugehoerigkeitEnum.BALD) {
			if (dto.getVerbandId() == null) {
				errors.add("Verband is required");
			}
			if (dto.getVerbandZugehoerigkeit() == AhvVerbandszugehoerigkeitEnum.JA && dto.getVerbandBeitrittDatum() == null) {
				errors.add("Verband beitritt datum is required");
			}
		}
		if (rechtsform == RechtsformEnum.EINZELFIRMA) {
			if (CollectionUtils.isEmpty(dto.getAhvTeilhabers())) {
				errors.add("Teilhaber is required");
			}
		}

		validateAhvAngestellte(rechtsform, dto, errors);
		validateAhvSozialvers(dto, errors);
	}

	private void validateAhvSozialvers(AhvAnmeldungDto dto, List<String> errors) {
		boolean isSuva = dto.getProzess().getOrganisation().getBranches().stream()
			.filter(b -> b.isSuva())
			.count() > 0l;
		if (!isSuva && dto.getSozialversUvg() == null) {
			errors.add("SozialversUvg is required");
		}
		if (dto.getSozialversBvg() == null) {
			errors.add("SozialversBvg is required");
		} else {
			if (dto.getSozialversBvg().booleanValue() && dto.getSozialversBvgName() == null) {
				errors.add("SozialversBvgName is required");
			} else if (!dto.getSozialversBvg().booleanValue() && dto.getSozialversBvgGrund() == null) {
				errors.add("SozialversBvgGrund is required");
			}
		}
	}

	private void validateAhvAngestellte(List<String> errors, RechtsformEnum rechtsform, AhvTeilhaberDto teihaber) {
		if (rechtsform == RechtsformEnum.EINZELFIRMA) {
			if (teihaber.getPartner() != null
				&& (teihaber.getPartnerLohnSumme() == null || teihaber.getPartnerHatKinder() == null)) {
				errors.add("Partner Lohn Summe and Hat Kinder are required");
			}
		}
	}

	private void validateAhvAngestellte(RechtsformEnum rechtsform, AhvAnmeldungDto dto, List<String> errors) {
		if (dto.getAngestellteUebAnz() == null || dto.getAngestellteUebAnz() < 0) {
			errors.add("AngestellteUebAnz is invalid. Must be an integer greater than or equals 0");
		} else if (dto.getAngestellteUebAnz() > 0) {
			if (dto.getAngestellteUebLohnSumme() == null || dto.getAngestellteUebLohnSumme().compareTo(BigDecimal.ZERO) < 0) {
				errors.add("AngestellteAngLohnSumme (in CHF) is invalid. Must be an integer greater than 0");
			}
			if (dto.getAngestellteUebHatKinder() == null) {
				errors.add("AngestellteAngHatKinder is required");
			}
		}
		switch (rechtsform) {
			case EINZELFIRMA:
			case KOLLGES:
			case KOMMGES:
				if (dto.getAngestellteAngAnz() == null || dto.getAngestellteAngAnz() < 0) {
					errors.add("AngestellteAngAnz is invalid. Must be an integer greater than or equals 0");
				} else if (dto.getAngestellteAngAnz() > 0) {
					if (dto.getAngestellteAngLohnSumme() == null || dto.getAngestellteAngLohnSumme().compareTo(BigDecimal.ZERO) < 0) {
						errors.add("AngestellteAngLohnSumme (in CHF) is invalid. Must be an integer greater than 0");
					}
					if (dto.getAngestellteAngHatKinder() == null) {
						errors.add("AngestellteAngHatKinder is required");
					}
				}
				break;
			case AG:
			case GMBH:
				if (dto.getAngestellteGiAnz() == null || dto.getAngestellteGiAnz() < 0) {
					errors.add("AngestellteGiAnz is invalid. Must be an integer greater than 0");
				} else if (dto.getAngestellteGiAnz() > 0) {
					if (dto.getAngestellteGiLohnSumme() == null || dto.getAngestellteGiLohnSumme().compareTo(BigDecimal.ZERO) < 0) {
						errors.add("AngestellteGiLohnSumme (in CHF) is invalid. Must be an integer greater than 0");
					}
					if (dto.getAngestellteGiHatKinder() == null) {
						errors.add("AngestellteGiHatKinder is required");
					}
				}
				break;
			default:
				break;
			
		}
	}

	private void validateAhvPbisher(List<String> errors, AhvTeilhaberDto teihaber) {
		if (teihaber.getBisherBeitragAls() == null) {
			errors.add("Bisher Beitrag Als is required");
		}
		List<CodeWertEntity> beitragAls = applicationService.getCodeWerts(KategorieEnum.AHV_BEITRAG_ALS);
		Optional<CodeWertEntity> selectedBeitragAls = beitragAls.stream()
			.filter(b -> b.getId().equals(teihaber.getBisherBeitragAls()))
			.findFirst();
		if (!selectedBeitragAls.isPresent()) {
			errors.add("Bisher Beitrag Als is unknown");
		}
		String beitragAlsCode = selectedBeitragAls.get().getCode();
		if (!AhvBeitraegeAlsEnum.AUSLANDAUFENTHALT.value().equals(beitragAlsCode)
			&& !AhvBeitraegeAlsEnum.KEINE_BEITRAEGE.value().equals(beitragAlsCode)) {
			if (teihaber.getBisherAk() == null
				|| teihaber.getBisherHatKinder() == null
				|| teihaber.getBisherVon() == null
				|| teihaber.getBisherBis() == null) {
				errors.add("BisherAk, Von, Bis, HatKinder is required");
			}
		}
		if (AhvBeitraegeAlsEnum.SELBSTAENDIGERWERBENDER.value().equals(beitragAlsCode)) {
			if (teihaber.getBisherEinkommen() == null) {
				errors.add("BisherEinkommen is required");
			}
		}
	}

	private void validateAhvPmitarbeit(List<String> errors, AhvTeilhaberDto teihaber) {
		switch (teihaber.getMitarbeit()) {
			case HAUPTERWERB:
				if (teihaber.getMitarbeitRolle() == null) {
					errors.add("Ihre Rolle is required");
				}
				break;
			case NEBENERWERB:
				if (teihaber.getMitarbeitRolle() == null) {
					errors.add("Ihre Rolle is required");
				}
				if (teihaber.getMitarbeitBezeichnung() == null
					|| teihaber.getMitarbeitName() == null
					|| teihaber.getMitarbeitStrasse() == null
					|| teihaber.getMitarbeitPlzOrt() == null) {
					errors.add("Bezeichnung, name, address, plz is required");
				}
				break;
			default:
				errors.add("Mitarbeit is required");
		}
	}

	@Override
	public ResponseEntity<?> lock(@PathVariable long orgId) {
		AhvAnmeldungEntity ahvAnmeldung = ahvService.getByOrganisationId(orgId);
		return ResponseEntity.ok(mapper.map(ahvService.lockProcess(ahvAnmeldung), AhvAnmeldungDto.class));
	}

	@Override
	public ResponseEntity<?> sign(@PathVariable long orgId) {
		return ResponseEntity.ok(mapper.map(ahvService.signProcess(ahvService.getByOrganisationId(orgId)), AhvAnmeldungDto.class));
	}
	
	@Override
	public ResponseEntity<?> relock(@PathVariable long orgId) {
		return ResponseEntity.ok(mapper.map(ahvService.relockProcess(ahvService.getByOrganisationId(orgId)), AhvAnmeldungDto.class));
	}
	
	@Override	
	public ResponseEntity<?> interrupt(@RequestBody AhvAnmeldungDto dto) {
		return updateProzess(dto);
	}

	private void mapAhvAnmeldung(AhvAnmeldungDto dto, AhvAnmeldungEntity entity) {
		mapper.map(dto, entity, AHV_PROZESS);
		if(entity.getAdresseKontakt() != null) {
			entity.getAdresseKontakt().setLand(getCodeWert(KategorieEnum.LAND, OSSConstants.SWISS_CODE_WERT));
		}
		mapAhvFiliales(dto, entity);
		mapAhvTeilhabers(dto, entity);
	}
	
	private void mapAhvAdditionalInfo(AhvAnmeldungDto dto, AhvAnmeldungEntity entity) {
		OrganisationEntity organisation = entity.getProzess().getOrganisation();
		
		dto.getProzess().getOrganisation().setImportData(importHRRegistrationFromZefix(organisation));
		
		dto.setHrRegistrationStatus(organisation.getPflichtenabklaerungen().getAnmeldungHRBefund());
		if (dto.getZefixStatus() == HRStatusEnum.REGISTERED) {
			dto.setImportData(new CompanyDetailedInfoDto(
				entity.getZefixCompanyName(),
				entity.getZefixChNr(),
				entity.getZefixUid(),
				entity.getZefixPolGemeinde()));
		}
		if (dto.getVerbandId() != null) {
			VerbandDto verband = getVerbandById(dto.getVerbandId());
			dto.setVerbandDto(verband);
			dto.setAusgleichskasseDto(verband.getAusgleichskasse());
		} else {
			dto.setAusgleichskasseDto(findAusleichskasseInOrganisationKanton(dto.getProzess().getOrganisation().getId()));
		}
		dto.getAhvTeilhabers().stream().forEach(t -> mapAhvTeihaberAdditionalInfo(t));
	}

	private void mapAhvTeihaberAdditionalInfo(AhvTeilhaberDto dto) {
		if (dto.getBisherVerbandAkId() != null) {
			dto.setBisherVerbandAkDto(ausgleichskasse()
				.stream()
				.filter(aus -> aus.getId().equals(dto.getBisherVerbandAkId()))
				.findFirst().get());
		}
		if (dto.getBisherBerufVerbandId() != null) {
			dto.setBisherBerufVerbandDto(getVerbandById(dto.getBisherBerufVerbandId()));
		}
		if (dto.getBisherBeitragAls() != null) {
			dto.setBisherBeitragAlsDto(getAhvBisherKategories(null)
				.stream()
				.filter(c -> c.getId().equals(dto.getBisherBeitragAls()))
				.findFirst().get());
		}
	}

	private void mapAhvFiliales(AhvAnmeldungDto dto, AhvAnmeldungEntity entity) {
		for (AhvFilialeDto filialeDto : dto.getAhvFiliales()) {
			entity.getAhvFiliales()
				.stream()
				.filter(f -> f.getId().equals(filialeDto.getId()))
				.forEach(f -> {
					f.setAngestellte(filialeDto.getAngestellte());
					f.setLohnSumme(filialeDto.getLohnSumme());
					f.setSeit(OSSDateUtil.toLocalDate(filialeDto.getSeit()));
				});
		}
	}
	
	private void mapAhvTeilhabers(AhvAnmeldungDto dto, AhvAnmeldungEntity entity) {
		for (AhvTeilhaberDto teilhaberDto : dto.getAhvTeilhabers()) {
			entity.getAhvTeilhabers()
				.stream()
				.filter(t -> t.getId().equals(teilhaberDto.getId()))
				.forEach(t -> {
					mapper.map(teilhaberDto, t, AHV_TEILHABER);
					
					if (teilhaberDto.getPartner() != null) {
						PersonEntity partnerEnt = new PersonEntity();
						if (teilhaberDto.getPartner().getId() != null) {
							partnerEnt = organisationService.getPerson(teilhaberDto.getPartner().getId());
						}
						mapper.map(teilhaberDto.getPartner(), partnerEnt);
						if (teilhaberDto.getPartner().getAnrede() != null) {
							String geschlechtCd = OSSConstants.ANDERE_MR_CODE
								.equals(teilhaberDto.getPartner().getAnrede().getCode())
									? OSSConstants.GESCHLECHT_MR_CODE : OSSConstants.GESCHLECHT_MRS_CODE;
							partnerEnt.setGeschlecht(getCodeWert(KategorieEnum.GESCHLECHT, geschlechtCd));
							partnerEnt.setAnrede(
								getCodeWert(KategorieEnum.ANREDE, teilhaberDto.getPartner().getAnrede().getCode()));
							
							// TODO [HHG / S9] how to solve the @NotNull constraints of PersonEntity on [wohnadresse] & [zivilstand]
							partnerEnt.setWohnadresse(entity.getProzess().getOrganisation().getDomizil());
							partnerEnt.setZivilstand(getCodeWert(KategorieEnum.ZIVILSTAND, "1"));
						}
						t.setPartner(partnerEnt);
					}
				});
		}
	}
	
	@RequestMapping(value = "/verband/{id}", method = RequestMethod.GET)
	public VerbandDto getVerbandById(@PathVariable long id) {
		return mapper.map(ahvService.getVerbandById(id), VerbandDto.class);
	}
	
	@RequestMapping(value = "/ausgleichskasse/{orgId}", method = RequestMethod.GET)
	public AusgleichskasseDto findAusleichskasseInOrganisationKanton(@PathVariable long orgId) {
		return mapper.map(ahvService.findAusleichskasseInOrganisationKanton(orgId), AusgleichskasseDto.class);
	}
	
	@RequestMapping(value = "/organisationGeschaftsrolle/{orgId}", method = RequestMethod.GET)
	public List<GeschaftsrolleDto> getOrganisationGeschaftsrolle(@PathVariable long orgId) {
		List<GeschaftsrolleDto> dtos = organisationService.loadEDCRollen(orgId)
				.stream()
				.map(ent -> mapper.map(ent, GeschaftsrolleDto.class))
				.collect(Collectors.toList());
		return dtos;
	}
	
	@RequestMapping(value = "/ahvBisherKategories", method = RequestMethod.GET)
	public List<CodeWertDto> getAhvBisherKategories(@RequestParam(required = false, name = "language") SupportedLanguage language) {
		if(language == null) {
			language = SecurityUtil.currentUser().getLanguagePreference();
		}
		List<CodeWertEntity> entities = applicationService.getCodeWerts(KategorieEnum.AHV_BEITRAG_ALS);
		List<CodeWertDto> dtos = new ArrayList<>();
		for(CodeWertEntity ent: entities) {
			dtos.add(new CodeWertDto(ent, language));
		}
		return dtos;
	}
	
	@RequestMapping(value = "/ausgleichskasse", method = RequestMethod.GET)
	public List<AusgleichskasseDto> filteredAusgleichskasse() {
		return ausgleichskasse().stream()
			.filter(ausg -> StringUtils.equalsIgnoreCase(ausg.getZustaendigkeit(), CHOrtEntity.CH_ALL_KANTON))
			.collect(Collectors.toList());
	}

	@RequestMapping(value = "/document/{orgId}", method = RequestMethod.GET)
	public ResponseEntity<?> downloadPdf(@PathVariable long orgId) {
		return download(ahvService.downloadDocument(orgId));
	}
	
	private List<AusgleichskasseDto> ausgleichskasse() {
		return cacheService.getAusgleichskasses()
			.stream()
			.map(ausg -> mapper.map(ausg, AusgleichskasseDto.class))
			.collect(Collectors.toList());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected ProzessStatusEnum getProcessStatus(long orgId) {
		return ahvService.getProcessStatusByOrgId(orgId);
	}
}