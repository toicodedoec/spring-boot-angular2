/*
 * ImageDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.generator.aspose.handler;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aspose.words.FieldMergingArgs;
import com.aspose.words.IFieldMergingCallback;
import com.aspose.words.ImageFieldMergingArgs;
import com.aspose.words.MergeFieldImageDimension;
import com.aspose.words.MergeFieldImageDimensionUnit;

import ch.admin.oss.util.ImageDto;

/**
 * @author hha
 */
public class HandleMergeImageField implements IFieldMergingCallback {

	private static final Logger LOGGER = LoggerFactory.getLogger(HandleMergeImageField.class);
	
	private static final HandleMergeImageField INSTANCE = new HandleMergeImageField();
	public static HandleMergeImageField getInstance() {
		return INSTANCE;
	}

	private static final BufferedImage EMPTY_IMAGE = new BufferedImage(1, 1, BufferedImage.TYPE_INT_RGB);
	static {
		final Graphics2D g2 = EMPTY_IMAGE.createGraphics();
		g2.setPaint(Color.WHITE);
		g2.fillRect(0, 0, EMPTY_IMAGE.getWidth(), EMPTY_IMAGE.getHeight());
		g2.dispose();
	}

	@Override
	public void fieldMerging(FieldMergingArgs field) throws Exception {
		// Do nothing.
	}

	/**
	 * Handle for image fields: «Image:ImageFieldName»
	 * <p>
	 * - Allowed return values: An image object / A filename / A stream contains the image
	 * </p>
	 */
	@Override
	public void imageFieldMerging(ImageFieldMergingArgs field) throws Exception {
		Object value = field.getFieldValue();
		if (!(value instanceof ImageDto)) {
			return;
		}

		ImageDto imageDto = (ImageDto) value;
		try {
			field.setImage(ImageIO.read(Thread.currentThread().getContextClassLoader().getResourceAsStream(imageDto.getPath())));
		} catch (IOException e) {
			field.setImage(EMPTY_IMAGE);
			LOGGER.error("Cannot load image from path: " + imageDto.getPath(), e);
		}

		if (imageDto.getHeight() != null) {
			field.setImageHeight(new MergeFieldImageDimension(imageDto.getHeight(), MergeFieldImageDimensionUnit.POINT));
		}
		if (imageDto.getWidth() != null) {
			field.setImageWidth(new MergeFieldImageDimension(imageDto.getWidth(), MergeFieldImageDimensionUnit.POINT));
		}
	}

}