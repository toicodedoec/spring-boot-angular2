/*
 * IfNotNullConverter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import org.dozer.DozerConverter;

/**
 * @author tdm
 *
 */
public class IfNotNullConverter extends DozerConverter<Object, Object> {

    public IfNotNullConverter() {
        super(Object.class, Object.class);
    }

    @Override
    public Object convertTo(Object source, Object destination) {
        return getObject(source, destination);
    }

    @Override
    public Object convertFrom(Object source, Object destination) {
        return getObject(source, destination);
    }

    private Object getObject(Object source, Object destination) {
        if (source != null) {
            return source;
        } else {
            return destination;
        }
    }

}
