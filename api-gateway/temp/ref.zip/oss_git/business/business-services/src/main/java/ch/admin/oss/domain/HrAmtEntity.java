/*
 * HrAmtEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author coh
 */
@Entity
@Table(name = "T_HR_AMT")
public class HrAmtEntity extends AbstractOSSEntity {

	@Column(name = "NR")
	private Integer nr;
	
	@Column(name = "KANTON")
	private String kanton;
	
	@Column(name = "AMTSBEZEICHNUNG")
	private String amtsbezeichnung;
	
	@Column(name = "AMTSSPRACHEN")
	private String amtssprachen;
	
	@Column(name = "STRASSE")
	private String strasse;
	
	@Column(name = "ZUSATZ")
	private String zusatz;
	
	@Column(name = "POSTFACH")
	private String postfach;
	
	@Column(name = "PLZ")
	private String plz;
	
	@Column(name = "ORT")
	private String ort;
	
	@Column(name = "PUB_TEL_1")
	private String pubTel1;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PUB_TEL1_BEMERKUNGEN", foreignKey = @ForeignKey(name = "FK_HR_AMT_PUB_TEL1"))
	private StandardTextEntity pubTel1Bemerkungen;
	
	@Column(name = "PUB_TEL_2")
	private String pubTel2;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PUB_TEL2_BEMERKUNGEN", foreignKey = @ForeignKey(name = "FK_HR_AMT_PUB_TEL2"))
	private StandardTextEntity pubTel2Bemerkungen;
	
	@Column(name = "PUB_FAX")
	private String pubFax;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PUB_FAX_BEMERKUNGEN", foreignKey = @ForeignKey(name = "FK_HR_AMT_PUB_FAX"))
	private StandardTextEntity pubFaxBemerkungen;
	
	@Column(name = "PUB_MAIL")
	private String pubMail;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PUB_MAIL_BEMERKUNGEN", foreignKey = @ForeignKey(name = "FK_HR_AMT_PUB_MAIL"))
	private StandardTextEntity pubMailBemerkungen;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_OEFFNUNGSZEITEN_SCHALTER", foreignKey = @ForeignKey(name = "FK_HR_AMT_SCHALTER"))
	private StandardTextEntity oeffnungszeitenSchalter;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_UNTERSCHRIFTSBEGLAUBIGUNG", foreignKey = @ForeignKey(name = "FK_HR_AMT_UNTERSCHRIFT"))
	private StandardTextEntity unterschriftsbeglaubigung;

	@Column(name = "HOMEPAGE")
	private String homepage;

	public Integer getNr() {
		return nr;
	}

	public String getKanton() {
		return kanton;
	}

	public String getAmtsbezeichnung() {
		return amtsbezeichnung;
	}

	public String getAmtssprachen() {
		return amtssprachen;
	}

	public String getStrasse() {
		return strasse;
	}

	public String getZusatz() {
		return zusatz;
	}

	public String getPostfach() {
		return postfach;
	}

	public String getPlz() {
		return plz;
	}

	public String getOrt() {
		return ort;
	}

	public String getPubTel1() {
		return pubTel1;
	}

	public StandardTextEntity getPubTel1Bemerkungen() {
		return pubTel1Bemerkungen;
	}

	public String getPubTel2() {
		return pubTel2;
	}

	public StandardTextEntity getPubTel2Bemerkungen() {
		return pubTel2Bemerkungen;
	}

	public String getPubFax() {
		return pubFax;
	}

	public StandardTextEntity getPubFaxBemerkungen() {
		return pubFaxBemerkungen;
	}

	public String getPubMail() {
		return pubMail;
	}

	public StandardTextEntity getPubMailBemerkungen() {
		return pubMailBemerkungen;
	}

	public StandardTextEntity getOeffnungszeitenSchalter() {
		return oeffnungszeitenSchalter;
	}

	public StandardTextEntity getUnterschriftsbeglaubigung() {
		return unterschriftsbeglaubigung;
	}

	public String getHomepage() {
		return homepage;
	}
}
