/*
 * KontoEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import ch.admin.oss.common.enums.KontotypEnum;
import ch.admin.oss.common.enums.ZahlungszweckEnum;

/**
 *  
 * @author coh
 */
@Audited
@Entity
@Table(name = "T_KONTO")
public class KontoEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name="FK_KONTO_ORGANISATION"))
	private OrganisationEntity organisation;
	
	@Column(name = "INHABER")
	private String inhaber;
	
	@Column(name = "ORT")
	private String ort;
	
	@Column(name = "ZWECK")
	@Enumerated(EnumType.STRING)
	private ZahlungszweckEnum zweck;
	
	@Column(name = "TYP")
	@Enumerated(EnumType.STRING)
	private KontotypEnum typ;
	
	@Column(name = "KONTO_NUMMER")
	private String kontonummer;
	
	@Column(name = "BANKNAME")
	private String bankname;
	
	@Column(name = "PLZ")
	private String plz;
	
	@Column(name = "LAND")
	private String land;
	
	@Column(name = "BANKLEITZAHL")
	private String bankleitzahl;
	
	@Column(name = "PC")
	private String pc;

	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public String getInhaber() {
		return inhaber;
	}

	public void setInhaber(String inhaber) {
		this.inhaber = inhaber;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public ZahlungszweckEnum getZweck() {
		return zweck;
	}

	public void setZweck(ZahlungszweckEnum zweck) {
		this.zweck = zweck;
	}

	public KontotypEnum getTyp() {
		return typ;
	}

	public void setTyp(KontotypEnum typ) {
		this.typ = typ;
	}

	public String getKontonummer() {
		return kontonummer;
	}

	public void setKontonummer(String kontonummer) {
		this.kontonummer = kontonummer;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getLand() {
		return land;
	}

	public void setLand(String land) {
		this.land = land;
	}

	public String getBankleitzahl() {
		return bankleitzahl;
	}

	public void setBankleitzahl(String bankleitzahl) {
		this.bankleitzahl = bankleitzahl;
	}

	public String getPc() {
		return pc;
	}

	public void setPc(String pc) {
		this.pc = pc;
	}
}
