/*
 * AbstractProcessService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.business.AbstractNaturalPersonDto;
import ch.admin.oss.business.AddressDto;
import ch.admin.oss.business.HrAmtDto;
import ch.admin.oss.common.enums.ISO2Enum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrAmtEntity;
import ch.admin.oss.domain.IProzessEntity;
import ch.admin.oss.domain.LandEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QProzessEntity;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.DataUtil;
import ch.admin.oss.util.IMailUtil;
import ch.admin.oss.util.ImageDto;

/**
 * @author hha
 */
public abstract class AbstractProcessService<T extends IProzessEntity> extends AbstractOrganisationService {

	@Autowired
	protected IMailUtil mailUtil;
	
	@Value("${oss.mail.helpdesk}")
	protected String helpdeskEmail;

	@Autowired
	private Environment environment;

	/**
	 * <p>
	 * Apply business logic when process is completed.
	 * <ul>
	 * <li>Completed = true</li>
	 * <li>Status = {@link ProzessStatusEnum#KOMPLETT}</li>
	 * <li>Record status history (if have)</li>
	 * </ul>
	 * </p>
	 * 
	 * @param prozessEntity
	 */
	protected void processCompleted(T entity) {
		ProzessEntity prozessEntity = entity.getProzess();
		verifyProcessBeforeUpdated(prozessEntity);
		prozessEntity.setCompleted(true);
		prozessEntity.setStatus(ProzessStatusEnum.KOMPLETT);
		processDocument(entity, true);
		recordProcessStatusChange(prozessEntity);
	}
	
	/**
	 * <p>
	 * Apply business logic when process is locked or user confirm the process will be signed.
	 * <ul>
	 * <li>Locked = true</li>
	 * <li>Organisation.baseDataLocked = true</li>
	 * <li>Status = {@link ProzessStatusEnum#GESCHLOSSEN}</li>
	 * <li>Record status history (if have)</li>
	 * </ul>
	 * </p>
	 * 
	 * @param prozessEntity
	 */
	protected void processLocked(T entity, boolean generateDocument) {
		ProzessEntity prozessEntity = entity.getProzess();
		verifyProcessBeforeUpdated(prozessEntity);
		prozessEntity.setLocked(true);
		prozessEntity.setStatus(ProzessStatusEnum.GESCHLOSSEN);
		if (generateDocument) {
			processDocument(entity, false);
		}
		recordProcessStatusChange(prozessEntity);
	}

	/**
	 * <p>
	 * Apply business logic when process is signed.
	 * <ul>
	 * <li>Status = {@link ProzessStatusEnum#GESENDET}</li>
	 * <li>Record status history (if have)</li>
	 * </ul>
	 * </p>
	 * 
	 * @param prozessEntity
	 */
	protected void processSigned(ProzessEntity prozessEntity) {
		processSigned(prozessEntity, null);
	}

	protected void processSigned(ProzessEntity prozessEntity, Long userId) {
		verifyProcessBeforeUpdated(prozessEntity);
		prozessEntity.setStatus(ProzessStatusEnum.GESENDET);
		recordProcessStatusChange(prozessEntity, userId);
	}

	protected void processExternIntern(ProzessEntity prozessEntity, boolean external) {
		prozessEntity.setStatus(external ? ProzessStatusEnum.EXTERN : ProzessStatusEnum.INITIAL);
		clearProcessHistory(prozessEntity);
		recordProcessStatusChange(prozessEntity);
		prozessRepository.save(prozessEntity);
	}
	
	private void clearProcessHistory(ProzessEntity prozessEntity) {
		prozessEntity.getFlowHistory().getItems().clear();
	}

	protected SupportedLanguage getSupportedLanguage(String supportedLanguages, String separator) {
		if (StringUtils.containsIgnoreCase(supportedLanguages, SecurityUtil.currentUser().getLanguagePreference().toString())) {
			return SecurityUtil.currentUser().getLanguagePreference();
		}
		String firstSupportedLanguage = StringUtils.substringBefore(supportedLanguages, separator);
		return SupportedLanguage.valueOf(firstSupportedLanguage.toUpperCase());
	}
	
	protected <P extends AbstractNaturalPersonDto> P convertNaturalPersonToDocumentDto(P person, SupportedLanguage language, GeschaftsrolleEntity entity) {

		PersonEntity personEntity = entity.getPerson();
		person.setAnrede(getCodeText(personEntity.getAnrede(), language));
		person.setTitel(personEntity.getTitel());
		person.setFamilienname(personEntity.getFamilienname());
		person.setVorname(personEntity.getVorname());
		person.setLedigname(personEntity.getLedigname());
		person.setWeitereVornamen(personEntity.getVornamenliste());
		person.setGeburtsdatum(personEntity.getGeburtsdatum());
		person.setAhvNummer(personEntity.getAhvNummer());
		person.setHeimatortCombined(DataUtil.formatHeimatorte(personEntity.getHeimatortes()));
		person.setNationalitaetenCombined(StringUtils.join(
			personEntity.getNationalitaetens().stream()
				.map(item -> item.getStandardText().textTranslation(language))
				.toArray(size -> new String[size]), ", ")
		);
		person.setAuslaenderAusweis(getCodeText(personEntity.getAuslaenderAusweis(), language));

		person.setFunktion(getCodeText(entity.getFunktion(), language));
		person.setZeichnung(getCodeText(entity.getZeichnung(), language));
		person.setZivilstand(getCodeText(personEntity.getZivilstand(), language));

		person.setHaftung(getCodeText(entity.getHaftung(), language));
		person.setHaftungChf(entity.getHaftungCHF());
		
		person.setAnzInhaberaktien(entity.getAnzInhaberaktien());
		person.setAnzNamensaktien(entity.getAnzNamensaktien());
		person.setAnzStammanteile(entity.getAnzStammanteile());
		
		person.setHauptsitz(entity.isNurHauptsitz()
			? applicationService.getTranslation("gui_labels.common.yes", language)
			: applicationService.getTranslation("gui_labels.common.no", language));
		person.setAdr(convertAddressToDocumentDto(personEntity.getWohnadresse(), language));

		person.setNatTyp(personEntity.getNatType().name());
		person.setEinreisedatum(personEntity.getEinreisedatum());

		return person;
	}

	protected String getCodeText(CodeWertEntity entity, SupportedLanguage language) {
		if (entity == null || entity.getStandardText() == null) {
			return null;
		}
		return entity.getStandardText().textTranslation(language);
	}
	
	protected AddressDto convertAddressToDocumentDto(AdresseEntity addressEntity, SupportedLanguage language) {
		if (addressEntity == null) {
			return null;
		}
		AddressDto adr = new AddressDto();
		adr.setCombinedWithName(DataUtil.formatAddressWithName(addressEntity, language));
		adr.setCombined(DataUtil.formatAddress(addressEntity, language));
		adr.setLand(getCodeText(addressEntity.getLand(), language));
		LandEntity land = applicationService.getLand(addressEntity.getLand());
		if (land != null) {
			ISO2Enum iso2 = land.getIso2();
			if (iso2 != null) {
				adr.setLandCode(iso2.name());
			}
		}
		adr.setPhone(addressEntity.getTelefon());
		adr.setMobile(addressEntity.getMobile());
		adr.setEmail(addressEntity.getEmail());
		adr.setFax(addressEntity.getFax());
		adr.setStrasse(addressEntity.getStrasse());
		adr.setZusatz(addressEntity.getZusatz());
		adr.setPostfach(addressEntity.getPostfach());
		adr.setPlz(addressEntity.getPlz());
		adr.setOrt(addressEntity.getOrt());
		adr.setPolGemeinde(addressEntity.getPolGemeinde());
		adr.setKanton(addressEntity.getKanton());
		adr.setHausnummer(addressEntity.getHausnummer());
		adr.setEmpfaenger(addressEntity.getEmpfaenger());
		return adr;
	}

	protected void processDocument(T entity, boolean draft) {
		if (!isSupportedDocument()) {
			return;
		}
		// TODO [HHA, S9] Generated Organisation doesn't have enough data to generate document. Complete later.
		if (Arrays.stream(environment.getActiveProfiles()).anyMatch(item -> 
			Arrays.asList(CommonConstants.PROFILE_TEST, CommonConstants.PROFILE_TEST_PERFORMANCE_DATA).contains(item))) {
			return;
		}
		entity.getProzess().setPdf(generateDocument(entity, draft));
	}

	protected abstract byte[] generateDocument(T entity, boolean draft);

	protected byte[] getDocument(long orgId) {
		return new JPAQuery<>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.organisation.id.eq(orgId))
			.where(QProzessEntity.prozessEntity.typ.eq(getProcessType()))
			.select(QProzessEntity.prozessEntity.pdf)
			.fetchFirst();
	}
	
	protected byte[] getDocument(long orgId, long prozessId) {
		return new JPAQuery<>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.organisation.id.eq(orgId))
			.where(QProzessEntity.prozessEntity.id.eq(prozessId))
			.where(QProzessEntity.prozessEntity.typ.eq(getProcessType()))
			.select(QProzessEntity.prozessEntity.pdf)
			.fetchFirst();
	}

	/**
	 * @return true if this process support to generate document.
	 */
	protected boolean isSupportedDocument() {
		return true;
	}
	
	protected ProzessStatusEnum getProcessStatus(long orgId) {
		return new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.organisation.id.eq(orgId)
				.and(QProzessEntity.prozessEntity.typ.eq(getProcessType())))
			.select(QProzessEntity.prozessEntity.status)
			.fetchOne();
	}
	
	/**
	 * @return process type.
	 */
	protected abstract ProzessTypEnum getProcessType();
	
	protected HrAmtDto constructHRAmtDto(HrAmtEntity amtEntity, SupportedLanguage language) {
		HrAmtEntity chAmtEntity = applicationService.getChHrAmt();
		HrAmtDto amt = new HrAmtDto();
		amt.setChAmtsbezeichnung(chAmtEntity.getAmtsbezeichnung());
		amt.setAmtsbezeichnung(amtEntity.getAmtsbezeichnung());
		amt.setStrasse(amtEntity.getStrasse());
		amt.setPlz(amtEntity.getPlz());
		amt.setOrt(amtEntity.getOrt());
		amt.setKanton(amtEntity.getKanton());
		amt.setKantonImage(new ImageDto("images/kanton/" + amtEntity.getKanton() + ".jpg", 25d, 25d));
		if (amtEntity.getUnterschriftsbeglaubigung() != null) {
			amt.setUnterschriftsbeglaubigung(amtEntity.getUnterschriftsbeglaubigung().textTranslation(language));
		}
		return amt;
	}
}
