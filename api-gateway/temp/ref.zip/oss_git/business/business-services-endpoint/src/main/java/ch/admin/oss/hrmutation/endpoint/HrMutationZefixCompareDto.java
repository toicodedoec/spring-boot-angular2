/*
 * HrMutationZefixCompareDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.endpoint;

import org.apache.commons.lang3.StringUtils;

import ch.admin.oss.common.AdresseDto;

public class HrMutationZefixCompareDto {

	private HrMutationOrgInfoDto easygovInfo;
	private HrMutationOrgInfoDto zefixInfo;
	private boolean different;
	private boolean differentName;
	private boolean differentLegalSeat;
	private boolean differentDomizil;
	private boolean differentPurpose;

	public HrMutationZefixCompareDto() {
		// default constructor
	}

	public HrMutationZefixCompareDto(HrMutationOrgInfoDto easygovInfo, HrMutationOrgInfoDto zefixInfo) {
		this.easygovInfo = easygovInfo;
		this.zefixInfo = zefixInfo;
		
		this.differentName = !StringUtils.equals(easygovInfo.getCompanyName(), zefixInfo.getCompanyName());
		this.differentLegalSeat = !StringUtils.equals(easygovInfo.getLegalSeat(), zefixInfo.getLegalSeat());
		this.differentPurpose = !StringUtils.equals(easygovInfo.getCompanyPurpose(), zefixInfo.getCompanyPurpose());
		this.differentDomizil = compareDomizil(easygovInfo.getDomizil(), zefixInfo.getDomizil());
		if (this.differentName || this.differentDomizil || this.differentLegalSeat || this.differentPurpose) {
			this.different = true;
		}
	}

	public HrMutationOrgInfoDto getEasygovInfo() {
		return easygovInfo;
	}

	public HrMutationOrgInfoDto getZefixInfo() {
		return zefixInfo;
	}

	public boolean isDifferent() {
		return different;
	}

	public boolean isDifferentName() {
		return differentName;
	}

	public boolean isDifferentLegalSeat() {
		return differentLegalSeat;
	}

	public boolean isDifferentDomizil() {
		return differentDomizil;
	}

	public boolean isDifferentPurpose() {
		return differentPurpose;
	}
	
	private boolean compareDomizil(AdresseDto domizil, AdresseDto anotherDomizil) {
		if(domizil.getBfsNr() != anotherDomizil.getBfsNr() 
				|| !StringUtils.equals(domizil.getStrasse(), anotherDomizil.getStrasse())
				|| !StringUtils.equals(domizil.getPolGemeinde(), anotherDomizil.getPolGemeinde())
				|| !StringUtils.equals(domizil.getHausnummer(), anotherDomizil.getHausnummer())
				|| !StringUtils.equals(domizil.getOrt(), anotherDomizil.getOrt())
				|| !StringUtils.equals(domizil.getPlz(), anotherDomizil.getPlz())
				|| !StringUtils.equals(domizil.getPostfach(), anotherDomizil.getPostfach())
				|| !StringUtils.equals(domizil.getZusatz(), anotherDomizil.getZusatz())) {
			return true;
		}
		return false;
	}
}
