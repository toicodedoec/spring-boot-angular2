/*
 * GeschaftsrolleDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;

/**
 * @author xdg
 */
public class GeschaftsrolleDto extends AbstractPersonRoleDto {

	private Long orgId;
	private GeschaeftsrolleTypEnum typ;
	private boolean delete;

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public GeschaeftsrolleTypEnum getTyp() {
		return typ;
	}

	public void setTyp(GeschaeftsrolleTypEnum typ) {
		this.typ = typ;
	}

	public boolean isDelete() {
		return delete;
	}

	public void setDelete(boolean delete) {
		this.delete = delete;
	}
}
