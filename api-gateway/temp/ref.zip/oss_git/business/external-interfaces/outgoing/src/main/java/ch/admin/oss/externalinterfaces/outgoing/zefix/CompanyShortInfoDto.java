/*
 * CompanyShortInfoDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

import java.io.Serializable;

import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author hhg
 *
 */
public class CompanyShortInfoDto implements Serializable {

	private static final long serialVersionUID = -5532278894674176373L;
	
	private String name;
	private String chid;
	private Integer uid;
	private String legalSeat;
	private RechtsformEnum rechtsform;
	private AddressInformationDto address;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getChid() {
		return chid;
	}
	
	public void setChid(String chid) {
		this.chid = chid;
	}
	
	public Integer getUid() {
		return uid;
	}
	
	public void setUid(Integer uid) {
		this.uid = uid;
	}
	
	public String getLegalSeat() {
		return legalSeat;
	}
	
	public void setLegalSeat(String legalSeat) {
		this.legalSeat = legalSeat;
	}
	
	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}

	public AddressInformationDto getAddress() {
		return address;
	}

	public void setAddress(AddressInformationDto address) {
		this.address = address;
	}

	public String getChidFormatted() {
		return OssNumberFormatUtil.formatChid(chid);
	}
	
	public String getUidFormatted() {
		return OssNumberFormatUtil.formatUid(uid);
	}
}
