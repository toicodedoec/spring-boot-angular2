/*
 * Nameadd
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.swissreg;

import java.io.Serializable;

/**
 * @author hhg
 *
 */
public class NameaddDto implements Serializable {

	private static final long serialVersionUID = 7550693020362044497L;

	protected String namel;
	protected String addrl;
	protected String plainco;
	
	public String getNamel() {
		return namel;
	}
	
	public void setNamel(String namel) {
		this.namel = namel;
	}
	
	public String getAddrl() {
		return addrl;
	}
	
	public void setAddrl(String addrl) {
		this.addrl = addrl;
	}
	
	public String getPlainco() {
		return plainco;
	}
	
	public void setPlainco(String plainco) {
		this.plainco = plainco;
	}
}
