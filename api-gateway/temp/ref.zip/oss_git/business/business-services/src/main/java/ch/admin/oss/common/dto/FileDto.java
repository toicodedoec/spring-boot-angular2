/*
 * FileDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common.dto;

import java.util.Arrays;

import ch.admin.oss.enums.SupportedFileTypeDownload;

/**
 * @author hha
 */
public class FileDto {

	private SupportedFileTypeDownload fileType;
	private String filename;
	private byte[] data;
	
	public FileDto(String filename, SupportedFileTypeDownload fileType, byte[] data) {
		this.filename = filename;
		this.data = Arrays.copyOf(data, data.length);
		this.fileType = fileType;
	}

	public String getFilename() {
		return filename;
	}

	public byte[] getData() {
		return data;
	}

	public SupportedFileTypeDownload getFileType() {
		return fileType;
	}
}
