/*
 * ContactAddressesDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.endpoint;

import java.util.Date;
import java.util.List;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.FlowHistoryDto;

/**
 * @author xdg
 */
public class ContactAddressesDto extends AbstractOSSDto {
	private String ort;
	private String polGemeinde;
	private List<BrancheDto> branches;
	private Long berufId;
	private String mitgliedschaft;
	private Date startDate;
	private List<ContactDto> contacts;
	private boolean storeHistory = true;
	private FlowHistoryDto flowHistory = new FlowHistoryDto();

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getPolGemeinde() {
		return polGemeinde;
	}

	public void setPolGemeinde(String polGemeinde) {
		this.polGemeinde = polGemeinde;
	}

	public List<BrancheDto> getBranches() {
		return branches;
	}

	public void setBranches(List<BrancheDto> branches) {
		this.branches = branches;
	}

	public Long getBerufId() {
		return berufId;
	}

	public void setBerufId(Long berufId) {
		this.berufId = berufId;
	}

	public String getMitgliedschaft() {
		return mitgliedschaft;
	}

	public void setMitgliedschaft(String mitgliedschaft) {
		this.mitgliedschaft = mitgliedschaft;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public List<ContactDto> getContacts() {
		return contacts;
	}

	public void setContacts(List<ContactDto> contacts) {
		this.contacts = contacts;
	}

	public boolean isStoreHistory() {
		return storeHistory;
	}

	public void setStoreHistory(boolean storeHistory) {
		this.storeHistory = storeHistory;
	}

	public FlowHistoryDto getFlowHistory() {
		return flowHistory;
	}

	public void setFlowHistory(FlowHistoryDto flowHistory) {
		this.flowHistory = flowHistory;
	}
}
