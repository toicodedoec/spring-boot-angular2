/*
 * MwstEintrBestEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;

import ch.admin.oss.common.enums.ProzessTypEnum;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_MWST_EINTR_BEST")
public class MwstEintrBestEntity extends AbstractOSSEntity {

	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name="FK_MWST_EINTR_PROZESS"))
	private ProzessEntity prozess;
	
	/**
	 * Company UID
	 */
	@NotNull
	@Column(name = "MWSTNR")
	private String mwstNr;
	
	/**
	 * Company name
	 */
	@NotNull
	@Column(name = "NAME")
	private String name;
	
	/**
	 * Company address
	 */
	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE", foreignKey = @ForeignKey(name="FK_MWST_EINTR_ADRESSE"))
	private AdresseEntity adresse;
	
	/**
	 * Legal form (concatenation of all legal forms)
	 */
	@NotNull
	@Column(name = "BRANCHE")
	private String branche;
	
	@Column(name = "JAHR")
	private BigDecimal jahr;
	
	/**
	 * Delivery address
	 */
	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ZUSTELL_ADRESSE", foreignKey = @ForeignKey(name="FK_MWST_EINTR_Z_ADRESSE"))
	private AdresseEntity zustellAdresse;
	
	/**
	 * Remarks
	 */
	@Column(name = "BEMERKUNGEN")
	private String bemerkungen;
	
	@NotNull
	@Type(type = "org.hibernate.type.TrueFalseType")
	@Column(name = "APOSTILLE", length = 1)
	private Boolean apostille = Boolean.FALSE;
	
	public MwstEintrBestEntity() {
		prozess = new ProzessEntity(ProzessTypEnum.MWST_EINTRBEST, false);
	}

	public ProzessEntity getProzess() {
		return prozess;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	public String getMwstNr() {
		return mwstNr;
	}

	public void setMwstNr(String mwstNr) {
		this.mwstNr = mwstNr;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public AdresseEntity getAdresse() {
		return adresse;
	}

	public void setAdresse(AdresseEntity adresse) {
		this.adresse = adresse;
	}

	public String getBranche() {
		return branche;
	}

	public void setBranche(String branche) {
		this.branche = branche;
	}

	public BigDecimal getJahr() {
		return jahr;
	}

	public void setJahr(BigDecimal jahr) {
		this.jahr = jahr;
	}

	public AdresseEntity getZustellAdresse() {
		return zustellAdresse;
	}

	public void setZustellAdresse(AdresseEntity zustellAdresse) {
		this.zustellAdresse = zustellAdresse;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public Boolean getApostille() {
		return apostille;
	}

	public void setApostille(Boolean apostille) {
		this.apostille = apostille;
	}
}
