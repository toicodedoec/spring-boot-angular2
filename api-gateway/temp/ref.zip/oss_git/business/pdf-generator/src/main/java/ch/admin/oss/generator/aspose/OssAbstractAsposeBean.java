/*
 * OssAbstractAsposeBean
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.generator.aspose;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;

import ch.admin.oss.OssEmptyFieldMapping;

/**
 * @author hha
 */
public abstract class OssAbstractAsposeBean {
	
	protected OssAsposeContext context;
	
	public OssAbstractAsposeBean(OssAsposeContext context) {
		this.context = context;
	}

	protected Object getValue(Object target, String field) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException  {
		if (target == null || StringUtils.isBlank(field)) {
			return null;
		}
		return PropertyUtils.getNestedProperty(target, standardFieldName(field));
	}
	
	protected Object getFormattedValue(Object inTarget, String inField) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException  {
		if (StringUtils.endsWithIgnoreCase(inField, "#Size")) {
			return getValueAsCollection(inTarget, inField.replace("#Size", StringUtils.EMPTY)).size();
		}

		Object target = inTarget;
		String field = standardFieldName(inField);
		if (StringUtils.isBlank(field)) {
			return null;
		}

		String[] fields = field.split("\\.");
		for (int i = 0; i < fields.length - 2; i++) {
			if (target == null) {
				return null;
			}
			target = PropertyUtils.getSimpleProperty(target, fields[i]);
		}
		if (target == null) {
			return null;
		}

		String fieldName = fields[fields.length - 1];
		Object value = context.formatValue(target, fieldName, PropertyUtils.getSimpleProperty(target, fieldName));
		if (value == null || (value instanceof String && StringUtils.isEmpty((String) value))) {
			return getEmptyValue(target, fieldName);
		}
		return value;
	}

	private Object getEmptyValue(Object entity, String fieldName) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException  {
		OssEmptyFieldMapping annotation = OssAsposeContext.getField(entity.getClass(), fieldName).getDeclaredAnnotation(OssEmptyFieldMapping.class);
		if (annotation != null) {
			String field = ((OssEmptyFieldMapping) annotation).value();
			return getFormattedValue(entity, field);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	protected Collection<Object> getValueAsCollection(Object target, String field) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException  {
		return (Collection<Object>) getValue(target, field);
	}

	private String standardFieldName(String inField) throws IllegalAccessException {
		if (StringUtils.isBlank(inField)) {
			return StringUtils.EMPTY;
		}
		String[] fields = StringUtils.trimToEmpty(inField).split("\\.");
		List<String> standardFields = new ArrayList<String>(fields.length);
		for (String field : fields) {
			if (StringUtils.isAllUpperCase(field)) {
				standardFields.add(StringUtils.lowerCase(field));
			} else {
				final int len = field.length();
				StringBuilder builder = new StringBuilder("");
				for (int i = 0; i < len; i++) {
					if ((i == 0) || ((i < len - 1) && Character.isUpperCase(field.charAt(i)) && Character.isUpperCase(field.charAt(i + 1)))) {
						builder.append(StringUtils.lowerCase(String.valueOf(field.charAt(i))));
					} else {
						builder.append(String.valueOf(field.charAt(i)));
					}
				}
				standardFields.add(builder.toString());
			}
		}
		return StringUtils.join(standardFields, ".");
	}
}