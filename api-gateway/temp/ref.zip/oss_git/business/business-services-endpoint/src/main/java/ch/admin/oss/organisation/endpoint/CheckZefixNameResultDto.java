/*
 * CheckZefixNameResultDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import ch.admin.oss.common.ZefixErrorEnum;
import ch.admin.oss.externalinterfaces.outgoing.zefix.ShortResponseDto;
import ch.admin.oss.hr.endpoint.HrAmtDto;

public class CheckZefixNameResultDto {

	private ShortResponseDto shortResponse = new ShortResponseDto();
	private HrAmtDto hrAmt;
	private ZefixErrorEnum error;

	public CheckZefixNameResultDto() {
		// default constructor
	}

	public CheckZefixNameResultDto(ShortResponseDto shortResponse, HrAmtDto hrAmt) {
		this.shortResponse = shortResponse;
		this.hrAmt = hrAmt;
	}

	public CheckZefixNameResultDto(ShortResponseDto shortResponse) {
		this.shortResponse = shortResponse;
	}

	public CheckZefixNameResultDto(ZefixErrorEnum error, HrAmtDto hrAmt) {
		this.error = error;
		this.hrAmt = hrAmt;
	}

	public CheckZefixNameResultDto(ZefixErrorEnum error) {
		this.error = error;
	}

	public CheckZefixNameResultDto(HrAmtDto hrAmt) {
		this.hrAmt = hrAmt;
	}

	public ShortResponseDto getShortResponse() {
		return shortResponse;
	}
	
	public HrAmtDto getHrAmt() {
		return hrAmt;
	}

	public ZefixErrorEnum getError() {
		return error;
	}
}
