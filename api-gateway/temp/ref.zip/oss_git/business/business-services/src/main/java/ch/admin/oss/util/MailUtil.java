/*
 * MailUtil
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.io.File;
import java.io.IOException;
import java.net.URLConnection;
import java.util.Map.Entry;

import javax.activation.MimetypesFileTypeMap;
import javax.mail.MessagingException;
import javax.mail.util.ByteArrayDataSource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import ch.admin.oss.common.OssTechnicalException;
import freemarker.template.Configuration;
import freemarker.template.TemplateException;

/**
 * Implementation from {@link IMailUtil} that uses FreeMarker as template engine.
 * 
 * @author phd
 */
@Profile("!unittest")
@Component
public class MailUtil implements IMailUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(MailUtil.class);

	@Autowired
	private JavaMailSender mailSender;

	@Qualifier("freemarkerEngine")
	@Autowired
	private Configuration freeMarkerEngine;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void send(MailMessage message) {
		try {
			MimeMessageHelper helper = new MimeMessageHelper(mailSender.createMimeMessage(), true, "UTF-8");

			if (StringUtils.isNotEmpty(message.getTemplateName())) {
				helper.setText(FreeMarkerTemplateUtils.processTemplateIntoString(
					freeMarkerEngine.getTemplate(message.getTemplateName()), message.getTemplateModel()), true);
			} else {
				helper.setText(message.getText());
			}

			if (message.getSentDate() != null) {
				helper.setSentDate(message.getSentDate());
			}

			if (message.getSubject() != null) {
				helper.setSubject(message.getSubject());
			}

			if (message.getFrom() != null) {
				helper.setFrom(message.getFrom());
			}

			if (message.getTo() != null) {
				helper.setTo(message.getTo());
			}

			if (message.getBcc() != null) {
				helper.setBcc(message.getBcc());
			}

			if (message.getCc() != null) {
				helper.setCc(message.getCc());
			}

			if (message.getReplyTo() != null) {
				helper.setReplyTo(message.getReplyTo());
			}

			if (message.getAttachments() != null && !message.getAttachments().isEmpty()) {
				for (Entry<String, File> entry : message.getAttachments().entrySet()) {
					helper.addAttachment(entry.getKey(), new FileSystemResource(entry.getValue()));
				}
			}
			
			if (message.getAttachmentDatas() != null && !message.getAttachmentDatas().isEmpty()) {
				for (Entry<String, byte[]> entry : message.getAttachmentDatas().entrySet()) {
					String mimeType = getMimeType(entry.getKey(), entry.getValue());
					helper.addAttachment(entry.getKey(), new ByteArrayDataSource(entry.getValue(), mimeType)); 
				}
			}

			mailSender.send(helper.getMimeMessage());
		} catch (MessagingException | IOException | TemplateException e) {
			LOGGER.error("Error sending mail", e);
			throw new OssTechnicalException("Error sending mail", e);
		}
	}
	
	private String getMimeType(String filename, byte[] data) throws IOException {
		String mimeType = URLConnection.guessContentTypeFromName(filename);
		if (mimeType == null) {
			mimeType = MimetypesFileTypeMap.getDefaultFileTypeMap().getContentType(filename);
		}
		if (mimeType == null) {
			mimeType = MediaType.APPLICATION_OCTET_STREAM_VALUE;
		}
		return mimeType;
	}
	
}
