package ch.admin.oss.ahv.endpoint;

import java.math.BigDecimal;
import java.util.Date;

import ch.admin.oss.admin.endpoint.AusgleichskasseDto;
import ch.admin.oss.admin.endpoint.VerbandDto;
import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.PersonDto;
import ch.admin.oss.common.enums.AhvMitarbeitEnum;
import ch.admin.oss.common.enums.AhvNamenEnum;

/**
 * @author hhu
 */
public class AhvTeilhaberDto extends AbstractOSSDto {
	private String bisherAk;
	private Date bisherVon;
	private Date bisherBis;
	private Boolean bisherHatKinder;
	private PersonDto person;
	private boolean complete;
	private Long bisherVerbandAkId;
	private AusgleichskasseDto bisherVerbandAkDto;
	private Long bisherBerufVerbandId;
	private VerbandDto bisherBerufVerbandDto;
	private Long bisherBeitragAls;
	private CodeWertDto bisherBeitragAlsDto;
	private BigDecimal bisherEinkommen;
	private AhvMitarbeitEnum mitarbeit;
	private String mitarbeitRolle;
	private String mitarbeitBezeichnung;
	private String mitarbeitName;
	private String mitarbeitStrasse;
	private String mitarbeitPlzOrt;
	private String mitarbeitStaaten;
	private Boolean aoaWeisung;
	private Boolean aoaKonkurrenzverbot;
	private Boolean aoaPersoenlich;
	private AhvNamenEnum aoaName;
	private Boolean aoaBriefpapier;
	private Boolean aoaWerbung;
	private Boolean aoaOfferten;
	private Boolean aoaRechnungen;
	private Boolean aoaRabatte;
	private Boolean aoaKundendienst;
	private BigDecimal einkommenEinkommen;
	private BigDecimal einkommenAnteilAmGewinn;
	private BigDecimal einkommenAnteilAmVerlust;
	private Boolean einkommenRechnung;
	private Boolean einkommenLohn;
	private Boolean einkommenProvision;
	private Boolean lastenUnkosten;
	private Boolean lastenUnterhalt;
	private Boolean lastenGarantie;
	private Boolean lastenMaterial;
	private Boolean lastenInkassorisiko;
	private Boolean lastenVerluste;
	private Boolean lastenLohnanspruch;
	private String lastenRisiko;
	private Boolean partnerArbeitetMit;
	private Boolean partnerEinkommenUeber;
	private PersonDto partner;
	private BigDecimal partnerLohnSumme;
	private Date partnerLohnSeit;
	private Boolean partnerHatKinder;

	public BigDecimal getBisherEinkommen() {
		return bisherEinkommen;
	}

	public void setBisherEinkommen(BigDecimal bisherEinkommen) {
		this.bisherEinkommen = bisherEinkommen;
	}

	public String getBisherAk() {
		return bisherAk;
	}

	public void setBisherAk(String bisherAk) {
		this.bisherAk = bisherAk;
	}

	public Date getBisherVon() {
		return bisherVon;
	}

	public void setBisherVon(Date bisherVon) {
		this.bisherVon = bisherVon;
	}

	public Date getBisherBis() {
		return bisherBis;
	}

	public void setBisherBis(Date bisherBis) {
		this.bisherBis = bisherBis;
	}

	public Boolean getBisherHatKinder() {
		return bisherHatKinder;
	}

	public void setBisherHatKinder(Boolean bisherHatKinder) {
		this.bisherHatKinder = bisherHatKinder;
	}

	public PersonDto getPerson() {
		return person;
	}

	public void setPerson(PersonDto person) {
		this.person = person;
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	public Long getBisherVerbandAkId() {
		return bisherVerbandAkId;
	}

	public void setBisherVerbandAkId(Long bisherVerbandAkId) {
		this.bisherVerbandAkId = bisherVerbandAkId;
	}

	public Long getBisherBerufVerbandId() {
		return bisherBerufVerbandId;
	}

	public void setBisherBerufVerbandId(Long bisherBerufVerbandId) {
		this.bisherBerufVerbandId = bisherBerufVerbandId;
	}

	public Long getBisherBeitragAls() {
		return bisherBeitragAls;
	}

	public void setBisherBeitragAls(Long bisherBeitragAls) {
		this.bisherBeitragAls = bisherBeitragAls;
	}

	public Boolean getAoaWeisung() {
		return aoaWeisung;
	}

	public void setAoaWeisung(Boolean aoaWeisung) {
		this.aoaWeisung = aoaWeisung;
	}

	public Boolean getAoaKonkurrenzverbot() {
		return aoaKonkurrenzverbot;
	}

	public void setAoaKonkurrenzverbot(Boolean aoaKonkurrenzverbot) {
		this.aoaKonkurrenzverbot = aoaKonkurrenzverbot;
	}

	public Boolean getAoaPersoenlich() {
		return aoaPersoenlich;
	}

	public void setAoaPersoenlich(Boolean aoaPersoenlich) {
		this.aoaPersoenlich = aoaPersoenlich;
	}

	public AhvNamenEnum getAoaName() {
		return aoaName;
	}

	public void setAoaName(AhvNamenEnum aoaName) {
		this.aoaName = aoaName;
	}

	public Boolean getAoaBriefpapier() {
		return aoaBriefpapier;
	}

	public void setAoaBriefpapier(Boolean aoaBriefpapier) {
		this.aoaBriefpapier = aoaBriefpapier;
	}

	public Boolean getAoaWerbung() {
		return aoaWerbung;
	}

	public void setAoaWerbung(Boolean aoaWerbung) {
		this.aoaWerbung = aoaWerbung;
	}

	public Boolean getAoaOfferten() {
		return aoaOfferten;
	}

	public void setAoaOfferten(Boolean aoaOfferten) {
		this.aoaOfferten = aoaOfferten;
	}

	public Boolean getAoaRechnungen() {
		return aoaRechnungen;
	}

	public void setAoaRechnungen(Boolean aoaRechnungen) {
		this.aoaRechnungen = aoaRechnungen;
	}

	public AhvMitarbeitEnum getMitarbeit() {
		return mitarbeit;
	}

	public void setMitarbeit(AhvMitarbeitEnum mitarbeit) {
		this.mitarbeit = mitarbeit;
	}

	public String getMitarbeitRolle() {
		return mitarbeitRolle;
	}

	public void setMitarbeitRolle(String mitarbeitRolle) {
		this.mitarbeitRolle = mitarbeitRolle;
	}

	public String getMitarbeitBezeichnung() {
		return mitarbeitBezeichnung;
	}

	public void setMitarbeitBezeichnung(String mitarbeitBezeichnung) {
		this.mitarbeitBezeichnung = mitarbeitBezeichnung;
	}

	public String getMitarbeitName() {
		return mitarbeitName;
	}

	public void setMitarbeitName(String mitarbeitName) {
		this.mitarbeitName = mitarbeitName;
	}

	public String getMitarbeitStrasse() {
		return mitarbeitStrasse;
	}

	public void setMitarbeitStrasse(String mitarbeitStrasse) {
		this.mitarbeitStrasse = mitarbeitStrasse;
	}

	public String getMitarbeitPlzOrt() {
		return mitarbeitPlzOrt;
	}

	public void setMitarbeitPlzOrt(String mitarbeitPlzOrt) {
		this.mitarbeitPlzOrt = mitarbeitPlzOrt;
	}

	public String getMitarbeitStaaten() {
		return mitarbeitStaaten;
	}

	public void setMitarbeitStaaten(String mitarbeitStaaten) {
		this.mitarbeitStaaten = mitarbeitStaaten;
	}

	public BigDecimal getEinkommenEinkommen() {
		return einkommenEinkommen;
	}

	public void setEinkommenEinkommen(BigDecimal einkommenEinkommen) {
		this.einkommenEinkommen = einkommenEinkommen;
	}

	public BigDecimal getEinkommenAnteilAmGewinn() {
		return einkommenAnteilAmGewinn;
	}

	public void setEinkommenAnteilAmGewinn(BigDecimal einkommenAnteilAmGewinn) {
		this.einkommenAnteilAmGewinn = einkommenAnteilAmGewinn;
	}

	public BigDecimal getEinkommenAnteilAmVerlust() {
		return einkommenAnteilAmVerlust;
	}

	public void setEinkommenAnteilAmVerlust(BigDecimal einkommenAnteilAmVerlust) {
		this.einkommenAnteilAmVerlust = einkommenAnteilAmVerlust;
	}

	public Boolean getEinkommenRechnung() {
		return einkommenRechnung;
	}

	public void setEinkommenRechnung(Boolean einkommenRechnung) {
		this.einkommenRechnung = einkommenRechnung;
	}

	public Boolean getEinkommenLohn() {
		return einkommenLohn;
	}

	public void setEinkommenLohn(Boolean einkommenLohn) {
		this.einkommenLohn = einkommenLohn;
	}

	public Boolean getEinkommenProvision() {
		return einkommenProvision;
	}

	public void setEinkommenProvision(Boolean einkommenProvision) {
		this.einkommenProvision = einkommenProvision;
	}

	public Boolean getLastenUnkosten() {
		return lastenUnkosten;
	}

	public void setLastenUnkosten(Boolean lastenUnkosten) {
		this.lastenUnkosten = lastenUnkosten;
	}

	public Boolean getLastenUnterhalt() {
		return lastenUnterhalt;
	}

	public void setLastenUnterhalt(Boolean lastenUnterhalt) {
		this.lastenUnterhalt = lastenUnterhalt;
	}

	public Boolean getLastenGarantie() {
		return lastenGarantie;
	}

	public void setLastenGarantie(Boolean lastenGarantie) {
		this.lastenGarantie = lastenGarantie;
	}

	public Boolean getLastenMaterial() {
		return lastenMaterial;
	}

	public void setLastenMaterial(Boolean lastenMaterial) {
		this.lastenMaterial = lastenMaterial;
	}

	public Boolean getLastenInkassorisiko() {
		return lastenInkassorisiko;
	}

	public void setLastenInkassorisiko(Boolean lastenInkassorisiko) {
		this.lastenInkassorisiko = lastenInkassorisiko;
	}

	public Boolean getLastenVerluste() {
		return lastenVerluste;
	}

	public void setLastenVerluste(Boolean lastenVerluste) {
		this.lastenVerluste = lastenVerluste;
	}

	public Boolean getLastenLohnanspruch() {
		return lastenLohnanspruch;
	}

	public void setLastenLohnanspruch(Boolean lastenLohnanspruch) {
		this.lastenLohnanspruch = lastenLohnanspruch;
	}

	public String getLastenRisiko() {
		return lastenRisiko;
	}

	public void setLastenRisiko(String lastenRisiko) {
		this.lastenRisiko = lastenRisiko;
	}

	public Boolean getPartnerArbeitetMit() {
		return partnerArbeitetMit;
	}

	public void setPartnerArbeitetMit(Boolean partnerArbeitetMit) {
		this.partnerArbeitetMit = partnerArbeitetMit;
	}

	public Boolean getPartnerEinkommenUeber() {
		return partnerEinkommenUeber;
	}

	public void setPartnerEinkommenUeber(Boolean partnerEinkommenUeber) {
		this.partnerEinkommenUeber = partnerEinkommenUeber;
	}

	public PersonDto getPartner() {
		return partner;
	}

	public void setPartner(PersonDto partner) {
		this.partner = partner;
	}

	public AusgleichskasseDto getBisherVerbandAkDto() {
		return bisherVerbandAkDto;
	}

	public void setBisherVerbandAkDto(AusgleichskasseDto bisherVerbandAkDto) {
		this.bisherVerbandAkDto = bisherVerbandAkDto;
	}

	public VerbandDto getBisherBerufVerbandDto() {
		return bisherBerufVerbandDto;
	}

	public void setBisherBerufVerbandDto(VerbandDto bisherBerufVerbandDto) {
		this.bisherBerufVerbandDto = bisherBerufVerbandDto;
	}

	public CodeWertDto getBisherBeitragAlsDto() {
		return bisherBeitragAlsDto;
	}

	public void setBisherBeitragAlsDto(CodeWertDto bisherBeitragAlsDto) {
		this.bisherBeitragAlsDto = bisherBeitragAlsDto;
	}

	public Boolean getAoaRabatte() {
		return aoaRabatte;
	}

	public void setAoaRabatte(Boolean aoaRabatte) {
		this.aoaRabatte = aoaRabatte;
	}

	public Boolean getAoaKundendienst() {
		return aoaKundendienst;
	}

	public void setAoaKundendienst(Boolean aoaKundendienst) {
		this.aoaKundendienst = aoaKundendienst;
	}

	public BigDecimal getPartnerLohnSumme() {
		return partnerLohnSumme;
	}

	public void setPartnerLohnSumme(BigDecimal partnerLohnSumme) {
		this.partnerLohnSumme = partnerLohnSumme;
	}

	public Date getPartnerLohnSeit() {
		return partnerLohnSeit;
	}

	public void setPartnerLohnSeit(Date partnerLohnSeit) {
		this.partnerLohnSeit = partnerLohnSeit;
	}

	public Boolean getPartnerHatKinder() {
		return partnerHatKinder;
	}

	public void setPartnerHatKinder(Boolean partnerHatKinder) {
		this.partnerHatKinder = partnerHatKinder;
	}
}
