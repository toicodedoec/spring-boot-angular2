/*
 * PflichtenabklaerungenEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import ch.admin.oss.common.enums.AnmeldungAHVBefundEnum;
import ch.admin.oss.common.enums.AnmeldungHRBefundEnum;
import ch.admin.oss.common.enums.AnmeldungMWSTBefundEnum;
import ch.admin.oss.common.enums.AnmeldungUVGBefundEnum;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author coh
 *
 */
@Audited
@Entity
@Table(name = "T_PFLICHTENABKLAERUNGEN", 
	uniqueConstraints = {
		@UniqueConstraint(name = "UK_PFLICHTEN_USER", columnNames = "LN_USER"), 
		@UniqueConstraint(name = "UK_PFLICHTEN_ORGANISATION", columnNames = "LN_ORGANISATION")
	})
public class PflichtenabklaerungenEntity extends AbstractOSSEntity {
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_USER", foreignKey = @ForeignKey(name="FK_PFLICHTEN_USER"))
	private UserEntity user;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name="FK_PFLICHTEN_ORGANISATION"))
	private OrganisationEntity organisation;
	
	@Column(name = "RECHTSFORM")
	@Enumerated(EnumType.STRING)
	private RechtsformEnum rechtsform;
		
	@Column(name = "ANMELDUNG_HR", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean anmeldungHR;
	
	@Column(name = "ANMELDUNG_HR_BEFUND")
	@Enumerated(EnumType.STRING)
	private AnmeldungHRBefundEnum anmeldungHRBefund;
	
	@Column(name = "ANMELDUNG_AHV", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean anmeldungAHV;
	
	@Column(name = "ANMELDUNG_AHV_BEFUND")
	@Enumerated(EnumType.STRING)
	private AnmeldungAHVBefundEnum anmeldungAHVBefund;
	
	@Column(name = "ANMELDUNG_MWST", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean anmeldungMWST;
	
	@Column(name = "ANMELDUNG_MWST_BEFUND")
	@Enumerated(EnumType.STRING)
	private AnmeldungMWSTBefundEnum anmeldungMWSTBefund;
	
	@Column(name = "ANMELDUNG_UVG", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean anmeldungUVG;
	
	@Column(name = "ANMELDUNG_UVG_BEFUND")
	@Enumerated(EnumType.STRING)
	private AnmeldungUVGBefundEnum anmeldungUVGBefund;
	
	@Column(name = "EROEFFNUNGS_DATUM")
	private LocalDate eroeffnungsdatum;
	
	@Column(name = "UMSATZ_100K", length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean umsatz100k;
	
	@Column(name = "ANGESTELLTE")
	private Integer angestellte;
	
	@Column(name = "NUR_VOLLZEIT", length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean nurVollzeit;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_BERUF", foreignKey = @ForeignKey(name = "FK_PFLICHTEN_BERUF"))
	private BerufEntity beruf;
	
	@Column(name = "BERUF_TEXT")
	private String berufText;
	
	@Column(name = "HANDEL", length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean handel;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@Fetch(FetchMode.SUBSELECT)
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name="T_PFLICHTEN_BRANCHE",
		joinColumns=
			@JoinColumn(name="LN_PFLICHTEN", referencedColumnName="PK", foreignKey = @ForeignKey(name = "FK_PFLICHTEN_BRANCHE_PFLICHTEN")),
		inverseJoinColumns=
			@JoinColumn(name="LN_BRANCHE", referencedColumnName="PK", foreignKey = @ForeignKey(name = "FK_PFLICHTEN_BRANCHE_BRANCHE")),
		uniqueConstraints={
			@UniqueConstraint(name="UK_PFLICHTEN_BRANCHE", columnNames = {"LN_PFLICHTEN", "LN_BRANCHE"})
		})
	private Set<BrancheEntity> branches = new HashSet<>();
	
	@Column(name = "DIGITAL", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean digital;
	
	// TODO [COH] Check usage of this field.
	@Column(name = "DATUM")
	private LocalDateTime datum;
	
	@Column(name = "LOCKED", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean locked;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@OneToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "LN_FLOW_HISTORY", foreignKey = @ForeignKey(name = "FK_PFLICHTEN_HISTORY"))
	private FlowHistoryEntity flowHistory;
	
	@Column(name = "COMPLETED", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean completed;

	public UserEntity getUser() {
		return user;
	}

	public void setUser(UserEntity user) {
		this.user = user;
	}

	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}

	public boolean isAnmeldungHR() {
		return anmeldungHR;
	}

	public void setAnmeldungHR(boolean anmeldungHR) {
		this.anmeldungHR = anmeldungHR;
	}

	public AnmeldungHRBefundEnum getAnmeldungHRBefund() {
		return anmeldungHRBefund;
	}

	public void setAnmeldungHRBefund(AnmeldungHRBefundEnum anmeldungHRBefund) {
		this.anmeldungHRBefund = anmeldungHRBefund;
	}

	public boolean isAnmeldungAHV() {
		return anmeldungAHV;
	}

	public void setAnmeldungAHV(boolean anmeldungAHV) {
		this.anmeldungAHV = anmeldungAHV;
	}

	public AnmeldungAHVBefundEnum getAnmeldungAHVBefund() {
		return anmeldungAHVBefund;
	}

	public void setAnmeldungAHVBefund(AnmeldungAHVBefundEnum anmeldungAHVBefund) {
		this.anmeldungAHVBefund = anmeldungAHVBefund;
	}

	public boolean isAnmeldungMWST() {
		return anmeldungMWST;
	}

	public void setAnmeldungMWST(boolean anmeldungMWST) {
		this.anmeldungMWST = anmeldungMWST;
	}

	public AnmeldungMWSTBefundEnum getAnmeldungMWSTBefund() {
		return anmeldungMWSTBefund;
	}

	public void setAnmeldungMWSTBefund(AnmeldungMWSTBefundEnum anmeldungMWSTBefund) {
		this.anmeldungMWSTBefund = anmeldungMWSTBefund;
	}

	public boolean isAnmeldungUVG() {
		return anmeldungUVG;
	}

	public void setAnmeldungUVG(boolean anmeldungUVG) {
		this.anmeldungUVG = anmeldungUVG;
	}

	public AnmeldungUVGBefundEnum getAnmeldungUVGBefund() {
		return anmeldungUVGBefund;
	}

	public void setAnmeldungUVGBefund(AnmeldungUVGBefundEnum anmeldungUVGBefund) {
		this.anmeldungUVGBefund = anmeldungUVGBefund;
	}

	public LocalDate getEroeffnungsdatum() {
		return eroeffnungsdatum;
	}

	public void setEroeffnungsdatum(LocalDate eroeffnungsdatum) {
		this.eroeffnungsdatum = eroeffnungsdatum;
	}

	public Boolean getUmsatz100k() {
		return umsatz100k;
	}

	public void setUmsatz100k(Boolean umsatz100k) {
		this.umsatz100k = umsatz100k;
	}

	public Integer getAngestellte() {
		return angestellte;
	}

	public void setAngestellte(Integer angestellte) {
		this.angestellte = angestellte;
	}

	public Boolean getNurVollzeit() {
		return nurVollzeit;
	}

	public void setNurVollzeit(Boolean nurVollzeit) {
		this.nurVollzeit = nurVollzeit;
	}

	public BerufEntity getBeruf() {
		return beruf;
	}

	public void setBeruf(BerufEntity beruf) {
		this.beruf = beruf;
	}

	public String getBerufText() {
		return berufText;
	}

	public void setBerufText(String berufText) {
		this.berufText = berufText;
	}

	public Boolean getHandel() {
		return handel;
	}

	public void setHandel(Boolean handel) {
		this.handel = handel;
	}

	public Set<BrancheEntity> getBranches() {
		return branches;
	}

	public void setBranches(Set<BrancheEntity> branches) {
		this.branches = branches;
	}

	public boolean isDigital() {
		return digital;
	}

	public void setDigital(boolean digital) {
		this.digital = digital;
	}

	public LocalDateTime getDatum() {
		return datum;
	}

	public void setDatum(LocalDateTime datum) {
		this.datum = datum;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public FlowHistoryEntity getFlowHistory() {
		return flowHistory;
	}

	public void setFlowHistory(FlowHistoryEntity flowHistory) {
		this.flowHistory = flowHistory;
	}
	
}
