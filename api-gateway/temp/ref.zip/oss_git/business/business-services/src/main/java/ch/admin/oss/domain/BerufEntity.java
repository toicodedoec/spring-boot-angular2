/*
 * BerufEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;

import com.querydsl.core.annotations.QueryProjection;

import ch.admin.oss.common.enums.HREPflichtEnum;

/**
 * @author coh
 */
@Entity
@Table(name = "T_BERUF")
public class BerufEntity extends AbstractOSSEntity {

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_STANDARD_TEXT", foreignKey = @ForeignKey(name = "FK_BERUF_TEXT"))
	private StandardTextEntity standardText;

	@Column(name = "CODE")
	private String code;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PARENT", foreignKey = @ForeignKey(name = "FK_BERUF_BERUF"))
	private BerufEntity parent;

	@Column(name = "AKTIV", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean aktiv;

	@Column(name = "HRE_PFLICHT")
	@Enumerated(EnumType.STRING)
	private HREPflichtEnum hrePflicht;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_BRANCHE", foreignKey = @ForeignKey(name = "FK_BERUF_BRANCH"))
	private BrancheEntity branche;

	@Column(name = "HANDEL", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean handel;

	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "parent", cascade = CascadeType.ALL)
	private Set<BerufEntity> childBerufs = new HashSet<>();

	@Column(name = "POS")
	private int pos;

	public BerufEntity() {}

	@QueryProjection
	public BerufEntity(Long id) {
		setId(id);
	}

	public StandardTextEntity getStandardText() {
		return standardText;
	}

	public String getCode() {
		return code;
	}

	public BerufEntity getParent() {
		return parent;
	}

	public boolean isAktiv() {
		return aktiv;
	}

	public HREPflichtEnum getHrePflicht() {
		return hrePflicht;
	}

	public BrancheEntity getBranche() {
		return branche;
	}

	public boolean isHandel() {
		return handel;
	}

	public Set<BerufEntity> getChildBerufs() {
		return childBerufs;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public void setStandardText(StandardTextEntity standardText) {
		this.standardText = standardText;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}

	public void setParent(BerufEntity parent) {
		this.parent = parent;
	}

	public void setBranche(BrancheEntity branche) {
		this.branche = branche;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setHrePflicht(HREPflichtEnum hrePflicht) {
		this.hrePflicht = hrePflicht;
	}

	public void setHandel(boolean handel) {
		this.handel = handel;
	}

	public void setChildBerufs(Set<BerufEntity> childBerufs) {
		this.childBerufs = childBerufs;
	}

}
