/*
 * FunktionRechteCriteria
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.criteria;

import ch.admin.oss.security.OssRole;

/**
 * @author hha
 */
public class FunktionRechteCriteria extends AbstractPaginationCriteria {

	private String funktionOrBeschreibung;
	private OssRole gruppen;

	public String getFunktionOrBeschreibung() {
		return funktionOrBeschreibung;
	}

	public void setFunktionOrBeschreibung(String funktionOrBeschreibung) {
		this.funktionOrBeschreibung = funktionOrBeschreibung;
	}

	public OssRole getGruppen() {
		return gruppen;
	}

	public void setGruppen(OssRole gruppen) {
		this.gruppen = gruppen;
	}

}
