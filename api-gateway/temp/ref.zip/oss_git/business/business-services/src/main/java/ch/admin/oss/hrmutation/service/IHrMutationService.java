/*
 * IHRService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.service;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;

import com.querydsl.core.types.Path;

import ch.admin.oss.common.IQuickwinProcessService;
import ch.admin.oss.common.dto.AutoCompletePersonResultDto;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonRoleEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrMutationEntity;
import ch.admin.oss.domain.HrMutationPersonEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.KommGesEntity;
import ch.admin.oss.domain.PersonEntity;

/**
 * @author hhg
 *
 */
@Validated
public interface IHrMutationService extends IQuickwinProcessService<HrMutationEntity> {

	/**
	 * Return HrMutation data.
	 * @param id HrMutation ID
	 * @param orgId Organization ID
	 * @return HrMutationEntity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationEntity getHrMutation(long id, int version, long orgId, Path<?>... associations);

	/**
	 * Return HrMutation data with all its referenced data.
	 * This method should use only in case of starting process flow.
	 * @param processId Process ID 
	 * @param orgId Organization ID
	 * @return HrMutationEntity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationEntity getHrMutationWithReferencedData(long processId, long orgId, Path<?>... associations);

	/**
	 * Update new company domicile for HR Mutation
	 * @param domicile New domicile
	 * @return AdresseEntity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	AdresseEntity updateDomicile(long orgId, AdresseEntity domicile);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<AutoCompletePersonResultDto> searchPersons(long orgId, String criterion, List<HrMutationTypeOfPersonRoleEnum> personTypes);

	// TODO [XDG/S9] Need to hasPermission with this method?
	PersonEntity getPerson(long personId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	PersonEntity getPerson(long orgId, long personId, int version);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	PersonEntity savePerson(long orgId, PersonEntity entity);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationPersonEntity getHrMutationPerson(long orgId, long mutationPersonId, int version);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationPersonEntity saveHrMutationPerson(long orgId, HrMutationPersonEntity entity);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<AdresseEntity> getListExistingAdresse(long orgId);

	GeschaftsrolleEntity saveGeschaftsrolle(GeschaftsrolleEntity ent);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	GeschaftsrolleEntity loadGeschaftsrolleById(long orgId, long id, int version);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationEntity deleteExcerptsAdresse(long orgId, long id, int version);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	GeschaftsrolleEntity loadFullGeschaftsrolleById(long orgId, long id, int version);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationEntity deleteMutationPerson(long orgId, long id, int version, long personId, int personVersion);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationEntity updateTaskProzess(long orgId, HrMutationEntity entity);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationPersonEntity saveMutationLegalPersonAndDeleteNaturalPerson(long orgId, HrMutationPersonEntity entity);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationPersonEntity saveMutationNaturalPersonAndDeleteLegalPerson(long orgId, HrMutationPersonEntity entity);

	// This method intend to used for unit test only.
	// TODO [COH] consider put @PreAuthorize as well. 
	public byte[] generateDocument(HrMutationEntity entity, boolean draft);

	/**
	 * @param id
	 * @param version
	 * @return
	 */
	KommFirmaEntity getKommfirmaById(Long id, int version);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	KommGesEntity loadKommgesByOrgId(long orgId);

	/**
	 * @param kommGesEntity
	 * @return
	 */
	KommGesEntity saveKommGes(KommGesEntity kommGesEntity);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	HrMutationEntity refreshDissNewOwner(long id, int version, long orgId, GeschaftsrolleEntity geschaftrolle);
}
