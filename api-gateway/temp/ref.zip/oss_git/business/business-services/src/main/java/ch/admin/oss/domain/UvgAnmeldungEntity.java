/*
 * UvgAnmeldungEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;

import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.VersichererWunschEnum;
import ch.admin.oss.validator.OSSSytemValidator;

/**
 *  
 * @author coh
 */
@Entity
@Table(name = "T_UVG_ANMELDUNG")
public class UvgAnmeldungEntity extends AbstractOSSEntity implements IProzessEntity {

	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name="FK_UVG_PROZESS"))
	private ProzessEntity prozess;
	
	@Column(name = "ANGESTELLTE_HEUTE")
	private BigDecimal angestellteHeute;
	
	@Column(name = "ERSTE_ANSTELLUNG")
	private LocalDate ersteAnstellung;
	
	@Column(name = "ANGESTELLTE_ZUKUNFT")
	private BigDecimal angestellteZukunft;
	
	@Column(name = "ERSTE_ANSTELLUNG_ZUKUNFT")
	private LocalDate ersteAnstellungZukunft;
	
	@Column(name = "ANGESTELLTE_PARTNER", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean angestelltePartner;
	
	@Column(name = "ANGESTELLTE_FAMILIE", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean angestellteFamilie;
	
	@Column(name = "ANGESTELLTE_LEHRLING", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean angestellteLehrling;
	
	@Column(name = "ANGESTELLTE_OHNE_LOHN", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean angestellteOhneLohn;
	
	@Column(name = "ANGESTELLTE_AUSHILFE", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean angestellteAushilfe;
	
	@Column(name = "ANGESTELLTE_GESELLSCHAFTER", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean angestellteGesellschafter;
	
	@Column(name = "UVG_INHABER_FREIWILLIG", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean uvgInhaberFreiwillig;
	
	@Column(name = "LOHNSUMME")
	private BigDecimal lohnsumme;
	
	@Column(name = "LOHNSUMME_FOLGEJAHR")
	private BigDecimal lohnsummeFolgejahr;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ZAHLUNGSMODUS", foreignKey = @ForeignKey(name="FK_UVG_CODE_WERT_1"))
	private CodeWertEntity zahlungsmodus;
	
	@Column(name = "TAGGELD_AN_BETRIEB", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean taggeldAnBetrieb;
	
	@Column(name = "AHV_NAME")
	private String ahvName;
	
	@Column(name = "AHV_NUMMER")
	private String ahvNummer;
	
	@Column(name = "VERSICHERUNG_NAME")
	private String versicherungName;
	
	@Column(name = "VERSICHERUNG_NUMMER")
	private String versicherungNummer;

	@Lob
	@Column(name = "BEMERKUNGEN")
	private String bemerkungen;
	
	@Column(name = "KONTAKT_NAME")
	private String kontaktName;
	
	@Column(name = "KONTAKT_VORNAME")
	private String kontaktVorname;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_KONTAKT_ADRESSE", foreignKey = @ForeignKey(name="FK_UVG_KONTAKT_ADRESSE"))
	private AdresseEntity kontaktAdresse;
	
	@Column(name = "PARTNER_NAME")
	private String partnerName;
	
	@Column(name = "PARTNER_LOHNSUMME")
	private BigDecimal partnerLohnsumme;

	@Column(name = "PARTNER_FREIWILLIG", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean partnerFreiwillig;
	
	@Column(name = "ANGEHOERIGE_LOHNSUMME")
	private BigDecimal angehoerigeLohnsumme;
	
	@Column(name = "ANGEHOERIGE_ANZAHL")
	private BigDecimal angehoerigeAnzahl;
	
	@Column(name = "ANGEHOERIGE_FREIWILLIG", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean angehoerigeFreiwillig;
	
	@Column(name = "GL_ANZAHL")
	private Integer glAnzahl;
	
	@Column(name = "GL_LOHNSUMME")
	private BigDecimal glLohnsumme;
	
	@Column(name = "VR_LOHNSUMME")
	private BigDecimal vrLohnsumme;
	
	@Column(name = "VERSICHERERWUNSCH")
	@Enumerated(EnumType.STRING)
	private VersichererWunschEnum versichererWunsch;
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch=FetchType.LAZY, mappedBy = "uvgAnmeldung", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<UvgGesellschafterEntity> gesellschafters = new HashSet<>();
	
	@NotNull(groups = {OSSSytemValidator.class})
	@Fetch(FetchMode.SUBSELECT)
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name="T_UVG_VERSWAHL",
		joinColumns=
			@JoinColumn(name="LN_UVG_ANMELDUNG", referencedColumnName="PK", foreignKey = @ForeignKey(name = "FK_UVG_VERSWAHL_ANMELDUNG")),
		inverseJoinColumns=
			@JoinColumn(name="LN_VERSICHERUNG", referencedColumnName="PK", foreignKey = @ForeignKey(name = "FK_UVG_VERSWAHL_VERSICHERUNG")),
		uniqueConstraints={
			@UniqueConstraint(name="UK_UVG_VERSICHERUNG", columnNames = {"LN_UVG_ANMELDUNG", "LN_VERSICHERUNG"})
		})
	private Set<VersicherungEntity> versicherer = new HashSet<>();

	public UvgAnmeldungEntity() {
		prozess = new ProzessEntity(ProzessTypEnum.UVG, true);
	}
	
	public UvgAnmeldungEntity(OrganisationEntity org) {
		prozess = new ProzessEntity(ProzessTypEnum.UVG, true, org);
	}

	public ProzessEntity getProzess() {
		return prozess;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	public BigDecimal getAngestellteHeute() {
		return angestellteHeute;
	}

	public void setAngestellteHeute(BigDecimal angestellteHeute) {
		this.angestellteHeute = angestellteHeute;
	}

	public LocalDate getErsteAnstellung() {
		return ersteAnstellung;
	}

	public void setErsteAnstellung(LocalDate ersteAnstellung) {
		this.ersteAnstellung = ersteAnstellung;
	}

	public BigDecimal getAngestellteZukunft() {
		return angestellteZukunft;
	}

	public void setAngestellteZukunft(BigDecimal angestellteZukunft) {
		this.angestellteZukunft = angestellteZukunft;
	}

	public LocalDate getErsteAnstellungZukunft() {
		return ersteAnstellungZukunft;
	}

	public void setErsteAnstellungZukunft(LocalDate ersteAnstellungZukunft) {
		this.ersteAnstellungZukunft = ersteAnstellungZukunft;
	}

	public boolean isAngestelltePartner() {
		return angestelltePartner;
	}

	public void setAngestelltePartner(boolean angestelltePartner) {
		this.angestelltePartner = angestelltePartner;
	}

	public boolean isAngestellteFamilie() {
		return angestellteFamilie;
	}

	public void setAngestellteFamilie(boolean angestellteFamilie) {
		this.angestellteFamilie = angestellteFamilie;
	}

	public boolean isAngestellteLehrling() {
		return angestellteLehrling;
	}

	public void setAngestellteLehrling(boolean angestellteLehrling) {
		this.angestellteLehrling = angestellteLehrling;
	}

	public boolean isAngestellteOhneLohn() {
		return angestellteOhneLohn;
	}

	public void setAngestellteOhneLohn(boolean angestellteOhneLohn) {
		this.angestellteOhneLohn = angestellteOhneLohn;
	}

	public boolean isAngestellteAushilfe() {
		return angestellteAushilfe;
	}

	public void setAngestellteAushilfe(boolean angestellteAushilfe) {
		this.angestellteAushilfe = angestellteAushilfe;
	}

	public boolean isAngestellteGesellschafter() {
		return angestellteGesellschafter;
	}

	public void setAngestellteGesellschafter(boolean angestellteGesellschafter) {
		this.angestellteGesellschafter = angestellteGesellschafter;
	}

	public boolean isUvgInhaberFreiwillig() {
		return uvgInhaberFreiwillig;
	}

	public void setUvgInhaberFreiwillig(boolean uvgInhaberFreiwillig) {
		this.uvgInhaberFreiwillig = uvgInhaberFreiwillig;
	}

	public BigDecimal getLohnsumme() {
		return lohnsumme;
	}

	public void setLohnsumme(BigDecimal lohnsumme) {
		this.lohnsumme = lohnsumme;
	}

	public BigDecimal getLohnsummeFolgejahr() {
		return lohnsummeFolgejahr;
	}

	public void setLohnsummeFolgejahr(BigDecimal lohnsummeFolgejahr) {
		this.lohnsummeFolgejahr = lohnsummeFolgejahr;
	}

	public CodeWertEntity getZahlungsmodus() {
		return zahlungsmodus;
	}

	public void setZahlungsmodus(CodeWertEntity zahlungsmodus) {
		this.zahlungsmodus = zahlungsmodus;
	}

	public boolean isTaggeldAnBetrieb() {
		return taggeldAnBetrieb;
	}

	public void setTaggeldAnBetrieb(boolean taggeldAnBetrieb) {
		this.taggeldAnBetrieb = taggeldAnBetrieb;
	}

	public String getAhvName() {
		return ahvName;
	}

	public void setAhvName(String ahvName) {
		this.ahvName = ahvName;
	}

	public String getAhvNummer() {
		return ahvNummer;
	}

	public void setAhvNummer(String ahvNummer) {
		this.ahvNummer = ahvNummer;
	}

	public String getVersicherungName() {
		return versicherungName;
	}

	public void setVersicherungName(String versicherungName) {
		this.versicherungName = versicherungName;
	}

	public String getVersicherungNummer() {
		return versicherungNummer;
	}

	public void setVersicherungNummer(String versicherungNummer) {
		this.versicherungNummer = versicherungNummer;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public String getKontaktName() {
		return kontaktName;
	}

	public void setKontaktName(String kontaktName) {
		this.kontaktName = kontaktName;
	}

	public String getKontaktVorname() {
		return kontaktVorname;
	}

	public void setKontaktVorname(String kontaktVorname) {
		this.kontaktVorname = kontaktVorname;
	}

	public AdresseEntity getKontaktAdresse() {
		return kontaktAdresse;
	}

	public void setKontaktAdresse(AdresseEntity kontaktAdresse) {
		this.kontaktAdresse = kontaktAdresse;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public BigDecimal getPartnerLohnsumme() {
		return partnerLohnsumme;
	}

	public void setPartnerLohnsumme(BigDecimal partnerLohnsumme) {
		this.partnerLohnsumme = partnerLohnsumme;
	}

	public boolean isPartnerFreiwillig() {
		return partnerFreiwillig;
	}

	public void setPartnerFreiwillig(boolean partnerFreiwillig) {
		this.partnerFreiwillig = partnerFreiwillig;
	}

	public BigDecimal getAngehoerigeLohnsumme() {
		return angehoerigeLohnsumme;
	}

	public void setAngehoerigeLohnsumme(BigDecimal angehoerigeLohnsumme) {
		this.angehoerigeLohnsumme = angehoerigeLohnsumme;
	}

	public BigDecimal getAngehoerigeAnzahl() {
		return angehoerigeAnzahl;
	}

	public void setAngehoerigeAnzahl(BigDecimal angehoerigeAnzahl) {
		this.angehoerigeAnzahl = angehoerigeAnzahl;
	}

	public boolean isAngehoerigeFreiwillig() {
		return angehoerigeFreiwillig;
	}

	public void setAngehoerigeFreiwillig(boolean angehoerigeFreiwillig) {
		this.angehoerigeFreiwillig = angehoerigeFreiwillig;
	}

	public Integer getGlAnzahl() {
		return glAnzahl;
	}

	public void setGlAnzahl(Integer glAnzahl) {
		this.glAnzahl = glAnzahl;
	}

	public BigDecimal getGlLohnsumme() {
		return glLohnsumme;
	}

	public void setGlLohnsumme(BigDecimal glLohnsumme) {
		this.glLohnsumme = glLohnsumme;
	}

	public BigDecimal getVrLohnsumme() {
		return vrLohnsumme;
	}

	public void setVrLohnsumme(BigDecimal vrLohnsumme) {
		this.vrLohnsumme = vrLohnsumme;
	}

	public Set<UvgGesellschafterEntity> getGesellschafters() {
		return gesellschafters;
	}

	public void setGesellschafters(Set<UvgGesellschafterEntity> gesellschafters) {
		this.gesellschafters = gesellschafters;
	}

	public VersichererWunschEnum getVersichererWunsch() {
		return versichererWunsch;
	}

	public void setVersichererWunsch(VersichererWunschEnum versichererWunsch) {
		this.versichererWunsch = versichererWunsch;
	}

	public Set<VersicherungEntity> getVersicherer() {
		return versicherer;
	}

	public void setVersicherer(Set<VersicherungEntity> versicherer) {
		this.versicherer = versicherer;
	}
}
