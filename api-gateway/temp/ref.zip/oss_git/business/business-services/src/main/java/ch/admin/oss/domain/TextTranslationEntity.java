/*
 * TextTranslationEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.SupportedLanguage;

/**
 *  
 * @author coh
 */
@Entity
@Table(name = "T_TEXT_TRANSLATION")
public class TextTranslationEntity extends AbstractOSSEntity implements IStandardTextCode, ITextTranslationText {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_STANDARD_TEXT", foreignKey = @ForeignKey(name="FK_TRANSLATION_STANDARD_TEXT"))
	private StandardTextEntity standardText;
	
	@Column(name = "LANGUAGE", nullable = false, length = 2)
	@Enumerated(EnumType.STRING)
	private SupportedLanguage language;

	@Column(name = "TEXT", columnDefinition = "CLOB")
    @Lob
	private String text;
	
	public TextTranslationEntity() {
	}	
	
	public TextTranslationEntity(SupportedLanguage language, String text) {
		super();
		this.language = language;
		this.text = text;
	}


	public StandardTextEntity getStandardText() {
		return standardText;
	}

	public void setLanguage(SupportedLanguage language) {
		this.language = language;
	}

	public SupportedLanguage getLanguage() {
		return language;
	}

	public String getText() {
		return text;
	}

	@Override
	@Transient
	public String getStandardTextCode() {
		return standardText.getCode();
	}

	public void setStandardText(StandardTextEntity standardText) {
		this.standardText = standardText;
	}

	public void setText(String text) {
		this.text = text;
	}	
}
