/*
 * HrMutationPersonDeletionDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.endpoint;

import java.util.Date;

import ch.admin.oss.common.enums.HrMutationTypeOfPersonEnum;

/**
 * @author hhu
 */
public class HrMutationPersonDeletionDto extends HrMutationAbstractDto {
	private Long personId;

	private int personVersion;

	private HrMutationTypeOfPersonEnum typeOfPerson;

	private String prevFamilyName;

	private String prevGivenName;

	private Date prevBirthday;

	private String prevCompanyName;

	private String prevLegalForm;

	private String prevCity;

	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

	public int getPersonVersion() {
		return personVersion;
	}

	public void setPersonVersion(int personVersion) {
		this.personVersion = personVersion;
	}

	public HrMutationTypeOfPersonEnum getTypeOfPerson() {
		return typeOfPerson;
	}

	public void setTypeOfPerson(HrMutationTypeOfPersonEnum typeOfPerson) {
		this.typeOfPerson = typeOfPerson;
	}

	public String getPrevFamilyName() {
		return prevFamilyName;
	}

	public void setPrevFamilyName(String prevFamilyName) {
		this.prevFamilyName = prevFamilyName;
	}

	public String getPrevGivenName() {
		return prevGivenName;
	}

	public void setPrevGivenName(String prevGivenName) {
		this.prevGivenName = prevGivenName;
	}

	public Date getPrevBirthday() {
		return prevBirthday;
	}

	public void setPrevBirthday(Date prevBirthday) {
		this.prevBirthday = prevBirthday;
	}

	public String getPrevCompanyName() {
		return prevCompanyName;
	}

	public void setPrevCompanyName(String prevCompanyName) {
		this.prevCompanyName = prevCompanyName;
	}

	public String getPrevLegalForm() {
		return prevLegalForm;
	}

	public void setPrevLegalForm(String prevLegalForm) {
		this.prevLegalForm = prevLegalForm;
	}

	public String getPrevCity() {
		return prevCity;
	}

	public void setPrevCity(String prevCity) {
		this.prevCity = prevCity;
	}

}
