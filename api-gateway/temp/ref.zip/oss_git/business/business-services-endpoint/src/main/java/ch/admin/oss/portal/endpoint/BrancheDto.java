/*
 * BrancheDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.endpoint;

import java.util.Optional;

import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.TextTranslationEntity;

/**
 * @author xdg
 */
public class BrancheDto extends AbstractGroupDto<BrancheDto> {
	private String code;
	private String standardText;
	private boolean suva;

	public BrancheDto() {}

	public BrancheDto(BrancheEntity branch, SupportedLanguage language) {
		this.setId(branch.getId());
		this.code = branch.getCode();
		this.setPos(branch.getPos());
		this.suva = branch.isSuva();
		Optional<TextTranslationEntity> textTranslation = branch.getStandardText().getTranslations().stream()
			.filter(t -> t.getLanguage() == language).findFirst();
		if (textTranslation.isPresent()) {
			this.standardText = textTranslation.get().getText();
		}
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStandardText() {
		return standardText;
	}

	public void setStandardText(String standardText) {
		this.standardText = standardText;
	}

	public boolean isSuva() {
		return suva;
	}

	public void setSuva(boolean suva) {
		this.suva = suva;
	}
}
