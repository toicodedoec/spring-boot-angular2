package ch.admin.oss.enums;

public enum SignResultEnum {
	NORMAL,
	SUCCESS,
	OUTDATED,
	UNSIGNED,
	MODIFIED
}
