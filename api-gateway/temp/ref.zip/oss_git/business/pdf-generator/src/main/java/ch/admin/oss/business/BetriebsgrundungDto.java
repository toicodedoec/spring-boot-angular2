/*
 * BetriebsgrundungDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import org.apache.commons.lang3.StringUtils;

/**
 * @author hhg
 *
 */
public class BetriebsgrundungDto {
	
	private String art;
	private String vormals;
	
	public BetriebsgrundungDto(String art, String vormals) {
		this.art = StringUtils.capitalize(art);
		this.vormals = vormals;
	}

	public String getArt() {
		return art;
	}
	
	public String getVormals() {
		return vormals;
	}
}
