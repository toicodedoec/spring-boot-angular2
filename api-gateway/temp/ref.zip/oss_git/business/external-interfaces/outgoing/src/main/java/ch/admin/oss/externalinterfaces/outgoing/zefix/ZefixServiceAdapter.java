/*
 * ZefixServiceAdapter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import ch.admin.e_service.zefix._2015_06_26.CompanyDetailedInfoType;
import ch.admin.e_service.zefix._2015_06_26.CompanyShortInfoType;
import ch.admin.e_service.zefix._2015_06_26.DetailledResponseType;
import ch.admin.e_service.zefix._2015_06_26.ErrorsType;
import ch.admin.e_service.zefix._2015_06_26.GetByCHidRequestType;
import ch.admin.e_service.zefix._2015_06_26.GetByUidRequestType;
import ch.admin.e_service.zefix._2015_06_26.SearchByNameRequest;
import ch.admin.e_service.zefix._2015_06_26.ShabPubType;
import ch.admin.e_service.zefix._2015_06_26.ShortResponse;
import ch.admin.e_service.zefix._2015_06_26.ZefixServicePortType;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author hhg
 *
 */
@Component
public class ZefixServiceAdapter implements IZefixServiceAdapter {

	@Autowired
	@Qualifier("outgoingInterfaceMapper")
	private DozerBeanMapper mapper;

	@Autowired
	private ZefixServicePortType zefixWebService;

	@Value("${zefix.result.limit}")
	private int zefixResultLimit;

	// Dozer map ID
	public static final String COMPANY_DETAIL = "CompanyDetail";
	
	private static final String UID_PREFIX = "CHE-";
	private static final String CHID_PREFIX = "CH-";
	private static final Map<RechtsformEnum, String> LEGAL_FORMS = new HashMap<>();

	static {
		LEGAL_FORMS.put(RechtsformEnum.EINZELFIRMA, "0101");
		LEGAL_FORMS.put(RechtsformEnum.KOLLGES, "0103");
		LEGAL_FORMS.put(RechtsformEnum.KOMMGES, "0104");
		LEGAL_FORMS.put(RechtsformEnum.AG, "0106");
		LEGAL_FORMS.put(RechtsformEnum.GMBH, "0107");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ShortResponseDto searchCompanyByName(String name, RechtsformEnum rechtsform, Integer bfsNr)
		throws ZefixTooShortNameException, ZefixTooManyResultsException, ZefixBusinessException {
		SearchByNameRequest request = new SearchByNameRequest();
		request.setName(refineCompanyNameToSearch(name));
		request.setLegalSeatId(bfsNr);
		request.setMaxSize(zefixResultLimit);
		request.setActive(true);
		if (rechtsform != null) {
			request.setLegalFormUid(LEGAL_FORMS.get(rechtsform));
		}

		ShortResponse response;
		try {
			response = zefixWebService.searchByName(request);
		} catch (Exception e) {
			// SECOOSS-640: any type of error when calling Zefix will be transformed to business exception since
			// we don't want the system treat it as an technical error. We will handle this error manually.
			throw new ZefixBusinessException("An error occurred when calling Zefix", e);
		}

		if (response.getErrors() != null) {
			for (ErrorsType.Error error : response.getErrors().getError()) {
				switch (error.getCode()) {
					case "105":
						throw new ZefixTooManyResultsException("Too many result found for company name: " + name);
					case "106":
						throw new ZefixTooShortNameException("The company name to search is too short: " + name);
					default:
						throw new ZefixBusinessException(error.getCode() + ": " + error.getMessage());
				}
			}
		}

		ShortResponseDto result =  new ShortResponseDto();
		for (CompanyShortInfoType companyInfo : response.getResult().getCompanyInfo()) {
			if(companyInfo.getUid() != null) {
				CompanyShortInfoDto companyInfoDto = mapper.map(companyInfo, CompanyShortInfoDto.class);
				companyInfoDto.setRechtsform(rechtsform);
				result.getCompanyShortInfo().add(companyInfoDto);
			}
		}
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DetailledResponseDto getCompanyDetailByUid(int uid, RechtsformEnum rechtsform)
		throws ZefixInvalidUIDException, ZefixBusinessException {
		GetByUidRequestType request = new GetByUidRequestType();
		request.setUid(uid);

		DetailledResponseType response;
		try {
			response = zefixWebService.getByUidDetailled(request);
		} catch (Exception e) {
			// SECOOSS-640: any type of error when calling Zefix will be transformed to business exception since
			// we don't want the system treat it as an technical error. We will handle this error manually.
			throw new ZefixBusinessException("An error occurred when calling Zefix", e);
		}

		if (response.getErrors() != null) {
			for (ErrorsType.Error error : response.getErrors().getError()) {
				switch (error.getCode()) {
					case "402":
						throw new ZefixInvalidUIDException("Invalid UID: " + uid);
					default:
						throw new ZefixBusinessException(error.getCode() + ": " + error.getMessage());
				}
			}
		}
		return convertToCompanyDetailInfoDto(rechtsform, response);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DetailledResponseDto getCompanyDetailByChid(String chid, RechtsformEnum rechtsform) 
		throws ZefixInvalidCHIdException, ZefixBusinessException {
		GetByCHidRequestType request = new GetByCHidRequestType();
		request.setChid(chid);

		DetailledResponseType response;
		try {
			response = zefixWebService.getByCHidDetailled(request);
		} catch (Exception e) {
			// SECOOSS-640: any type of error when calling Zefix will be transformed to business exception since
			// we don't want the system treat it as an technical error. We will handle this error manually.
			throw new ZefixBusinessException("An error occurred when calling Zefix", e);
		}

		if (response.getErrors() != null) {
			for (ErrorsType.Error error : response.getErrors().getError()) {
				switch (error.getCode()) {
					case "202":
						throw new ZefixInvalidCHIdException("Invalid CHId: " + chid);
					default:
						throw new ZefixBusinessException(error.getCode() + ": " + error.getMessage());
				}
			}
		}
		return convertToCompanyDetailInfoDto(rechtsform, response);
	}

	private DetailledResponseDto convertToCompanyDetailInfoDto(RechtsformEnum rechtsform,
		DetailledResponseType response) {
		List<CompanyDetailedInfoType> companyInfos = response.getResult().getCompanyInfo();
		if (rechtsform != null) {
			String legalFormUid = LEGAL_FORMS.get(rechtsform);
			companyInfos = companyInfos.stream()
				.filter(c -> c.getLegalform().getLegalFormUid().equals(legalFormUid))
				.collect(Collectors.toList());
		}
		
		DetailledResponseDto result = new DetailledResponseDto();
		for (CompanyDetailedInfoType companyInfo : companyInfos) {
			CompanyDetailedInfoDto companyInfoDto = mapper.map(companyInfo, CompanyDetailedInfoDto.class, COMPANY_DETAIL);
			if (CollectionUtils.isNotEmpty(companyInfo.getShabPub())) {
				ShabPubType latestShaPub = companyInfo.getShabPub().get(0);
				if (companyInfo.getShabPub().size() > 1) {
					latestShaPub = companyInfo.getShabPub()
						.stream()
						.sorted((s1, s2) -> s2.getShabDate().compare(s1.getShabDate()))
						.findFirst().get();
				}
				ShabPubDto shabPub = new ShabPubDto(latestShaPub.getShabDate(), latestShaPub.getShabNr(),
					latestShaPub.getShabPage(), latestShaPub.getShabId());
				companyInfoDto.setShabPub(shabPub);
			}
			for (Map.Entry<RechtsformEnum, String> entry : LEGAL_FORMS.entrySet()) {
				RechtsformEnum rechtsformType = entry.getKey();
				String legalFormUid = entry.getValue();
				if (legalFormUid.equals(companyInfo.getLegalform().getLegalFormUid())) {
					companyInfoDto.setRechtsform(rechtsformType);
					break;
				}
			}
			AddressInformationDto address = new AddressInformationDto(
					companyInfo.getAddress().getAddressInformation().getStreet(),
					companyInfo.getAddress().getAddressInformation().getHouseNumber(),
					companyInfo.getAddress().getAddressInformation().getTown(),
					companyInfo.getAddress().getAddressInformation().getSwissZipCode());
			companyInfoDto.setAddress(address);
			result.getCompanyDetailedInfo().add(companyInfoDto);
		}
		return result;
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public DetailledResponseDto getCompanyDetail(String uidOrChid)
		throws ZefixInvalidCHIdException, ZefixInvalidUIDException, ZefixBusinessException {
		if (StringUtils.startsWith(uidOrChid, CHID_PREFIX)) {
			return getCompanyDetailByChid(refineChidToSearch(uidOrChid), null);
		}
		return getCompanyDetailByUid(refineUidToSearch(uidOrChid), null);
	}

	private Integer refineUidToSearch(String uid) {
		uid = StringUtils.remove(uid, UID_PREFIX);
		uid = StringUtils.remove(uid, ".");
		return Integer.parseInt(uid);
	}

	private String refineChidToSearch(String chid) {
		chid = StringUtils.remove(chid, "-");
		chid = StringUtils.remove(chid, ".");
		return chid;
	}

	private String refineCompanyNameToSearch(String name) {
		name = StringUtils.trim(name);
		name = name.replaceAll(" +", " ");
		name = StringUtils.replace(name, " - ", " ");
		name = StringUtils.remove(name, ",");
		name = StringUtils.replace(name, " + ", "+");
		name = StringUtils.replace(name, " & ", "&");

		// remove the DOT after capital letters
		StringBuilder builder = new StringBuilder("");
		String[] parts = StringUtils.split(name, ".");
		int length = parts.length;
		for (int i = 0; i < length; i++) {
			String part = parts[i];
			builder.append(part);
			if ((i < length - 1) && !Character.isUpperCase(part.codePointAt(part.length() - 1))) {
				builder.append(".");
			}
		}
		name = builder.toString();
		return name;
	}
}
