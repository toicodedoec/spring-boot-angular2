/*
 * FunktionRechteEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;

import ch.admin.oss.common.enums.FunktionEnum;
import ch.admin.oss.security.OssRole;

/**
 * @author hha
 */
@Entity
@Table(name = "T_FUNKTION_RECHTE")
public class FunktionRechteEntity extends AbstractOSSEntity {

	private static final String GROUP_SEPARATOR = ",";

	@NotNull
	@Column(name = "FUNKTION")
	@Enumerated(EnumType.STRING)
	private FunktionEnum funktion;

	@NotNull
	@Column(name = "BESCHREIBUNG")
	private String beschreibung;

	@Column(name = "GRUPPENS")
	private String gruppens;

	public FunktionEnum getFunktion() {
		return funktion;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	public String getGruppens() {
		return gruppens;
	}

	public void setGruppens(String gruppens) {
		this.gruppens = gruppens;
	}

	public void setGroups(List<OssRole> groups) {
		if (groups == null) {
			gruppens = null;
		} else {
			gruppens = StringUtils.join(groups.stream()
				.map(item -> item.name())
				.collect(Collectors.toList()), GROUP_SEPARATOR);
		}
	}

	public List<OssRole> getGroups() {
		// Trim to empty to avoid null array.
		String[] groupNames = StringUtils.split(StringUtils.trimToEmpty(gruppens), GROUP_SEPARATOR);
		return Arrays.stream(groupNames).map(item -> OssRole.valueOf(item))
			// Make sure groups are always ordered in the result.
			.sorted(new Comparator<OssRole>() {
				@Override
				public int compare(OssRole o1, OssRole o2) {
					return o1.compareTo(o2);
				}
			}).collect(Collectors.toList());
	}
}
