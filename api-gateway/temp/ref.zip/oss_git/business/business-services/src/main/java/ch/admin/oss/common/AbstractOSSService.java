/*
 * AbstractOssService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;

import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.application.service.ICacheService;
import ch.admin.oss.util.JpaUtil;

/**
 * @author hha
 */
public abstract class AbstractOSSService {

	@PersistenceContext
	protected EntityManager em;
	
	@Autowired
	protected JpaUtil jpaUtil;

	@Autowired
	protected IApplicationService applicationService;
	
	@Autowired
	protected ICacheService cacheService;
}
