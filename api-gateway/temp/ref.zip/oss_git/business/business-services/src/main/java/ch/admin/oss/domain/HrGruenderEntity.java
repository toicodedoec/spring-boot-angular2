/*
 * HrGruenderEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;

/**
 *  
 * @author coh
 */
@Entity
@Table(name = "T_HR_GRUENDER", 
	uniqueConstraints = {
		@UniqueConstraint(name = "UK_GRUENDER_HR_PERSON", columnNames = {"LN_HR_ANMELDUNG", "LN_PERSON"})
	})		
public class HrGruenderEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_HR_ANMELDUNG", foreignKey = @ForeignKey(name="FK_GRUENDER_HR"))
	private HrAnmeldungEntity hrAnmeldung;
	
	@NotNull
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PERSON", foreignKey = @ForeignKey(name="FK_GRUENDER_PERSON"))
	private PersonEntity person;
	
	@Column(name = "ANZ_INHABERAKTIEN")
	private Integer anzInhaberaktien;
	
	@Column(name = "ANZ_NAMENSAKTIEN")
	private Integer anzNamensaktien;
	
	@Column(name = "ANZ_STAMMANTEILE")
	private Integer anzStammanteile;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_FUNKTION", foreignKey = @ForeignKey(name="FK_GRUENDER_CODE_WERT_1"))
	private CodeWertEntity funktion;
	
	@Column(name = "COMPLETE", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean complete;
	
	@Column(name = "NURHAUPTSITZ")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean nurHauptsitz;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ZEICHNUNG", foreignKey = @ForeignKey(name="FK_GRUENDER_CODE_WERT_2"))
	private CodeWertEntity zeichnung;

	public HrAnmeldungEntity getHrAnmeldung() {
		return hrAnmeldung;
	}

	public void setHrAnmeldung(HrAnmeldungEntity hrAnmeldung) {
		this.hrAnmeldung = hrAnmeldung;
	}

	public PersonEntity getPerson() {
		return person;
	}

	public void setPerson(PersonEntity person) {
		this.person = person;
	}

	public Integer getAnzInhaberaktien() {
		return anzInhaberaktien;
	}

	public void setAnzInhaberaktien(Integer anzInhaberaktien) {
		this.anzInhaberaktien = anzInhaberaktien;
	}

	public Integer getAnzNamensaktien() {
		return anzNamensaktien;
	}

	public void setAnzNamensaktien(Integer anzNamensaktien) {
		this.anzNamensaktien = anzNamensaktien;
	}

	public Integer getAnzStammanteile() {
		return anzStammanteile;
	}

	public void setAnzStammanteile(Integer anzStammanteile) {
		this.anzStammanteile = anzStammanteile;
	}

	public CodeWertEntity getFunktion() {
		return funktion;
	}

	public void setFunktion(CodeWertEntity funktion) {
		this.funktion = funktion;
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	public Boolean getNurHauptsitz() {
		return nurHauptsitz;
	}

	public void setNurHauptsitz(Boolean nurHauptsitz) {
		this.nurHauptsitz = nurHauptsitz;
	}

	public CodeWertEntity getZeichnung() {
		return zeichnung;
	}

	public void setZeichnung(CodeWertEntity zeichnung) {
		this.zeichnung = zeichnung;
	}
}
