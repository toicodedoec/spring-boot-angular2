/*
 * HrTemplateType
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ch.admin.oss.util.TemplateFile;

/**
 * @author hha
 */
public enum HrTemplateType {

	KG_ANALOG(TemplateFile.get("KG_analog")),
	KG_DIGITAL(TemplateFile.get("KG_digital")),
	EF(TemplateFile.get("EF_01_Info"),
		TemplateFile.get("EF_02_Header"),
		TemplateFile.get("EF_03_Data"),
		TemplateFile.get("EF_04_Owner"),
		TemplateFile.get("EF_05_Signatory", "signatories")),
	EF_ELECTRONIC(TemplateFile.get("EF_01_Info_SuisseID"),
		TemplateFile.get("EF_02_Header"),
		TemplateFile.get("EF_03_Data"),
		TemplateFile.get("EF_04_Owner_SuisseID"),
		TemplateFile.get("EF_05_Signatory_SuisseID", "signatories")),
	PG(TemplateFile.get("PG_01_Info"),
		TemplateFile.get("PG_02_Header"),
		TemplateFile.get("PG_03_Data"),
		TemplateFile.get("PG_04_NatPersons", "organisation.naturalPersons"),
		TemplateFile.get("PG_05_LegalPersons", "organisation.kommFirmas"),
		TemplateFile.get("PG_06_Signatory", "signatories"))
	;

	private List<TemplateFile> files;

	private HrTemplateType(TemplateFile... files) {
		this.files = Stream.of(files)
			.map(item -> {
				item.setFileName("hr/" + item.getFileName());
				return item;
			})
			.collect(Collectors.toList());
	}

	public List<TemplateFile> getFiles() {
		return files;
	}

	
	
}