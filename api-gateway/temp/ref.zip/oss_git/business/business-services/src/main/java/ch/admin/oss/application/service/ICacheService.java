/*
 * ICacheService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.application.service;

import java.util.List;
import java.util.Map;

import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.LandEntity;
import ch.admin.oss.domain.VerbandEntity;
import ch.admin.oss.domain.VersicherungEntity;

/**
 * Service for caching all reference data.
 * 
 * @author coh
 */
public interface ICacheService {

	Map<String, String> getTranslationByLang(SupportedLanguage targetLang);
	
	List<CodeWertEntity> getCodeWerts();
	
	List<BrancheEntity> getBranches();

	List<VerbandEntity> getVerbands();

	List<BerufEntity> getBerufs();

	List<CHOrtEntity> getCHOrts();
	
	List<AusgleichskasseEntity> getAusgleichskasses();
	
	List<VersicherungEntity> getVersicherungs();
	
	Map<String, LandEntity> getLands();
}
