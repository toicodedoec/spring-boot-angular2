/*
 * MwstMoaIdDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.mwst.endpoint;

import java.util.Base64;

import org.apache.commons.lang3.StringUtils;

/**
 * @author hhg
 *
 */
public class MwstMoaIdDto {
	
	private static final String ID_SAPARATOR = "-";

	private Long orgId;
	private Long userId;
	
	public MwstMoaIdDto(Long orgId, Long userId) {
		this.orgId = orgId;
		this.userId = userId;
	}

	public Long getOrgId() {
		return orgId;
	}

	public Long getUserId() {
		return userId;
	}
	
	public String encode() {
		return Base64.getEncoder().encodeToString((orgId + ID_SAPARATOR + userId).getBytes());
	}

	public static MwstMoaIdDto decode(String encoded) {
		String keys = new String(Base64.getDecoder().decode(encoded));
		String[] ids = StringUtils.split(keys, ID_SAPARATOR);
		return new MwstMoaIdDto(Long.valueOf(ids[0]), Long.valueOf(ids[1]));
	}
}
