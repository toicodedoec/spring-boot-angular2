/*
 * VerbandEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;

import com.querydsl.core.annotations.QueryProjection;

/**
 * @author coh
 *
 */
@Entity
@Table(name = "T_VERBAND")
public class VerbandEntity extends AbstractOSSEntity {
	
	@Column(name = "AKTIV", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean aktiv;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_STANDARD_TEXT", foreignKey = @ForeignKey(name="FK_VERBAND_TEXT"))
	private StandardTextEntity standardText;
	
	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_AUSGLEICHSKASSE", foreignKey = @ForeignKey(name="FK_VERBAND_AUSGLEICHSKASSE"))
	private AusgleichskasseEntity ausgleichskasse;

	public VerbandEntity() {}
	
	@QueryProjection
	public VerbandEntity(Long id) {
		setId(id);
	}
	
	public void setStandardText(StandardTextEntity standardText) {
		this.standardText = standardText;
	}

	public StandardTextEntity getStandardText() {
		return standardText;
	}

	public AusgleichskasseEntity getAusgleichskasse() {
		return ausgleichskasse;
	}

	public void setAusgleichskasse(AusgleichskasseEntity ausgleichskasse) {
		this.ausgleichskasse = ausgleichskasse;
	}

	public boolean isAktiv() {
		return aktiv;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}
	
}
