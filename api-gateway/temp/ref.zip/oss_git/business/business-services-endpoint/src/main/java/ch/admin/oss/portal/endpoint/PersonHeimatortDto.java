/*
 * PersonHeimatortDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.endpoint;

import com.fasterxml.jackson.annotation.JsonIgnore;

import ch.admin.oss.common.AbstractOSSDto;

/**
 * @author xdg
 */
public class PersonHeimatortDto extends AbstractOSSDto {
	private String ort;
	private String polGemeinde;
	private String kanton;
	private int bfsnr;

	@JsonIgnore
	public String getDisplayText() {
		return this.polGemeinde + ", " + this.kanton;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getPolGemeinde() {
		return polGemeinde;
	}

	public void setPolGemeinde(String polgemeinde) {
		this.polGemeinde = polgemeinde;
	}

	public String getKanton() {
		return kanton;
	}

	public void setKanton(String kanton) {
		this.kanton = kanton;
	}

	public int getBfsnr() {
		return bfsnr;
	}

	public void setBfsnr(int bfsnr) {
		this.bfsnr = bfsnr;
	}

}
