/*
 * PflichtenabklaerungenDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.endpoint;

import java.util.Date;
import java.util.List;

import ch.admin.oss.common.FlowHistoryDto;
import ch.admin.oss.common.enums.AnmeldungAHVBefundEnum;
import ch.admin.oss.common.enums.AnmeldungHRBefundEnum;
import ch.admin.oss.common.enums.AnmeldungMWSTBefundEnum;
import ch.admin.oss.common.enums.AnmeldungUVGBefundEnum;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author phd
 */
public class PflichtenabklaerungenDto {
	
	private Long id;
	private Integer version;
	private Long orgId;
	private RechtsformEnum rechtsform;
	
	private AnmeldungHRBefundEnum anmeldungHRBefund;
	private AnmeldungAHVBefundEnum anmeldungAHVBefund;
	private AnmeldungMWSTBefundEnum anmeldungMWSTBefund;
	private AnmeldungUVGBefundEnum anmeldungUVGBefund;
	
	private boolean anmeldungHR;
	private boolean anmeldungMWST;
	private boolean anmeldungAHV;
	private boolean anmeldungUVG;
	
	private Boolean umsatz100k;
	
	private Integer angestellte;
	private Boolean nurVollzeit;
	
	private Boolean handel;
	
	private List<BrancheDto> branches;
	
	private boolean completed;
	
	private Date eroeffnungsdatum;
	
	private BerufDto beruf;
	private String berufText;
	
	private Date datum;
	
	private boolean digital;
	
	private boolean storeHistory = true;
	
	private FlowHistoryDto flowHistory = new FlowHistoryDto();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}

	public boolean isAnmeldungHR() {
		return anmeldungHR;
	}

	public void setAnmeldungHR(boolean anmeldungHR) {
		this.anmeldungHR = anmeldungHR;
	}

	public boolean isAnmeldungMWST() {
		return anmeldungMWST;
	}

	public void setAnmeldungMWST(boolean anmeldungMWST) {
		this.anmeldungMWST = anmeldungMWST;
	}

	public boolean isAnmeldungAHV() {
		return anmeldungAHV;
	}

	public void setAnmeldungAHV(boolean anmeldungAHV) {
		this.anmeldungAHV = anmeldungAHV;
	}

	public boolean isAnmeldungUVG() {
		return anmeldungUVG;
	}

	public void setAnmeldungUVG(boolean anmeldungUVG) {
		this.anmeldungUVG = anmeldungUVG;
	}

	public Boolean getUmsatz100k() {
		return umsatz100k;
	}

	public void setUmsatz100k(Boolean umsatz100k) {
		this.umsatz100k = umsatz100k;
	}

	public Integer getAngestellte() {
		return angestellte;
	}

	public void setAngestellte(Integer angestellte) {
		this.angestellte = angestellte;
	}

	public Boolean getNurVollzeit() {
		return nurVollzeit;
	}

	public void setNurVollzeit(Boolean nurVollzeit) {
		this.nurVollzeit = nurVollzeit;
	}

	public Boolean getHandel() {
		return handel;
	}

	public void setHandel(Boolean handel) {
		this.handel = handel;
	}

	public List<BrancheDto> getBranches() {
		return branches;
	}

	public void setBranches(List<BrancheDto> branches) {
		this.branches = branches;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public Date getEroeffnungsdatum() {
		return eroeffnungsdatum;
	}

	public void setEroeffnungsdatum(Date eroeffnungsdatum) {
		this.eroeffnungsdatum = eroeffnungsdatum;
	}

	public BerufDto getBeruf() {
		return beruf;
	}

	public void setBeruf(BerufDto beruf) {
		this.beruf = beruf;
	}

	public String getBerufText() {
		return berufText;
	}

	public void setBerufText(String berufText) {
		this.berufText = berufText;
	}

	public Date getDatum() {
		return datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}

	public boolean isDigital() {
		return digital;
	}

	public void setDigital(boolean digital) {
		this.digital = digital;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public boolean isStoreHistory() {
		return storeHistory;
	}

	public void setStoreHistory(boolean storeHistory) {
		this.storeHistory = storeHistory;
	}

	public AnmeldungHRBefundEnum getAnmeldungHRBefund() {
		return anmeldungHRBefund;
	}

	public void setAnmeldungHRBefund(AnmeldungHRBefundEnum anmeldungHRBefund) {
		this.anmeldungHRBefund = anmeldungHRBefund;
	}

	public AnmeldungAHVBefundEnum getAnmeldungAHVBefund() {
		return anmeldungAHVBefund;
	}

	public void setAnmeldungAHVBefund(AnmeldungAHVBefundEnum anmeldungAHVBefund) {
		this.anmeldungAHVBefund = anmeldungAHVBefund;
	}

	public AnmeldungMWSTBefundEnum getAnmeldungMWSTBefund() {
		return anmeldungMWSTBefund;
	}

	public void setAnmeldungMWSTBefund(AnmeldungMWSTBefundEnum anmeldungMWSTBefund) {
		this.anmeldungMWSTBefund = anmeldungMWSTBefund;
	}

	public AnmeldungUVGBefundEnum getAnmeldungUVGBefund() {
		return anmeldungUVGBefund;
	}

	public void setAnmeldungUVGBefund(AnmeldungUVGBefundEnum anmeldungUVGBefund) {
		this.anmeldungUVGBefund = anmeldungUVGBefund;
	}

	public FlowHistoryDto getFlowHistory() {
		return flowHistory;
	}

	public void setFlowHistory(FlowHistoryDto flowHistory) {
		this.flowHistory = flowHistory;
	}

	public boolean isInitializedNurVollzeit() {
		return this.nurVollzeit != null;
	}

	public boolean isInitializedUmsatz100k() {
		return this.umsatz100k != null;
	}

	public boolean isInitializedHandel() {
		return this.handel != null;
	}
	
	public void setInitializedHandel(boolean initializedHandel) {
	}
	
	public void setInitializedNurVollzeit(boolean initializedNurVollzeit) {
	}

	public void setInitializedUmsatz100k(boolean initializedUmsatz100k) {
	}
}
