/*
 * MwstAnmeldungDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.mwst.endpoint;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.ProzessDto;

/**
 * 
 * @author hhu
 *
 */
public class MwstAnmeldungDto extends AbstractOSSDto {
	private ProzessDto prozess;
	
	private boolean canAccessPdf1;
	
	private boolean canAccessPdf2;
	
	private boolean canAccessPdf3;
	
	private boolean canAccessPdf4;

	public ProzessDto getProzess() {
		return prozess;
	}

	public void setProzess(ProzessDto prozess) {
		this.prozess = prozess;
	}

	public boolean getCanAccessPdf1() {
		return canAccessPdf1;
	}

	public void setCanAccessPdf1(boolean canAccessPdf1) {
		this.canAccessPdf1 = canAccessPdf1;
	}

	public boolean getCanAccessPdf2() {
		return canAccessPdf2;
	}

	public void setCanAccessPdf2(boolean canAccessPdf2) {
		this.canAccessPdf2 = canAccessPdf2;
	}

	public boolean getCanAccessPdf3() {
		return canAccessPdf3;
	}

	public void setCanAccessPdf3(boolean canAccessPdf3) {
		this.canAccessPdf3 = canAccessPdf3;
	}

	public boolean getCanAccessPdf4() {
		return canAccessPdf4;
	}

	public void setCanAccessPdf4(boolean canAccessPdf4) {
		this.canAccessPdf4 = canAccessPdf4;
	}
	
}
