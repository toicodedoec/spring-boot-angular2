/*
 * AdresseEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;
import org.hibernate.annotations.FetchProfile.FetchOverride;
import org.hibernate.annotations.FetchProfiles;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import ch.admin.oss.validator.OSSSytemValidator;

/**
 *  
 * @author coh
 */
@FetchProfiles({@FetchProfile(fetchOverrides = {
	@FetchOverride(association = "land", entity = AdresseEntity.class, mode = FetchMode.JOIN)}, name = "adresse-with-land")})
@Audited
@Entity
@Table(name = "T_ADRESSE")
public class AdresseEntity extends AbstractOSSEntity {

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@NotNull(groups = {OSSSytemValidator.class})
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_LAND", foreignKey = @ForeignKey(name="FK_ADRESSE_LAND"))
	private CodeWertEntity land;

	@Column(name = "LN_LAND", insertable = false, updatable = false)
	@Access(AccessType.FIELD)
	private Long landId;

	@Column(name = "EMPFAENGER")
	private String empfaenger;
	
	@NotNull(groups = {OSSSytemValidator.class})
	@Column(name = "STRASSE")
	private String strasse;
	
	@Column(name = "HAUSNUMMER")
	private String hausnummer;
	
	@Column(name = "ZUSATZ")
	private String zusatz;
	
	@NotNull(groups = {OSSSytemValidator.class})
	@Column(name = "PLZ")
	private String plz;
	
	@NotNull(groups = {OSSSytemValidator.class})
	@Column(name = "ORT")
	private String ort;
	
	@Column(name = "BFS_NR")
	private int bfsNr;
	
	@Column(name = "POL_GEMEINDE")
	private String polGemeinde;
	
	@Column(name = "KANTON")
	private String kanton;
	
	@NotNull(groups = {OSSSytemValidator.class})
	@Column(name = "TELEFON")
	private String telefon;
	
	@Column(name = "MOBILE")
	private String mobile;
	
	@Column(name = "FAX")
	private String fax;
	
	@Column(name = "POSTFACH")
	private String postfach;
	
	@Column(name = "POSTFACH_PLZ")
	private String postfachPlz;
	
	@Column(name = "POSTFACH_ORT")
	private String postfachOrt;
	
	@Column(name = "EMAIL")
	private String email;

	public CodeWertEntity getLand() {
		return land;
	}

	public void setLand(CodeWertEntity land) {
		this.land = land;
	}

	public String getEmpfaenger() {
		return empfaenger;
	}

	public void setEmpfaenger(String empfaenger) {
		this.empfaenger = empfaenger;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getHausnummer() {
		return hausnummer;
	}

	public void setHausnummer(String hausnummer) {
		this.hausnummer = hausnummer;
	}

	public String getZusatz() {
		return zusatz;
	}

	public void setZusatz(String zusatz) {
		this.zusatz = zusatz;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public int getBfsNr() {
		return bfsNr;
	}

	public void setBfsNr(int bfsNr) {
		this.bfsNr = bfsNr;
	}

	public String getPolGemeinde() {
		return polGemeinde;
	}

	public void setPolGemeinde(String polGemeinde) {
		this.polGemeinde = polGemeinde;
	}

	public String getKanton() {
		return kanton;
	}

	public void setKanton(String kanton) {
		this.kanton = kanton;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getPostfach() {
		return postfach;
	}

	public void setPostfach(String postfach) {
		this.postfach = postfach;
	}

	public String getPostfachPlz() {
		return postfachPlz;
	}

	public void setPostfachPlz(String postfachPlz) {
		this.postfachPlz = postfachPlz;
	}

	public String getPostfachOrt() {
		return postfachOrt;
	}

	public void setPostfachOrt(String postfachOrt) {
		this.postfachOrt = postfachOrt;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public void setLandId(Long landId) {
		this.landId = landId;
	}

	public Long getLandId() {
		return landId;
	}

	public void copyFrom(AdresseEntity domizil) {
		setBfsNr(domizil.getBfsNr());
		setEmail(domizil.getEmail());
		setEmpfaenger(domizil.getEmpfaenger());
		setFax(domizil.getFax());
		setHausnummer(domizil.getHausnummer());
		setKanton(domizil.getKanton());
		setLand(domizil.getLand());
		setLandId(domizil.getLandId());
		setMobile(domizil.getMobile());
		setOrt(domizil.getOrt());
		setPlz(domizil.getPlz());
		setPolGemeinde(domizil.getPolGemeinde());
		setPostfach(domizil.getPostfach());
		setPostfachPlz(domizil.getPostfachPlz());
		setPostfachOrt(domizil.getPostfachOrt());
		setStrasse(domizil.getStrasse());
		setTelefon(domizil.getTelefon());
		setZusatz(domizil.getZusatz());		
	}
}
