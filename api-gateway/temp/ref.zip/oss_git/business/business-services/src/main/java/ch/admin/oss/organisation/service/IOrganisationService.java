/*
 * IOrganisationService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.organisation.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.validation.Valid;
import javax.validation.groups.Default;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;

import com.querydsl.core.types.Path;

import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.dto.DigitalSignatureDto;
import ch.admin.oss.common.dto.ExistingOrgSearchResultDto;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.enums.CheckCompanyNameSourceEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.EinladungEntity;
import ch.admin.oss.domain.GeschaeftsstelleEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.KommFirmaEntity;
import ch.admin.oss.domain.KommGesEntity;
import ch.admin.oss.domain.KontoEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.StartBizDataEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.util.PdfBoxUtil;
import ch.admin.oss.validator.OSSSytemValidator;

/**
 * @author xdg
 */
@Validated
public interface IOrganisationService {

	OrganisationEntity createOrganisationFromScratch(String orgName, boolean isConnectToDuty);

	long countCodOfUser();

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	EinladungEntity findEinladungByIdAndOrgId(long orgId, long id);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).FULL)")
	EinladungEntity saveEinladung(long orgId, @Valid EinladungEntity einladungEntity, String fromEmailAddress, String invitationLinkPrefix);

	// TODO [COH / S9] To review this method
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<EinladungEntity> getAllEinladungOfOrganisation(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<EinladungEntity> getEinladung(long orgId);

	@PreAuthorize("hasPermission(#einladungEntity.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).FULL)")
	void deleteEinladung(@Valid EinladungEntity einladungEntity);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	ZugriffEntity findZugriffByIdAndOrgId(long orgId, long id);

	@PreAuthorize("hasPermission(#zugriffEntity.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).FULL)")
	ZugriffEntity updateZugriff(@Valid ZugriffEntity zugriffEntity);

	// TODO [COH / S9] To review this method.
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<ZugriffEntity> getAllZugriffOfOrganisation(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<ZugriffEntity> getZugriff(long orgId);

	@PreAuthorize("hasPermission(#zugriffEntity.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).FULL)")
	void deleteUserOforganisation(@Valid ZugriffEntity zugriffEntity);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity loadOrganisationForEDC(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	Set<GeschaftsrolleEntity> loadEDCRollen(long orgId);

	/**
	 * Update Organisation in each step
	 * 
	 * @param organisationEntity
	 * @return OrganisationEntity
	 */
	@PreAuthorize("hasPermission(#organisationEntity.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity updateOrganisation(OrganisationEntity organisationEntity);

	/**
	 * Update Organisation in final step (completing Organisation flow)
	 * 
	 * @param organisationEntity
	 * @return OrganisationEntity
	 */
	@PreAuthorize("hasPermission(#organisationEntity.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity saveCompletedOrganisationWithValidation(@Valid OrganisationEntity organisationEntity);

	@PreAuthorize("hasPermission(#organisationEntity.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity confirmRechsform(OrganisationEntity organisationEntity);

	/**
	 * Get address entity by ID
	 * 
	 * @param addressId
	 *            Address ID
	 * @return AdresseEntity
	 */
	AdresseEntity getAdresse(long addressId);

	/**
	 * Get person entity by ID
	 * 
	 * @param personId
	 * @return PersonEntity
	 */
	PersonEntity getPerson(long personId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	GeschaftsrolleEntity findGeschaftsrolleByIdAndOrgId(long orgId, long id, int version);

	/**
	 * Save address information.
	 * 
	 * @param address
	 *            AdresseEntity
	 * @return AdresseEntity
	 */
	AdresseEntity saveAdresse(AdresseEntity address);

	/**
	 * Get organisation entity by its id.
	 * 
	 * @param orgId
	 * @return OrganisationEntity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity getOrganisation(long orgId, Path<?>... associations);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity getOrganisationForPflichtenabklaerungen(long orgId);

	/**
	 * Get kommges entity of organisation.
	 * 
	 * @param orgId
	 * @return KommGesEntity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	KommGesEntity loadEDCKommGes(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	KommFirmaEntity findKommFirmaByIdAndOrgId(long orgId, long id, int version);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity deleteKommFirma(long orgId, KommFirmaEntity kommFirmaEntity);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	KommFirmaEntity saveKommFirma(long orgId, KommFirmaEntity kommFirmaEntity);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	GeschaeftsstelleEntity findGeschaeftsstellenByIdAndOrgId(long orgId, long id);

	@PreAuthorize("hasPermission(#org.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	GeschaeftsstelleEntity saveGeschaeftsstellen(OrganisationEntity org, GeschaeftsstelleEntity ges);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	GeschaeftsstelleEntity findGeschaeftsstellenByIdAndOrgId(long orgId, long id, int version);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	void deleteGeschaeftsstellen(long orgId, GeschaeftsstelleEntity ges);

	/**
	 * Save GeschaftsrolleEntity.
	 * 
	 * @param ent
	 * @return GeschaftsrolleEntity
	 */
	GeschaftsrolleEntity saveUnvalidatedGeschaftsrolle(GeschaftsrolleEntity ent, RechtsformEnum rechtsform);

	/**
	 * Save GeschaftsrolleEntity with @Validated.
	 * 
	 * @param ent
	 * @return GeschaftsrolleEntity
	 */
	GeschaftsrolleEntity saveValidatedGeschaftsrolle(
		@Validated({OSSSytemValidator.class, Default.class}) GeschaftsrolleEntity ent);

	GeschaftsrolleEntity editUnvalidatedGeschaftsrolle(GeschaftsrolleEntity ent);

	/**
	 * delete GeschaftsrolleEntity by geschaftsrolleEntity
	 * 
	 * @param geschaftsrolleEntity
	 * @return void
	 */
	@PreAuthorize("hasPermission(#geschaftsrolleEntity.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity deleteGeschaftsrolle(GeschaftsrolleEntity geschaftsrolleEntity);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	CheckNameResult validateOrganisationName(long orgId, Long hrMutationId, String name, SupportedLanguage language, CheckCompanyNameSourceEnum source);

	KommFirmaEntity getKommFirma(long id, Path<?>... associations);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	KontoEntity saveKonto(@Valid KontoEntity ent, long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	KontoEntity getKontoById(long id, long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	PflichtenabklaerungenEntity getPflichtenabklaerungenOfOganisation(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	void markProcessExternal(long orgId, PflichtenabklaerungenEntity pflichtenabklaerungen);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	OrganisationEntity getDomizilOfAllPersons(long orgId);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	AdresseEntity getOrgDomizil(long orgId);

	FileDto downloadProzessPdf(long prozessId);
	
	/**
	 * <p><strong>Funtion name: </strong>updateSignedProzessPdf</p>
	 * <p><strong>Purpose: </strong> Verify the submit-pdf and update it to table T_PROZESS.
	 * <p>Before update signed pdf we will compare the pdf file sumitted and existing-pdf file in database</p>
	 * <p>If content of the submit-pdf is not match with existing-pdf, {@code return} DigitalSignatureDto#signResult = SignResultEnum.MODIFIED</p>
	 * <p>If number of signatures in submit-pdf is empty org equal with number of signatures in existing-pdf, {@code return} DigitalSignatureDto#signResult = SignResultEnum.UNSIGNED
	 * <p>If {@link PdfBoxUtil#validateSignatures(byte[], byte[])} == {@code false}, {@code return} DigitalSignatureDto#signResult = SignResultEnum.OUTDATED</p>
	 * 
	 * <p>If submit-pdf pass all steps above, we will update submit-pdf to pdf column in table T_PROZESS and {@code return} DigitalSignatureDto#signResult = SignResultEnum.SUCCESS and DigitalSignatureDto#digitalSignees = name of all person who signed 
	 * @param signedPdf byte array submit from client
	 * @param prozessId
	 * @return DigitalSignatureDto
	 */
	DigitalSignatureDto updateSignedProzessPdf(byte[] signedPdf, long prozessId);
	
	DigitalSignatureDto getDigitalSignees(long prozessId);

	ExistingOrgSearchResultDto getExistingOrgsByUid(String uid);
	
	ExistingOrgSearchResultDto getExistingOrgsByNonUid(String uid);
	
	StartBizDataEntity getStartBizDataById(Long id);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	Map<ProzessTypEnum, ProzessStatusEnum> getStatuOfAllProzessByOrgId(Long orgId);
}
