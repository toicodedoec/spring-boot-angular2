/*
 * ZugriffDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import java.util.Date;

import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.AccessLevelEnum;
import ch.admin.oss.portal.endpoint.UserDto;

/**
 * @author tdm
 */
public class ZugriffDto {
	@NotNull
	private long id;
	@NotNull
	private long orgId;
	private String eid;
	@NotNull
	private int version;
	@NotNull
	private AccessLevelEnum accessLevel;
	private Date fromDate;
	private Date toDate;
	
	private UserDto user;
	
	public ZugriffDto() {}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public UserDto getUser() {
		return user;
	}

	public void setUser(UserDto user) {
		this.user = user;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	public AccessLevelEnum getAccessLevel() {
		return accessLevel;
	}

	public void setAccessLevel(AccessLevelEnum accessLevel) {
		this.accessLevel = accessLevel;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

}
