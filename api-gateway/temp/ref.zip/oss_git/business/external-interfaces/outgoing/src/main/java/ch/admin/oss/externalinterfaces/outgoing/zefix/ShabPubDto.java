/*
 * ShabPubDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

import java.io.Serializable;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

/**
 * @author hhg
 *
 */
public class ShabPubDto implements Serializable {

	private static final long serialVersionUID = -9000448422158216286L;
	
	private Date shabDate;
	private String shabNr;
	private String shabPage;
	private String shabId;
	
	public ShabPubDto() {
		// default constructor
	}

	public ShabPubDto(XMLGregorianCalendar shabDate, String shabNr, String shabPage, String shabId) {
		this.shabDate = shabDate.toGregorianCalendar().getTime();
		this.shabNr = shabNr;
		this.shabPage = shabPage;
		this.shabId = shabId;
	}

	public Date getShabDate() {
		return shabDate;
	}
	
	public void setShabDate(Date shabDate) {
		this.shabDate = shabDate;
	}
	
	public String getShabNr() {
		return shabNr;
	}
	
	public void setShabNr(String shabNr) {
		this.shabNr = shabNr;
	}
	
	public String getShabPage() {
		return shabPage;
	}
	
	public void setShabPage(String shabPage) {
		this.shabPage = shabPage;
	}
	
	public String getShabId() {
		return shabId;
	}
	
	public void setShabId(String shabId) {
		this.shabId = shabId;
	}
}
