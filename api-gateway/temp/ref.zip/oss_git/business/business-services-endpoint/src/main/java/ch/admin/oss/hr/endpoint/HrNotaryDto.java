/*
 * HrNotaryDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hr.endpoint;

import ch.admin.oss.common.CodeWertDto;

/**
 * @author hha
 */
public class HrNotaryDto {

	private CodeWertDto notarAnrede;
	private String notarTitel;
	private String notarName;
	private String notarVorname;
	private String notarPostadresse;
	private String notarTelefon;
	private String notarEmail;
	private String notarFunktion;
	private String notarFax;
	private String notarUpRegUUID;
	private String notarKanton;

	public CodeWertDto getNotarAnrede() {
		return notarAnrede;
	}

	public void setNotarAnrede(CodeWertDto notarAnrede) {
		this.notarAnrede = notarAnrede;
	}

	public String getNotarTitel() {
		return notarTitel;
	}

	public void setNotarTitel(String notarTitel) {
		this.notarTitel = notarTitel;
	}

	public String getNotarName() {
		return notarName;
	}

	public void setNotarName(String notarName) {
		this.notarName = notarName;
	}

	public String getNotarVorname() {
		return notarVorname;
	}

	public void setNotarVorname(String notarVorname) {
		this.notarVorname = notarVorname;
	}

	public String getNotarPostadresse() {
		return notarPostadresse;
	}

	public void setNotarPostadresse(String notarPostadresse) {
		this.notarPostadresse = notarPostadresse;
	}

	public String getNotarTelefon() {
		return notarTelefon;
	}

	public void setNotarTelefon(String notarTelefon) {
		this.notarTelefon = notarTelefon;
	}

	public String getNotarEmail() {
		return notarEmail;
	}

	public void setNotarEmail(String notarEmail) {
		this.notarEmail = notarEmail;
	}

	public String getNotarFunktion() {
		return notarFunktion;
	}

	public void setNotarFunktion(String notarFunktion) {
		this.notarFunktion = notarFunktion;
	}

	public String getNotarFax() {
		return notarFax;
	}

	public void setNotarFax(String notarFax) {
		this.notarFax = notarFax;
	}

	public String getNotarUpRegUUID() {
		return notarUpRegUUID;
	}

	public void setNotarUpRegUUID(String notarUpRegUUID) {
		this.notarUpRegUUID = notarUpRegUUID;
	}

	public String getNotarKanton() {
		return notarKanton;
	}

	public void setNotarKanton(String notarKanton) {
		this.notarKanton = notarKanton;
	}

}
