/*
 * MailMessage
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.mail.SimpleMailMessage;

/**
 * Model for a mail message, including template name, its model, attachments ...
 * 
 * @author phd
 */
public class MailMessage extends SimpleMailMessage {

	private static final long serialVersionUID = 8334577580916729312L;

	/**
	 * Name of the template.
	 */
	private String templateName;

	/**
	 * When {@link #templateName} is defined, it can be used as a Velocity template whose model is defined here.
	 */
	private Map<String, Object> templateModel = new HashMap<String, Object>();

	/**
	 * List of attachments to be sent (map from attachment names and the corresponding file).
	 */
	private Map<String, File> attachments = new HashMap<String, File>();
	
	/**
	 * List of data to be sent (map from attachment names and the corresponding file).
	 */
	private Map<String, byte[]> attachmentDatas = new HashMap<String, byte[]>();

	/**
	 * Empty constructor.
	 */
	public MailMessage() {}

	/**
	 * Constructor from a simple template message.
	 * 
	 * @param original
	 */
	public MailMessage(MailMessage original) {
		super(original);
		this.templateName = original.templateName;
		this.templateModel = original.templateModel;
		this.attachments = original.attachments;
	}

	@NotNull
	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateLocation) {
		this.templateName = templateLocation;
	}

	public Map<String, Object> getTemplateModel() {
		return templateModel;
	}

	public void setTemplateModel(Map<String, Object> templateModel) {
		this.templateModel = templateModel;
	}

	public Map<String, File> getAttachments() {
		return attachments;
	}

	public void setAttachments(Map<String, File> attachments) {
		this.attachments = attachments;
	}
	
	public Map<String, byte[]> getAttachmentDatas() {
		return attachmentDatas;
	}

	@NotNull
	/**
	 * Regex allowing email addresses permitted by RFC 5322
	 */
	@Pattern(regexp = OSSConstants.EMAIL_REGEX_PATTERN)
	@Override
	public String getFrom() {
		return super.getFrom();
	}

}
