/*
 * AhvTeilhaber
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Type;

import ch.admin.oss.common.enums.AhvMitarbeitEnum;
import ch.admin.oss.common.enums.AhvNamenEnum;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_AHV_TEILHABER")
public class AhvTeilhaberEntity extends AbstractOSSEntity {
	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_AHV_ANMELDUNG", foreignKey = @ForeignKey(name="FK_AHV_TEILHABER_AHV_ANMELDUNG"))
	private AhvAnmeldungEntity ahv;
	
	@Column(name = "BISHER_AK")
	private String bisherAk;

	@Column(name = "BISHER_VON")
	private LocalDate bisherVon;

	@Column(name = "BISHER_BIS")
	private LocalDate bisherBis;

	@Column(name = "LN_BISHER_VERBAND_AK")
	private Long bisherVerbandAkId;

	@Column(name = "LN_BISHER_BERUF_VERBAND")
	private Long bisherBerufVerbandId;

	@Column(name = "BISHER_HAT_KINDER", length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean bisherHatKinder;
	
	@Column(name = "MITARBEIT")
	@Enumerated(EnumType.STRING)
	private AhvMitarbeitEnum mitarbeit;
	
	@Column(name = "MITARBEIT_ROLLE")
	private String mitarbeitRolle;
	
	@Column(name = "MITARBEIT_BEZEICHNUNG")
	private String mitarbeitBezeichnung;
	
	@Column(name = "MITARBEIT_NAME")
	private String mitarbeitName;
	
	@Column(name = "MITARBEIT_STRASSE")
	private String mitarbeitStrasse;
	
	@Column(name = "MITARBEIT_PLZ_ORT")
	private String mitarbeitPlzOrt;

	@Column(name = "MITARBEIT_STAATEN")
	private String mitarbeitStaaten;
	
	@Column(name = "EINKOMMEN_EINKOMMEN")
	private BigDecimal einkommenEinkommen;
	
	@Column(name = "EINKOMMEN_ANTEIL_AM_GEWINN")
	private BigDecimal einkommenAnteilAmGewinn;
	
	@Column(name = "EINKOMMEN_ANTEIL_AM_VERLUST")
	private BigDecimal einkommenAnteilAmVerlust;
	
	@Column(name = "EINKOMMEN_RECHNUNG")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean einkommenRechnung;
	
	@Column(name = "EINKOMMEN_LOHN")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean einkommenLohn;

	@Column(name = "EINKOMMEN_PROVISION")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean einkommenProvision;
	
	@Column(name = "LASTEN_UNKOSTEN")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean lastenUnkosten;
	
	@Column(name = "LASTEN_UNTERHALT")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean lastenUnterhalt;
	
	@Column(name = "LASTEN_GARANTIE")
	private Boolean lastenGarantie;
	
	@Column(name = "LASTEN_MATERIAL")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean lastenMaterial;
	
	@Column(name = "LASTEN_INKASSORISIKO")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean lastenInkassorisiko;
	
	@Column(name = "LASTEN_VERLUSTE")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean lastenVerluste;

	@Column(name = "LASTEN_LOHNANSPRUCH")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean lastenLohnanspruch;
	
	@Column(name = "LASTEN_RISIKO", length = 4000)
	private String lastenRisiko;
	
	@Column(name = "AOA_WEISUNG")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean aoaWeisung;
	
	@Column(name = "AOA_KONKURRENZVERBOT")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean aoaKonkurrenzverbot;
	
	@Column(name = "AOA_PERSOENLICH")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean aoaPersoenlich;
	
	@Column(name = "AOA_NAME")
	@Enumerated(EnumType.STRING)
	private AhvNamenEnum aoaName;
	
	@Column(name = "AOA_BRIEFPAPIER")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean aoaBriefpapier;
	
	@Column(name = "AOA_WERBUNG")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean aoaWerbung;
	
	@Column(name = "AOA_OFFERTEN")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean aoaOfferten;
	
	@Column(name = "AOA_RECHNUNGEN")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean aoaRechnungen;
	
	@Column(name = "AOA_RABATTE")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean aoaRabatte;

	@Column(name = "AOA_KUNDENDIENST")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean aoaKundendienst;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PARTNER", foreignKey = @ForeignKey(name = "FK_AHV_TEILHABER_PERSON_1"))
	private PersonEntity partner;
	
	@Column(name = "PARTNER_ARBEITET_MIT")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean partnerArbeitetMit;
	
	@Column(name = "PARTNER_EINKOMMEN_UEBER")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean partnerEinkommenUeber;
	
	@Column(name = "PARTNER_LOHN_SUMME")
	private BigDecimal partnerLohnSumme;

	@Column(name = "PARTNER_LOHN_SEIT")
	private LocalDate partnerLohnSeit;

	@Column(name = "PARTNER_HAT_KINDER")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean partnerHatKinder;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PERSON", foreignKey = @ForeignKey(name="FK_AHV_TEILHABER_PERSON_2"))
	private PersonEntity person;
	
	@Column(name = "COMPLETE")
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean complete;
	
	@Column(name = "LN_BISHER_BEITRAG_ALS")	
	private Long bisherBeitragAls;
	
	@Column(name = "BISHER_EINKOMMEN")
	private BigDecimal bisherEinkommen;

	public AhvTeilhaberEntity() {
		// default constructor
	}

	public AhvTeilhaberEntity(AhvAnmeldungEntity ahv, PersonEntity person) {
		this.ahv = ahv;
		this.person = person;
	}

	public String getBisherAk() {
		return bisherAk;
	}

	public void setBisherAk(String bisherAk) {
		this.bisherAk = bisherAk;
	}

	public LocalDate getBisherVon() {
		return bisherVon;
	}

	public void setBisherVon(LocalDate bisherVon) {
		this.bisherVon = bisherVon;
	}

	public LocalDate getBisherBis() {
		return bisherBis;
	}

	public void setBisherBis(LocalDate bisherBis) {
		this.bisherBis = bisherBis;
	}

	public Long getBisherVerbandAkId() {
		return bisherVerbandAkId;
	}

	public void setBisherVerbandAkId(Long bisherVerbandAkId) {
		this.bisherVerbandAkId = bisherVerbandAkId;
	}

	public Boolean getBisherHatKinder() {
		return bisherHatKinder;
	}

	public void setBisherHatKinder(Boolean bisherHatKinder) {
		this.bisherHatKinder = bisherHatKinder;
	}

	public AhvMitarbeitEnum getMitarbeit() {
		return mitarbeit;
	}

	public void setMitarbeit(AhvMitarbeitEnum mitarbeit) {
		this.mitarbeit = mitarbeit;
	}

	public String getMitarbeitRolle() {
		return mitarbeitRolle;
	}

	public void setMitarbeitRolle(String mitarbeitRolle) {
		this.mitarbeitRolle = mitarbeitRolle;
	}

	public String getMitarbeitBezeichnung() {
		return mitarbeitBezeichnung;
	}

	public void setMitarbeitBezeichnung(String mitarbeitBezeichnung) {
		this.mitarbeitBezeichnung = mitarbeitBezeichnung;
	}

	public String getMitarbeitName() {
		return mitarbeitName;
	}

	public void setMitarbeitName(String mitarbeitName) {
		this.mitarbeitName = mitarbeitName;
	}

	public String getMitarbeitStrasse() {
		return mitarbeitStrasse;
	}

	public void setMitarbeitStrasse(String mitarbeitStrasse) {
		this.mitarbeitStrasse = mitarbeitStrasse;
	}

	public String getMitarbeitPlzOrt() {
		return mitarbeitPlzOrt;
	}

	public void setMitarbeitPlzOrt(String mitarbeitPlzOrt) {
		this.mitarbeitPlzOrt = mitarbeitPlzOrt;
	}

	public String getMitarbeitStaaten() {
		return mitarbeitStaaten;
	}

	public void setMitarbeitStaaten(String mitarbeitStaaten) {
		this.mitarbeitStaaten = mitarbeitStaaten;
	}

	public BigDecimal getEinkommenEinkommen() {
		return einkommenEinkommen;
	}

	public void setEinkommenEinkommen(BigDecimal einkommenEinkommen) {
		this.einkommenEinkommen = einkommenEinkommen;
	}

	public BigDecimal getEinkommenAnteilAmGewinn() {
		return einkommenAnteilAmGewinn;
	}

	public void setEinkommenAnteilAmGewinn(BigDecimal einkommenAnteilAmGewinn) {
		this.einkommenAnteilAmGewinn = einkommenAnteilAmGewinn;
	}

	public BigDecimal getEinkommenAnteilAmVerlust() {
		return einkommenAnteilAmVerlust;
	}

	public void setEinkommenAnteilAmVerlust(BigDecimal einkommenAnteilAmVerlust) {
		this.einkommenAnteilAmVerlust = einkommenAnteilAmVerlust;
	}

	public Boolean getEinkommenRechnung() {
		return einkommenRechnung;
	}

	public void setEinkommenRechnung(Boolean einkommenRechnung) {
		this.einkommenRechnung = einkommenRechnung;
	}

	public Boolean getEinkommenLohn() {
		return einkommenLohn;
	}

	public void setEinkommenLohn(Boolean einkommenLohn) {
		this.einkommenLohn = einkommenLohn;
	}

	public Boolean getEinkommenProvision() {
		return einkommenProvision;
	}

	public void setEinkommenProvision(Boolean einkommenProvision) {
		this.einkommenProvision = einkommenProvision;
	}

	public Boolean getLastenUnkosten() {
		return lastenUnkosten;
	}

	public void setLastenUnkosten(Boolean lastenUnkosten) {
		this.lastenUnkosten = lastenUnkosten;
	}

	public Boolean getLastenUnterhalt() {
		return lastenUnterhalt;
	}

	public void setLastenUnterhalt(Boolean lastenUnterhalt) {
		this.lastenUnterhalt = lastenUnterhalt;
	}

	public Boolean getLastenGarantie() {
		return lastenGarantie;
	}

	public void setLastenGarantie(Boolean lastenGarantie) {
		this.lastenGarantie = lastenGarantie;
	}

	public Boolean getLastenMaterial() {
		return lastenMaterial;
	}

	public void setLastenMaterial(Boolean lastenMaterial) {
		this.lastenMaterial = lastenMaterial;
	}

	public Boolean getLastenInkassorisiko() {
		return lastenInkassorisiko;
	}

	public void setLastenInkassorisiko(Boolean lastenInkassorisiko) {
		this.lastenInkassorisiko = lastenInkassorisiko;
	}

	public Boolean getLastenVerluste() {
		return lastenVerluste;
	}

	public void setLastenVerluste(Boolean lastenVerluste) {
		this.lastenVerluste = lastenVerluste;
	}

	public Boolean getLastenLohnanspruch() {
		return lastenLohnanspruch;
	}

	public void setLastenLohnanspruch(Boolean lastenLohnanspruch) {
		this.lastenLohnanspruch = lastenLohnanspruch;
	}

	public String getLastenRisiko() {
		return lastenRisiko;
	}

	public void setLastenRisiko(String lastenRisiko) {
		this.lastenRisiko = lastenRisiko;
	}

	public Boolean getAoaPersoenlich() {
		return aoaPersoenlich;
	}

	public void setAoaPersoenlich(Boolean aoaPersoenlich) {
		this.aoaPersoenlich = aoaPersoenlich;
	}

	public AhvNamenEnum getAoaName() {
		return aoaName;
	}

	public void setAoaName(AhvNamenEnum aoaName) {
		this.aoaName = aoaName;
	}

	public Boolean getAoaWerbung() {
		return aoaWerbung;
	}

	public void setAoaWerbung(Boolean aoaWerbung) {
		this.aoaWerbung = aoaWerbung;
	}

	public Boolean getAoaOfferten() {
		return aoaOfferten;
	}

	public void setAoaOfferten(Boolean aoaOfferten) {
		this.aoaOfferten = aoaOfferten;
	}

	public Boolean getAoaRechnungen() {
		return aoaRechnungen;
	}

	public void setAoaRechnungen(Boolean aoaRechnungen) {
		this.aoaRechnungen = aoaRechnungen;
	}

	public PersonEntity getPartner() {
		return partner;
	}

	public void setPartner(PersonEntity partner) {
		this.partner = partner;
	}

	public Boolean getPartnerArbeitetMit() {
		return partnerArbeitetMit;
	}

	public void setPartnerArbeitetMit(Boolean partnerArbeitetMit) {
		this.partnerArbeitetMit = partnerArbeitetMit;
	}

	public Boolean getPartnerEinkommenUeber() {
		return partnerEinkommenUeber;
	}

	public void setPartnerEinkommenUeber(Boolean partnerEinkommenUeber) {
		this.partnerEinkommenUeber = partnerEinkommenUeber;
	}

	public AhvAnmeldungEntity getAhv() {
		return ahv;
	}

	public void setAhv(AhvAnmeldungEntity ahv) {
		this.ahv = ahv;
	}

	public Boolean getPartnerHatKinder() {
		return partnerHatKinder;
	}

	public void setPartnerHatKinder(Boolean partnerHatKinder) {
		this.partnerHatKinder = partnerHatKinder;
	}

	public PersonEntity getPerson() {
		return person;
	}

	public void setPerson(PersonEntity person) {
		this.person = person;
	}

	public BigDecimal getPartnerLohnSumme() {
		return partnerLohnSumme;
	}

	public void setPartnerLohnSumme(BigDecimal partnerLohnSumme) {
		this.partnerLohnSumme = partnerLohnSumme;
	}

	public LocalDate getPartnerLohnSeit() {
		return partnerLohnSeit;
	}

	public void setPartnerLohnSeit(LocalDate partnerLohnSeit) {
		this.partnerLohnSeit = partnerLohnSeit;
	}

	public Long getBisherBeitragAls() {
		return bisherBeitragAls;
	}

	public void setBisherBeitragAls(Long bisherBeitragAls) {
		this.bisherBeitragAls = bisherBeitragAls;
	}

	public Long getBisherBerufVerbandId() {
		return bisherBerufVerbandId;
	}

	public void setBisherBerufVerbandId(Long bisherBerufVerbandId) {
		this.bisherBerufVerbandId = bisherBerufVerbandId;
	}

	public Boolean getComplete() {
		return complete;
	}

	public void setComplete(Boolean complete) {
		this.complete = complete;
	}

	public BigDecimal getBisherEinkommen() {
		return bisherEinkommen;
	}

	public void setBisherEinkommen(BigDecimal bisherEinkommen) {
		this.bisherEinkommen = bisherEinkommen;
	}

	public Boolean getAoaWeisung() {
		return aoaWeisung;
	}

	public void setAoaWeisung(Boolean aoaWeisung) {
		this.aoaWeisung = aoaWeisung;
	}

	public Boolean getAoaKonkurrenzverbot() {
		return aoaKonkurrenzverbot;
	}

	public void setAoaKonkurrenzverbot(Boolean aoaKonkurrenzverbot) {
		this.aoaKonkurrenzverbot = aoaKonkurrenzverbot;
	}

	public Boolean getAoaBriefpapier() {
		return aoaBriefpapier;
	}

	public void setAoaBriefpapier(Boolean aoaBriefpapier) {
		this.aoaBriefpapier = aoaBriefpapier;
	}

	public Boolean getAoaRabatte() {
		return aoaRabatte;
	}

	public void setAoaRabatte(Boolean aoaRabatte) {
		this.aoaRabatte = aoaRabatte;
	}

	public Boolean getAoaKundendienst() {
		return aoaKundendienst;
	}

	public void setAoaKundendienst(Boolean aoaKundendienst) {
		this.aoaKundendienst = aoaKundendienst;
	}
}
