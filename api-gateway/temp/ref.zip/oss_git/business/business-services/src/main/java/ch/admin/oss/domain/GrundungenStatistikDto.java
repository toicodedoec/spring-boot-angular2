package ch.admin.oss.domain;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;

@Entity
@SqlResultSetMapping(name = "GrundungenStatistikDto", entities = @EntityResult(entityClass = GrundungenStatistikDto.class))
public class GrundungenStatistikDto {
	@Id
	private String monat;
	private String monYear;
	private Long ef;
	private Long koll;
	private Long kom;
	private Long ag;
	private Long gmbh;

	public GrundungenStatistikDto() {}

	public String getMonYear() {
		return monYear;
	}

	public void setMonYear(String monYear) {
		this.monYear = monYear;
	}

	public String getMonat() {
		return monat;
	}

	public void setMonat(String monat) {
		this.monat = monat;
	}

	public Long getEf() {
		return ef;
	}

	public void setEf(Long ef) {
		this.ef = ef;
	}

	public Long getKoll() {
		return koll;
	}

	public void setKoll(Long koll) {
		this.koll = koll;
	}

	public Long getKom() {
		return kom;
	}

	public void setKom(Long kom) {
		this.kom = kom;
	}

	public Long getAg() {
		return ag;
	}

	public void setAg(Long ag) {
		this.ag = ag;
	}

	public Long getGmbh() {
		return gmbh;
	}

	public void setGmbh(Long gmbh) {
		this.gmbh = gmbh;
	}
}
