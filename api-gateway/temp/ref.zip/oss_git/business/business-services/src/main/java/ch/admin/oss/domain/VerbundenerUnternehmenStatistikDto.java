package ch.admin.oss.domain;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;

@Entity
@SqlResultSetMapping(name = "VerbundenerUnternehmenStatistikDto", entities = @EntityResult(entityClass = VerbundenerUnternehmenStatistikDto.class))
public class VerbundenerUnternehmenStatistikDto {
	@Id
	private String monYear;
	private Long ef;
	private Long koll;
	private Long kom;
	private Long ag;
	private Long gmbh;

	public VerbundenerUnternehmenStatistikDto() {}

	public VerbundenerUnternehmenStatistikDto(String monYear, long ef, long koll, long kom, long ag, long gmbh) {
		this.monYear = monYear;
		this.ef = ef;
		this.koll = koll;
		this.kom = kom;
		this.ag = ag;
		this.gmbh = gmbh;
	}

	public String getMonYear() {
		return monYear;
	}

	public void setMonYear(String monYear) {
		this.monYear = monYear;
	}

	public Long getEf() {
		return ef;
	}

	public void setEf(Long ef) {
		this.ef = ef;
	}

	public Long getKoll() {
		return koll;
	}

	public void setKoll(Long koll) {
		this.koll = koll;
	}

	public Long getKom() {
		return kom;
	}

	public void setKom(Long kom) {
		this.kom = kom;
	}

	public Long getAg() {
		return ag;
	}

	public void setAg(Long ag) {
		this.ag = ag;
	}

	public Long getGmbh() {
		return gmbh;
	}

	public void setGmbh(Long gmbh) {
		this.gmbh = gmbh;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((ag == null) ? 0 : ag.hashCode());
		result = prime * result + ((ef == null) ? 0 : ef.hashCode());
		result = prime * result + ((gmbh == null) ? 0 : gmbh.hashCode());
		result = prime * result + ((koll == null) ? 0 : koll.hashCode());
		result = prime * result + ((kom == null) ? 0 : kom.hashCode());
		result = prime * result + ((monYear == null) ? 0 : monYear.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		VerbundenerUnternehmenStatistikDto other = (VerbundenerUnternehmenStatistikDto) obj;
		if (ag == null) {
			if (other.ag != null)
				return false;
		} else if (!ag.equals(other.ag))
			return false;
		if (ef == null) {
			if (other.ef != null)
				return false;
		} else if (!ef.equals(other.ef))
			return false;
		if (gmbh == null) {
			if (other.gmbh != null)
				return false;
		} else if (!gmbh.equals(other.gmbh))
			return false;
		if (koll == null) {
			if (other.koll != null)
				return false;
		} else if (!koll.equals(other.koll))
			return false;
		if (kom == null) {
			if (other.kom != null)
				return false;
		} else if (!kom.equals(other.kom))
			return false;
		if (monYear == null) {
			if (other.monYear != null)
				return false;
		} else if (!monYear.equals(other.monYear))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "VerbundenerUnternehmenStatistikDto [monYear=" + monYear + ", ef=" + ef + ", koll=" + koll + ", kom="
			+ kom + ", ag=" + ag + ", gmbh=" + gmbh + "]";
	}
}