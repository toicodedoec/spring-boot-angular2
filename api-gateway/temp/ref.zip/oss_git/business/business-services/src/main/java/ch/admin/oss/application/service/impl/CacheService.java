/*
 * CacheService
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.application.service.impl;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.application.service.ICacheService;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.BrancheEntity;
import ch.admin.oss.domain.CHOrtEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.IStandardTextCode;
import ch.admin.oss.domain.ITextTranslationText;
import ch.admin.oss.domain.LandEntity;
import ch.admin.oss.domain.QAusgleichskasseEntity;
import ch.admin.oss.domain.QBerufEntity;
import ch.admin.oss.domain.QBrancheEntity;
import ch.admin.oss.domain.QCHOrtEntity;
import ch.admin.oss.domain.QCodeWertEntity;
import ch.admin.oss.domain.QLandEntity;
import ch.admin.oss.domain.QStandardTextEntity;
import ch.admin.oss.domain.QTextTranslationEntity;
import ch.admin.oss.domain.QVerbandEntity;
import ch.admin.oss.domain.QVersicherungEntity;
import ch.admin.oss.domain.TextTranslationEntity;
import ch.admin.oss.domain.VerbandEntity;
import ch.admin.oss.domain.VersicherungEntity;
import ch.admin.oss.util.JpaUtil;

/**
 * Cache service implementation
 * 
 * @author coh
 */

@Service
@Transactional(rollbackFor = Throwable.class)
public class CacheService implements ICacheService {
	
	public static final String CODE_WERT_CACHE_MAP = "CODE_WERT";
	public static final String TRANSLATION_CACHE_MAP = "TRANSLATION";
	public static final String BRANCHE_CACHE_MAP = "BRANCHE";
	public static final String VERBAN_CACHE_MAP = "VERBAN";
	public static final String BERUF_CACHE_MAP = "BERUF";
	public static final String CH_ORT_CACHE_MAP = "CH_ORT";
	public static final String AUSGLEICHSKASSE_CACHE_MAP = "AUSGLEICHSKASSE";
	public static final String VERSICHERUNG_CACHE_MAP = "VERSICHERUNG";
	public static final String LAND_CACHE_MAP = "LAND";

	@PersistenceContext
	private EntityManager em;

	@Autowired
	private JpaUtil jpaUtil;

	@Cacheable(cacheNames = TRANSLATION_CACHE_MAP)
	@Override
	public Map<String, String> getTranslationByLang(SupportedLanguage targetLang) {
		return new JPAQuery<TextTranslationEntity>(em).from(QTextTranslationEntity.textTranslationEntity)
			.join(QTextTranslationEntity.textTranslationEntity.standardText).fetchJoin()
			.where(QTextTranslationEntity.textTranslationEntity.language.eq(targetLang)
				.and(QTextTranslationEntity.textTranslationEntity.standardText.code.isNotNull()))
			.fetch()
			.stream()
			.collect(Collectors.toMap(IStandardTextCode::getStandardTextCode, ITextTranslationText::getText));
	}

	@Cacheable(cacheNames = CODE_WERT_CACHE_MAP)
	@Override
	public List<CodeWertEntity> getCodeWerts() {
		List<CodeWertEntity> codeWerts = new JPAQuery<CodeWertEntity>(em)
			.from(QCodeWertEntity.codeWertEntity)
			.join(QCodeWertEntity.codeWertEntity.standardText).fetchJoin()
			.where(QCodeWertEntity.codeWertEntity.aktiv.isTrue())
			.orderBy(QCodeWertEntity.codeWertEntity.pos.asc())
			.fetch();

		for (CodeWertEntity codeWertEntity : codeWerts) {
			jpaUtil.initialize(codeWertEntity, QCodeWertEntity.codeWertEntity.standardText.translations);
		}

		return codeWerts;
	}

	@Cacheable(cacheNames = BRANCHE_CACHE_MAP)
	@Override
	public List<BrancheEntity> getBranches() {
		List<BrancheEntity> branches = new JPAQuery<BrancheEntity>(em)
			.from(QBrancheEntity.brancheEntity)
			.join(QBrancheEntity.brancheEntity.standardText).fetchJoin()
			.where(QBrancheEntity.brancheEntity.aktiv.isTrue())
			.orderBy(QBrancheEntity.brancheEntity.pos.asc())
			.fetch();
		for (BrancheEntity brancheEntity : branches) {
			jpaUtil.initialize(brancheEntity, QBrancheEntity.brancheEntity.standardText.translations);
		}
		return branches;
	}

	@Cacheable(cacheNames = VERBAN_CACHE_MAP)
	@Override
	public List<VerbandEntity> getVerbands() {
		List<VerbandEntity> verbands = new JPAQuery<VerbandEntity>(em)
			.from(QVerbandEntity.verbandEntity)
			.join(QVerbandEntity.verbandEntity.standardText).fetchJoin()
			.where(QVerbandEntity.verbandEntity.aktiv.isTrue())
			.fetch();
		for (VerbandEntity verbandEntity : verbands) {
			jpaUtil.initialize(verbandEntity, QVerbandEntity.verbandEntity.standardText.translations,
					QVerbandEntity.verbandEntity.ausgleichskasse.standardText.translations);
		}
		return verbands;
	}

	@Cacheable(cacheNames = BERUF_CACHE_MAP)
	@Override
	public List<BerufEntity> getBerufs() {
		QBrancheEntity brancheEntity = QBrancheEntity.brancheEntity;
		QStandardTextEntity standardTextEntity = QStandardTextEntity.standardTextEntity;

		List<BerufEntity> berufs = new JPAQuery<BerufEntity>(em)
			.from(QBerufEntity.berufEntity)
			.leftJoin(QBerufEntity.berufEntity.branche, brancheEntity).fetchJoin()
			.join(QBerufEntity.berufEntity.standardText, standardTextEntity).fetchJoin()
			.where(QBerufEntity.berufEntity.aktiv.isTrue())
			.orderBy(QBerufEntity.berufEntity.code.asc())
			.fetch();
		for (BerufEntity berufEntity : berufs) {
			jpaUtil.initialize(berufEntity, QBerufEntity.berufEntity.standardText.translations);
		}
		return berufs;
	}

	@Cacheable(cacheNames = CH_ORT_CACHE_MAP)
	@Override
	public List<CHOrtEntity> getCHOrts() {
		return new JPAQuery<CHOrtEntity>(em).from(QCHOrtEntity.cHOrtEntity).fetch();
	}

	@Cacheable(cacheNames = AUSGLEICHSKASSE_CACHE_MAP)
	@Override
	public List<AusgleichskasseEntity> getAusgleichskasses() {
		List<AusgleichskasseEntity> ausgleichskasses = new JPAQuery<AusgleichskasseEntity>(em)
			.from(QAusgleichskasseEntity.ausgleichskasseEntity)
			.where(QAusgleichskasseEntity.ausgleichskasseEntity.aktiv.isTrue())
			.fetch();
		ausgleichskasses.stream().forEach(ausg -> {
			jpaUtil.initialize(ausg, QAusgleichskasseEntity.ausgleichskasseEntity.standardText.translations);
		});	
		return ausgleichskasses;
	}
	
	@Cacheable(cacheNames = VERSICHERUNG_CACHE_MAP)
	@Override
	public List<VersicherungEntity> getVersicherungs() {
		List<VersicherungEntity> versicherung = new JPAQuery<VersicherungEntity>(em)
			.from(QVersicherungEntity.versicherungEntity)
			.where(QVersicherungEntity.versicherungEntity.aktiv.isTrue())
			.fetch();
		versicherung.stream().forEach(vers -> {
			jpaUtil.initialize(vers, QVersicherungEntity.versicherungEntity.standardText.translations);
		});
		return versicherung;
	}

	@Cacheable(cacheNames = LAND_CACHE_MAP)
	@Override
	public Map<String, LandEntity> getLands() {
		List<LandEntity> lands = new JPAQuery<LandEntity>(em)
			.from(QLandEntity.landEntity)
			.fetch();
		return lands.stream().collect(Collectors.toMap(LandEntity::getBfscode, Function.identity()));
	}
}
