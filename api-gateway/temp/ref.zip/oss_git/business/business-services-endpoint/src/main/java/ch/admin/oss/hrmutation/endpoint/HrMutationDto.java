/*
 * HrMutationDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.endpoint;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.FlowHistoryDto;
import ch.admin.oss.common.GeschaftsrolleDto;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author hhg
 */
public class HrMutationDto extends AbstractOSSDto {

	public HrMutationDto() {
		// default constructor
	}

	public HrMutationDto(Long prozessId, Long orgId, RechtsformEnum rechtsform) {
		this.prozessId = prozessId;
		this.orgId = orgId;
		this.rechtsform = rechtsform;
	}

	private Long prozessId;
	
	private ProzessStatusEnum status;

	private Long orgId;

	private RechtsformEnum rechtsform;

	private FlowHistoryDto flowHistory = new FlowHistoryDto();

	private HrMutationZefixCompareDto orgInfoContainer;

	// user has chosen to modify the company name
	private boolean taskName;

	// user has chosen to modify the domicile address
	private boolean taskAddress;

	// user has chosen to modify the company purpose
	private boolean taskPurpose;

	// user has chosen to modify persons
	private boolean taskPersons;

	// user has chosen to declare the dissolution of the partnership
	// (KollG/KommG)
	private boolean taskDissolution;

	// user has chosen to modify the seat of the revision body (AG/GMBH)
	private boolean taskRevision;

	// user has chosen to order register excerpts
	private boolean taskExcerpts;

	private String newCompanyName;

	// old company name from ZEFIX or from Organization#DefaultFirmenname
	private String oldCompanyName;

	// old company purpose; from ZEFIX or from Organization#Zweck
	private String oldPurpose;

	private String newPurpose;

	// old company address from ZEFIX or a copied reference of
	// Organization#Domizil
	private AdresseDto oldDomicile;

	private AdresseDto newDomicile;

	private Date zefixUpdateDate;

	private AdresseDto excerptsDeliveryAddress;

	// billing address for excerpts
	private AdresseDto excerptsBillingAddress;

	private Set<HrMutationPersonDto> persons = new HashSet<>();

	private HrMutationTypeOfPersonEnum confirmTypeOfPerson;

	private HrMutationPersonDto currentUpdatePerson;

	@NotNull
	private int excerptsNum = 0;

	@NotNull
	private int excerptsNumPrelim = 0;

	private String revCompanyName;

	private Integer revPreviousSeatBfsNr;

	private String revPreviousSeatCity;

	private String revPreviousSeatPolCommunity;

	private String revPreviousSeatCanton;

	private Integer revNewSeatBfsNr;

	private String revNewSeatCity;

	private String revNewSeatPolCommunity;

	private String revNewSeatCanton;

	// given name of the leaving partner
	private String dissLeavingPartnerGivenName;

	// family name of the leaving partner
	private String dissLeavingPartnerFamilyName;

	// birthday of the leaving partner
	private Date dissLeavingPartnerBirthday;

	// new owner of the remaining single proprietorship
	private GeschaftsrolleDto dissNewOwner;

	// new name of the company
	private String dissNewCompanyName;

	// a List of address for dropdown in screen HrMutationDeliveryAdrress and HrMutationBillingAddress
	private List<AdresseDto> existingAddresses;

	// for font-end recognized editing state of flow.
	private HrMutationEditingState editingState;

	public Long getProzessId() {
		return prozessId;
	}

	public void setProzessId(Long prozessId) {
		this.prozessId = prozessId;
	}

	public HrMutationPersonDto getCurrentUpdatePerson() {
		return currentUpdatePerson;
	}

	public void setCurrentUpdatePerson(HrMutationPersonDto currentUpdatePerson) {
		this.currentUpdatePerson = currentUpdatePerson;
	}

	public HrMutationTypeOfPersonEnum getConfirmTypeOfPerson() {
		return confirmTypeOfPerson;
	}

	public void setConfirmTypeOfPerson(HrMutationTypeOfPersonEnum confirmTypeOfPerson) {
		this.confirmTypeOfPerson = confirmTypeOfPerson;
	}

	public Set<HrMutationPersonDto> getPersons() {
		return persons;
	}

	public void setPersons(Set<HrMutationPersonDto> persons) {
		this.persons = persons;
	}

	public boolean isNewCompanyNameValid() {
		return newCompanyNameValid;
	}

	public void setNewCompanyNameValid(boolean newCompanyNameValid) {
		this.newCompanyNameValid = newCompanyNameValid;
	}

	private boolean newCompanyNameValid = false;

	private boolean selectionChangesValid = false;

	public boolean isSelectionChangesValid() {
		return selectionChangesValid;
	}

	public void setSelectionChangesValid(boolean selectionChangesValid) {
		this.selectionChangesValid = selectionChangesValid;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}

	public FlowHistoryDto getFlowHistory() {
		return flowHistory;
	}

	public void setFlowHistory(FlowHistoryDto flowHistory) {
		this.flowHistory = flowHistory;
	}

	public boolean isTaskName() {
		return taskName;
	}

	public void setTaskName(boolean taskName) {
		this.taskName = taskName;
	}

	public boolean isTaskAddress() {
		return taskAddress;
	}

	public void setTaskAddress(boolean taskAddress) {
		this.taskAddress = taskAddress;
	}

	public boolean isTaskPurpose() {
		return taskPurpose;
	}

	public void setTaskPurpose(boolean taskPurpose) {
		this.taskPurpose = taskPurpose;
	}

	public boolean isTaskPersons() {
		return taskPersons;
	}

	public void setTaskPersons(boolean taskPersons) {
		this.taskPersons = taskPersons;
	}

	public boolean isTaskDissolution() {
		return taskDissolution;
	}

	public void setTaskDissolution(boolean taskDissolution) {
		this.taskDissolution = taskDissolution;
	}

	public boolean isTaskRevision() {
		return taskRevision;
	}

	public void setTaskRevision(boolean taskRevision) {
		this.taskRevision = taskRevision;
	}

	public boolean isTaskExcerpts() {
		return taskExcerpts;
	}

	public void setTaskExcerpts(boolean taskExcerpts) {
		this.taskExcerpts = taskExcerpts;
	}

	public String getOldCompanyName() {
		return oldCompanyName;
	}

	public void setOldCompanyName(String oldCompanyName) {
		this.oldCompanyName = oldCompanyName;
	}

	public String getNewCompanyName() {
		return newCompanyName;
	}

	public void setNewCompanyName(String newCompanyName) {
		this.newCompanyName = newCompanyName;
	}

	public String getOldPurpose() {
		return oldPurpose;
	}

	public void setOldPurpose(String oldPurpose) {
		this.oldPurpose = oldPurpose;
	}

	public AdresseDto getOldDomicile() {
		return oldDomicile;
	}

	public void setOldDomicile(AdresseDto oldDomicile) {
		this.oldDomicile = oldDomicile;
	}

	public AdresseDto getNewDomicile() {
		return newDomicile;
	}

	public void setNewDomicile(AdresseDto newDomicile) {
		this.newDomicile = newDomicile;
	}

	public String getNewPurpose() {
		return newPurpose;
	}

	public void setNewPurpose(String newPurpose) {
		this.newPurpose = newPurpose;
	}

	public AdresseDto getExcerptsDeliveryAddress() {
		return excerptsDeliveryAddress;
	}

	public void setExcerptsDeliveryAddress(AdresseDto excerptsDeliveryAddress) {
		this.excerptsDeliveryAddress = excerptsDeliveryAddress;
	}

	public AdresseDto getExcerptsBillingAddress() {
		return excerptsBillingAddress;
	}

	public void setExcerptsBillingAddress(AdresseDto excerptsBillingAddress) {
		this.excerptsBillingAddress = excerptsBillingAddress;
	}

	public Date getZefixUpdateDate() {
		return zefixUpdateDate;
	}

	public void setZefixUpdateDate(Date zefixUpdateDate) {
		this.zefixUpdateDate = zefixUpdateDate;
	}

	public HrMutationZefixCompareDto getOrgInfoContainer() {
		return orgInfoContainer;
	}

	public void setOrgInfoContainer(HrMutationZefixCompareDto orgInfoContainer) {
		this.orgInfoContainer = orgInfoContainer;
	}

	public int getExcerptsNum() {
		return excerptsNum;
	}

	public void setExcerptsNum(int excerptsNum) {
		this.excerptsNum = excerptsNum;
	}

	public int getExcerptsNumPrelim() {
		return excerptsNumPrelim;
	}

	public void setExcerptsNumPrelim(int excerptsNumPrelim) {
		this.excerptsNumPrelim = excerptsNumPrelim;
	}

	public String getRevCompanyName() {
		return revCompanyName;
	}

	public void setRevCompanyName(String revCompanyName) {
		this.revCompanyName = revCompanyName;
	}

	public Integer getRevPreviousSeatBfsNr() {
		return revPreviousSeatBfsNr;
	}

	public void setRevPreviousSeatBfsNr(Integer revPreviousSeatBfsNr) {
		this.revPreviousSeatBfsNr = revPreviousSeatBfsNr;
	}

	public String getRevPreviousSeatCity() {
		return revPreviousSeatCity;
	}

	public void setRevPreviousSeatCity(String revPreviousSeatCity) {
		this.revPreviousSeatCity = revPreviousSeatCity;
	}

	public String getRevPreviousSeatPolCommunity() {
		return revPreviousSeatPolCommunity;
	}

	public void setRevPreviousSeatPolCommunity(String revPreviousSeatPolCommunity) {
		this.revPreviousSeatPolCommunity = revPreviousSeatPolCommunity;
	}

	public String getRevPreviousSeatCanton() {
		return revPreviousSeatCanton;
	}

	public void setRevPreviousSeatCanton(String revPreviousSeatCanton) {
		this.revPreviousSeatCanton = revPreviousSeatCanton;
	}

	public Integer getRevNewSeatBfsNr() {
		return revNewSeatBfsNr;
	}

	public void setRevNewSeatBfsNr(Integer revNewSeatBfsNr) {
		this.revNewSeatBfsNr = revNewSeatBfsNr;
	}

	public String getRevNewSeatCity() {
		return revNewSeatCity;
	}

	public void setRevNewSeatCity(String revNewSeatCity) {
		this.revNewSeatCity = revNewSeatCity;
	}

	public String getRevNewSeatPolCommunity() {
		return revNewSeatPolCommunity;
	}

	public void setRevNewSeatPolCommunity(String revNewSeatPolCommunity) {
		this.revNewSeatPolCommunity = revNewSeatPolCommunity;
	}

	public String getRevNewSeatCanton() {
		return revNewSeatCanton;
	}

	public void setRevNewSeatCanton(String revNewSeatCanton) {
		this.revNewSeatCanton = revNewSeatCanton;
	}

	public String getDissLeavingPartnerGivenName() {
		return dissLeavingPartnerGivenName;
	}

	public void setDissLeavingPartnerGivenName(String dissLeavingPartnerGivenName) {
		this.dissLeavingPartnerGivenName = dissLeavingPartnerGivenName;
	}

	public String getDissLeavingPartnerFamilyName() {
		return dissLeavingPartnerFamilyName;
	}

	public void setDissLeavingPartnerFamilyName(String dissLeavingPartnerFamilyName) {
		this.dissLeavingPartnerFamilyName = dissLeavingPartnerFamilyName;
	}

	public Date getDissLeavingPartnerBirthday() {
		return dissLeavingPartnerBirthday;
	}

	public void setDissLeavingPartnerBirthday(Date dissLeavingPartnerBirthday) {
		this.dissLeavingPartnerBirthday = dissLeavingPartnerBirthday;
	}

	public GeschaftsrolleDto getDissNewOwner() {
		return dissNewOwner;
	}

	public void setDissNewOwner(GeschaftsrolleDto dissNewOwner) {
		this.dissNewOwner = dissNewOwner;
	}

	public String getDissNewCompanyName() {
		return dissNewCompanyName;
	}

	public void setDissNewCompanyName(String dissNewCompanyName) {
		this.dissNewCompanyName = dissNewCompanyName;
	}

	public List<AdresseDto> getExistingAddresses() {
		return existingAddresses;
	}

	public void setExistingAddresses(List<AdresseDto> existingAddresses) {
		this.existingAddresses = existingAddresses;
	}

	public HrMutationEditingState getEditingState() {
		return editingState;
	}

	public void setEditingState(HrMutationEditingState editingState) {
		this.editingState = editingState;
	}

	public ProzessStatusEnum getStatus() {
		return status;
	}

	public void setStatus(ProzessStatusEnum status) {
		this.status = status;
	}
}
