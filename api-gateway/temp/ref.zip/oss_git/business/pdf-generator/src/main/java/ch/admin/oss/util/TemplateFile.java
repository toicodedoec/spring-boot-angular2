/*
 * TemplateFile
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.util;

/**
 * @author hha
 */
public class TemplateFile {

	private String fileName;
	private String field;

	private TemplateFile(String fileName, String field) {
		this.fileName = fileName;
		this.field = field;
	}

	public static TemplateFile get(String fileName) {
		return TemplateFile.get(fileName, null);
	}

	public static TemplateFile get(String fileName, String field) {
		return new TemplateFile(fileName, field);
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

}