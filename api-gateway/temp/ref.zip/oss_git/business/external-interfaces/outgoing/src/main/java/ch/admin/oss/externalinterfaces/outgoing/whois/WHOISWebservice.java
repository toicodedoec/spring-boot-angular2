/*
 * WHOISWebservice
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.whois;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.UnknownHostException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.whois.WhoisClient;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * @author tdm
 */
@Service
public class WHOISWebservice implements IWHOISWebservice {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(WHOISWebservice.class);

	@Value("${whois.server.port}")
	private int port;

	@Value("${whois.server.host}")
	private String host;

	@Override
	public WHOISCheckResultEnum checkDomain(String domainName) {

		InetAddress address = null;
		WhoisClient whois = null;

		WHOISCheckResultEnum result = WHOISCheckResultEnum.UNEXPECTED_ERROR;

		try {
			if (StringUtils.isBlank(domainName)) {
				LOGGER.error("Input domainName is null");
				return result;
			}
			whois = new WhoisClient();
			// We want to timeout if a response takes longer than 60 seconds
			whois.setDefaultTimeout(60000);

			address = InetAddress.getByName(host);

			String checkResult = null;

			String proxyIp = System.getProperty("http.proxyHost");
			if (StringUtils.isNotBlank(proxyIp)) {
				int proxyPort = Integer.valueOf(System.getProperty("http.proxyPort"));
				SocketAddress addr = new InetSocketAddress(proxyIp, proxyPort);
				Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
				whois.setProxy(proxy);
			}

			whois.setDefaultPort(Integer.valueOf(port));
			whois.connect(address);
			checkResult = whois.query(domainName);

			if (checkResult != null) {
				result = WHOISCheckResultEnum.getFromCode(checkResult.split(":")[0]);
			}
		} catch (UnknownHostException uhe) {
			LOGGER.error("No IP address for the host (" + host + ") could be found", uhe);
			return result;
		} catch (IOException ioe) {
			LOGGER.error("There is an technical Exception occurring", ioe);
			return result;
		} finally {
			try {
				if (whois != null && whois.isConnected()) {
					whois.disconnect();
				}
			} catch (IOException ioe) {
				LOGGER.error("There is an technical Exception occurring", ioe);
			}
		}
		return result;
	}
}
