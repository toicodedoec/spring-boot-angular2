/*
 * UvgServiceEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.uvg.endpoint;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.groups.Default;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import ch.admin.oss.common.AbstractProzessEndpoint;
import ch.admin.oss.common.CommonAddress;
import ch.admin.oss.common.ExceptionHandlingController;
import ch.admin.oss.common.UvgKontaktAdresse;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.UvgAnmeldungEntity;
import ch.admin.oss.domain.UvgGesellschafterEntity;
import ch.admin.oss.portal.endpoint.BrancheDto;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.uvg.service.IUVGService;

/**
 * 
 * @author hhu
 *
 */
@CrossOrigin
@RestController
@RequestMapping("/private/ext/uvg")
public class UvgServiceEndpoint extends AbstractProzessEndpoint<UvgAnmeldungDto> {
	
	public static final String UVG_ANMELDUNG = "UvgAnmeldung";

	@Autowired
	private IUVGService uvgService;

	@Override
	protected boolean isProcessDoneExternal(PflichtenabklaerungenEntity pflich) {
		return pflich != null && pflich.isAnmeldungUVG();
	}

	@Override
	public UvgAnmeldungDto getProcessByOrgId(@PathVariable long orgId) {
		UvgAnmeldungEntity entity = uvgService.getByOrganisationId(orgId);
		UvgAnmeldungDto dto = mapper.map(entity, UvgAnmeldungDto.class);

		OrganisationEntity organisation = entity.getProzess().getOrganisation();
		if (CollectionUtils.isNotEmpty(organisation.getBranches())) {
			dto.getProzess().getOrganisation().setBranches(
				organisation.getBranches()
				.stream()
				.map(b -> new BrancheDto(b, SecurityUtil.currentUser().getLanguagePreference()))
				.collect(Collectors.toList())
			);
		}
		dto.getProzess().getOrganisation().setAccessFromOutsideFlow(true);
		dto.getProzess().getOrganisation().setImportData(importHRRegistrationFromZefix(organisation));
		return dto;
	}

	@Override
	public ResponseEntity<?> update(@RequestBody UvgAnmeldungDto dto) {
		UvgAnmeldungEntity entity = mapDtoToEntity(dto);
		return ResponseEntity.ok(mapper.map(uvgService.updateProcess(entity), UvgAnmeldungDto.class));
	}

	@Override
	public ResponseEntity<?> complete(@RequestBody
		@Validated({CommonAddress.class, UvgKontaktAdresse.class, Default.class}) UvgAnmeldungDto dto) {
		List<String> errors = validateBusiness(dto);
		if (CollectionUtils.isNotEmpty(errors)) {
			return ResponseEntity
				.status(HttpStatus.PRECONDITION_FAILED)
				.body(ExceptionHandlingController.errorFor(StringUtils.join(errors, ". ")));
		}
		UvgAnmeldungEntity entity = mapDtoToEntity(dto);
		return ResponseEntity.ok(mapper.map(uvgService.completeProcess(entity), UvgAnmeldungDto.class));
	}

	/*
	 * Validate UVG business before completing the process. Returns a list of error message if any.
	 */
	private List<String> validateBusiness(UvgAnmeldungDto dto) {
		List <String> errors = new ArrayList<>();
		if (dto.isAngestelltePartner()) {
			if (dto.getPartnerName() == null || dto.getPartnerLohnsumme() == null) {
				errors.add("Parter name and lohnsumme are required");

			}
			if (dto.getPartnerLohnsumme().compareTo(BigDecimal.ZERO) <= 0) {
				errors.add("Parter lohnsumme must be greater than 0");
			}
		}
		if (dto.isAngestellteFamilie()) {
			if (dto.getAngehoerigeAnzahl() == null || dto.getAngehoerigeLohnsumme() == null) {
				errors.add("Angehoerige anzahl and lohnsumme are required");
			}
			if (dto.getAngehoerigeLohnsumme().compareTo(BigDecimal.ZERO) <= 0) {
				errors.add("Angehoerige lohnsumme must be greater than 0");
			}
		}
		return errors;
	}

	@Override
	public ResponseEntity<?> lock(@PathVariable long orgId) {
		UvgAnmeldungEntity uvgAnmeldung = uvgService.getByOrganisationId(orgId);
		return ResponseEntity.ok(mapper.map(uvgService.lockProcess(uvgAnmeldung), UvgAnmeldungDto.class));
	}

	@Override
	public ResponseEntity<?> sign(@PathVariable long orgId) {
		throw new UnsupportedOperationException("Sign UVG process is not supported.");
	}

	@Override
	public ResponseEntity<?> relock(@PathVariable long orgId) {
		throw new UnsupportedOperationException("Relock UVG process is not supported.");
	}

	@RequestMapping(value = "/document/{orgId}", method = RequestMethod.GET)
	public ResponseEntity<?> downloadDocument(@PathVariable long orgId) {
		return download(uvgService.downloadDocument(orgId));
	}

	private UvgAnmeldungEntity mapDtoToEntity(UvgAnmeldungDto dto) {
		UvgAnmeldungEntity entity = uvgService.getByOrganisationId(dto.getProzess().getOrganisation().getId());
		entity.getVersicherer().clear();
		mapper.map(dto, entity, UVG_ANMELDUNG);

		// Map Gesellschafter
		Set<UvgGesellschafterDto> gesellschafterDtos = dto.getGesellschafters();
		Set<Long> existingGesellschafterPersonIds = new HashSet<>();
		gesellschafterDtos.forEach(gesellschafterDto -> {
			Optional<UvgGesellschafterEntity> gesellschafterOptional = entity.getGesellschafters().stream()
				.filter(item -> item.getPerson().getId().equals(gesellschafterDto.getPerson().getId()))
				.findFirst();
			UvgGesellschafterEntity gesellschafterEntity;
			if (gesellschafterOptional.isPresent()) {
				gesellschafterEntity = gesellschafterOptional.get();
			} else {
				gesellschafterEntity = new UvgGesellschafterEntity();
				gesellschafterEntity.setPerson(mapper.map(gesellschafterDto.getPerson(), PersonEntity.class));
				entity.getGesellschafters().add(gesellschafterEntity);
			}
			gesellschafterEntity.setUvgAnmeldung(entity);
			gesellschafterEntity.setLohnsumme(gesellschafterDto.getLohnsumme());
			existingGesellschafterPersonIds.add(gesellschafterDto.getPerson().getId());
		});
		entity.getGesellschafters().removeIf(item -> !existingGesellschafterPersonIds.contains(item.getPerson().getId()));
		return entity;
	}

	@Override
	public ResponseEntity<?> interrupt(@RequestBody UvgAnmeldungDto dto) {
		UvgAnmeldungEntity entity = mapDtoToEntity(dto);
		return ResponseEntity.ok(mapper.map(uvgService.updateProcess(entity), UvgAnmeldungDto.class));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected ProzessStatusEnum getProcessStatus(long orgId) {
		return uvgService.getProcessStatusByOrgId(orgId);
	}

}
