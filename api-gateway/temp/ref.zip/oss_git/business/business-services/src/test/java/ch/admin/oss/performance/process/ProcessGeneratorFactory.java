/*
 * GenerateProcessFactory
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.performance.process;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ch.admin.oss.ahv.service.IAhvService;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.domain.AhvAnmeldungEntity;
import ch.admin.oss.domain.HrAnmeldungEntity;
import ch.admin.oss.domain.MwstAnmeldungEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.UvgAnmeldungEntity;
import ch.admin.oss.hr.service.IHRService;
import ch.admin.oss.mwst.service.IMWSTService;
import ch.admin.oss.uvg.service.IUVGService;

/**
 * @author hha
 */
@Component
public class ProcessGeneratorFactory {

	@Autowired
	private ProcessGenerator<HrAnmeldungEntity, IHRService> hrGenerator;
	@Autowired
	private ProcessGenerator<UvgAnmeldungEntity, IUVGService> uvgGenerator;
	@Autowired
	private ProcessGenerator<AhvAnmeldungEntity, IAhvService> ahvGenerator;
	@Autowired
	private ProcessGenerator<MwstAnmeldungEntity, IMWSTService> mwstGenerator;

	public OrganisationEntity generate(OrganisationEntity organisation, ProzessTypEnum prozessTyp) {
		switch (prozessTyp) {
			case AHV:
				return ahvGenerator.generate(organisation);
			case HR:
				return hrGenerator.generate(organisation);
			case MWST:
				return mwstGenerator.generate(organisation);
			case UVG:
				return uvgGenerator.generate(organisation);
			default:
				return organisation;
		}
	}
	
}
