/*
 * OssPdfGenerateTechnicalException
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss;

/**
 * @author coh
 *
 */
public class OssPdfGenerateTechnicalException extends RuntimeException {

	private static final long serialVersionUID = 988607157133472550L;

	public OssPdfGenerateTechnicalException(String message, Throwable e) {
		super(message, e);
	}

	public OssPdfGenerateTechnicalException(String message) {
		super(message);
	}
}
