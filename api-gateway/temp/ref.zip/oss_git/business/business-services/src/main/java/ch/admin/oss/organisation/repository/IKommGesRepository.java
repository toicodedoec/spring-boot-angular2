package ch.admin.oss.organisation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.stereotype.Repository;

import ch.admin.oss.domain.KommGesEntity;

/**
 * 
 * @author hhu
 *
 */
@Repository
public interface IKommGesRepository extends JpaRepository<KommGesEntity, Long>, QueryDslPredicateExecutor<KommGesEntity>{

}
