/*
 * WebHttpSessionConfig
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss;

import org.springframework.context.annotation.Configuration;
import org.springframework.session.jdbc.config.annotation.web.http.EnableJdbcHttpSession;

import ch.admin.oss.common.CommonHttpSessionConfig;

/**
 * Spring-Session configuration. No datasource is needed here as it will automatically pick up the one configured in
 * "business-service".
 * 
 * @author phd
 */
@Configuration
@EnableJdbcHttpSession(tableName = "T_SPRING_SESSION")
public class BusinessServiceEndpointHttpSessionConfig extends CommonHttpSessionConfig {

	
}
