/*
 * AngestellteBuchhaltungBVGDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

/**
 * @author hhg
 *
 */
public class AngestellteBuchhaltungBVGDto {
	
	private AngestellteDto gl;
	private AngestellteDto ang;
	private AngestellteDto family;
	private AngestellteDto partner;
	private String bvg;
	private String begrundung;
	private String buchhaltung;
	
	public AngestellteBuchhaltungBVGDto(AngestellteDto manager, AngestellteDto employee, AngestellteDto family, AngestellteDto partner, String bvg, String begrundung, String buchhaltung) {
		this.gl = manager;
		this.ang = employee;
		this.family = family;
		this.partner = partner;
		this.bvg = bvg;
		this.begrundung = begrundung;
		this.buchhaltung = buchhaltung;
	}

	public AngestellteDto getGl() {
		return gl;
	}

	public AngestellteDto getAng() {
		return ang;
	}

	public String getBvg() {
		return bvg;
	}

	public void setGl(AngestellteDto gl) {
		this.gl = gl;
	}

	public void setAng(AngestellteDto ang) {
		this.ang = ang;
	}

	public void setBvg(String bvg) {
		this.bvg = bvg;
	}

	public AngestellteDto getFamily() {
		return family;
	}

	public AngestellteDto getPartner() {
		return partner;
	}

	public String getBuchhaltung() {
		return buchhaltung;
	}

	public String getBegrundung() {
		return begrundung;
	}
}
