/*
 * BerufDetailInitDataDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import java.util.ArrayList;
import java.util.List;

import ch.admin.oss.portal.endpoint.BrancheDto;

/**
 * @author xdg
 */
public class BerufDetailInitDataDto {
	List<BerufAdminDto> berufe = new ArrayList<BerufAdminDto>();
	List<BrancheDto> brachen = new ArrayList<BrancheDto>();

	public List<BerufAdminDto> getBerufe() {
		return berufe;
	}

	public void setBerufe(List<BerufAdminDto> berufe) {
		this.berufe = berufe;
	}

	public List<BrancheDto> getBrachen() {
		return brachen;
	}

	public void setBrachen(List<BrancheDto> brachen) {
		this.brachen = brachen;
	}

}
