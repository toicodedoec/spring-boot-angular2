/*
 * HrMutationAbstractDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.endpoint;

public abstract class HrMutationAbstractDto {
	private long orgId;
	private long hrMutationId;
	private int hrMutationVersion;

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public long getHrMutationId() {
		return hrMutationId;
	}

	public void setHrMutationId(long hrMutationId) {
		this.hrMutationId = hrMutationId;
	}

	public int getHrMutationVersion() {
		return hrMutationVersion;
	}

	public void setHrMutationVersion(int hrMutationVersion) {
		this.hrMutationVersion = hrMutationVersion;
	}
}
