/*
 * PersonEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;
import org.hibernate.annotations.FetchProfile.FetchOverride;
import org.hibernate.annotations.FetchProfiles;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import ch.admin.oss.common.enums.NatTypEnum;
import ch.admin.oss.validator.OSSSytemValidator;

/**
 *  
 * @author coh
 */
@FetchProfiles({
	@FetchProfile(fetchOverrides = {@FetchOverride(association = "wohnadresse", entity = PersonEntity.class, mode = FetchMode.JOIN)}, name = "person-with-wohnadresse"),
	@FetchProfile(fetchOverrides = {
			@FetchOverride(association = "nationalitaetens", entity = PersonEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "geschlecht", entity = PersonEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "anrede", entity = PersonEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "heimatortes", entity = PersonEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "wohnadresse", entity = PersonEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "auslaenderAusweis", entity = PersonEntity.class, mode = FetchMode.JOIN)			
		}, 
		name = "full-person-except-zivilstand-teilhaber"),
})
@Audited
@Entity
@Table(name = "T_PERSON")
public class PersonEntity extends AbstractOSSEntity {

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@Fetch(FetchMode.SUBSELECT)
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name="T_PERSON_NATION",
		joinColumns=
			@JoinColumn(name="LN_PERSON", referencedColumnName="PK", foreignKey = @ForeignKey(name = "FK_PERSON_NATION_PERSON")),
		inverseJoinColumns=
			@JoinColumn(name="LN_NATION", referencedColumnName="PK", foreignKey = @ForeignKey(name = "FK_PERSON_NATION_NATION")),
		uniqueConstraints={
			@UniqueConstraint(name="UK_PERSON_NATION", columnNames = {"LN_PERSON", "LN_NATION"})
		})
	private Set<CodeWertEntity> nationalitaetens = new HashSet<>();
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "person")
	private AhvTeilhaberEntity teilhaber;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ZIVILSTAND", foreignKey = @ForeignKey(name="FK_PERSON_CODE_WERT_2"))
	private CodeWertEntity zivilstand;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@NotNull(groups = {OSSSytemValidator.class})
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_GESCHLECHT", foreignKey = @ForeignKey(name="FK_PERSON_CODE_WERT_3"))
	private CodeWertEntity geschlecht;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@NotNull(groups = {OSSSytemValidator.class})
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ANREDE", foreignKey = @ForeignKey(name="FK_PERSON_CODE_WERT_4"))
	private CodeWertEntity anrede;
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "person", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<PersonHeimatortEntity> heimatortes = new HashSet<>();
	
	@NotNull(groups = {OSSSytemValidator.class})
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_WOHNADRESSE", foreignKey = @ForeignKey(name = "FK_PERSON_ADRESSE"))
	private AdresseEntity wohnadresse;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_AUSLAENDER_AUSWEIS", foreignKey = @ForeignKey(name="FK_PERSON_CODE_WERT_5"))
	private CodeWertEntity auslaenderAusweis;

	@Column(name = "EINREISE_DATUM")
	private LocalDate einreisedatum;
	
	@Column(name = "TITEL")
	private String titel;
	
	@Column(name = "FAMILIENNAME")
	private String familienname;
	
	@Column(name = "LEDIGNAME")
	private String ledigname;
	
	@Column(name = "VORNAME")
	private String vorname;
	
	@Column(name = "RUFNAME")
	private String rufname;
	
	@Column(name = "VORNAMENLISTE")
	private String vornamenliste;
	
	@Column(name = "GEBURTSDATUM")
	private LocalDate geburtsdatum;
	
	@Column(name = "AHVNUMMER")
	private String ahvNummer;

	@Column(name = "NAT_TYPE")
	@Enumerated(EnumType.STRING)
	private NatTypEnum natType;

	@Column(name = "STEUERN_USA", length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean steuernUSA;

	public Set<CodeWertEntity> getNationalitaetens() {
		return nationalitaetens;
	}

	public void setNationalitaetens(Set<CodeWertEntity> nationalitaetens) {
		this.nationalitaetens = nationalitaetens;
	}

	public CodeWertEntity getZivilstand() {
		return zivilstand;
	}

	public void setZivilstand(CodeWertEntity zivilstand) {
		this.zivilstand = zivilstand;
	}

	public CodeWertEntity getGeschlecht() {
		return geschlecht;
	}

	public void setGeschlecht(CodeWertEntity geschlecht) {
		this.geschlecht = geschlecht;
	}

	public CodeWertEntity getAnrede() {
		return anrede;
	}

	public void setAnrede(CodeWertEntity anrede) {
		this.anrede = anrede;
	}

	public Set<PersonHeimatortEntity> getHeimatortes() {
		return heimatortes;
	}

	public void setHeimatortes(Set<PersonHeimatortEntity> heimatortes) {
		this.heimatortes = heimatortes;
	}

	public AdresseEntity getWohnadresse() {
		return wohnadresse;
	}

	public void setWohnadresse(AdresseEntity wohnadresse) {
		this.wohnadresse = wohnadresse;
	}

	public String getTitel() {
		return titel;
	}

	public void setTitel(String titel) {
		this.titel = titel;
	}

	public String getFamilienname() {
		return familienname;
	}

	public void setFamilienname(String familienname) {
		this.familienname = familienname;
	}

	public String getLedigname() {
		return ledigname;
	}

	public void setLedigname(String ledigname) {
		this.ledigname = ledigname;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getRufname() {
		return rufname;
	}

	public void setRufname(String rufname) {
		this.rufname = rufname;
	}

	public String getVornamenliste() {
		return vornamenliste;
	}

	public void setVornamenliste(String vornamenliste) {
		this.vornamenliste = vornamenliste;
	}

	public LocalDate getGeburtsdatum() {
		return geburtsdatum;
	}

	public void setGeburtsdatum(LocalDate geburtsdatum) {
		this.geburtsdatum = geburtsdatum;
	}

	public String getAhvNummer() {
		return ahvNummer;
	}

	public void setAhvNummer(String ahvNummer) {
		this.ahvNummer = ahvNummer;
	}

	public CodeWertEntity getAuslaenderAusweis() {
		return auslaenderAusweis;
	}

	public void setAuslaenderAusweis(CodeWertEntity auslaenderAusweis) {
		this.auslaenderAusweis = auslaenderAusweis;
	}

	public LocalDate getEinreisedatum() {
		return einreisedatum;
	}

	public void setEinreisedatum(LocalDate einreisedatum) {
		this.einreisedatum = einreisedatum;
	}

	public NatTypEnum getNatType() {
		return natType;
	}

	public void setNatType(NatTypEnum natType) {
		this.natType = natType;
	}

	public Boolean getSteuernUSA() {
		return steuernUSA;
	}

	public void setSteuernUSA(Boolean steuernUSA) {
		this.steuernUSA = steuernUSA;
	}

	public AhvTeilhaberEntity getTeilhaber() {
		return teilhaber;
	}

	public void setTeilhaber(AhvTeilhaberEntity teilhaber) {
		this.teilhaber = teilhaber;
	}
	
	public void copyFrom(PersonEntity entity){
		setAhvNummer(entity.getAhvNummer());
		setAnrede(entity.getAnrede());
		setAuslaenderAusweis(entity.getAuslaenderAusweis());
		setEinreisedatum(entity.getEinreisedatum());
		setFamilienname(entity.getFamilienname());
		setGeburtsdatum(entity.getGeburtsdatum());
		setGeschlecht(entity.getGeschlecht());
		setLedigname(entity.getLedigname());
		setNatType(entity.getNatType());
		setRufname(entity.getRufname());
		setSteuernUSA(entity.getSteuernUSA());
		setTitel(entity.getTitel());
		setVorname(entity.getVorname());
		setVornamenliste(entity.getVornamenliste());
		wohnadresse.copyFrom(entity.getWohnadresse());
		
		getHeimatortes().clear();
		getHeimatortes().addAll(new HashSet<>(entity.getHeimatortes()));
		getHeimatortes().stream().forEach(h -> {
			h.setId(null);
			h.setPerson(this);
		});
		
		getNationalitaetens().clear();
		getNationalitaetens().addAll(new HashSet<>(entity.getNationalitaetens()));
	}
}
