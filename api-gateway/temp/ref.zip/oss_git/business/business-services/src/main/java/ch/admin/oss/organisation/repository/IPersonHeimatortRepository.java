package ch.admin.oss.organisation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.stereotype.Repository;

import ch.admin.oss.domain.PersonHeimatortEntity;

@Repository
public interface IPersonHeimatortRepository extends JpaRepository<PersonHeimatortEntity, Long>, QueryDslPredicateExecutor<PersonHeimatortEntity>{

}
