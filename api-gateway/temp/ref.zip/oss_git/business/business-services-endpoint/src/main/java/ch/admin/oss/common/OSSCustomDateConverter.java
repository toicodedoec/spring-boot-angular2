/*
 * OSSCustomDateConverter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.time.LocalDate;
import java.util.Date;

import org.dozer.DozerConverter;

import ch.admin.oss.util.OSSDateUtil;

/**
 * @author hhg
 *
 */
public class OSSCustomDateConverter extends DozerConverter<Date, LocalDate> {

	public OSSCustomDateConverter() {
		super(Date.class, LocalDate.class);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public LocalDate convertTo(Date source, LocalDate destination) {
		return OSSDateUtil.toLocalDate(source);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Date convertFrom(LocalDate source, Date destination) {
		return OSSDateUtil.toDate(source);
	}

}
