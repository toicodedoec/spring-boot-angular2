package ch.admin.oss.admin.criteria;

import ch.admin.oss.common.enums.AktivFilterEnum;

/**
 * 
 * @author hhu
 *
 */
public class PrivatversichererCriteria extends AbstractPaginationCriteria {
	private AktivFilterEnum status;
	private String name;
	
	public AktivFilterEnum getStatus() {
		return status;
	}
	public void setStatus(AktivFilterEnum status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
