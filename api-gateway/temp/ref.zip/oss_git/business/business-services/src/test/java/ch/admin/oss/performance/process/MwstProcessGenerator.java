/*
 * GenerateDataTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.performance.process;

import org.springframework.stereotype.Component;

import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.domain.MwstAnmeldungEntity;
import ch.admin.oss.mwst.service.IMWSTService;

/**
 * @author hha
 */
@Component
public class MwstProcessGenerator extends ProcessGenerator<MwstAnmeldungEntity, IMWSTService> {

	@Override
	public MwstAnmeldungEntity generate(MwstAnmeldungEntity entity) {
		return service.completeProcess(entity);
	}

	@Override
	protected ProzessTypEnum getProcessType() {
		return ProzessTypEnum.MWST;
	}

}
