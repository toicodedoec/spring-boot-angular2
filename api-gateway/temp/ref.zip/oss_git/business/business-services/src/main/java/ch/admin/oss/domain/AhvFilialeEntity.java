/*
 * AhvFilialeEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.math.BigDecimal;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_AHV_FILIALE")
public class AhvFilialeEntity extends AbstractOSSEntity {

	@Column(name = "ANGESTELLTE")
	private Long angestellte;

	@Column(name = "LOHN_SUMME")
	private BigDecimal lohnSumme;

	@Column(name = "SEIT")
	private LocalDate seit;

	@NotNull
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_GESCHAEFTSSTELLE", foreignKey = @ForeignKey(name="FK_AHV_GESCHAEFTSSTELLE"))
	private GeschaeftsstelleEntity geschaeftsstelle;

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_AHV_ANMELDUNG", foreignKey = @ForeignKey(name="FK_AHV_FILIALE_ANMELDUNG"))
	private AhvAnmeldungEntity ahvAnmeldung;
	
	public AhvFilialeEntity() {
		// default constructor
	}

	public AhvFilialeEntity(AhvAnmeldungEntity ahvAnmeldung, GeschaeftsstelleEntity geschaeftsstelle) {
		this.ahvAnmeldung = ahvAnmeldung;
		this.geschaeftsstelle = geschaeftsstelle;
	}

	public Long getAngestellte() {
		return angestellte;
	}

	public void setAngestellte(Long angestellte) {
		this.angestellte = angestellte;
	}

	public BigDecimal getLohnSumme() {
		return lohnSumme;
	}

	public void setLohnSumme(BigDecimal lohnSumme) {
		this.lohnSumme = lohnSumme;
	}

	public LocalDate getSeit() {
		return seit;
	}

	public void setSeit(LocalDate seit) {
		this.seit = seit;
	}

	public GeschaeftsstelleEntity getGeschaeftsstelle() {
		return geschaeftsstelle;
	}

	public void setGeschaeftsstelle(GeschaeftsstelleEntity geschaeftsstelle) {
		this.geschaeftsstelle = geschaeftsstelle;
	}

	public AhvAnmeldungEntity getAhvAnmeldung() {
		return ahvAnmeldung;
	}

	public void setAhvAnmeldung(AhvAnmeldungEntity ahvAnmeldung) {
		this.ahvAnmeldung = ahvAnmeldung;
	}
}
