/*
 * TemplateDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.util;

import java.util.List;

/**
 * @author hha
 */
public class TemplateDto<T> {

	private T data;
	private List<TemplateFile> files;
	private int format;
	private String language;
	private String watermark;

	public TemplateDto(T data, List<TemplateFile> files, int format, String language) {
		this.data = data;
		this.files = files;
		this.format = format;
		this.language = language;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public List<TemplateFile> getFiles() {
		return files;
	}

	public void setFiles(List<TemplateFile> files) {
		this.files = files;
	}

	public int getFormat() {
		return format;
	}

	public void setFormat(int format) {
		this.format = format;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getWatermark() {
		return watermark;
	}

	public void setWatermark(String watermark) {
		this.watermark = watermark;
	}

}
