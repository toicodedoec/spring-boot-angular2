/*
 * FunktionRecheDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.SupportedLanguage;

/**
 * @author hha
 */
public class TextTranslationDto extends AbstractOSSDto {

	@NotNull
	private SupportedLanguage language;

	@NotNull
	private String text;

	public SupportedLanguage getLanguage() {
		return language;
	}

	public void setLanguage(SupportedLanguage language) {
		this.language = language;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

}
