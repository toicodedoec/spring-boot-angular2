/*
 * MockedMailUtil
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import org.slf4j.Logger;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.util.IMailUtil;
import ch.admin.oss.util.MailMessage;

/**
 * @author phd
 */
@Profile(CommonConstants.PROFILE_TEST)
@Component
public class MockedMailUtil implements IMailUtil {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MockedMailUtil.class);

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void send(MailMessage message) {
		LOGGER.info("Mail sent to {}, from {} with subject {}", message.getTo(), message.getFrom(),
			message.getSubject());
	}
}
