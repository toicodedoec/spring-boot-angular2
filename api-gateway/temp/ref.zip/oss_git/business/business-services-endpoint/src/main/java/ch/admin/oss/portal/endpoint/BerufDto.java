/*
 * BerufDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.endpoint;

import java.util.Optional;

import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.HREPflichtEnum;
import ch.admin.oss.domain.BerufEntity;
import ch.admin.oss.domain.TextTranslationEntity;

/**
 * @author hhg
 */
public class BerufDto extends AbstractGroupDto<BerufDto> {

	private boolean handel;
	private String code;
	private String text;
	private BrancheDto branche;
	private int pos;
	private HREPflichtEnum hrePflicht;

	public BerufDto() {
		// default constructor
	}

	public BerufDto(BerufEntity beruf, SupportedLanguage language) {
		this.setId(beruf.getId());
		this.handel = beruf.isHandel();
		this.code = beruf.getCode();
		this.pos = beruf.getPos();
		this.hrePflicht = beruf.getHrePflicht();
		Optional<TextTranslationEntity> textTranslation = beruf.getStandardText().getTranslations().stream()
			.filter(t -> t.getLanguage() == language).findFirst();
		if (textTranslation.isPresent()) {
			this.text = textTranslation.get().getText();
		}
		if (beruf.getBranche() != null) {
			BrancheDto branche = new BrancheDto();
			branche.setId(beruf.getBranche().getId());
			branche.setCode(beruf.getBranche().getCode());
			this.branche = branche;
		}
	}

	public boolean isHandel() {
		return handel;
	}

	public void setHandel(boolean handel) {
		this.handel = handel;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public BrancheDto getBranche() {
		return branche;
	}

	public void setBranche(BrancheDto branche) {
		this.branche = branche;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public HREPflichtEnum getHrePflicht() {
		return hrePflicht;
	}

	public void setHrePflicht(HREPflichtEnum hrePflicht) {
		this.hrePflicht = hrePflicht;
	}
}
