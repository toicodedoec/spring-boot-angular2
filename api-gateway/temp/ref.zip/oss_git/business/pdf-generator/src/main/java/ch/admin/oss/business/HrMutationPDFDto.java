/*
 * HrMutationPDFDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;

/**
 * @author coh
 *
 */
public class HrMutationPDFDto {

	private String oldCompanyName;
	private CompanyDto organisation;
	private AddressDto oldDomicile;
	
	private boolean taskName;
	private String newCompanyName;
	
	private boolean taskAddress;
	private AddressDto newDomicile;
	
	private boolean taskPurpose;
	private String newPurpose;
	
	private List<HrMutationNaturalPersonDto> addNaturalPersons = new ArrayList<>();
	private List<HrMutationLegalPersonDto> addLegalPersons = new ArrayList<>();
	
	private List<HrMutationNaturalPersonDto> updateNaturalPersons = new ArrayList<>();
	private List<HrMutationLegalPersonDto> updateLegalPersons = new ArrayList<>();
	
	private List<HrMutationNaturalPersonDto> deleteNaturalPersons = new ArrayList<>();
	private List<HrMutationLegalPersonDto> deleteLegalPersons = new ArrayList<>();
	
	private boolean taskDissolution;
	private String dissLeavingPartnerGivenName;
	private String dissLeavingPartnerFamilyName;
	private LocalDate dissLeavingPartnerBirthday;
	private HrMutationNaturalPersonDto dissNewOwner;
	private String dissNewCompanyName;
	
	private boolean taskRevision;
	private String revCompanyName;
	private String revPreviousSeatCity;
	private String revPreviousSeatPolCommunity;
	private String revPreviousSeatCanton;
	private String revNewSeatCity;
	private String revNewSeatPolCommunity;
	private String revNewSeatCanton;
	
	private boolean taskExcerpts;
	private AddressDto excerptsDeliveryAddress;
	private AddressDto excerptsBillingAddress;
	private int excerptsNum = 0;
	private int excerptsNumPrelim = 0;
	
	private String signingHintForLegalForm;
	private String prozessUid;
	private LocalDateTime dateTime = LocalDateTime.now();
	private String signDocTitle;
	private String addMoreFormsIfNecessary;
	private HrAmtDto amt;
	
	private List<HrMutationNaturalPersonDto> addUpdateSignatories = new ArrayList<>();

	public String getOldCompanyName() {
		return oldCompanyName;
	}

	public void setOldCompanyName(String oldCompanyName) {
		this.oldCompanyName = oldCompanyName;
	}

	public CompanyDto getOrganisation() {
		return organisation;
	}

	public void setOrganisation(CompanyDto organisation) {
		this.organisation = organisation;
	}

	public AddressDto getOldDomicile() {
		return oldDomicile;
	}

	public void setOldDomicile(AddressDto oldDomicile) {
		this.oldDomicile = oldDomicile;
	}

	public boolean isTaskName() {
		return taskName;
	}

	public void setTaskName(boolean taskName) {
		this.taskName = taskName;
	}

	public String getNewCompanyName() {
		return newCompanyName;
	}

	public void setNewCompanyName(String newCompanyName) {
		this.newCompanyName = newCompanyName;
	}

	public boolean isTaskAddress() {
		return taskAddress;
	}

	public void setTaskAddress(boolean taskAddress) {
		this.taskAddress = taskAddress;
	}

	public AddressDto getNewDomicile() {
		return newDomicile;
	}

	public void setNewDomicile(AddressDto newDomicile) {
		this.newDomicile = newDomicile;
	}

	public boolean isTaskPurpose() {
		return taskPurpose;
	}

	public void setTaskPurpose(boolean taskPurpose) {
		this.taskPurpose = taskPurpose;
	}

	public String getNewPurpose() {
		return newPurpose;
	}

	public void setNewPurpose(String newPurpose) {
		this.newPurpose = newPurpose;
	}

	public boolean isTaskPersonAdd() {
		return CollectionUtils.isNotEmpty(addNaturalPersons) || CollectionUtils.isNotEmpty(addLegalPersons);
	}

	public List<HrMutationNaturalPersonDto> getAddNaturalPersons() {
		return addNaturalPersons;
	}

	public void setAddNaturalPersons(List<HrMutationNaturalPersonDto> addNaturalPersons) {
		this.addNaturalPersons = addNaturalPersons;
	}

	public List<HrMutationLegalPersonDto> getAddLegalPersons() {
		return addLegalPersons;
	}

	public void setAddLegalPersons(List<HrMutationLegalPersonDto> addLegalPersons) {
		this.addLegalPersons = addLegalPersons;
	}

	public boolean isTaskPersonUpdate() {
		return CollectionUtils.isNotEmpty(updateNaturalPersons) || CollectionUtils.isNotEmpty(updateLegalPersons);
	}

	public List<HrMutationNaturalPersonDto> getUpdateNaturalPersons() {
		return updateNaturalPersons;
	}

	public void setUpdateNaturalPersons(List<HrMutationNaturalPersonDto> updateNaturalPersons) {
		this.updateNaturalPersons = updateNaturalPersons;
	}

	public List<HrMutationLegalPersonDto> getUpdateLegalPersons() {
		return updateLegalPersons;
	}

	public void setUpdateLegalPersons(List<HrMutationLegalPersonDto> updateLegalPersons) {
		this.updateLegalPersons = updateLegalPersons;
	}

	public boolean isTaskPersonDelete() {
		return CollectionUtils.isNotEmpty(deleteNaturalPersons) || CollectionUtils.isNotEmpty(deleteLegalPersons);
	}

	public List<HrMutationNaturalPersonDto> getDeleteNaturalPersons() {
		return deleteNaturalPersons;
	}

	public void setDeleteNaturalPersons(List<HrMutationNaturalPersonDto> deleteNaturalPersons) {
		this.deleteNaturalPersons = deleteNaturalPersons;
	}

	public List<HrMutationLegalPersonDto> getDeleteLegalPersons() {
		return deleteLegalPersons;
	}

	public void setDeleteLegalPersons(List<HrMutationLegalPersonDto> deleteLegalPersons) {
		this.deleteLegalPersons = deleteLegalPersons;
	}

	public boolean isTaskDissolution() {
		return taskDissolution;
	}

	public void setTaskDissolution(boolean taskDissolution) {
		this.taskDissolution = taskDissolution;
	}

	public String getDissLeavingPartnerGivenName() {
		return dissLeavingPartnerGivenName;
	}

	public void setDissLeavingPartnerGivenName(String dissLeavingPartnerGivenName) {
		this.dissLeavingPartnerGivenName = dissLeavingPartnerGivenName;
	}

	public String getDissLeavingPartnerFamilyName() {
		return dissLeavingPartnerFamilyName;
	}

	public void setDissLeavingPartnerFamilyName(String dissLeavingPartnerFamilyName) {
		this.dissLeavingPartnerFamilyName = dissLeavingPartnerFamilyName;
	}

	public LocalDate getDissLeavingPartnerBirthday() {
		return dissLeavingPartnerBirthday;
	}

	public void setDissLeavingPartnerBirthday(LocalDate dissLeavingPartnerBirthday) {
		this.dissLeavingPartnerBirthday = dissLeavingPartnerBirthday;
	}

	public HrMutationNaturalPersonDto getDissNewOwner() {
		return dissNewOwner;
	}

	public void setDissNewOwner(HrMutationNaturalPersonDto dissNewOwner) {
		this.dissNewOwner = dissNewOwner;
	}

	public String getDissNewCompanyName() {
		return dissNewCompanyName;
	}

	public void setDissNewCompanyName(String dissNewCompanyName) {
		this.dissNewCompanyName = dissNewCompanyName;
	}

	public boolean isTaskRevision() {
		return taskRevision;
	}

	public void setTaskRevision(boolean taskRevision) {
		this.taskRevision = taskRevision;
	}

	public String getRevCompanyName() {
		return revCompanyName;
	}

	public void setRevCompanyName(String revCompanyName) {
		this.revCompanyName = revCompanyName;
	}

	public String getRevPreviousSeatCity() {
		return revPreviousSeatCity;
	}

	public void setRevPreviousSeatCity(String revPreviousSeatCity) {
		this.revPreviousSeatCity = revPreviousSeatCity;
	}

	public String getRevPreviousSeatPolCommunity() {
		return revPreviousSeatPolCommunity;
	}

	public void setRevPreviousSeatPolCommunity(String revPreviousSeatPolCommunity) {
		this.revPreviousSeatPolCommunity = revPreviousSeatPolCommunity;
	}

	public String getRevPreviousSeatCanton() {
		return revPreviousSeatCanton;
	}

	public void setRevPreviousSeatCanton(String revPreviousSeatCanton) {
		this.revPreviousSeatCanton = revPreviousSeatCanton;
	}

	public String getRevNewSeatCity() {
		return revNewSeatCity;
	}

	public void setRevNewSeatCity(String revNewSeatCity) {
		this.revNewSeatCity = revNewSeatCity;
	}

	public String getRevNewSeatPolCommunity() {
		return revNewSeatPolCommunity;
	}

	public void setRevNewSeatPolCommunity(String revNewSeatPolCommunity) {
		this.revNewSeatPolCommunity = revNewSeatPolCommunity;
	}

	public String getRevNewSeatCanton() {
		return revNewSeatCanton;
	}

	public void setRevNewSeatCanton(String revNewSeatCanton) {
		this.revNewSeatCanton = revNewSeatCanton;
	}

	public boolean isTaskExcerpts() {
		return taskExcerpts;
	}

	public void setTaskExcerpts(boolean taskExcerpts) {
		this.taskExcerpts = taskExcerpts;
	}

	public AddressDto getExcerptsDeliveryAddress() {
		return excerptsDeliveryAddress;
	}

	public void setExcerptsDeliveryAddress(AddressDto excerptsDeliveryAddress) {
		this.excerptsDeliveryAddress = excerptsDeliveryAddress;
	}

	public AddressDto getExcerptsBillingAddress() {
		return excerptsBillingAddress;
	}

	public void setExcerptsBillingAddress(AddressDto excerptsBillingAddress) {
		this.excerptsBillingAddress = excerptsBillingAddress;
	}

	public int getExcerptsNum() {
		return excerptsNum;
	}

	public void setExcerptsNum(int excerptsNum) {
		this.excerptsNum = excerptsNum;
	}

	public int getExcerptsNumPrelim() {
		return excerptsNumPrelim;
	}

	public void setExcerptsNumPrelim(int excerptsNumPrelim) {
		this.excerptsNumPrelim = excerptsNumPrelim;
	}

	public String getSigningHintForLegalForm() {
		return signingHintForLegalForm;
	}

	public void setSigningHintForLegalForm(String signingHintForLegalForm) {
		this.signingHintForLegalForm = signingHintForLegalForm;
	}

	public String getProzessUid() {
		return prozessUid;
	}

	public void setProzessUid(String prozessUid) {
		this.prozessUid = prozessUid;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public String getSignDocTitle() {
		return signDocTitle;
	}

	public void setSignDocTitle(String signDocTitle) {
		this.signDocTitle = signDocTitle;
	}

	public String getAddMoreFormsIfNecessary() {
		return addMoreFormsIfNecessary;
	}

	public void setAddMoreFormsIfNecessary(String addMoreFormsIfNecessary) {
		this.addMoreFormsIfNecessary = addMoreFormsIfNecessary;
	}

	public List<HrMutationNaturalPersonDto> getAddUpdateSignatories() {
		return addUpdateSignatories;
	}

	public void setAddUpdateSignatories(List<HrMutationNaturalPersonDto> addUpdateSignatories) {
		this.addUpdateSignatories = addUpdateSignatories;
	}

	public HrAmtDto getAmt() {
		return amt;
	}

	public void setAmt(HrAmtDto amt) {
		this.amt = amt;
	}
}
