/*
 * ApplicationServiceTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.application.service;

import java.util.Arrays;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.application.repository.IKmuAdminDataRepository;
import ch.admin.oss.application.repository.IStartBizDataRepository;
import ch.admin.oss.business.AbstractOSSTest;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.common.enums.OrganisationCreationTypeEnum;
import ch.admin.oss.domain.KmuAdminDataEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.StartBizDataEntity;
import ch.admin.oss.organisation.repository.IOrganisationRepository;

/**
 * @author xdg
 */
@ActiveProfiles(CommonConstants.PROFILE_TEST)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Transactional
public class ApplicationServiceTest extends AbstractOSSTest {

	@PersistenceContext
	private EntityManager em;

	@Autowired
	private IOrganisationRepository orgRepo;	
	
	@Autowired
	private IStartBizDataRepository startBizRepo;

	@Autowired
	private IKmuAdminDataRepository kmuRepo;

	@Test
	public void testCountOrg() {
		// insert org
		OrganisationEntity org1 = new OrganisationEntity();
		org1.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		OrganisationEntity org2 = new OrganisationEntity();
		org2.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		OrganisationEntity org3 = new OrganisationEntity();
		org3.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		OrganisationEntity org4 = new OrganisationEntity();
		org4.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		OrganisationEntity org5 = new OrganisationEntity();
		org5.setCreationType(OrganisationCreationTypeEnum.SCRATCH);
		orgRepo.save(Arrays.asList(org1, org2, org3, org4, org5));

		// insert startbiz
		StartBizDataEntity sBiz1 = new StartBizDataEntity();
		sBiz1.setOrganisation(null);

		StartBizDataEntity sBiz2 = new StartBizDataEntity();
		sBiz1.setOrganisation(null);

		StartBizDataEntity sBiz3 = new StartBizDataEntity();
		sBiz1.setOrganisation(null);

		StartBizDataEntity sBiz4 = new StartBizDataEntity();
		sBiz1.setOrganisation(null);

		StartBizDataEntity sBiz5 = new StartBizDataEntity();
		sBiz1.setOrganisation(org5);

		startBizRepo.save(Arrays.asList(sBiz1, sBiz2, sBiz3, sBiz4, sBiz5));

		// insert kmu
		KmuAdminDataEntity kmu1 = new KmuAdminDataEntity();
		kmu1.setFirma("KMU1");
		kmu1.setZefixMatchUID(null);

		KmuAdminDataEntity kmu2 = new KmuAdminDataEntity();
		kmu2.setFirma("KMU2");
		kmu2.setZefixMatchUID(null);

		KmuAdminDataEntity kmu3 = new KmuAdminDataEntity();
		kmu3.setFirma("KMU3");
		kmu3.setZefixMatchUID(null);

		KmuAdminDataEntity kmu4 = new KmuAdminDataEntity();
		kmu4.setFirma("KMU4");
		kmu4.setZefixMatchUID(null);

		KmuAdminDataEntity kmu5 = new KmuAdminDataEntity();
		kmu5.setFirma("KMU5");
		kmu5.setZefixMatchUID("TEST-UID");

		kmuRepo.save(Arrays.asList(kmu1, kmu2, kmu3, kmu4, kmu5));

		em.flush();

		Assert.assertEquals(62, applicationService.countAllOrgs());
	}
}
