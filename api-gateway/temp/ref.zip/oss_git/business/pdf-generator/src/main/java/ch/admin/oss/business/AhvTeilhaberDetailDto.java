/*
 * AhvTeilhaberDetailDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

/**
 * @author hhg
 *
 */
public class AhvTeilhaberDetailDto {

	private CompanyDto part;
	private AusgleichskasseDto ak;
	private PersonlicheAngabenDto pi;
	private FinanzielleDto fin;
	private ErwerbstatigkeitDto oc;
	private ErwerbsUndSelbstkostenDto cost;
	private ArbeitsorganisationDto org;
	private SelbsteinschatzungDto sb;
	private AuftrageKundenDto cust;
	private String date;

	public CompanyDto getPart() {
		return part;
	}
	public void setPart(CompanyDto part) {
		this.part = part;
	}
	public AusgleichskasseDto getAk() {
		return ak;
	}
	public void setAk(AusgleichskasseDto ak) {
		this.ak = ak;
	}
	public PersonlicheAngabenDto getPi() {
		return pi;
	}
	public void setPi(PersonlicheAngabenDto pi) {
		this.pi = pi;
	}
	public FinanzielleDto getFin() {
		return fin;
	}
	public void setFin(FinanzielleDto fin) {
		this.fin = fin;
	}
	public ErwerbstatigkeitDto getOc() {
		return oc;
	}
	public void setOc(ErwerbstatigkeitDto oc) {
		this.oc = oc;
	}
	public ErwerbsUndSelbstkostenDto getCost() {
		return cost;
	}
	public void setCost(ErwerbsUndSelbstkostenDto cost) {
		this.cost = cost;
	}
	public ArbeitsorganisationDto getOrg() {
		return org;
	}
	public void setOrg(ArbeitsorganisationDto org) {
		this.org = org;
	}
	public SelbsteinschatzungDto getSb() {
		return sb;
	}
	public void setSb(SelbsteinschatzungDto sb) {
		this.sb = sb;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public AuftrageKundenDto getCust() {
		return cust;
	}
	public void setCust(AuftrageKundenDto cust) {
		this.cust = cust;
	}
}
