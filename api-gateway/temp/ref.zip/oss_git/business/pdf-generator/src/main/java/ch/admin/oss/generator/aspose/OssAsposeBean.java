/*
 * OssAsposeBean
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.generator.aspose;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.beanutils.NestedNullException;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;

import com.aspose.words.IMailMergeDataSource;

import ch.admin.oss.OssPdfGenerateTechnicalException;

/**
 * @author hha
 */
public class OssAsposeBean extends OssAbstractAsposeBean implements IMailMergeDataSource {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(OssAsposeBean.class);

	private List<Object> objects = new ArrayList<>();
	private int index = -1;
	private String regionName;

	public OssAsposeBean(OssAsposeContext context, Object object) {
		super(context);
		objects.add(object);
	}

	public OssAsposeBean(OssAsposeContext context, Object object, String regionName) {
		this(context, object);
		this.regionName = regionName;
	}

	public OssAsposeBean(OssAsposeContext context, Collection<?> dtos, String regionName) {
		super(context);
		this.regionName = regionName;

		objects = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(dtos)) {
			objects.addAll(dtos);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public IMailMergeDataSource getChildDataSource(String regionName) throws Exception {
		try {
			Object object = objects.get(index);
			Object value = getValue(object, regionName);
			if (value != null && Collection.class.isAssignableFrom(value.getClass())) {
				// <<TableStart:regionName>>
				return new OssAsposeBean(context, (Collection<Object>) value, regionName);
			} else {
				// <<user.firstName>>
				// "user" is treated as a region.
				return new OssAsposeBean(context, value, regionName);
			}
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
			throw new OssPdfGenerateTechnicalException("Cannot read field " + regionName, e);
		} catch (NestedNullException e) {
			LOGGER.warn("Parent's value is null, consider that the returned value is nul", e);
			return new OssAsposeBean(context, null, regionName);
		}
	}

	@Override
	public String getTableName() throws Exception {
		return regionName;
	}

	@Override
	public boolean getValue(String fieldName, Object[] values) throws Exception {
		try {
			values[0] = getFormattedValue(objects.get(index), fieldName);
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
			throw new OssPdfGenerateTechnicalException("Cannot read field " + fieldName, e);
		} catch (NestedNullException e) {
			LOGGER.warn("Parent's value is null, consider that the returned value is null.", e);
			return false;
		}
		return true;
	}

	@Override
	public boolean moveNext() throws Exception {
		if (++index < objects.size()) {
			return true;
		}
		return false;
	}
}