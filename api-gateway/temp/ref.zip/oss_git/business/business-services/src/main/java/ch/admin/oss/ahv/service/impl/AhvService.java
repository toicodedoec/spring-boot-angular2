/*
 * IHRService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.ahv.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.ahv.repository.IAhvAnmeldungRepository;
import ch.admin.oss.ahv.service.IAhvService;
import ch.admin.oss.business.AddressDto;
import ch.admin.oss.business.AhvDto;
import ch.admin.oss.business.AhvHeaderDto;
import ch.admin.oss.business.AhvTeilhaberDetailDto;
import ch.admin.oss.business.AhvTemplateType;
import ch.admin.oss.business.AngestellteBuchhaltungBVGDto;
import ch.admin.oss.business.AngestellteDto;
import ch.admin.oss.business.ArbeitsorganisationDto;
import ch.admin.oss.business.AuftrageKundenDto;
import ch.admin.oss.business.AusgleichskasseDto;
import ch.admin.oss.business.BemerkungenDto;
import ch.admin.oss.business.BetriebDto;
import ch.admin.oss.business.BetriebsAdressenDto;
import ch.admin.oss.business.BetriebsgrundungDto;
import ch.admin.oss.business.CompanyDto;
import ch.admin.oss.business.EhePartnerInDto;
import ch.admin.oss.business.ErwerbsUndSelbstkostenDto;
import ch.admin.oss.business.ErwerbstatigkeitDto;
import ch.admin.oss.business.FinanzielleDto;
import ch.admin.oss.business.GeschaftslokaleDto;
import ch.admin.oss.business.GesellschafterDto;
import ch.admin.oss.business.InvestitionenDto;
import ch.admin.oss.business.KontaktpersonDto;
import ch.admin.oss.business.OrtderTatigkeitDto;
import ch.admin.oss.business.PersonlicheAngabenDto;
import ch.admin.oss.business.PurchaseDto;
import ch.admin.oss.business.RentDto;
import ch.admin.oss.business.RoomDto;
import ch.admin.oss.business.SelbsteinschatzungDto;
import ch.admin.oss.business.VrHonorareTantiemenDto;
import ch.admin.oss.business.WunschtInformationenDto;
import ch.admin.oss.business.ZahlungsverbindungDto;
import ch.admin.oss.common.AbstractProcessService;
import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.common.enums.AhvNamenEnum;
import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.common.enums.ZahlungszweckEnum;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.AhvAnmeldungEntity;
import ch.admin.oss.domain.AhvFilialeEntity;
import ch.admin.oss.domain.AhvTeilhaberEntity;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.GeschaeftsstelleEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.KontoEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PersonEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QAhvAnmeldungEntity;
import ch.admin.oss.domain.QAhvFilialeEntity;
import ch.admin.oss.domain.QAhvTeilhaberEntity;
import ch.admin.oss.domain.QCodeWertEntity;
import ch.admin.oss.domain.QGeschaftsrolleEntity;
import ch.admin.oss.domain.QOrganisationEntity;
import ch.admin.oss.domain.QPersonEntity;
import ch.admin.oss.domain.QVerbandEntity;
import ch.admin.oss.domain.VerbandEntity;
import ch.admin.oss.enums.SupportedFileTypeDownload;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.MailMessage;
import ch.admin.oss.util.OSSConstants;
import ch.admin.oss.util.OssAsposeUtil;

/**
 * @author hhg
 *
 */
@Service
@Transactional(rollbackFor = Throwable.class)
public class AhvService extends AbstractProcessService<AhvAnmeldungEntity> implements IAhvService {

	/**
	 * 
	 */
	private static final long TAETIGKEIT_MONTH_PLUS = 12L;

	private static final String DATE_FORMAT_FOR_PDF = "EEEE, d. MMMM yyyy";

	@Value("${oss.ahv.email.cc.to.ausgleichskasse}")
	private boolean ccToAusgleichskasse;

	@Autowired
	private IAhvAnmeldungRepository ahvRepository;
	
	private AdresseEntity getOrganisationDomizil(long orgId) {
		OrganisationEntity orgEntity = new JPAQuery<OrganisationEntity>(em)
				.from(QOrganisationEntity.organisationEntity)
				.join(QOrganisationEntity.organisationEntity.domizil).fetchJoin()
				.where(QOrganisationEntity.organisationEntity.id.eq(orgId))
				.fetchOne();
		return orgEntity.getDomizil();
	}

	@Override
	public AusgleichskasseEntity findAusleichskasseInOrganisationKanton(long orgId) {
		AdresseEntity domizil = getOrganisationDomizil(orgId);
		return applicationService.findDefaultAusleichskasseInKanton(domizil.getKanton(), domizil.getOrt(), domizil.getPlz());
	}

	@Override
	public AhvAnmeldungEntity createProcess(OrganisationEntity organisation) {
		AhvAnmeldungEntity entity = new AhvAnmeldungEntity();
		
		entity.getProzess().setOrganisation(organisation);

		if (organisation.getPflichtenabklaerungen().isAnmeldungAHV()) {
			entity.getProzess().setStatus(ProzessStatusEnum.EXTERN);
		}

		recordProcessStatusChange(entity.getProzess());
		
		return ahvRepository.save(entity);
	}

	@Override
	public AhvAnmeldungEntity createAhvFiliale(GeschaeftsstelleEntity geschaeftsstelle) {
		boolean isExstingAhvFiliale = new JPAQuery<AhvFilialeEntity>(em)
				.from(QAhvFilialeEntity.ahvFilialeEntity)
				.where(QAhvFilialeEntity.ahvFilialeEntity.geschaeftsstelle.id.eq(geschaeftsstelle.getId()))
				.fetchCount() > 0;
		
		if(isExstingAhvFiliale) {
			return null;
		}

		AhvAnmeldungEntity ahvEntity = getByOrganisationId(geschaeftsstelle.getOrganisation().getId());
		ahvEntity.getAhvFiliales().add(new AhvFilialeEntity(ahvEntity, geschaeftsstelle));
		return ahvRepository.save(ahvEntity);
	}

	@Override
	public FileDto downloadDocument(long orgId) {
		return new FileDto("ahv.pdf", SupportedFileTypeDownload.PDF, getDocument(orgId));
	}

	@Override
	protected byte[] generateDocument(AhvAnmeldungEntity ahvAnmeldung, boolean draft) {
		RechtsformEnum rechtsform = ahvAnmeldung.getProzess().getOrganisation().getRechtsform();
		AhvTemplateType templateType;
		switch (rechtsform) {
			case EINZELFIRMA:
				templateType = AhvTemplateType.EF;
				break;
			case KOLLGES:
			case KOMMGES:
				templateType = AhvTemplateType.PG;
				break;
			case AG:
			case GMBH:
				templateType = AhvTemplateType.KG;
				break;
			default:
				throw new IllegalArgumentException("Unknown rechtform " + rechtsform);
		}
		SupportedLanguage language = findRecipientSupportedLanguage(getAusleichskasse(ahvAnmeldung));
		AhvDto data = dataForAhvPdf(ahvAnmeldung, language, templateType);
		if (draft) {
			String watermark = applicationService.getTranslation("gui_labels.ahv.document.watermark", language);
			return OssAsposeUtil.generateAhvPdf(templateType, language.name(), data, watermark);
		}
		return OssAsposeUtil.generateAhvPdf(templateType, language.name(), data, null);
	}

	private SupportedLanguage findRecipientSupportedLanguage(AusgleichskasseEntity ausgleichskasse) {
		return getSupportedLanguage(ausgleichskasse.getSprache(), ",");
	}

	private AhvDto dataForAhvPdf(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage language, AhvTemplateType templateType) {
		AhvDto ahvDto = new AhvDto();
		ahvDto.setDate(dataForDate(language));
		ahvDto.setAk(dataForAusgleichskasse(ahvAnmeldung, language));
		ahvDto.setH(new AhvHeaderDto(ahvDto.getAk()));
		ahvDto.setB(dataForBetrieb(ahvAnmeldung, language));
		ahvDto.setBg(dataForBetriebsgrundung(ahvAnmeldung, language));
		ahvDto.setBa(dataForBetriebsAdressen(ahvAnmeldung, language));
		ahvDto.setZ(dataForZahlungsverbindung(ahvAnmeldung, language));
		ahvDto.setGl(dataForGeschaftslokales(ahvAnmeldung));
		ahvDto.setAbb(dataForAngestellteBuchhaltungBVG(ahvAnmeldung, language));
		ahvDto.setCust(dataForAuftrageKunden(ahvAnmeldung));
		ahvDto.setK(dataForKontaktperson(ahvAnmeldung));
		ahvDto.setBem(dataForBemerkungen(ahvAnmeldung));
		ahvDto.setI(dataForWunschtInformationen(ahvAnmeldung, language));
		ahvDto.setCapital(dataForInvestitionen(ahvAnmeldung));
		ahvDto.setAhvTeilhabers(dataForAhvTeilhabers(ahvAnmeldung, ahvDto.getAk(), language));
		switch (templateType) {
			case PG:
				ahvDto.setOrt(dataForOrtderTatigkeit(ahvAnmeldung, language));
				ahvDto.setOwners(dataForOwners(ahvAnmeldung, language));
				break;
			case KG:
				ahvDto.setVr(dataForVrHonorareTantiemen(ahvAnmeldung));
				break;
			case EF:
				AhvTeilhaberEntity ahvTeilhaber = ahvAnmeldung.getAhvTeilhabers().iterator().next();
				ahvDto.setPi(dataForPersonlicheAngaben(ahvTeilhaber, language));
				ahvDto.setCost(dataForErwerbsUndSelbstkosten(ahvTeilhaber, language));
				ahvDto.setOrg(dataForArbeitsorganisation(ahvAnmeldung, ahvTeilhaber, language));
				ahvDto.setPartner(dataForEhePartnerIn(ahvTeilhaber, language));
				ahvDto.setSb(dataForSelbsteinschatzung(ahvAnmeldung, ahvTeilhaber));
				ahvDto.setOc(new ErwerbstatigkeitDto(ahvTeilhaber.getMitarbeitStaaten()));
				break;
			default:
				break;
		}
		return ahvDto;
	}
	
	/**
	 * @param ahvTeilhaber
	 * @param language
	 * @return
	 */
	private EhePartnerInDto dataForEhePartnerIn(AhvTeilhaberEntity ahvTeilhaber, SupportedLanguage language) {
		PersonEntity person = ahvTeilhaber.getPartner();
		if(person == null) {
			return null;
		}
		
		EhePartnerInDto partner = new EhePartnerInDto();
		partner.setAnrede(person.getAnrede().getStandardText().textTranslation(language));
		partner.setTitel(person.getTitel());
		partner.setFamilienname(person.getFamilienname());
		partner.setVorname(person.getVorname());
		partner.setVornamenliste(person.getVornamenliste());
		partner.setGeburtsdatum(person.getGeburtsdatum());
		partner.setAhvNummer(person.getAhvNummer());
		partner.setPartnerArbeitetMit(getTranslation(ahvTeilhaber.getPartnerArbeitetMit(), language));
		if(ahvTeilhaber.getPartnerEinkommenUeber()) {
			partner.setEinkommen(applicationService.getTranslation("gui_labels.ahvTeilhaber.einkommen.greater.7000", language));
		} else {
			partner.setEinkommen(applicationService.getTranslation("gui_labels.ahvTeilhaber.einkommen.lower.7000", language));
		}
		return partner;
	}

	private InvestitionenDto dataForInvestitionen(AhvAnmeldungEntity ahvAnmeldung) {
		RentDto rent = new RentDto(
			ahvAnmeldung.getInvestBueroMiete(),
			ahvAnmeldung.getInvestLagerMiete(),
			ahvAnmeldung.getInvestWerkstattMiete(),
			ahvAnmeldung.getInvestLadenMiete(),
			ahvAnmeldung.getInvestWeitereMiete(),
			ahvAnmeldung.getInvestWeitereMieteArt());
		
		PurchaseDto purchase = new PurchaseDto(ahvAnmeldung.getInvestWerkzeugKauf(),
			ahvAnmeldung.getInvestWarenInvKauf(),
			ahvAnmeldung.getInvestFahrzeugKauf(),
			ahvAnmeldung.getInvestWeitereKauf(),
			ahvAnmeldung.getInvestWeitereKaufArt());
		
		return new InvestitionenDto(rent, purchase, ahvAnmeldung.getKapitalEigen(), ahvAnmeldung.getKapitalDarlehen());
	}
	
	private OrtderTatigkeitDto dataForOrtderTatigkeit(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage lang) {
		RoomDto room = new RoomDto(
			getTranslation(ahvAnmeldung.getRaumEigene(), lang),
			getTranslation(ahvAnmeldung.getRaumWohnung(), lang),
			getTranslation(ahvAnmeldung.getRaumKunde(), lang),
			getTranslation(ahvAnmeldung.getRaumKeine(), lang)
		);
		return new OrtderTatigkeitDto(room);
	}
	
	private String dataForDate(SupportedLanguage language) {
		Locale locale = new Locale(language.name().toLowerCase());
		return FastDateFormat.getInstance(DATE_FORMAT_FOR_PDF, locale).format(new Date());
	}
	
	private FinanzielleDto dataForFinanzielle(AhvTeilhaberEntity ahvTeilhaber) {
		return new FinanzielleDto(ahvTeilhaber.getEinkommenAnteilAmGewinn(), ahvTeilhaber.getEinkommenAnteilAmVerlust());
	}
	
	private BemerkungenDto dataForBemerkungen(AhvAnmeldungEntity ahvAnmeldung) {
		String anschluss = "AK";
		if (BooleanUtils.isTrue(ahvAnmeldung.getVerbandFak())) {
			anschluss = "AK, FAK";
		}
		int sonderFormulare = ahvAnmeldung.getSonderFormulare() == null ? 0 : ahvAnmeldung.getSonderFormulare();
		return new BemerkungenDto(anschluss, ahvAnmeldung.getSonderPartnerWeb(), ahvAnmeldung.getKontaktBemerkungen(), sonderFormulare, ahvAnmeldung.getTaetigGemeinsameKunden());
	}
	
	private WunschtInformationenDto dataForWunschtInformationen(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage lang) {
		return new WunschtInformationenDto(
			getTranslation(ahvAnmeldung.getSonderVerband(), lang),
			getTranslation(ahvAnmeldung.getSonderBvg(), lang),
			getTranslation(ahvAnmeldung.getSonderUvg(), lang),
			getTranslation(ahvAnmeldung.getSonderKkv(), lang),
			getTranslation(ahvAnmeldung.getSonderWeitere(),lang)
		);
	}
	
	private VrHonorareTantiemenDto dataForVrHonorareTantiemen(AhvAnmeldungEntity ahvAnmeldung) {
		return new VrHonorareTantiemenDto(ahvAnmeldung.getAngestellteVrHonorare());
	}

	private KontaktpersonDto dataForKontaktperson(AhvAnmeldungEntity ahvAnmeldung) {
		return new KontaktpersonDto(
			ahvAnmeldung.getKontaktVorname(),
			ahvAnmeldung.getKontaktFamilienname(),
			ahvAnmeldung.getKontaktTelefon(),
			ahvAnmeldung.getKontaktMobile(),
			ahvAnmeldung.getKontaktEmail()
		);
	}
	
	private AusgleichskasseDto dataForAusgleichskasse(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage language) {
		AusgleichskasseEntity ausgleichskasseEntity = getAusleichskasse(ahvAnmeldung);
		AusgleichskasseDto ausgleichskasse = new AusgleichskasseDto();
		ausgleichskasse.setName(ausgleichskasseEntity.getStandardText().textTranslation(language));
		ausgleichskasse.setPostfach(ausgleichskasseEntity.getPostfach());
		ausgleichskasse.setStrasse(ausgleichskasseEntity.getStrasse());
		ausgleichskasse.setHausnr(ausgleichskasseEntity.getHausnummer());
		ausgleichskasse.setPlz(ausgleichskasseEntity.getPlz());
		ausgleichskasse.setOrt(ausgleichskasseEntity.getOrt());
		ausgleichskasse.setTelefon(ausgleichskasseEntity.getTelefon());
		ausgleichskasse.setHomepage(ausgleichskasseEntity.getHomepage());
		return ausgleichskasse;
	}
	
	private AusgleichskasseEntity getAusleichskasse(AhvAnmeldungEntity ahvAnmeldung) {
		if (ahvAnmeldung.getVerbandId() != null) {
			return getVerbandById(ahvAnmeldung.getVerbandId()).getAusgleichskasse();
		}
		return findAusleichskasseInOrganisationKanton(ahvAnmeldung.getProzess().getOrganisation().getId());
	}

	private BetriebDto dataForBetrieb(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage language) {
		OrganisationEntity organisation = ahvAnmeldung.getProzess().getOrganisation();
	
		BetriebDto betrieb = new BetriebDto();
		betrieb.setLegalForm(applicationService.getTranslation(organisation.getRechtsform(), language));
		betrieb.setCompanyName(organisation.defaultName());
		betrieb.setCompanyObject(organisation.getZweck());
		betrieb.setDateStartBusiness(organisation.getEroeffnungsDatum());
		if (StringUtils.isNotBlank(ahvAnmeldung.getSozialversUvg())) {
			betrieb.setUvg(ahvAnmeldung.getSozialversUvg());
		} else {
			betrieb.setUvg("SUVA");
		}

		// Main address
		AddressDto mainAddr = convertToAddressDto(organisation.getDomizil(), language);
		betrieb.setMainAddr(mainAddr);
		
		// Branches (or industries)
		if (CollectionUtils.isNotEmpty(organisation.getBranches())) {
			List<Long> brancheIds = organisation.getBranches()
				.stream()
				.map(b -> b.getId()).collect(Collectors.toList());
			List<String> brancheTexts = cacheService.getBranches()
				.stream()
				.filter(b -> brancheIds.contains(b.getId()))
				.map(b -> b.getStandardText().textTranslation(language))
				.collect(Collectors.toList());
			betrieb.setIndustries(StringUtils.join(brancheTexts, ", "));
		}
		
		// Verband
		if (ahvAnmeldung.getVerbandId() != null) {
			VerbandEntity verband = getVerbandById(ahvAnmeldung.getVerbandId());
			String verbandName = verband.getStandardText().textTranslation(language);
			betrieb.setVerband(getTranslation(Boolean.TRUE, language) + " / " + verbandName);
			betrieb.setSeit(ahvAnmeldung.getVerbandBeitrittDatum());
			String ausgleichskasseName = verband.getAusgleichskasse().getStandardText().textTranslation(language);
			betrieb.setVak(ausgleichskasseName);
		} else {
			betrieb.setVerband(getTranslation(Boolean.FALSE, language));
		}
		if(organisation.getHrStatus() != null) {
			betrieb.setHrStatus(organisation.getHrStatus().name());
			if (organisation.getHrStatus() == HRStatusEnum.REGISTERED) {
				betrieb.setChNr(OssNumberFormatUtil.formatChid(organisation.getChNr()));
				betrieb.setShabNr(organisation.getShabNr());
				betrieb.setShabDatum(organisation.getShabDatum());
			}
		} else if (ahvAnmeldung.getZefixStatus() != null) {
			betrieb.setHrStatus(ahvAnmeldung.getZefixStatus().name());
			if (ahvAnmeldung.getZefixStatus() == HRStatusEnum.REGISTERED) {
				betrieb.setChNr(OssNumberFormatUtil.formatChid(ahvAnmeldung.getZefixChNr()));
				betrieb.setShabNr(ahvAnmeldung.getZefixShabNr());
				betrieb.setShabDatum(ahvAnmeldung.getZefixShabDate());
			}
		} else {
			betrieb.setHrStatus(HRStatusEnum.NONE.name());
		}
		
		return betrieb;
	}
	
	private AusgleichskasseEntity getAusgleichskass(Long ausgleichskassId) {
		AusgleichskasseEntity ausgleichskasse = cacheService.getAusgleichskasses()
			.stream()
			.filter(a -> a.getId().equals(ausgleichskassId))
			.findFirst().get();
		return ausgleichskasse;
	}
	
	private CodeWertEntity getCodeWert(Long codewertId, KategorieEnum kategorie) {
		CodeWertEntity codewert = applicationService.getCodeWerts(kategorie)
			.stream()
			.filter(c -> c.getId().equals(codewertId))
			.findFirst().get();
		return codewert;
	}

	private BetriebsgrundungDto dataForBetriebsgrundung(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage language) {
		switch (ahvAnmeldung.getGruendArt()) {
			case NEU:
				return new BetriebsgrundungDto(getTranslationForGrundungsart(ahvAnmeldung, language), null);
			case UBERNAHME:
				String vormals = ahvAnmeldung.getGruendUebernameName();
				if(StringUtils.isNoneEmpty(ahvAnmeldung.getGruendUebernameNummer())) {
					vormals += " (" + ahvAnmeldung.getGruendUebernameNummer() + ")";
				}
				return new BetriebsgrundungDto(getTranslationForGrundungsart(ahvAnmeldung, language), vormals);
			case UMWANDLUNG:
				return new BetriebsgrundungDto(getTranslationForGrundungsart(ahvAnmeldung, language), ahvAnmeldung.getGruendAlteBezeichnung());
			default:
				throw new IllegalArgumentException("Unknown AhvGruendungsartEnum " + ahvAnmeldung.getGruendArt());
		}
	}

	private String getTranslationForGrundungsart(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage language) {
		ArrayList<String> art = new ArrayList<>();
		art.add(applicationService.getTranslation(ahvAnmeldung.getGruendArt(), language));
		if (ahvAnmeldung.getGruendUebernameArt() != null) {
			art.add(applicationService.getTranslation("gui_labels.ahvUgruendung.durchRadio", language));
			art.add(applicationService.getTranslation(ahvAnmeldung.getGruendUebernameArt(), language));
		}
		return StringUtils.join(art, StringUtils.SPACE);
	}

	private BetriebsAdressenDto dataForBetriebsAdressen(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage language) {
		AddressDto ahvAddr = convertToAddressDto(ahvAnmeldung.getAdresseKontakt(), language);
		AddressDto ahvTrust = convertToAddressDto(ahvAnmeldung.getAdresseTreuhand(), language);
		return new BetriebsAdressenDto(ahvAddr, ahvTrust);
	}
	
	private ZahlungsverbindungDto dataForZahlungsverbindung(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage language) {
		KontoEntity konto = ahvAnmeldung.getProzess().getOrganisation().konto(ZahlungszweckEnum.AHV);
		ZahlungsverbindungDto z = new ZahlungsverbindungDto();
		if (konto == null) {
			return z;
		}
		z.setTyp(konto.getTyp().name());
		z.setInhaber(konto.getInhaber());
		z.setBankname(konto.getBankname());
		z.setKontonummer(konto.getKontonummer());
		z.setOrt(konto.getOrt());
		z.setPlz(konto.getPlz());
		z.setBankleitzahl(konto.getBankleitzahl());
		z.setPc(konto.getPc());
		if(StringUtils.isNotEmpty(konto.getLand())) {
			CodeWertEntity land = applicationService.getCodeWerts(KategorieEnum.LAND)
					.stream()
					.filter(cw -> cw.getCode().equals(konto.getLand()))
					.findFirst().get();
			z.setLand(getCodeText(land, language));
			z.setLandCode(cacheService.getLands().get(konto.getLand()).getIso2().name());
		}
		return z;
	}
	
	private List<GeschaftslokaleDto> dataForGeschaftslokales(AhvAnmeldungEntity ahvAnmeldung) {
		if (CollectionUtils.isNotEmpty(ahvAnmeldung.getAhvFiliales())) {
			return ahvAnmeldung.getAhvFiliales()
				.stream()
				.map(f -> {
					return new GeschaftslokaleDto(
						f.getGeschaeftsstelle().getAdresse().getStrasse(),
						f.getGeschaeftsstelle().getAdresse().getHausnummer(),
						f.getGeschaeftsstelle().getAdresse().getPlz(), 
						f.getGeschaeftsstelle().getAdresse().getOrt(),
						f.getLohnSumme(),
						f.getAngestellte(),
						f.getSeit());
				}).collect(Collectors.toList());
		}
		return Collections.emptyList();
	}
	
	private AngestellteBuchhaltungBVGDto dataForAngestellteBuchhaltungBVG(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage lang) {
		AngestellteDto employee = new AngestellteDto(
			ahvAnmeldung.getAngestellteUebAnz(), ahvAnmeldung.getAngestellteUebLohnSumme(),
			getTranslation(ahvAnmeldung.getAngestellteUebHatKinder(), lang),
			ahvAnmeldung.getAngestellteUebLohnSeit());
		
		AngestellteDto manager = null;
		if (ahvAnmeldung.getAngestellteGiLohnSumme() != null) {
			manager = new AngestellteDto(
				ahvAnmeldung.getAngestellteGiAnz(), ahvAnmeldung.getAngestellteGiLohnSumme(),
				getTranslation(ahvAnmeldung.getAngestellteGiHatKinder(), lang),
				ahvAnmeldung.getAngestellteGiLohnSeit());
		}

		AngestellteDto family = null;
		if (ahvAnmeldung.getAngestellteAngLohnSumme() != null) {
			family = new AngestellteDto(
				ahvAnmeldung.getAngestellteAngAnz(), ahvAnmeldung.getAngestellteAngLohnSumme(),
				getTranslation(ahvAnmeldung.getAngestellteAngHatKinder(), lang),
				ahvAnmeldung.getAngestellteAngLohnSeit());
		}

		AngestellteDto partner = null;
		if (CollectionUtils.isNotEmpty(ahvAnmeldung.getAhvTeilhabers())) {
			for (AhvTeilhaberEntity ahvTeilhaber : ahvAnmeldung.getAhvTeilhabers()) {
				if (ahvTeilhaber.getPartnerLohnSumme() != null) {
					partner = new AngestellteDto(
						null, ahvTeilhaber.getPartnerLohnSumme(),
						getTranslation(ahvTeilhaber.getPartnerHatKinder(), lang),
						ahvTeilhaber.getPartnerLohnSeit());
					break;
				}
			}
		}
		
		List<String> lohnbuchhaltung = new ArrayList<>();
		if (BooleanUtils.isTrue(ahvAnmeldung.getLohnbuchPapier())) {
			lohnbuchhaltung.add(applicationService.getTranslation("gui_labels.ahvLohnbuch.papier", lang));
		}
		if (BooleanUtils.isTrue(ahvAnmeldung.getLohnbuchComputer())) {
			lohnbuchhaltung.add(applicationService.getTranslation("gui_labels.ahvLohnbuch.computer", lang));
		}
		if (BooleanUtils.isTrue(ahvAnmeldung.getLohnbuchSuva())) {
			lohnbuchhaltung.add(applicationService.getTranslation("gui_labels.ahvLohnbuch.suva", lang));
		}
		if (BooleanUtils.isTrue(ahvAnmeldung.getLohnbuchTreuhaender())) {
			lohnbuchhaltung.add(applicationService.getTranslation("gui_labels.ahvLohnbuch.treuhaender", lang));
		}
		String nameVersicherungBVG = StringUtils.EMPTY;
		String begrundung = StringUtils.EMPTY;
		if (BooleanUtils.isTrue(ahvAnmeldung.getSozialversBvg())) {
			nameVersicherungBVG = ahvAnmeldung.getSozialversBvgName();
		} else {
			nameVersicherungBVG = getTranslation(Boolean.FALSE, lang);
			nameVersicherungBVG = nameVersicherungBVG + StringUtils.SPACE + "(" + ahvAnmeldung.getSozialversBvgGrund()
				+ ")";
			begrundung = ahvAnmeldung.getSozialversBvgGrund();
		}
		if (!lohnbuchhaltung.isEmpty()) {
			StringUtils.join(lohnbuchhaltung, " / ");
			return new AngestellteBuchhaltungBVGDto(manager, employee, family, partner, nameVersicherungBVG, begrundung, StringUtils.join(lohnbuchhaltung, " / "));
		}
		return new AngestellteBuchhaltungBVGDto(manager, employee, family, partner, nameVersicherungBVG, begrundung, "-");
	}
	
	private String getTranslation(Boolean value, SupportedLanguage lang) {
		if (BooleanUtils.isTrue(value)) {
			return applicationService.getTranslation("gui_labels.common.yes", lang).toUpperCase();
		}
		return applicationService.getTranslation("gui_labels.common.no", lang).toUpperCase();
	}
	
	private SelbsteinschatzungDto dataForSelbsteinschatzung(AhvAnmeldungEntity ahvAnmeldung, AhvTeilhaberEntity ahvTeilhaber) {
		PflichtenabklaerungenEntity pflichtenabklaerungen = ahvAnmeldung.getProzess().getOrganisation().getPflichtenabklaerungen();
		return new SelbsteinschatzungDto(
			ahvTeilhaber.getEinkommenEinkommen(),
			ahvAnmeldung.getKapitalEigen(),
			ahvAnmeldung.getKapitalDarlehen(),
			pflichtenabklaerungen.getEroeffnungsdatum(),
			pflichtenabklaerungen.getEroeffnungsdatum().plusMonths(TAETIGKEIT_MONTH_PLUS));
	}
	
	private PersonlicheAngabenDto dataForPersonlicheAngaben(AhvTeilhaberEntity ahvTeilhaber, SupportedLanguage language) {
		PersonEntity person = ahvTeilhaber.getPerson();
		AdresseEntity wohnadresse = person.getWohnadresse();

		PersonlicheAngabenDto personlicheAngaben = new PersonlicheAngabenDto();
		personlicheAngaben.setAddress(person.getAnrede().getStandardText().textTranslation(language));
		personlicheAngaben.setName(person.getFamilienname());
		personlicheAngaben.setGivenName(person.getVorname());
		personlicheAngaben.setDateOfBirth(person.getGeburtsdatum());
		personlicheAngaben.setAhv(person.getAhvNummer());
		personlicheAngaben.setMaritalStatus(person.getZivilstand().getStandardText().textTranslation(language));
		personlicheAngaben.setChildren(getTranslation(ahvTeilhaber.getBisherHatKinder(), language));
		if (CollectionUtils.isNotEmpty(person.getHeimatortes())) {
			String placeOfOrigin = StringUtils.join(person.getHeimatortes()
				.stream()
				.map(h -> h.getPolGemeinde() + " (" + h.getKanton() + ")")
				.collect(Collectors.toSet()), ", ");
			personlicheAngaben.setPlaceOfOrigin(placeOfOrigin);
		}
		if (CollectionUtils.isNotEmpty(person.getNationalitaetens())) {
			String nationalities = StringUtils.join(person.getNationalitaetens()
				.stream()
				.map(n -> n.getStandardText().textTranslation(language))
				.collect(Collectors.toSet()), ", ");
			personlicheAngaben.setNationalities(nationalities);
		}
		personlicheAngaben.setResidence(convertToAddressDto(wohnadresse, language));
		if(wohnadresse != null) {
			personlicheAngaben.setPhone(wohnadresse.getTelefon());
		}
		if (ahvTeilhaber.getBisherBeitragAls() != null) {
			CodeWertEntity bisherBeitragAls = getCodeWert(ahvTeilhaber.getBisherBeitragAls(), KategorieEnum.AHV_BEITRAG_ALS);
			personlicheAngaben.setPrevOccupation(bisherBeitragAls.getStandardText().textTranslation(language));
			personlicheAngaben.setPrevIncome(ahvTeilhaber.getBisherEinkommen());
		}
		personlicheAngaben.setPrevCompensation(ahvTeilhaber.getBisherAk());
		personlicheAngaben.setFrom(ahvTeilhaber.getBisherVon());
		personlicheAngaben.setTo(ahvTeilhaber.getBisherBis());
		if (ahvTeilhaber.getMitarbeit() != null) {
			personlicheAngaben.setMitarbeit(ahvTeilhaber.getMitarbeit().name());
		}
		personlicheAngaben.setMitarbeitRolle(ahvTeilhaber.getMitarbeitRolle());
		personlicheAngaben.setMitarbeitBezeichnung(ahvTeilhaber.getMitarbeitBezeichnung());
		personlicheAngaben.setMitarbeitName(ahvTeilhaber.getMitarbeitName());
		personlicheAngaben.setMitarbeitStrasse(ahvTeilhaber.getMitarbeitStrasse());
		personlicheAngaben.setMitarbeitPlzOrt(ahvTeilhaber.getMitarbeitPlzOrt());
		if (ahvTeilhaber.getBisherBerufVerbandId() != null) {
			VerbandEntity verband = getVerbandById(ahvTeilhaber.getBisherBerufVerbandId());
			personlicheAngaben.setUnion(verband.getStandardText().textTranslation(language));
		}
		if (ahvTeilhaber.getBisherVerbandAkId() != null) {
			AusgleichskasseEntity ausgleichskasse = getAusgleichskass(ahvTeilhaber.getBisherVerbandAkId());
			personlicheAngaben.setVak(ausgleichskasse.getStandardText().textTranslation(language));
		}
		
		return personlicheAngaben;
	}
	
	private AuftrageKundenDto dataForAuftrageKunden(AhvAnmeldungEntity ahvAnmeldung) {
		StringBuilder builder = new StringBuilder("");
		if (ahvAnmeldung.getTaetigKunde1() != null) {
			builder.append(ahvAnmeldung.getTaetigKunde1());
		}
		if (ahvAnmeldung.getTaetigKunde2() != null) {
			builder.append(", ").append(ahvAnmeldung.getTaetigKunde2());
		}
		if (ahvAnmeldung.getTaetigKunde3() != null) {
			builder.append(", ").append(ahvAnmeldung.getTaetigKunde3());
		}
		String names = builder.toString();
		return new AuftrageKundenDto(ahvAnmeldung.getTaetigAnzKunden(), names, ahvAnmeldung.getTaetigArtAuftraege(), ahvAnmeldung.getTaetigDatumLetzterAuftrag());
	}
	
	private ErwerbsUndSelbstkostenDto dataForErwerbsUndSelbstkosten(AhvTeilhaberEntity ahvTeilhaber, SupportedLanguage lang) {
		ErwerbsUndSelbstkostenDto erwerbsUndSelbstkosten = new ErwerbsUndSelbstkostenDto();
		erwerbsUndSelbstkosten.setRisk(ahvTeilhaber.getLastenRisiko());
		erwerbsUndSelbstkosten.setWage(getTranslation(ahvTeilhaber.getLastenLohnanspruch(), lang));
		erwerbsUndSelbstkosten.setCost(getTranslation(ahvTeilhaber.getLastenUnkosten(), lang));
		erwerbsUndSelbstkosten.setMaintenance(getTranslation(ahvTeilhaber.getLastenUnterhalt(), lang));
		erwerbsUndSelbstkosten.setFaults(getTranslation(ahvTeilhaber.getLastenGarantie(), lang));
		erwerbsUndSelbstkosten.setMaterial(getTranslation(ahvTeilhaber.getLastenMaterial(), lang));
		erwerbsUndSelbstkosten.setLoss(getTranslation(ahvTeilhaber.getLastenVerluste(), lang));
		erwerbsUndSelbstkosten.setCollection(getTranslation(ahvTeilhaber.getLastenInkassorisiko(), lang));
		erwerbsUndSelbstkosten.setTypeOfCompensation(getTypeOfCompensation(ahvTeilhaber, lang));
		return erwerbsUndSelbstkosten;
	}
	
	/**
	 * @param ahvTeilhaber
	 * @return
	 */
	private String getTypeOfCompensation(AhvTeilhaberEntity ahvTeilhaber, SupportedLanguage lang) {
		ArrayList<String> typeOfCompensation = new ArrayList<String>();
		
		if (BooleanUtils.isTrue(ahvTeilhaber.getEinkommenRechnung())) {
			typeOfCompensation.add(applicationService.getTranslation("gui_labels.ahvPdf.einkommenRechnung", lang));
		}
		if (BooleanUtils.isTrue(ahvTeilhaber.getEinkommenLohn())) {
			typeOfCompensation.add(applicationService.getTranslation("gui_labels.ahvPdf.einkommenLohn", lang));
		}
		if (BooleanUtils.isTrue(ahvTeilhaber.getEinkommenProvision())) {
			typeOfCompensation.add(applicationService.getTranslation("gui_labels.ahvPdf.einkommenProvision", lang));
		}
		return StringUtils.join(typeOfCompensation, " / ");
	}

	private ArbeitsorganisationDto dataForArbeitsorganisation(AhvAnmeldungEntity ahvAnmeldung, AhvTeilhaberEntity ahvTeilhaber, SupportedLanguage lang) {
		ArbeitsorganisationDto arbeitsorganisation = new ArbeitsorganisationDto();
		arbeitsorganisation.setIsAgent(getTranslation(ahvAnmeldung.getTaetigAgent() , lang));
		arbeitsorganisation.setEmployer(ahvAnmeldung.getTaetigAuftraggeber());
		arbeitsorganisation.setProvision(getTranslation(ahvTeilhaber.getEinkommenProvision(), lang));
		arbeitsorganisation.setWage(getTranslation(ahvTeilhaber.getEinkommenLohn(), lang));
		if (ahvTeilhaber.getAoaName() == AhvNamenEnum.EIGENER) {
			arbeitsorganisation.setOwnName(getTranslation(Boolean.TRUE, lang));
		} else {
			arbeitsorganisation.setOwnName(getTranslation(Boolean.FALSE, lang));
		}
		RoomDto room = new RoomDto(
			getTranslation(ahvAnmeldung.getRaumEigene(), lang),
			getTranslation(ahvAnmeldung.getRaumWohnung(), lang),
			getTranslation(ahvAnmeldung.getRaumKunde(), lang),
			getTranslation(ahvAnmeldung.getRaumKeine(), lang)
		);
		arbeitsorganisation.setRoom(room);
		arbeitsorganisation.setDirectives(getTranslation(ahvTeilhaber.getAoaWeisung(), lang));
		arbeitsorganisation.setNonCompetition(getTranslation(ahvTeilhaber.getAoaKonkurrenzverbot(), lang));
		arbeitsorganisation.setPersonally(getTranslation(ahvTeilhaber.getAoaPersoenlich(), lang));
		arbeitsorganisation.setStationery(getTranslation(ahvTeilhaber.getAoaBriefpapier(), lang));
		arbeitsorganisation.setAds(getTranslation(ahvTeilhaber.getAoaWerbung(), lang));
		arbeitsorganisation.setOffers(getTranslation(ahvTeilhaber.getAoaOfferten(), lang));
		arbeitsorganisation.setBills(getTranslation(ahvTeilhaber.getAoaRechnungen(), lang));
		arbeitsorganisation.setDiscount(getTranslation(ahvTeilhaber.getAoaRabatte(), lang));
		arbeitsorganisation.setAfterSales(getTranslation(ahvTeilhaber.getAoaKundendienst(), lang));
		return arbeitsorganisation;
	}
	
	private CompanyDto dataForCompany(AhvAnmeldungEntity ahvAnmeldung, AhvTeilhaberEntity ahvTeilhaber) {
		String companyName = ahvAnmeldung.getProzess().getOrganisation().defaultName();
		String givenName = ahvTeilhaber.getPerson().getVorname();
		String name = ahvTeilhaber.getPerson().getFamilienname();
		return new CompanyDto(companyName, givenName, name);
	}
	
	private List<AhvTeilhaberDetailDto> dataForAhvTeilhabers(AhvAnmeldungEntity ahvAnmeldung, AusgleichskasseDto ak, SupportedLanguage language) {
		return ahvAnmeldung.getAhvTeilhabers()
			.stream()
			.map(t -> {
				AhvTeilhaberDetailDto teilhaberDetail = new AhvTeilhaberDetailDto();
				teilhaberDetail.setAk(ak);
				teilhaberDetail.setCost(dataForErwerbsUndSelbstkosten(t, language));
				teilhaberDetail.setFin(dataForFinanzielle(t));
				teilhaberDetail.setOc(new ErwerbstatigkeitDto(t.getMitarbeitStaaten()));
				teilhaberDetail.setOrg(dataForArbeitsorganisation(ahvAnmeldung, t, language));
				teilhaberDetail.setPart(dataForCompany(ahvAnmeldung, t));
				teilhaberDetail.setPi(dataForPersonlicheAngaben(t, language));
				teilhaberDetail.setSb(dataForSelbsteinschatzung(ahvAnmeldung, t));
				teilhaberDetail.setDate(dataForDate(language));
				teilhaberDetail.setCust(dataForAuftrageKunden(ahvAnmeldung));
				return teilhaberDetail;
			})
			.collect(Collectors.toList());
	}
	
	private List<GesellschafterDto> dataForOwners(AhvAnmeldungEntity ahvAnmeldung, SupportedLanguage language) {
		return ahvAnmeldung.getProzess().getOrganisation().getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC)
			.stream()
			.map(g -> {
				String givenName = g.getPerson().getVorname();
				String name = g.getPerson().getFamilienname();
				String city = g.getPerson().getWohnadresse().getOrt();
				String liability = g.getHaftung().getStandardText().textTranslation(language);
				return new GesellschafterDto(givenName, name, city, liability);
			})
			.collect(Collectors.toList());
	}

	private AddressDto convertToAddressDto(AdresseEntity address, SupportedLanguage language) {
		if (address == null) {
			return null;
		}
		return convertAddressToDocumentDto(address, language);
//		return new AddressDto(
//			address.getEmpfaenger(),
//			address.getStrasse(),
//			address.getHausnummer(),
//			address.getPlz(),
//			address.getOrt(),
//			address.getTelefon(),
//			address.getBfsNr(),
//			address.getEmail());
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public AhvAnmeldungEntity createAhvTeilhaber(GeschaftsrolleEntity geschaftsrolle) {
		if(geschaftsrolle.getTyp() != GeschaeftsrolleTypEnum.EDC) {
			return null;
		}

		boolean isExstingAhvTeilhaber = new JPAQuery<AhvTeilhaberEntity>(em)
				.from(QAhvTeilhaberEntity.ahvTeilhaberEntity)
				.where(QAhvTeilhaberEntity.ahvTeilhaberEntity.person.id.eq(geschaftsrolle.getPerson().getId()))
				.fetchCount() > 0;

		if(isExstingAhvTeilhaber) {
			return null;
		}

		AhvAnmeldungEntity ahvEntity = getByOrganisationId(geschaftsrolle.getOrganisation().getId());
		ahvEntity.getAhvTeilhabers().add(new AhvTeilhaberEntity(ahvEntity, geschaftsrolle.getPerson()));
		return ahvRepository.save(ahvEntity);
	}

	@Override
	public AhvAnmeldungEntity getByOrganisationId(long orgId) {
		AhvAnmeldungEntity ahvAnmeldung = new JPAQuery<AhvAnmeldungEntity>(em)
				.from(QAhvAnmeldungEntity.ahvAnmeldungEntity)
				.where(QAhvAnmeldungEntity.ahvAnmeldungEntity.prozess.organisation.id.eq(orgId))
				.fetchOne();
			if (ahvAnmeldung == null) {
				return null;
			}
			
			// TODO [HHG, S9]: try to test lazy load, remove this
			if (ahvAnmeldung.getAdresseTreuhand() != null) {
				ahvAnmeldung.getAdresseTreuhand().getLand().getId();
			}

			jpaUtil.initialize(ahvAnmeldung,
					QAhvAnmeldungEntity.ahvAnmeldungEntity.prozess.flowHistory.items.any().data,
					QAhvAnmeldungEntity.ahvAnmeldungEntity.adresseKontakt.land,
					QAhvAnmeldungEntity.ahvAnmeldungEntity.adresseTreuhand.land,
					QAhvAnmeldungEntity.ahvAnmeldungEntity.prozess.statuswechsels,
					QAhvAnmeldungEntity.ahvAnmeldungEntity.ahvFiliales.any().geschaeftsstelle.adresse);

			jpaUtil.initialize(ahvAnmeldung.getProzess().getOrganisation(),
					QOrganisationEntity.organisationEntity.pflichtenabklaerungen,
					QOrganisationEntity.organisationEntity.kontens,
					QOrganisationEntity.organisationEntity.geschaeftsrollens.any().haftung.standardText.translations,
					QOrganisationEntity.organisationEntity.geschaeftsrollens.any().person,
					QOrganisationEntity.organisationEntity.domizil,
					QOrganisationEntity.organisationEntity.branches.any().standardText.translations,
					QOrganisationEntity.organisationEntity.geschaeftsstellens.any().adresse,
					QOrganisationEntity.organisationEntity.namens,
					QOrganisationEntity.organisationEntity.flowHistory.items.any().data
				);
			
			jpaUtil.initialize(ahvAnmeldung.getProzess().getOrganisation().getDomizil().getLand(), QCodeWertEntity.codeWertEntity.standardText.translations);
			
			ahvAnmeldung.getProzess().getOrganisation().getGeschaeftsrollens(GeschaeftsrolleTypEnum.EDC).stream().forEach(item -> {
				jpaUtil.initialize(item, 
					QGeschaftsrolleEntity.geschaftsrolleEntity.funktion.standardText.translations,
					QGeschaftsrolleEntity.geschaftsrolleEntity.zeichnung.standardText.translations
				);
				initPersonEntity(item.getPerson());
			});
			
			for (AhvTeilhaberEntity item : ahvAnmeldung.getAhvTeilhabers()) {
				initPersonEntity(item.getPerson());
				jpaUtil.initialize(item.getPartner(), QPersonEntity.personEntity.anrede.standardText.translations);
			}

			if (ahvAnmeldung.getProzess().getOrganisation().getRechtsform() == RechtsformEnum.KOMMGES) {
				jpaUtil.initialize(ahvAnmeldung.getProzess().getOrganisation(), 
						QOrganisationEntity.organisationEntity.kommGes.kommFirmas.any().domizil,
						QOrganisationEntity.organisationEntity.kommGes.kommFirmas.any().einlage.standardText.translations);
			}
			return ahvAnmeldung;
	}
	
	private void initPersonEntity(PersonEntity person) {
		jpaUtil.initialize(person, 
				QPersonEntity.personEntity.wohnadresse.land,
				QPersonEntity.personEntity.heimatortes,
				QPersonEntity.personEntity.auslaenderAusweis.standardText.translations,
				QPersonEntity.personEntity.anrede.standardText.translations,
				QPersonEntity.personEntity.zivilstand.standardText.translations,
				QPersonEntity.personEntity.nationalitaetens.any().standardText.translations
		);
		
		jpaUtil.initialize(person.getWohnadresse().getLand(), QCodeWertEntity.codeWertEntity.standardText.translations);
	}

	@Override
	public AhvAnmeldungEntity updateProcess(AhvAnmeldungEntity entity) {
		processUpdated(entity.getProzess());
		return ahvRepository.save(entity);
	}

	@Override
	public AhvAnmeldungEntity completeProcess(AhvAnmeldungEntity entity) {
		processCompleted(entity);
		return ahvRepository.save(entity);
	}

	@Override
	public AhvAnmeldungEntity lockProcess(AhvAnmeldungEntity entity) {
		processLocked(entity, true);
		sendNotificationEmail(entity);
		return ahvRepository.save(entity);
	}
	
	private void sendNotificationEmail(AhvAnmeldungEntity ahvAnmeldung) {
		String organisationName = ahvAnmeldung.getProzess().getOrganisation().defaultName();
		AusgleichskasseEntity ausgleichskasse = getAusleichskasse(ahvAnmeldung);
		SupportedLanguage language = findRecipientSupportedLanguage(ausgleichskasse);
		MailMessage message = new MailMessage();
		message.setFrom(helpdeskEmail);
		message.setTo(SecurityUtil.currentUser().getEmail());
		if (ccToAusgleichskasse) {
			message.setCc(ausgleichskasse.getEmail());
			message.getTemplateModel().put("ausgleichskasseEmail", "");
		} else {
			// For test only, ensure we use the right CC email
			message.getTemplateModel().put("ausgleichskasseEmail", ausgleichskasse.getEmail());
		}
		message.getTemplateModel().put("organisationName", organisationName);
		// SECOOSS-401 : AHV registration and HR registration email attachment is missing
		message.getAttachmentDatas().put("ahv.pdf", ahvAnmeldung.getProzess().getPdf());
		message.setSubject(applicationService.getTranslation("gui_labels.ahv.email.subject", language));
		switch (language) {
			case EN:
				message.setTemplateName("ahv-mail-template-en.ftl");
				break;
			case FR:
				message.setTemplateName("ahv-mail-template-fr.ftl");
				break;
			case IT:
				message.setTemplateName("ahv-mail-template-it.ftl");
				break;
			case DE:
				message.setTemplateName("ahv-mail-template-de.ftl");
				break;
			default:
				throw new IllegalArgumentException("Unsupported language " + language);
		}
		mailUtil.send(message);
	}

	@Override
	public AhvAnmeldungEntity signProcess(AhvAnmeldungEntity entity) {
		processSigned(entity.getProzess());
		return ahvRepository.save(entity);
	}

	@Override
	public AhvAnmeldungEntity relockProcess(AhvAnmeldungEntity entity) {
		processLocked(entity, false);
		return ahvRepository.save(entity);
	}

	@Override
	public void markProcessExternal(ProzessEntity prozess, boolean external) {
		processExternIntern(prozess, external);
	}

	@Override
	public List<AdresseEntity> getAhvAdresseKontaktByOrgId(long orgId) {
		return new JPAQuery<AhvAnmeldungEntity>(em)
			.from(QAhvAnmeldungEntity.ahvAnmeldungEntity)
			.join(QAhvAnmeldungEntity.ahvAnmeldungEntity.adresseKontakt).fetchJoin()
			.where(QAhvAnmeldungEntity.ahvAnmeldungEntity.prozess.organisation.id.eq(orgId)
				.and(QAhvAnmeldungEntity.ahvAnmeldungEntity.adresseKontakt.land.code.eq(OSSConstants.SWISS_CODE_WERT)))
			.fetch()
			.stream()
			.map(a -> a.getAdresseKontakt())
			.collect(Collectors.toList());
	}

	@Override
	protected ProzessTypEnum getProcessType() {
		return ProzessTypEnum.AHV;
	}

	@Override
	public AhvAnmeldungEntity updateProcess(long orgId, AhvAnmeldungEntity entity) {
		throw new UnsupportedOperationException("Not use in UVG process");
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public ProzessStatusEnum getProcessStatusByOrgId(long orgId) {
		return getProcessStatus(orgId);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public VerbandEntity getVerbandById(long verbandId) {
		VerbandEntity verband = new JPAQuery<VerbandEntity>(em)
			.from(QVerbandEntity.verbandEntity)
			.where(QVerbandEntity.verbandEntity.id.eq(verbandId))
			.fetchOne();
		
		jpaUtil.initialize(verband, QVerbandEntity.verbandEntity.standardText.translations,
			QVerbandEntity.verbandEntity.ausgleichskasse.standardText.translations);
		
		return verband;
	}

}
