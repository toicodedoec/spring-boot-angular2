/*
 * GenerateDataTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.performance.process;

import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import ch.admin.oss.ahv.repository.IKontoRepository;
import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.application.service.ICacheService;
import ch.admin.oss.common.IProcessService;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.domain.IProzessEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.performance.DataHelper;

/**
 * @author hha
 */
public abstract class ProcessGenerator<T extends IProzessEntity, S extends IProcessService<T>> {

	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessGenerator.class);

	protected static byte[] PDF_DATA;
	static {
		try {
			PDF_DATA = IOUtils.toByteArray(ProcessGenerator.class.getClassLoader().getResourceAsStream("hr_pdf.pdf"));
		} catch (IOException e) {
			LOGGER.error("Cannot convert pdf to byte array", e);
		}
	}

	@Autowired
	protected S service;

	@Autowired
	protected ICacheService cacheService;
	@Autowired
	protected IApplicationService applicationService;
	@Autowired
	protected DataHelper dataHelper;
	@Autowired
	protected IKontoRepository kontoRepository;

	public OrganisationEntity generate(OrganisationEntity organisation) {
		T entity = service.getByOrganisationId(organisation.getId());
		generate(entity);

		if (entity.getProzess().getTyp() != ProzessTypEnum.MWST) {
			entity.getProzess().setPdf(PDF_DATA);
		}
		return organisation;
	}

	protected abstract T generate(T entity);

	protected abstract ProzessTypEnum getProcessType();

}
