/*
 * DetailledResponseDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.zefix;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author hhg
 *
 */
public class DetailledResponseDto implements Serializable {

	private static final long serialVersionUID = -6717071957378410519L;

	private List<CompanyDetailedInfoDto> companyDetailedInfo = new ArrayList<>();

	public List<CompanyDetailedInfoDto> getCompanyDetailedInfo() {
		return companyDetailedInfo;
	}

	public void setCompanyDetailedInfo(List<CompanyDetailedInfoDto> companyDetailedInfo) {
		this.companyDetailedInfo = companyDetailedInfo;
	}
}
