/*
 * CodeWertDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.util.Optional;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.TextTranslationEntity;

/**
 * @author hhg
 *
 */
public class CodeWertDto extends AbstractOSSDto {

	@NotNull
	private String code;

	@NotNull
	private KategorieEnum kategorie;

	@NotNull
	private boolean aktiv;

	@Min(1)
	@NotNull
	private int pos;

	@NotNull
	private String textDE;

	@NotNull
	private String textEN;

	@NotNull
	private String textFR;

	@NotNull
	private String textIT;

	private String text;

	public CodeWertDto() {}

	public CodeWertDto(CodeWertEntity entity, SupportedLanguage language) {
		setId(entity.getId());
		setVersion(entity.getVersion());
		code = entity.getCode();
		
		Optional<TextTranslationEntity> textTranslation = entity.getStandardText().getTranslations().stream()
			.filter(t -> t.getLanguage() == language).findFirst();
		
		if (textTranslation.isPresent()) {
			text = textTranslation.get().getText();
		}		
		kategorie = entity.getKategorie();
		aktiv = entity.isAktiv();
		pos = entity.getPos();
		
		entity.getStandardText().getTranslations().stream().forEach(t -> {
			if(t.getLanguage() == SupportedLanguage.DE) {
				textDE = t.getText();
			}
			if(t.getLanguage() == SupportedLanguage.EN) {
				textEN = t.getText();
			}
			if(t.getLanguage() == SupportedLanguage.FR) {
				textFR = t.getText();
			}
			if(t.getLanguage() == SupportedLanguage.IT) {
				textIT = t.getText();
			}			
		});
	}
	
	public boolean isAktiv() {
		return aktiv;
	}

	public void setAktiv(boolean aktiv) {
		this.aktiv = aktiv;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}	

	public KategorieEnum getKategorie() {
		return kategorie;
	}

	public void setKategorie(KategorieEnum kategorie) {
		this.kategorie = kategorie;
	}

	public String getTextDE() {
		return textDE;
	}

	public void setTextDE(String textDE) {
		this.textDE = textDE;
	}

	public String getTextEN() {
		return textEN;
	}

	public void setTextEN(String textEN) {
		this.textEN = textEN;
	}

	public String getTextFR() {
		return textFR;
	}

	public void setTextFR(String textFR) {
		this.textFR = textFR;
	}

	public String getTextIT() {
		return textIT;
	}

	public void setTextIT(String textIT) {
		this.textIT = textIT;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}
	
	
}
