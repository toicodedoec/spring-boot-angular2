/*
 * CHOrtHRAmtEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

/**
 *  
 * @author coh
 */
@Entity
@Table(name = "T_CH_ORT_HR_AMT", 
	uniqueConstraints = {
		@UniqueConstraint(name = "UK_CH_ORT_HR_AMT", columnNames = {"BFSNR"})
})
public class CHOrtHRAmtEntity extends AbstractOSSEntity {
	
	@Column(name = "BFSNR")
	private int bfsnr;

	@Column(name = "HRAMTNR")
	private int hramtNr;

	public int getBfsnr() {
		return bfsnr;
	}

	public int getHramtNr() {
		return hramtNr;
	}
}
