/*
 * MwstFristverlangerungEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.QuarSemEnum;

/**
 * @author hhg
 *
 */
@Entity
@Table(name = "T_MWST_FRISTVERLANGERUNG")
public class MwstFristverlangerungEntity extends AbstractOSSEntity {

	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name="FK_MWST_FRIST_PROZESS"))
	private ProzessEntity prozess;
	
	/**
	 * Company UID
	 */
	@NotNull
	@Column(name = "MWSTNR")
	private String mwstNr;
	
	/**
	 * "Quartals- oder Semesterabrechnung". Possible values: Q (quarterly) or S (semestrial)
	 */
	@NotNull
	@Column(name = "QUARSEM", nullable = false)
	@Enumerated(EnumType.STRING)
	private QuarSemEnum quarSem;
	
	@NotNull
	@Column(name = "FRIST")
	private String frist;
	
	/**
	 * Company name
	 */
	@NotNull
	@Column(name = "NAME")
	private String name;
	
	/**
	 * City of company domicil
	 */
	@NotNull
	@Column(name = "ORT")
	private String ort;
	
	/**
	 * Phone number and/or name of a contact person
	 */
	@NotNull
	@Column(name = "KONTAKT")
	private String kontakt;
	
	/**
	 * Mail address of a contact person
	 */
	@NotNull
	@Column(name = "EMAIL")
	private String email;
	
	public MwstFristverlangerungEntity() {
		prozess = new ProzessEntity(ProzessTypEnum.MWST_FRISTVERLAENGERUNG, false);
	}

	public ProzessEntity getProzess() {
		return prozess;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	public String getMwstNr() {
		return mwstNr;
	}

	public void setMwstNr(String mwstNr) {
		this.mwstNr = mwstNr;
	}

	public QuarSemEnum getQuarSem() {
		return quarSem;
	}

	public void setQuarSem(QuarSemEnum quarSem) {
		this.quarSem = quarSem;
	}

	public String getFrist() {
		return frist;
	}

	public void setFrist(String frist) {
		this.frist = frist;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getKontakt() {
		return kontakt;
	}

	public void setKontakt(String kontakt) {
		this.kontakt = kontakt;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
