/*
 * ValidationUtil
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDate;
import java.time.temporal.IsoFields;
import java.util.Base64;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import ch.admin.oss.common.OssTechnicalException;

/**
 * @author xdg
 */
public class ValidationUtil {
	
	private static final int WEIGHT_FOR_MEN = 100;
	private static final int WEIGHT_PLUS_FOR_WOMEN = 400;
	private static final String CH_COUNTRY_CODE = "756";
	private static final String DEFAULT_DUMMY_AHV_NUMBER = "999.99.999.999";
	private static final String NEW_PATTERN_AHV_NUMBER = "^756\\.[0-9]{4}\\.[0-9]{4}\\.[0-9]{2}$";
	
	private static final Pattern NEW_AHV_NUMBER_PATTERN = Pattern.compile(NEW_PATTERN_AHV_NUMBER);
	
	/**
	 * Check whether this is a valid ahv number.
	 * @param ahvNumber
	 * @param geburtsdatum
	 * @param isMale
	 * @return boolean
	 */
	public static boolean isValidAhvNumber(String ahvNumber, LocalDate geburtsdatum, boolean isMale) {
		if (StringUtils.isEmpty(ahvNumber)) {
			return false;
		}

		if (DEFAULT_DUMMY_AHV_NUMBER.equals(ahvNumber)) {
			return true;
		} else {
			String[] ahvParts = ahvNumber.split("\\.");
			char[] digits = ahvNumber.replaceAll("\\.", "").toCharArray();
			int sumOfProduct = 0;

			// validate for the new pattern of AHV number
			if (NEW_AHV_NUMBER_PATTERN.matcher(ahvNumber).find()) {
				// validate the first block
				if (!CH_COUNTRY_CODE.equals(ahvParts[0])) {
					return false;
				}

				// validate the last digit: the last digit must be an EAN13 checksum of the first 12 digits
				// calculate the EAN13 checksum of the first 12 digits based on the weight values of AHV new pattern
				int[] weights = {1, 3, 1, 3, 1, 3, 1, 3, 1, 3, 1, 3};
				for (int i = 0; i < digits.length - 1; i++) {
					sumOfProduct += Integer.valueOf(String.valueOf(digits[i])) * weights[i];
				}
				int difference = 0;
				if (sumOfProduct % 10 != 0) {
					difference = 10 - sumOfProduct % 10;
				}

				// check whether the last digit equals to the EAN13 checksum of the first 12 digits
				return (Integer.valueOf(String.valueOf(digits[12])) == difference);
			} else { // validate for the old pattern of AHV number
				// validate the second block: it must be the last two digits of the year of birth (eg. 56 for 1956)
				String year = String.valueOf(geburtsdatum.getYear());
				if (!ahvParts[1].equals(year.substring(year.length() - 2, year.length()))) {
					return false;
				}

				// validate the third block: it must be the value that encodes the gender and day and month of birth
				int ahvCalendar = geburtsdatum.get(IsoFields.QUARTER_OF_YEAR) * WEIGHT_FOR_MEN
					+ geburtsdatum.get(IsoFields.DAY_OF_QUARTER);
				ahvCalendar += isMale ? 0 : WEIGHT_PLUS_FOR_WOMEN;
				if (!ahvParts[2].equals(String.valueOf(ahvCalendar))) {
					return false;
				}

				// validate the last digit: it must be the checksum calculated by the "modulo 11" algorithm for the
				// first 12 digits
				int[] weights = {5, 4, 3, 2, 7, 6, 5, 4, 3, 2};
				for (int i = 0; i < digits.length - 1; i++) {
					sumOfProduct += Integer.valueOf(String.valueOf(digits[i])) * weights[i];
				}

				// check whether the last digit equals to the checksum of the first 12 digits
				return (Integer.valueOf(String.valueOf(digits[10])) == (11 - sumOfProduct % 11));
			}
		}
	}
	
	/**
	 * Check whether originalPassword equals to encodedPassword
	 * @param originalPassword
	 * @param encodedPassword
	 * @param salt
	 * @return true/false
	 * @throws NoSuchAlgorithmException
	 */
	public static boolean isValidStartBizPassword(String originalPassword, String encodedPassword, String salt) {
		try {
			MessageDigest digest;

			digest = MessageDigest.getInstance("SHA-512");

			digest.update(Base64.getDecoder().decode(salt));
			byte[] buf = digest.digest(originalPassword.getBytes());

			int N = buf.length;
			StringBuffer s = new StringBuffer(2 * N);
			for (int i = 0; i < N; i++) {
				s.append(Character.forDigit((buf[i] & 0xF0) >> 4, 16));
				s.append(Character.forDigit(buf[i] & 0xF, 16));
			}

			return s.toString().equals(encodedPassword);
		} catch (NoSuchAlgorithmException e) {
			throw new OssTechnicalException(e);
		}
	}
}
