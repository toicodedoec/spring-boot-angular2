/*
 * StatuswechselEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

import ch.admin.oss.common.enums.ProzessStatusEnum;

/**
 * @author coh
 */
@Audited
@Entity
@Table(name = "T_STATUSWECHSEL")
public class StatuswechselEntity extends AbstractOSSEntity {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name = "FK_STATUSWECHSEL_PROZESS"))
	private ProzessEntity prozess;

	@NotNull
	@Column(name = "STATUS", nullable = false)
	@Enumerated(EnumType.STRING)
	private ProzessStatusEnum status;

	@Column(name = "ZEITSTEMPEL")
	private LocalDateTime zeitstempel;

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_USER", foreignKey = @ForeignKey(name = "FK_STATUSWECHSEL_USER"))
	private UserEntity user;

	public ProzessEntity getProzess() {
		return prozess;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	public ProzessStatusEnum getStatus() {
		return status;
	}

	public void setStatus(ProzessStatusEnum status) {
		this.status = status;
	}

	public LocalDateTime getZeitstempel() {
		return zeitstempel;
	}

	public void setZeitstempel(LocalDateTime zeitstempel) {
		this.zeitstempel = zeitstempel;
	}

	public UserEntity getUser() {
		return user;
	}

	public void setUser(UserEntity user) {
		this.user = user;
	}

}
