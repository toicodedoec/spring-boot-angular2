package ch.admin.oss.ahv.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.stereotype.Repository;

import ch.admin.oss.domain.AhvFilialeEntity;

@Repository
public interface IAhvFilialeRepository 
	extends JpaRepository<AhvFilialeEntity, Long>, QueryDslPredicateExecutor<AhvFilialeEntity> {

}
