/*
 * KmuAdminDataEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *  
 * @author coh
 */
@Entity
@Table(name = "T_KMU_ADMIN_DATA")
public class KmuAdminDataEntity extends AbstractOSSEntity {

	@Column(name = "OWNER")
	private String owner;
	
	@Column(name = "RECHTSFORM")
	private String rechtsform;
	
	@Column(name = "FIRMA", nullable = false)
	private String firma;
	
	@Column(name = "UEBERNOMMEN_FIRMA")
	private String uebernommenFirma;
	
	@Column(name = "BRANCHE")
	private String branche;
	
	@Column(name = "DATUM_EROEFFNUNG")
	private String datumEroeffnung;
	
	@Column(name = "DATUM_ERSTERECHNUNG")
	private String datumErsteRechnung;
	
	@Column(name = "DATUM_ERSTERAUFTRAG")
	private String datumErsterAuftrag;
	
	@Column(name = "STRASSE")
	private String strasse;
	
	@Column(name = "ORT")
	private String ort;
	
	@Column(name = "TELEFON")
	private String telefon;
	
	@Column(name = "MOBIL")
	private String mobil;
	
	@Column(name = "EMAIL")
	private String email;
	
	@Column(name = "INH_ANREDE")
	private String inhAnrede;
	
	@Column(name = "INH_NAME")
	private String inhName;
	
	@Column(name = "INH_VORNAME")
	private String inhVorname;
	
	@Column(name = "INH_STRASSE")
	private String inhStrasse;
	
	@Column(name = "INH_ORT")
	private String inhOrt;
	
	@Column(name = "INH_TELEFON")
	private String inhTelefon;
	
	@Column(name = "INH_MOBIL")
	private String inhMobil;
	
	@Column(name = "INH_EMAIL")
	private String inhEmail;
	
	@Column(name = "AHV")
	private String ahv;
	
	@Column(name = "DATUM_AHV")
	private String datumAhv;
	
	@Column(name = "MWST")
	private String mwst;
	
	@Column(name = "DATUM_MWST")
	private String datumMwst;
	
	@Column(name = "HR")
	private String hr;
	
	@Column(name = "DATUM_HR")
	private String datumHr;
	
	@Column(name = "SUVA")
	private String suva;
	
	@Column(name = "DATUM_SUVA")
	private String datumSuva;
	
	@Column(name = "ZEFIX_MATCH_UID")
	private String zefixMatchUID;

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(String rechtsform) {
		this.rechtsform = rechtsform;
	}

	public String getFirma() {
		return firma;
	}

	public void setFirma(String firma) {
		this.firma = firma;
	}

	public String getUebernommenFirma() {
		return uebernommenFirma;
	}

	public void setUebernommenFirma(String uebernommenFirma) {
		this.uebernommenFirma = uebernommenFirma;
	}

	public String getBranche() {
		return branche;
	}

	public void setBranche(String branche) {
		this.branche = branche;
	}

	public String getDatumEroeffnung() {
		return datumEroeffnung;
	}

	public void setDatumEroeffnung(String datumEroeffnung) {
		this.datumEroeffnung = datumEroeffnung;
	}

	public String getDatumErsteRechnung() {
		return datumErsteRechnung;
	}

	public void setDatumErsteRechnung(String datumErsteRechnung) {
		this.datumErsteRechnung = datumErsteRechnung;
	}

	public String getDatumErsterAuftrag() {
		return datumErsterAuftrag;
	}

	public void setDatumErsterAuftrag(String datumErsterAuftrag) {
		this.datumErsterAuftrag = datumErsterAuftrag;
	}

	public String getStrasse() {
		return strasse;
	}

	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getTelefon() {
		return telefon;
	}

	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	public String getMobil() {
		return mobil;
	}

	public void setMobil(String mobil) {
		this.mobil = mobil;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getInhAnrede() {
		return inhAnrede;
	}

	public void setInhAnrede(String inhAnrede) {
		this.inhAnrede = inhAnrede;
	}

	public String getInhName() {
		return inhName;
	}

	public void setInhName(String inhName) {
		this.inhName = inhName;
	}

	public String getInhVorname() {
		return inhVorname;
	}

	public void setInhVorname(String inhVorname) {
		this.inhVorname = inhVorname;
	}

	public String getInhStrasse() {
		return inhStrasse;
	}

	public void setInhStrasse(String inhStrasse) {
		this.inhStrasse = inhStrasse;
	}

	public String getInhOrt() {
		return inhOrt;
	}

	public void setInhOrt(String inhOrt) {
		this.inhOrt = inhOrt;
	}

	public String getInhTelefon() {
		return inhTelefon;
	}

	public void setInhTelefon(String inhTelefon) {
		this.inhTelefon = inhTelefon;
	}

	public String getInhMobil() {
		return inhMobil;
	}

	public void setInhMobil(String inhMobil) {
		this.inhMobil = inhMobil;
	}

	public String getInhEmail() {
		return inhEmail;
	}

	public void setInhEmail(String inhEmail) {
		this.inhEmail = inhEmail;
	}

	public String getAhv() {
		return ahv;
	}

	public void setAhv(String ahv) {
		this.ahv = ahv;
	}

	public String getDatumAhv() {
		return datumAhv;
	}

	public void setDatumAhv(String datumAhv) {
		this.datumAhv = datumAhv;
	}

	public String getMwst() {
		return mwst;
	}

	public void setMwst(String mwst) {
		this.mwst = mwst;
	}

	public String getDatumMwst() {
		return datumMwst;
	}

	public void setDatumMwst(String datumMwst) {
		this.datumMwst = datumMwst;
	}

	public String getHr() {
		return hr;
	}

	public void setHr(String hr) {
		this.hr = hr;
	}

	public String getDatumHr() {
		return datumHr;
	}

	public void setDatumHr(String datumHr) {
		this.datumHr = datumHr;
	}

	public String getSuva() {
		return suva;
	}

	public void setSuva(String suva) {
		this.suva = suva;
	}

	public String getDatumSuva() {
		return datumSuva;
	}

	public void setDatumSuva(String datumSuva) {
		this.datumSuva = datumSuva;
	}

	public String getZefixMatchUID() {
		return zefixMatchUID;
	}

	public void setZefixMatchUID(String zefixMatchUID) {
		this.zefixMatchUID = zefixMatchUID;
	}
}
