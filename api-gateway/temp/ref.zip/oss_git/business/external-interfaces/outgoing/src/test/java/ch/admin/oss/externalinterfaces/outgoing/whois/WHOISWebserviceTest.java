/*
 * WHOISWebserviceTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.whois;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.externalinterfaces.outgoing.OutgoingInterfaceConfig;

/**
 * @author tdm
 *
 */
@ActiveProfiles(CommonConstants.PROFILE_TEST)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = OutgoingInterfaceConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
public class WHOISWebserviceTest {
	
	@Autowired
	private IWHOISWebservice whoisWebservice;
	
	@Test
	public void testRegisteredDomain(){
		WHOISCheckResultEnum result = whoisWebservice.checkDomain("about.ch");
		Assert.assertEquals(WHOISCheckResultEnum.CAN_NOT_REGISTERED, result);
	}
	
	@Test
	public void testDomainIsNull(){
		WHOISCheckResultEnum result = whoisWebservice.checkDomain(null);
		Assert.assertEquals(WHOISCheckResultEnum.UNEXPECTED_ERROR, result);
	}
}
