/*
 * MwstMoaIntegrationDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.mwst.endpoint;

import java.io.Serializable;

/**
 * @author hhg
 *
 */
public class MwstMoaConfigDto implements Serializable {

	private static final long serialVersionUID = -5002964531087620294L;
	
	private String uuid;
	private String moaUrl;
	private String jumpBackUrl;
	private String getUserDataUrl;
	private String putMoaDataUrl;
	
	public MwstMoaConfigDto() {
	}

	public MwstMoaConfigDto(String uuid, String moaUrl, String jumpBackUrl, String getUserDataUrl,
		String putMoaDataUrl) {
		this.uuid = uuid;
		this.moaUrl = moaUrl;
		this.jumpBackUrl = jumpBackUrl;
		this.getUserDataUrl = getUserDataUrl;
		this.putMoaDataUrl = putMoaDataUrl;
	}

	public String getMoaUrl() {
		return moaUrl;
	}
	public String getUuid() {
		return uuid;
	}
	public String getJumpBackUrl() {
		return jumpBackUrl;
	}
	public String getGetUserDataUrl() {
		return getUserDataUrl;
	}
	public String getPutMoaDataUrl() {
		return putMoaDataUrl;
	}
}
