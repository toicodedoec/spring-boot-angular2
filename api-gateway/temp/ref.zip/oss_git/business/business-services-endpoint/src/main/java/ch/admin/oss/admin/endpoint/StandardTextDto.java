/*
 * FunktionRecheDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.endpoint;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.enums.StandardTextTypeEnum;

/**
 * @author hha
 */
public class StandardTextDto extends AbstractOSSDto {

	private StandardTextTypeEnum type;

	private String code;

	@Valid
	@NotNull
	private List<TextTranslationDto> translations;

	public StandardTextTypeEnum getType() {
		return type;
	}

	public void setType(StandardTextTypeEnum type) {
		this.type = type;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public List<TextTranslationDto> getTranslations() {
		return translations;
	}

	public void setTranslations(List<TextTranslationDto> translations) {
		this.translations = translations;
	}

}
