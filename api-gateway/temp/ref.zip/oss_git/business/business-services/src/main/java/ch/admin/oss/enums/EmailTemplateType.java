/*
 * EmailTemplateType
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.enums;

import ch.admin.oss.common.SupportedLanguage;

/**
 * @author hha
 */
public enum EmailTemplateType {

	AG_ANALOG("ag-analog-mail-template"),
	AG_DIGITAL("ag-digital-mail-template"),
	EF_JUSPACE("ef-juspace-mail-template"),
	EF_KOLLG_KOMMG_NORMAL("ef-kollG-kommG-normal-mail-template");

	private String filename;

	private EmailTemplateType(String filename) {
		this.filename = filename;
	}

	public String getFilePath(SupportedLanguage language) {
		return "hr/" + filename + "_" + language.name().toLowerCase() + ".ftl";
	}
	
}
