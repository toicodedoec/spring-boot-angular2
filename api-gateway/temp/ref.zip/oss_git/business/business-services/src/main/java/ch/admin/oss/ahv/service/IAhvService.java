/*
 * IAhvService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.ahv.service;

import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;

import ch.admin.oss.common.IProcessService;
import ch.admin.oss.common.dto.FileDto;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.AhvAnmeldungEntity;
import ch.admin.oss.domain.AusgleichskasseEntity;
import ch.admin.oss.domain.GeschaeftsstelleEntity;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.VerbandEntity;

/**
 * @author hhg
 *
 */
@Validated
public interface IAhvService extends IProcessService<AhvAnmeldungEntity> {

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	AusgleichskasseEntity findAusleichskasseInOrganisationKanton(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	FileDto downloadDocument(long orgId);
	
	@PreAuthorize("hasPermission(#geschaftsrolle.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	AhvAnmeldungEntity createAhvTeilhaber(GeschaftsrolleEntity geschaftsrolle);
	
	@PreAuthorize("hasPermission(#geschaeftsstelle.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	AhvAnmeldungEntity createAhvFiliale(GeschaeftsstelleEntity geschaeftsstelle);
	
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	List<AdresseEntity> getAhvAdresseKontaktByOrgId(long orgId);
	
	VerbandEntity getVerbandById(long verbandId);
}
