/*
 * AbstractPersonRoleDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;
import java.time.LocalDate;

import ch.admin.oss.OssCurrencyFormatter;

/**
 * @author hha
 */
public class AbstractNaturalPersonDto implements IShowAsCollection {

	private long index = 1;
	private boolean last;

	private HrDto hr;
	private UvgDto uvg;

	private String ownerType;

	private String titel;
	private String anrede;
	private String vorname;
	private String familienname;
	private String polGemeinde;
	private LocalDate geburtsdatum;
	private String heimatortCombined;
	private String nationalitaetenCombined;
	private String funktion;
	private String zeichnung;
	private String zivilstand;

	private AddressDto adr;
	private String weitereVornamen;
	private String ledigname;
	private String ahvNummer;

	private String haftung;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal haftungChf;

	private Integer anzInhaberaktien;
	private Integer anzNamensaktien;
	private Integer anzStammanteile;

	private String natTyp;
	private String auslaenderAusweis;

	private LocalDate einreisedatum;

	@OssCurrencyFormatter
	private BigDecimal shareValue;
	
	private String hauptsitz;

	public String getHauptsitz() {
		return hauptsitz;
	}

	public void setHauptsitz(String hauptsitz) {
		this.hauptsitz = hauptsitz;
	}

	public long getIndex() {
		return index;
	}

	public void setIndex(long index) {
		this.index = index;
	}

	@Override
	public boolean isLast() {
		return last;
	}

	@Override
	public void setLast(boolean last) {
		this.last = last;
	}

	public HrDto getHr() {
		return hr;
	}

	public AbstractNaturalPersonDto setHr(HrDto hr) {
		this.hr = hr;
		return this;
	}

	public UvgDto getUvg() {
		return uvg;
	}

	public AbstractNaturalPersonDto setUvg(UvgDto uvg) {
		this.uvg = uvg;
		return this;
	}

	public String getOwnerType() {
		return ownerType;
	}

	public void setOwnerType(String ownerType) {
		this.ownerType = ownerType;
	}

	public String getTitel() {
		return titel;
	}

	public void setTitel(String titel) {
		this.titel = titel;
	}

	public String getAnrede() {
		return anrede;
	}

	public void setAnrede(String anrede) {
		this.anrede = anrede;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getFamilienname() {
		return familienname;
	}

	public void setFamilienname(String familienname) {
		this.familienname = familienname;
	}

	public String getPolGemeinde() {
		return polGemeinde;
	}

	public void setPolGemeinde(String polGemeinde) {
		this.polGemeinde = polGemeinde;
	}

	public LocalDate getGeburtsdatum() {
		return geburtsdatum;
	}

	public void setGeburtsdatum(LocalDate geburtsdatum) {
		this.geburtsdatum = geburtsdatum;
	}

	public String getHeimatortCombined() {
		return heimatortCombined;
	}

	public void setHeimatortCombined(String heimatortCombined) {
		this.heimatortCombined = heimatortCombined;
	}

	public String getNationalitaetenCombined() {
		return nationalitaetenCombined;
	}

	public void setNationalitaetenCombined(String nationalitaetenCombined) {
		this.nationalitaetenCombined = nationalitaetenCombined;
	}

	public String getFunktion() {
		return funktion;
	}

	public void setFunktion(String funktion) {
		this.funktion = funktion;
	}

	public String getZeichnung() {
		return zeichnung;
	}

	public void setZeichnung(String zeichnung) {
		this.zeichnung = zeichnung;
	}

	public String getZivilstand() {
		return zivilstand;
	}

	public void setZivilstand(String zivilstand) {
		this.zivilstand = zivilstand;
	}

	public AddressDto getAdr() {
		return adr;
	}

	public void setAdr(AddressDto adr) {
		this.adr = adr;
	}

	public String getWeitereVornamen() {
		return weitereVornamen;
	}

	public void setWeitereVornamen(String weitereVornamen) {
		this.weitereVornamen = weitereVornamen;
	}

	public String getLedigname() {
		return ledigname;
	}

	public void setLedigname(String ledigname) {
		this.ledigname = ledigname;
	}

	public String getAhvNummer() {
		return ahvNummer;
	}

	public void setAhvNummer(String ahvNummer) {
		this.ahvNummer = ahvNummer;
	}

	public String getHaftung() {
		return haftung;
	}

	public void setHaftung(String haftung) {
		this.haftung = haftung;
	}
	
	public BigDecimal getHaftungChf() {
		return haftungChf;
	}

	public void setHaftungChf(BigDecimal haftungChf) {
		this.haftungChf = haftungChf;
	}

	public Integer getAnzInhaberaktien() {
		return anzInhaberaktien;
	}

	public void setAnzInhaberaktien(Integer anzInhaberaktien) {
		this.anzInhaberaktien = anzInhaberaktien;
	}

	public Integer getAnzNamensaktien() {
		return anzNamensaktien;
	}

	public void setAnzNamensaktien(Integer anzNamensaktien) {
		this.anzNamensaktien = anzNamensaktien;
	}

	public Integer getAnzStammanteile() {
		return anzStammanteile;
	}

	public void setAnzStammanteile(Integer anzStammanteile) {
		this.anzStammanteile = anzStammanteile;
	}

	public String getNatTyp() {
		return natTyp;
	}

	public void setNatTyp(String natTyp) {
		this.natTyp = natTyp;
	}

	public String getAuslaenderAusweis() {
		return auslaenderAusweis;
	}

	public void setAuslaenderAusweis(String auslaenderAusweis) {
		this.auslaenderAusweis = auslaenderAusweis;
	}

	public BigDecimal getShareValue() {
		return shareValue;
	}

	public void setShareValue(BigDecimal shareValue) {
		this.shareValue = shareValue;
	}

	public LocalDate getEinreisedatum() {
		return einreisedatum;
	}

	public void setEinreisedatum(LocalDate einreisedatum) {
		this.einreisedatum = einreisedatum;
	}

}
