/*
 * HrGruenderDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.math.BigDecimal;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.PersonDto;

/**
 * @author hha
 */
public class AbstractPersonRoleDto extends AbstractOSSDto {

	private PersonDto person;
	private CodeWertDto funktion;
	private CodeWertDto zeichnung;
	private boolean nurHauptsitz;
	private boolean complete;

	private CodeWertDto haftung;
	private CodeWertDto einlage;
	private BigDecimal haftungCHF;
	
	private Integer anzInhaberaktien;
	private Integer anzNamensaktien;
	private Integer anzStammanteile;

	public PersonDto getPerson() {
		return person;
	}

	public void setPerson(PersonDto person) {
		this.person = person;
	}

	public CodeWertDto getFunktion() {
		return funktion;
	}

	public void setFunktion(CodeWertDto funktion) {
		this.funktion = funktion;
	}

	public CodeWertDto getZeichnung() {
		return zeichnung;
	}

	public void setZeichnung(CodeWertDto zeichnung) {
		this.zeichnung = zeichnung;
	}

	public boolean isNurHauptsitz() {
		return nurHauptsitz;
	}

	public void setNurHauptsitz(boolean nurHauptsitz) {
		this.nurHauptsitz = nurHauptsitz;
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	public CodeWertDto getHaftung() {
		return haftung;
	}

	public void setHaftung(CodeWertDto haftung) {
		this.haftung = haftung;
	}

	public CodeWertDto getEinlage() {
		return einlage;
	}

	public void setEinlage(CodeWertDto einlage) {
		this.einlage = einlage;
	}

	public BigDecimal getHaftungCHF() {
		return haftungCHF;
	}

	public void setHaftungCHF(BigDecimal haftungCHF) {
		this.haftungCHF = haftungCHF;
	}

	public Integer getAnzInhaberaktien() {
		return anzInhaberaktien;
	}

	public void setAnzInhaberaktien(Integer anzInhaberaktien) {
		this.anzInhaberaktien = anzInhaberaktien;
	}

	public Integer getAnzNamensaktien() {
		return anzNamensaktien;
	}

	public void setAnzNamensaktien(Integer anzNamensaktien) {
		this.anzNamensaktien = anzNamensaktien;
	}

	public Integer getAnzStammanteile() {
		return anzStammanteile;
	}

	public void setAnzStammanteile(Integer anzStammanteile) {
		this.anzStammanteile = anzStammanteile;
	}

}
