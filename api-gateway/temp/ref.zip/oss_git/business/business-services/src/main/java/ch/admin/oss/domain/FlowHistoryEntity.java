/*
 * FlowHistoryEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

/**
 * @author coh
 */
@Entity
@Table(name = "T_FLOW_HISTORY")
public class FlowHistoryEntity extends AbstractOSSEntity {

	@Fetch(FetchMode.SUBSELECT)
	@OrderColumn(name="\"INDEX\"")
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "flowHistory", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<FlowHistoryItemEntity> items = new ArrayList<>();
	
	@Column(name = "CALL_BACK_URL")
	private String callbackURL;

	public FlowHistoryEntity() {}

	public FlowHistoryEntity(List<FlowHistoryItemEntity> items) {
		this.items = items;
		for (FlowHistoryItemEntity item : items) {
			item.setFlowHistory(this);
		}
	}

	public List<FlowHistoryItemEntity> getItems() {
		return items;
	}

	public FlowHistoryEntity replaceItems(List<FlowHistoryItemEntity> items) {
		for (FlowHistoryItemEntity item : items) {
			item.setFlowHistory(this);
		}
		this.items = items;
		return this;
	}

	public String getCallbackURL() {
		return callbackURL;
	}

	public void setCallbackURL(String callbackURL) {
		this.callbackURL = callbackURL;
	}
}
