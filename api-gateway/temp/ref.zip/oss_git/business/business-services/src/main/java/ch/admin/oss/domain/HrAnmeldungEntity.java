/*
 * HrAnmeldungEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;

import ch.admin.oss.common.enums.ProzessTypEnum;

/**
 *  
 * @author coh
 */
@Entity
@Table(name = "T_HR_ANMELDUNG")
public class HrAnmeldungEntity extends AbstractOSSEntity implements IProzessEntity {

	@NotNull
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PROZESS", foreignKey = @ForeignKey(name="FK_HR_PROZESS"))
	private ProzessEntity prozess;
	
	@Column(name = "TRANSLATE", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean translate;
	
	@Column(name = "AUSZUEGE")
	private Integer auszuege;
	
	@Column(name = "AUSZUEGE_VOR")
	private Integer auszuegeVor;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE_KORRESPONDENZ", foreignKey = @ForeignKey(name="FK_HR_ADRESSE_KORRES"))
	private AdresseEntity adresseKorrespondenz;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_ADRESSE_RECHNUNG", foreignKey = @ForeignKey(name="FK_HR_ADRESSE_RECHNUNG"))
	private AdresseEntity adresseRechnung;
	
	@Lob
	@Column(name = "BEMERKUNGEN")
	private String bemerkungen;
	
	@Column(name = "ELEKTRONISCH", length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private Boolean elektronisch;
	
	@Column(name = "BARGRUENDUNG", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean bargruendung;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_NOTAR_ANREDE", foreignKey = @ForeignKey(name="FK_HR_CODE_WERT"))
	private CodeWertEntity notarAnrede;

	@Column(name = "NOTAR_TITEL")
	private String notarTitel;
	
	@Column(name = "NOTAR_NAME")
	private String notarName;
	
	@Column(name = "NOTAR_VORNAME")
	private String notarVorname;
	
	@Column(name = "NOTAR_POST_ADRESSE")
	private String notarPostadresse;
	
	@Column(name = "NOTAR_TELEFON")
	private String notarTelefon;
	
	//SECOOSS-475: migrate data to table HrAnmeldung, HrGruender
	//@Pattern(regexp = OSSConstants.EMAIL_REGEX_PATTERN)
	@Column(name = "NOTAR_EMAIL")
	private String notarEmail;

	@Column(name = "NOTAR_FUNKTION")
	private String notarFunktion;
	
	@Column(name = "NOTAR_FAX")
	private String notarFax;
	
	@Column(name = "NOTAR_UP_REG_UUID")
	private String notarUpRegUUID;
	
	@Column(name = "NOTAR_KANTON")
	private String notarKanton;
	
	@Column(name = "STAMMKAPITAL")
	private Integer stammkapital;
	
	@Column(name = "STAMMANTEILE")
	private Integer stammanteile;
	
	@Column(name = "AKTIENKAPITAL")
	private Integer aktienkapital;
	
	@Column(name = "LIBERIERUNGSUMFANG")
	private Integer liberierungsumfang;
	
	@Column(name = "NAMENSAKTIEN")
	private Integer namensaktien;
	
	@Column(name = "INHABERAKTIEN")
	private Integer inhaberaktien;

	@Lob
	@Column(name = "FINANZ_BEMERKUNGEN")
	private String finanzBemerkungen;
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "hrAnmeldung", cascade = CascadeType.ALL)
	private Set<HrGruenderEntity> gruenders = new HashSet<>();
	
	public HrAnmeldungEntity() {
		prozess = new ProzessEntity(ProzessTypEnum.HR, true);
	}
	
	public HrAnmeldungEntity(OrganisationEntity org) {
		prozess = new ProzessEntity(ProzessTypEnum.HR, true, org);
	}

	public ProzessEntity getProzess() {
		return prozess;
	}

	public void setProzess(ProzessEntity prozess) {
		this.prozess = prozess;
	}

	public boolean isTranslate() {
		return translate;
	}

	public void setTranslate(boolean translate) {
		this.translate = translate;
	}

	public Integer getAuszuege() {
		return auszuege;
	}

	public void setAuszuege(Integer auszuege) {
		this.auszuege = auszuege;
	}

	public Integer getAuszuegeVor() {
		return auszuegeVor;
	}

	public void setAuszuegeVor(Integer auszuegeVor) {
		this.auszuegeVor = auszuegeVor;
	}

	public AdresseEntity getAdresseKorrespondenz() {
		return adresseKorrespondenz;
	}

	public void setAdresseKorrespondenz(AdresseEntity adresseKorrespondenz) {
		this.adresseKorrespondenz = adresseKorrespondenz;
	}

	public AdresseEntity getAdresseRechnung() {
		return adresseRechnung;
	}

	public void setAdresseRechnung(AdresseEntity adresseRechnung) {
		this.adresseRechnung = adresseRechnung;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public Boolean getElektronisch() {
		return elektronisch;
	}

	public void setElektronisch(Boolean elektronisch) {
		this.elektronisch = elektronisch;
	}

	public boolean isBargruendung() {
		return bargruendung;
	}

	public void setBargruendung(boolean bargruendung) {
		this.bargruendung = bargruendung;
	}

	public CodeWertEntity getNotarAnrede() {
		return notarAnrede;
	}

	public void setNotarAnrede(CodeWertEntity notarAnrede) {
		this.notarAnrede = notarAnrede;
	}

	public String getNotarTitel() {
		return notarTitel;
	}

	public void setNotarTitel(String notarTitel) {
		this.notarTitel = notarTitel;
	}

	public String getNotarName() {
		return notarName;
	}

	public void setNotarName(String notarName) {
		this.notarName = notarName;
	}

	public String getNotarVorname() {
		return notarVorname;
	}

	public void setNotarVorname(String notarVorname) {
		this.notarVorname = notarVorname;
	}

	public String getNotarPostadresse() {
		return notarPostadresse;
	}

	public void setNotarPostadresse(String notarPostadresse) {
		this.notarPostadresse = notarPostadresse;
	}

	public String getNotarTelefon() {
		return notarTelefon;
	}

	public void setNotarTelefon(String notarTelefon) {
		this.notarTelefon = notarTelefon;
	}

	public String getNotarEmail() {
		return notarEmail;
	}

	public void setNotarEmail(String notarEmail) {
		this.notarEmail = notarEmail;
	}

	public String getNotarFunktion() {
		return notarFunktion;
	}

	public void setNotarFunktion(String notarFunktion) {
		this.notarFunktion = notarFunktion;
	}

	public String getNotarFax() {
		return notarFax;
	}

	public void setNotarFax(String notarFax) {
		this.notarFax = notarFax;
	}

	public String getNotarUpRegUUID() {
		return notarUpRegUUID;
	}

	public void setNotarUpRegUUID(String notarUpRegUUID) {
		this.notarUpRegUUID = notarUpRegUUID;
	}

	public String getNotarKanton() {
		return notarKanton;
	}

	public void setNotarKanton(String notarKanton) {
		this.notarKanton = notarKanton;
	}

	public Integer getStammkapital() {
		return stammkapital;
	}

	public void setStammkapital(Integer stammkapital) {
		this.stammkapital = stammkapital;
	}

	public Integer getStammanteile() {
		return stammanteile;
	}

	public void setStammanteile(Integer stammanteile) {
		this.stammanteile = stammanteile;
	}

	public Integer getAktienkapital() {
		return aktienkapital;
	}

	public void setAktienkapital(Integer aktienkapital) {
		this.aktienkapital = aktienkapital;
	}

	public Integer getLiberierungsumfang() {
		return liberierungsumfang;
	}

	public void setLiberierungsumfang(Integer liberierungsumfang) {
		this.liberierungsumfang = liberierungsumfang;
	}

	public Integer getNamensaktien() {
		return namensaktien;
	}

	public void setNamensaktien(Integer namensaktien) {
		this.namensaktien = namensaktien;
	}

	public Integer getInhaberaktien() {
		return inhaberaktien;
	}

	public void setInhaberaktien(Integer inhaberaktien) {
		this.inhaberaktien = inhaberaktien;
	}

	public String getFinanzBemerkungen() {
		return finanzBemerkungen;
	}

	public void setFinanzBemerkungen(String finanzBemerkungen) {
		this.finanzBemerkungen = finanzBemerkungen;
	}

	public Set<HrGruenderEntity> getGruenders() {
		return gruenders;
	}

	public void setGruenders(Set<HrGruenderEntity> gruenders) {
		this.gruenders = gruenders;
	}
}
