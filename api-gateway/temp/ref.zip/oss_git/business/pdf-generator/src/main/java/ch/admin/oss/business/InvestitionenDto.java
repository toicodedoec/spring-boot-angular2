/*
 * InvestitionenDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;

import ch.admin.oss.OssCurrencyFormatter;

/**
 * @author hhg
 *
 */
public class InvestitionenDto {

	private RentDto rent;
	private PurchaseDto purchase;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal ownCapital;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal debt;
	
	public InvestitionenDto(RentDto rent, PurchaseDto purchase, BigDecimal ownCapital, BigDecimal debt) {
		this.rent = rent;
		this.purchase = purchase;
		this.ownCapital = ownCapital;
		this.debt = debt;
	}

	public RentDto getRent() {
		return rent;
	}

	public PurchaseDto getPurchase() {
		return purchase;
	}

	public BigDecimal getOwnCapital() {
		return ownCapital;
	}

	public BigDecimal getDebt() {
		return debt;
	}
}
