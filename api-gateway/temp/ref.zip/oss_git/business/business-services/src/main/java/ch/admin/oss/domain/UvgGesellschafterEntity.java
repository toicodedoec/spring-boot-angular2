/*
 * UvgGesellschafterEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

/**
 * @author coh
 */
@Entity
@Table(name = "T_UVG_GESELLSCHAFTER")
public class UvgGesellschafterEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_UVG_ANMELDUNG", foreignKey = @ForeignKey(name = "FK_UVG_GESELLS_ANMELDUNG"))
	private UvgAnmeldungEntity uvgAnmeldung;

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PERSON", foreignKey = @ForeignKey(name = "FK_UVG_GESELLS_PERSON"))
	private PersonEntity person;

	@Column(name = "LOHNSUMME")
	private BigDecimal lohnsumme;

	public UvgAnmeldungEntity getUvgAnmeldung() {
		return uvgAnmeldung;
	}

	public void setUvgAnmeldung(UvgAnmeldungEntity uvgAnmeldung) {
		this.uvgAnmeldung = uvgAnmeldung;
	}

	public PersonEntity getPerson() {
		return person;
	}

	public void setPerson(PersonEntity person) {
		this.person = person;
	}

	public BigDecimal getLohnsumme() {
		return lohnsumme;
	}

	public void setLohnsumme(BigDecimal lohnsumme) {
		this.lohnsumme = lohnsumme;
	}
}
