/*
 * OrganisationStandardTextConverter
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss;

import java.util.Optional;

import org.dozer.DozerConverter;
import org.hibernate.Hibernate;

import ch.admin.oss.application.service.IApplicationService;
import ch.admin.oss.common.CodeWertDto;
import ch.admin.oss.common.SupportedLanguage;
import ch.admin.oss.domain.CodeWertEntity;
import ch.admin.oss.domain.TextTranslationEntity;
import ch.admin.oss.security.SecurityUtil;

/**
 * @author tdm
 *
 */
public class CodeWertConverter extends DozerConverter<CodeWertEntity, CodeWertDto> {

	private IApplicationService applicationService;
	
	public CodeWertConverter(IApplicationService applicationService) {
		super(CodeWertEntity.class, CodeWertDto.class);
		this.applicationService = applicationService;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public CodeWertDto convertTo(CodeWertEntity source, CodeWertDto destination) {
		if (source == null) {
			return null;
		}
		
		destination = new CodeWertDto();
		destination.setId(source.getId());
		destination.setVersion(source.getVersion());
		destination.setCode(source.getCode());
		destination.setKategorie(source.getKategorie());
		destination.setAktiv(source.isAktiv());
		destination.setPos(source.getPos());
		if (Hibernate.isInitialized(source.getStandardText())
			&& source.getStandardText() != null
			&& Hibernate.isInitialized(source.getStandardText().getTranslations())) {
			Optional<TextTranslationEntity> textTranslation = source.getStandardText().getTranslations().stream()
					.filter(t -> t.getLanguage() == SecurityUtil.currentUser().getLanguagePreference()).findFirst();
			if (textTranslation.isPresent()) {
				destination.setText(textTranslation.get().getText());
			}
			
			Optional<TextTranslationEntity> textDe = source.getStandardText().getTranslations().stream()
					.filter(t -> t.getLanguage() == SupportedLanguage.DE).findFirst();			
			if(textDe.isPresent()) {
				destination.setTextDE(textDe.get().getText());
			}
			
			Optional<TextTranslationEntity> textFr = source.getStandardText().getTranslations().stream()
					.filter(t -> t.getLanguage() == SupportedLanguage.FR).findFirst();			
			if(textFr.isPresent()) {
				destination.setTextFR(textFr.get().getText());
			}
			
			Optional<TextTranslationEntity> textEn = source.getStandardText().getTranslations().stream()
					.filter(t -> t.getLanguage() == SupportedLanguage.EN).findFirst();			
			if(textEn.isPresent()) {
				destination.setTextEN(textEn.get().getText());
			}
			
			Optional<TextTranslationEntity> textIt = source.getStandardText().getTranslations().stream()
					.filter(t -> t.getLanguage() == SupportedLanguage.IT).findFirst();			
			if(textIt.isPresent()) {
				destination.setTextIT(textIt.get().getText());
			}
		}
		return destination;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public CodeWertEntity convertFrom(CodeWertDto source, CodeWertEntity destination) {
		if (source == null || source.getId() == null) {
			return null;
		}
		
		destination = applicationService.getCodeWert(source.getId());
		destination.setVersion(source.getVersion());
		return destination;
	}
}
