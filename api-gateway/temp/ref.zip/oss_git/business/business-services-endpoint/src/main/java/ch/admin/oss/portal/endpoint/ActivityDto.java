/*
 * ActivityDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.endpoint;

import java.time.LocalDate;
import java.util.Date;

import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author xdg
 */
public class ActivityDto {
	private Long orgId;
	private Date modifyDate;
	private Long processId;
	private ProzessTypEnum processTyp;
	private ProzessStatusEnum status;
	private RechtsformEnum rechtsform;
	private LocalDate zefixImportDate;
	private HRStatusEnum hrStatus;

	public ActivityDto() {}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public ProzessStatusEnum getStatus() {
		return status;
	}

	public void setStatus(ProzessStatusEnum status) {
		this.status = status;
	}

	public Long getProcessId() {
		return processId;
	}

	public void setProcessId(Long processId) {
		this.processId = processId;
	}

	public ProzessTypEnum getProcessTyp() {
		return processTyp;
	}

	public void setProcessTyp(ProzessTypEnum processTyp) {
		this.processTyp = processTyp;
	}

	public String getProcessName() {
		return processTyp.name();
	}

	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}

	public LocalDate getZefixImportDate() {
		return zefixImportDate;
	}

	public void setZefixImportDate(LocalDate zefixImportDate) {
		this.zefixImportDate = zefixImportDate;
	}

	public HRStatusEnum getHrStatus() {
		return hrStatus;
	}

	public void setHrStatus(HRStatusEnum hrStatus) {
		this.hrStatus = hrStatus;
	}

}
