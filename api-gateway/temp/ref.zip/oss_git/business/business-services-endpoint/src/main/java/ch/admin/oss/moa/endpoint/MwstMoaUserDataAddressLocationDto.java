package ch.admin.oss.moa.endpoint;

public class MwstMoaUserDataAddressLocationDto {

	private String zip;

	private String place;

	private String canton;

	private String communityNumber; // bfsNbr
	
	public MwstMoaUserDataAddressLocationDto() {
		
	}

	public MwstMoaUserDataAddressLocationDto(String zip, String place, String canton, String communityNumber) {
		this.zip = zip;
		this.place = place;
		this.canton = canton;
		this.communityNumber = communityNumber;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getCanton() {
		return canton;
	}

	public void setCanton(String canton) {
		this.canton = canton;
	}

	public String getCommunityNumber() {
		return communityNumber;
	}

	public void setCommunityNumber(String communityNumber) {
		this.communityNumber = communityNumber;
	}

}
