/*
 * HrMutationLegalPersonDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;

import ch.admin.oss.OssCurrencyFormatter;

/**
 * @author coh
 *
 */
public class HrMutationLegalPersonDto {

	private String name;
	private AddressDto domizil;
	private String rechtsformCh;
	private String rechtsformAusland;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal haftung;
	private String einlage;
	
	private String prevCompanyName;
	private String prevLegalForm;
	private String prevCity;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public AddressDto getDomizil() {
		return domizil;
	}
	public void setDomizil(AddressDto domizil) {
		this.domizil = domizil;
	}
	public String getRechtsformCh() {
		return rechtsformCh;
	}
	public void setRechtsformCh(String rechtsformCh) {
		this.rechtsformCh = rechtsformCh;
	}
	public String getRechtsformAusland() {
		return rechtsformAusland;
	}
	public void setRechtsformAusland(String rechtsformAusland) {
		this.rechtsformAusland = rechtsformAusland;
	}
	public BigDecimal getHaftung() {
		return haftung;
	}
	public void setHaftung(BigDecimal haftung) {
		this.haftung = haftung;
	}
	public String getEinlage() {
		return einlage;
	}
	public void setEinlage(String einlage) {
		this.einlage = einlage;
	}
	public String getPrevCompanyName() {
		return prevCompanyName;
	}
	public void setPrevCompanyName(String prevCompanyName) {
		this.prevCompanyName = prevCompanyName;
	}
	public String getPrevLegalForm() {
		return prevLegalForm;
	}
	public void setPrevLegalForm(String prevLegalForm) {
		this.prevLegalForm = prevLegalForm;
	}
	public String getPrevCity() {
		return prevCity;
	}
	public void setPrevCity(String prevCity) {
		this.prevCity = prevCity;
	}
}
