/*
 * UvgKontaktAdresse
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

/**
 * Uvg Kontakt Adresse Bean Validation group.
 *
 * @author hhg
 */
public interface UvgKontaktAdresse {
}
