/*
 * AbstractOSSEntity
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.SequenceGenerator;
import javax.persistence.Transient;
import javax.persistence.Version;

import ch.admin.oss.util.OSSConstants;

/**
 * Base entity.
 * 
 * @author phd
 */
@MappedSuperclass
public class AbstractOSSEntity {

	/**
	 * A special entity ID for transient one (i.e. this entity hasn't been persisted).
	 */
	public static final long TRANSIENT_ENTITY_ID = 1;

	@Transient
	private boolean transientHashCodeLeaked = false;

	@Transient
	private String rawClassName = getClass().getName();

	@Id
	@Column(name = "PK", updatable = false, nullable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = OSSConstants.OSS_ID_SEQUENCE)
	@SequenceGenerator(name = OSSConstants.OSS_ID_SEQUENCE, sequenceName = OSSConstants.OSS_ID_SEQUENCE, initialValue = 1)
	private Long id;

	@Version
	@Column(name = "VERSION", nullable = false)
	private int version = 0;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(int version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return this.getClass().getSimpleName() + "(" + id + ")";
	}

	public boolean isPersisted() {
		return this.id != null;
	}

	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (obj == null) {
			return false;
		}

		/*
		 * The following is a solution that works for hibernate lazy loading proxies. if (getClass() !=
		 * HibernateProxyHelper.getClassWithoutInitializingProxy(obj)) { return false; }
		 */
		if (obj instanceof AbstractOSSEntity) {
			final AbstractOSSEntity other = (AbstractOSSEntity) obj;
			if (isPersisted() && other.isPersisted()) { // both entities are not new

				// Because entities are currently used in clientside, we cannot use
				// HibernateProxyHelper here > we cannot compare class for sure they are the same class, just compare
				// ID.
				return getId().equals(other.getId()) && rawClassName.equals(other.getRawClassName());
			}
			// if one of entity is new (transient), they are considered not equal.
		}
		return false;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode() {
		if (!isPersisted()) { // is new or is in transient state.
			transientHashCodeLeaked = true;
			return -super.hashCode();
		}

		// because hashcode has just been asked for when the object is in transient state
		// at that time, super.hashCode(); is returned. Now for consistency, we return the
		// same value.
		if (transientHashCodeLeaked) {
			return -super.hashCode();
		}
		return getId().hashCode();
		// The above mechanism obey the rule: if 2 objects are equal, their hashcode must be same.
	}

	public final String getRawClassName() {
		return rawClassName;
	}
}
