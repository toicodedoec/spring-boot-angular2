/*
 * ProzessDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.organisation.endpoint.OrganisationDto;

/**
 * @author coh
 */
public class ProzessDto extends AbstractOSSDto {

	private OrganisationDto organisation;
	private byte[] pdf;
	private ProzessStatusEnum status;
	private boolean completed;
	private boolean locked;
	private String digitalSignees;

	private FlowHistoryDto flowHistory = new FlowHistoryDto();

	public OrganisationDto getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationDto organisation) {
		this.organisation = organisation;
	}

	public byte[] getPdf() {
		return pdf;
	}

	public void setPdf(byte[] pdf) {
		this.pdf = pdf;
	}

	public ProzessStatusEnum getStatus() {
		return status;
	}

	public void setStatus(ProzessStatusEnum status) {
		this.status = status;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public FlowHistoryDto getFlowHistory() {
		return flowHistory;
	}

	public void setFlowHistory(FlowHistoryDto flowHistory) {
		this.flowHistory = flowHistory;
	}

	public String getDigitalSignees() {
		return digitalSignees;
	}

	public void setDigitalSignees(String digitalSignees) {
		this.digitalSignees = digitalSignees;
	}
}
