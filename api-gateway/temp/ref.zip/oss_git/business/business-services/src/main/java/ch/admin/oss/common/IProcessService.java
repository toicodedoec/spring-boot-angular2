/*
 * IHRService
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import javax.validation.Valid;
import javax.validation.groups.Default;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;

import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.validator.OSSSytemValidator;

/**
 * @author coh
 *
 */
@Validated
public interface IProcessService<T> {

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	ProzessStatusEnum getProcessStatusByOrgId(long orgId);

	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	T getByOrganisationId(long orgId);

	/**
	 * Create the process from the scratch. The process now under status {@link ProzessStatusEnum#INITIAL} 
	 * or {@link ProzessStatusEnum#EXTERN}. 
	 * 
	 * @param organisation
	 * @return
	 */
	@PreAuthorize("hasPermission(#organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	T createProcess(OrganisationEntity organisation);

	/**
	 * Modify and update the process. The process now will be mark to uncompleted and under status {@link ProzessStatusEnum#BEARBEITUNG}.
	 * 
	 * @param entity
	 * @return
	 */
	@PreAuthorize("hasPermission(#entity.prozess.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	T updateProcess(T entity);
	
	/**
	 * Modify and update the process. The process now will be mark to uncompleted and under status {@link ProzessStatusEnum#BEARBEITUNG}.
	 * 
	 * @param orgId Organization ID to check user permission
	 * @param entity Process entity to update
	 * @return Process entity
	 */
	@PreAuthorize("hasPermission(#orgId, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	T updateProcess(long orgId, T entity);

	/**
	 * Complete the ongoing process. Validation at service level will be turn on. Process mark to complete and under status {@link ProzessStatusEnum#KOMPLETT}.
	 * 
	 * @param entity
	 * @return
	 */
	@PreAuthorize("hasPermission(#entity.prozess.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	@Validated({OSSSytemValidator.class, Default.class })
	T completeProcess(@Valid T entity);

	/**
	 * Lock the complete process. Process and its corresponding organisation data will be marked to locked and under status 
	 * {@link ProzessStatusEnum#GESCHLOSSEN}.
	 * 
	 * @param entity
	 * @return
	 */
	@PreAuthorize("hasPermission(#entity.prozess.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE_SEND)")
	T lockProcess(T entity);

	/**
	 * Sign the complete process. Process and its corresponding organisation data will be marked to locked and under status 
	 * {@link ProzessStatusEnum#SIGNIERT}.
	 * 
	 * @param entity
	 * @return
	 */
	@PreAuthorize("hasPermission(#entity.prozess.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE_SEND)")
	T signProcess(T entity);

	/**
	 * Re lock the process after Sign. It just simply change the status of the process back to {@link ProzessStatusEnum#GESCHLOSSEN}.
	 * 
	 * @param entity
	 * @return
	 */
	@PreAuthorize("hasPermission(#entity.prozess.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE_SEND)")
	T relockProcess(T entity);
	
	/**
	 * Re lock the process after Sign. It just simply change the status of the process back to {@link ProzessStatusEnum#GESCHLOSSEN}.
	 * 
	 * @param entity
	 * @return
	 */
	@PreAuthorize("hasPermission(#prozess.organisation.id, T(ch.admin.oss.enums.SecuredEntityEnum).ORGANISATION, T(ch.admin.oss.common.enums.AccessLevelEnum).WRITE)")
	void markProcessExternal(ProzessEntity prozess, boolean external);
}
