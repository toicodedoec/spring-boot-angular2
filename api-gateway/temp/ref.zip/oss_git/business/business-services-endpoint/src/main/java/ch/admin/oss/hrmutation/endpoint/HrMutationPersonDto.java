/*
 * HrMutationPersonDto
 * 
 * Project: OSS
 *
 * Copyright 2017 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.endpoint;

import java.util.Date;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.GeschaftsrolleDto;
import ch.admin.oss.common.enums.HrMutationPersonTypeOfChangeEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonRoleEnum;
import ch.admin.oss.organisation.endpoint.KommFirmaDto;

/**
 * @author xdg
 */
public class HrMutationPersonDto extends AbstractOSSDto {

	private HrMutationPersonTypeOfChangeEnum typeOfChange;

	private HrMutationTypeOfPersonEnum typeOfPerson;

	private HrMutationTypeOfPersonRoleEnum typeOfPersonRole;

	private GeschaftsrolleDto newNaturalPerson;

	private KommFirmaDto newLegalPerson;

	private GeschaftsrolleDto existingNaturalPerson;

	private KommFirmaDto existingLegalPeson;

	private String prevFamilyName;

	private String prevGivenName;

	private Date prevBirthday;

	private String prevCompanyName;

	private String prevLegalForm;

	private String prevCity;
	
	private boolean editForDissolution = false;

	public HrMutationPersonDto() {}

	public HrMutationPersonTypeOfChangeEnum getTypeOfChange() {
		return typeOfChange;
	}

	public void setTypeOfChange(HrMutationPersonTypeOfChangeEnum typeOfChange) {
		this.typeOfChange = typeOfChange;
	}

	public HrMutationTypeOfPersonEnum getTypeOfPerson() {
		return typeOfPerson;
	}

	public void setTypeOfPerson(HrMutationTypeOfPersonEnum typeOfPerson) {
		this.typeOfPerson = typeOfPerson;
	}

	public KommFirmaDto getNewLegalPerson() {
		return newLegalPerson;
	}

	public void setNewLegalPerson(KommFirmaDto newLegalPerson) {
		this.newLegalPerson = newLegalPerson;
	}

	public KommFirmaDto getExistingLegalPeson() {
		return existingLegalPeson;
	}

	public void setExistingLegalPeson(KommFirmaDto existingLegalPeson) {
		this.existingLegalPeson = existingLegalPeson;
	}

	public String getPrevFamilyName() {
		return prevFamilyName;
	}

	public void setPrevFamilyName(String prevFamilyName) {
		this.prevFamilyName = prevFamilyName;
	}

	public String getPrevGivenName() {
		return prevGivenName;
	}

	public void setPrevGivenName(String prevGivenName) {
		this.prevGivenName = prevGivenName;
	}

	public Date getPrevBirthday() {
		return prevBirthday;
	}

	public void setPrevBirthday(Date prevBirthday) {
		this.prevBirthday = prevBirthday;
	}

	public String getPrevCompanyName() {
		return prevCompanyName;
	}

	public void setPrevCompanyName(String prevCompanyName) {
		this.prevCompanyName = prevCompanyName;
	}

	public String getPrevLegalForm() {
		return prevLegalForm;
	}

	public void setPrevLegalForm(String prevLegalForm) {
		this.prevLegalForm = prevLegalForm;
	}

	public String getPrevCity() {
		return prevCity;
	}

	public void setPrevCity(String prevCity) {
		this.prevCity = prevCity;
	}

	public HrMutationTypeOfPersonRoleEnum getTypeOfPersonRole() {
		return typeOfPersonRole;
	}

	public void setTypeOfPersonRole(HrMutationTypeOfPersonRoleEnum typeOfPersonRole) {
		this.typeOfPersonRole = typeOfPersonRole;
	}

	public GeschaftsrolleDto getNewNaturalPerson() {
		return newNaturalPerson;
	}

	public void setNewNaturalPerson(GeschaftsrolleDto newNaturalPerson) {
		this.newNaturalPerson = newNaturalPerson;
	}

	public GeschaftsrolleDto getExistingNaturalPerson() {
		return existingNaturalPerson;
	}

	public void setExistingNaturalPerson(GeschaftsrolleDto existingNaturalPerson) {
		this.existingNaturalPerson = existingNaturalPerson;
	}

	public boolean isEditForDissolution() {
		return editForDissolution;
	}

	public void setEditForDissolution(boolean editForDissolution) {
		this.editForDissolution = editForDissolution;
	}

}
