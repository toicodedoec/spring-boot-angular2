/*
 * GenerateDataTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.performance.process;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.springframework.stereotype.Component;

import ch.admin.oss.ahv.service.IAhvService;
import ch.admin.oss.common.enums.AhvGruendungsartEnum;
import ch.admin.oss.common.enums.AhvMitarbeitEnum;
import ch.admin.oss.common.enums.AhvNamenEnum;
import ch.admin.oss.common.enums.AhvUebernahmeEnum;
import ch.admin.oss.common.enums.AhvVerbandszugehoerigkeitEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.KategorieEnum;
import ch.admin.oss.common.enums.KontotypEnum;
import ch.admin.oss.common.enums.ProzessTypEnum;
import ch.admin.oss.common.enums.ZahlungszweckEnum;
import ch.admin.oss.domain.AhvAnmeldungEntity;
import ch.admin.oss.domain.KontoEntity;
import ch.admin.oss.domain.OrganisationEntity;

/**
 * @author hha
 */
@Component
public class AhvProcessGenerator extends ProcessGenerator<AhvAnmeldungEntity, IAhvService> {

	private static final BigDecimal DUMMY_VALUE = BigDecimal.valueOf(1000);

	@Override
	public AhvAnmeldungEntity generate(AhvAnmeldungEntity entity) {
		OrganisationEntity organisation = entity.getProzess().getOrganisation();

		entity.setVerbandId(cacheService.getVerbands().get(0).getId());
		entity.setVerbandBeitrittDatum(LocalDate.now());
		entity.setVerbandZugehoerigkeit(AhvVerbandszugehoerigkeitEnum.JA);
		entity.setVerbandFak(true);
		entity.setGruendArt(AhvGruendungsartEnum.NEU);
		entity.setGruendAlteBezeichnung("Test");
		entity.setGruendUebernameArt(AhvUebernahmeEnum.KAUF);
		entity.setGruendUebernameName("UName");
		entity.setGruendUebernameNummer("999");
		entity.setKapitalEigen(DUMMY_VALUE);
		entity.setKapitalDarlehen(DUMMY_VALUE);
		entity.setInvestWerkzeugKauf(DUMMY_VALUE);
		entity.setInvestFahrzeugKauf(DUMMY_VALUE);
		entity.setInvestWarenInvKauf(DUMMY_VALUE);
		entity.setInvestWeitereKaufArt("Blah");
		entity.setInvestWeitereKauf(DUMMY_VALUE);
		entity.setInvestBueroMiete(DUMMY_VALUE);
		entity.setInvestLadenMiete(DUMMY_VALUE);
		entity.setInvestWerkstattMiete(DUMMY_VALUE);
		entity.setInvestLagerMiete(DUMMY_VALUE);
		entity.setInvestFahrzeugMiete(DUMMY_VALUE);
		entity.setInvestWeitereMieteArt("Art");
		entity.setInvestWeitereMiete(DUMMY_VALUE);
		entity.setRaumKeine(true);
		entity.setRaumEigene(true);
		entity.setRaumWohnung(true);
		entity.setRaumKunde(true);
		entity.setTaetigAnzKunden(1000);
		entity.setTaetigKunde1("K1");
		entity.setTaetigKunde2("K2");
		entity.setTaetigKunde3("K3");
		entity.setTaetigArtAuftraege("Auft");
		entity.setTaetigDatumLetzterAuftrag(LocalDate.now());
		entity.setTaetigAgent(true);
		entity.setTaetigAuftraggeber("Auftra");
		entity.setTaetigGemeinsameKunden(true);
		entity.setZefixStatus(HRStatusEnum.NONE);
		entity.setZefixCompanyName("Zefix CName");
		entity.setZefixPolGemeinde("Zefix Pol");
		entity.setZefixChNr("Zefix123");
		entity.setZefixUid("12456");
		entity.setZefixShabNr("12");
		entity.setZefixShabDate(LocalDate.now());
		entity.setAngestellteVrHonorare(DUMMY_VALUE);
		entity.setAngestellteGiAnz(1000);
		entity.setAngestellteGiLohnSumme(DUMMY_VALUE);
		entity.setAngestellteGiLohnSeit(LocalDate.now());
		entity.setAngestellteGiHatKinder(true);
		entity.setAngestellteAngAnz(1000);
		entity.setAngestellteAngLohnSumme(DUMMY_VALUE);
		entity.setAngestellteAngLohnSeit(LocalDate.now());
		entity.setAngestellteAngHatKinder(true);
		entity.setAngestellteUebAnz(1000);
		entity.setAngestellteUebLohnSumme(DUMMY_VALUE);
		entity.setAngestellteUebLohnSeit(LocalDate.now());
		entity.setAngestellteUebHatKinder(true);
		entity.setKontaktVorname("KVName");
		entity.setKontaktFamilienname("KFName");
		entity.setKontaktTelefon("1234");
		entity.setKontaktMobile("1234");
		entity.setKontaktEmail("hha@elca.vn");
		entity.setKontaktBemerkungen("Desc");
		entity.setAdresseKontakt(dataHelper.createAddress());
		entity.setAdresseTreuhand(dataHelper.createAddress());
		entity.setSonderPartnerWeb(true);
		entity.setSonderVerband(true);
		entity.setSonderBvg(true);
		entity.setSonderUvg(true);
		entity.setSonderKkv(true);
		entity.setSonderWeitere(true);
		entity.setSonderFormulare(1000);
		entity.setSozialversUvg("SUVG");
		entity.setSozialversBvg(true);
		entity.setSozialversBvgName("BvgName");
		entity.setSozialversBvgGrund("BvgGrund");
		entity.setLohnbuchPapier(true);
		entity.setLohnbuchComputer(true);
		entity.setLohnbuchSuva(true);
		entity.setLohnbuchTreuhaender(true);

		entity.getAhvFiliales()
			.forEach(item -> {
				item.setAngestellte(1000L);
				item.setLohnSumme(DUMMY_VALUE);
				item.setSeit(LocalDate.now());
			});

		entity.getAhvTeilhabers()
			.forEach(item -> {
				item.setBisherAk("AK");;
				item.setBisherVon(LocalDate.now());;
				item.setBisherBis(LocalDate.now().plusYears(1));
				item.setBisherVerbandAkId(cacheService.getVerbands().get(1).getId());
				item.setBisherBerufVerbandId(cacheService.getVerbands().get(1).getId());
				item.setBisherHatKinder(true);;
				item.setMitarbeit(AhvMitarbeitEnum.HAUPTERWERB);
				item.setMitarbeitRolle("MRolle");
				item.setMitarbeitBezeichnung("MBezeichnung");
				item.setMitarbeitName("MName");
				item.setMitarbeitStrasse("MAddress");
				item.setMitarbeitPlzOrt("70001");
				item.setMitarbeitStaaten("MSta");
				item.setEinkommenEinkommen(DUMMY_VALUE);
				item.setEinkommenAnteilAmGewinn(DUMMY_VALUE);
				item.setEinkommenAnteilAmVerlust(DUMMY_VALUE);
				item.setEinkommenRechnung(true);
				item.setEinkommenLohn(true);
				item.setEinkommenProvision(true);
				item.setLastenUnkosten(true);
				item.setLastenUnterhalt(true);
				item.setLastenGarantie(true);
				item.setLastenMaterial(true);
				item.setLastenInkassorisiko(true);
				item.setLastenVerluste(true);
				item.setLastenLohnanspruch(true);
				item.setLastenRisiko("Riskio");
				item.setAoaWeisung(true);
				item.setAoaKonkurrenzverbot(true);
				item.setAoaPersoenlich(true);
				item.setAoaName(AhvNamenEnum.AUFTRAGGEBER);
				item.setAoaBriefpapier(true);
				item.setAoaWerbung(true);
				item.setAoaOfferten(true);
				item.setAoaRechnungen(true);
				item.setAoaRabatte(true);
				item.setAoaKundendienst(true);
				item.setPartnerArbeitetMit(true);
				item.setPartnerEinkommenUeber(true);
				item.setPartnerLohnSumme(DUMMY_VALUE);
				item.setPartnerLohnSeit(LocalDate.now());
				item.setPartnerHatKinder(true);
				item.setComplete(true);
				item.setBisherBeitragAls(applicationService.getCodeWerts(KategorieEnum.AHV_BEITRAG_ALS).get(0).getId());
				item.setBisherEinkommen(DUMMY_VALUE);
			});

		KontoEntity konten = new KontoEntity();
		konten.setOrganisation(organisation);
		konten.setZweck(ZahlungszweckEnum.AHV);
		konten.setTyp(KontotypEnum.NOCH);
		kontoRepository.save(konten);

		return service.completeProcess(entity);
	}

	@Override
	protected ProzessTypEnum getProcessType() {
		return ProzessTypEnum.AHV;
	}

}
