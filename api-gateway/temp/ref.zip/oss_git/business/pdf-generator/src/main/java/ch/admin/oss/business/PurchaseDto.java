/*
 * PurchaseDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;

import ch.admin.oss.OssCurrencyFormatter;

/**
 * @author hhg
 *
 */
public class PurchaseDto {

	@OssCurrencyFormatter(integer = true)
	private BigDecimal werkzeug;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal warenInv;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal fahrzeug;
	@OssCurrencyFormatter(integer = true)
	private BigDecimal weitere;
	private String weitereArt;
	
	public PurchaseDto(BigDecimal werkzeug, BigDecimal warenInv, BigDecimal fahrzeug, BigDecimal weitere, String weitereArt) {
		this.werkzeug = werkzeug;
		this.warenInv = warenInv;
		this.fahrzeug = fahrzeug;
		this.weitere = weitere;
		this.weitereArt = weitereArt;
	}

	public BigDecimal getWerkzeug() {
		return werkzeug;
	}

	public BigDecimal getWarenInv() {
		return warenInv;
	}

	public BigDecimal getFahrzeug() {
		return fahrzeug;
	}

	public BigDecimal getWeitere() {
		return weitere;
	}

	public String getWeitereArt() {
		return weitereArt;
	}
}
