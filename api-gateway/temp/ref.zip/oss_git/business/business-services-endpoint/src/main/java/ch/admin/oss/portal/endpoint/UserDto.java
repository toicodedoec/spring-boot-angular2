package ch.admin.oss.portal.endpoint;

import ch.admin.oss.common.AbstractOSSDto;

public class UserDto extends AbstractOSSDto {
	private String eid;
	private String familienname;
	private String vorname;
	private String email;

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getFamilienname() {
		return familienname;
	}

	public void setFamilienname(String familienname) {
		this.familienname = familienname;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
