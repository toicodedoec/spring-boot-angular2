package ch.admin.oss.portal.endpoint;

import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.security.AuthorizedPermission;

public class OrganisationShortInfoDto {
	private Long orgId;
	private String companyName;
	private AuthorizedPermission permission;
	private AdresseDto domizil;
	private OrganisationProcessesDto openProcesses;
	private OrganisationProcessesDto finishedProcesses;
	private boolean displayOpenProcess;

	public OrganisationShortInfoDto() {
		this.openProcesses = new OrganisationProcessesDto();
		this.finishedProcesses = new OrganisationProcessesDto();
		this.domizil = new AdresseDto();
		displayOpenProcess = true;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public AuthorizedPermission getPermission() {
		return permission;
	}

	public void setPermission(AuthorizedPermission permission) {
		this.permission = permission;
	}

	public AdresseDto getDomizil() {
		return domizil;
	}

	public void setDomizil(AdresseDto domizil) {
		this.domizil = domizil;
	}

	public boolean isDisplayOpenProcess() {
		return displayOpenProcess;
	}

	public void setDisplayOpenProcess(boolean displayOpenProcess) {
		this.displayOpenProcess = displayOpenProcess;
	}

	public OrganisationProcessesDto getOpenProcesses() {
		return openProcesses;
	}

	public void setOpenProcesses(OrganisationProcessesDto openProcesses) {
		this.openProcesses = openProcesses;
	}

	public OrganisationProcessesDto getFinishedProcesses() {
		return finishedProcesses;
	}

	public void setFinishedProcesses(OrganisationProcessesDto finishedProcesses) {
		this.finishedProcesses = finishedProcesses;
	}
	
}
