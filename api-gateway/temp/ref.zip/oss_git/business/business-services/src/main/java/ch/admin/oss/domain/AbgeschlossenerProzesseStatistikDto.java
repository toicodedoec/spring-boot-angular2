package ch.admin.oss.domain;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;

@Entity
@SqlResultSetMapping(name = "AbgeschlossenerProzesseStatistikDto", entities = @EntityResult(entityClass = AbgeschlossenerProzesseStatistikDto.class))
public class AbgeschlossenerProzesseStatistikDto {
	@Id
	private String monYear;
	private Long hr;
	private Long ahv;
	private Long uvg;
	private Long mwst;
	private Long mwstEintrbest;
	private Long mwstAbmeldung;
	private Long mwstAdressaenderung;
	private Long mwstFristverlaengerung;
	
	public String getMonYear() {
		return monYear;
	}
	public void setMonYear(String monYear) {
		this.monYear = monYear;
	}
	public Long getHr() {
		return hr;
	}
	public void setHr(Long hr) {
		this.hr = hr;
	}
	public Long getAhv() {
		return ahv;
	}
	public void setAhv(Long ahv) {
		this.ahv = ahv;
	}
	public Long getUvg() {
		return uvg;
	}
	public void setUvg(Long uvg) {
		this.uvg = uvg;
	}
	public Long getMwst() {
		return mwst;
	}
	public void setMwst(Long mwst) {
		this.mwst = mwst;
	}
	public Long getMwstEintrbest() {
		return mwstEintrbest;
	}
	public void setMwstEintrbest(Long mwstEintrbest) {
		this.mwstEintrbest = mwstEintrbest;
	}
	public Long getMwstAbmeldung() {
		return mwstAbmeldung;
	}
	public void setMwstAbmeldung(Long mwstAbmeldung) {
		this.mwstAbmeldung = mwstAbmeldung;
	}
	public Long getMwstAdressaenderung() {
		return mwstAdressaenderung;
	}
	public void setMwstAdressaenderung(Long mwstAdressaenderung) {
		this.mwstAdressaenderung = mwstAdressaenderung;
	}
	public Long getMwstFristverlaengerung() {
		return mwstFristverlaengerung;
	}
	public void setMwstFristverlaengerung(Long mwstFristverlaengerung) {
		this.mwstFristverlaengerung = mwstFristverlaengerung;
	}
	
}