/*
 * GeschaftsrolleEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;
import org.hibernate.annotations.FetchProfiles;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.FetchProfile.FetchOverride;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.validator.OSSSytemValidator;

/**
 *  
 * @author coh
 */
@FetchProfiles({
	@FetchProfile(
		fetchOverrides = {
			@FetchOverride(association = "person", entity = GeschaftsrolleEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "funktion", entity = GeschaftsrolleEntity.class, mode = FetchMode.JOIN),
		}, 
		name = "geschaeftsrollen-with-person-and-funktion"
	),
	@FetchProfile(
		fetchOverrides = {
			@FetchOverride(association = "person", entity = GeschaftsrolleEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "funktion", entity = GeschaftsrolleEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "haftung", entity = GeschaftsrolleEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "zeichnung", entity = GeschaftsrolleEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "einlage", entity = GeschaftsrolleEntity.class, mode = FetchMode.JOIN)
		}, 
		name = "full-geschaeftsrollen-except-organisation"
	)
})
@Audited
@Entity
@Table(name = "T_GESCHAFTSROLLE", 
	uniqueConstraints = {
		@UniqueConstraint(name = "UK_GESCHAFTSROLLE_ORGA_PERSON", columnNames = {"LN_ORGANISATION", "LN_PERSON"})
	})
public class GeschaftsrolleEntity extends AbstractOSSEntity {

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ORGANISATION", foreignKey = @ForeignKey(name="FK_GESCHAFTSROLLE_ORGA"))
	private OrganisationEntity organisation;
	
	@NotNull(groups = {OSSSytemValidator.class})
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_PERSON", foreignKey = @ForeignKey(name="FK_GESCHAFTSROLLE_PERSON"))
	private PersonEntity person;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_FUNKTION", foreignKey = @ForeignKey(name="FK_GESCHAFTSROLLE_CODE_WERT_1"))
	private CodeWertEntity funktion;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_HAFTUNG", foreignKey = @ForeignKey(name="FK_GESCHAFTSROLLE_CODE_WERT_2"))
	private CodeWertEntity haftung;
	
	@Column(name = "HAFTUNG_CHF")
	private BigDecimal haftungCHF;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_ZEICHNUNG", foreignKey = @ForeignKey(name="FK_GESCHAFTSROLLE_CODE_WERT_3"))
	private CodeWertEntity zeichnung;
	
	@Column(name = "NUR_HAUPTSITZ", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean nurHauptsitz;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_EINLAGE", foreignKey = @ForeignKey(name="FK_GESCHAFTSROLLE_CODE_WERT_4"))
	private CodeWertEntity einlage;
	
	@Column(name = "STAMMANTEILE")
	private Integer stammanteile;
	
	@Column(name = "TYPE")
	@Enumerated(EnumType.STRING)
	private GeschaeftsrolleTypEnum typ;
	
	@Column(name = "COMPLETE", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean complete;
	
	@Column(name = "ANZ_INHABERAKTIEN")
	private Integer anzInhaberaktien;
	
	@Column(name = "ANZ_NAMENSAKTIEN")
	private Integer anzNamensaktien;
	
	@Column(name = "ANZ_STAMMANTEILE")
	private Integer anzStammanteile;
	
	@Column(name = "DELETED", length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean delete = false;

	public OrganisationEntity getOrganisation() {
		return organisation;
	}

	public void setOrganisation(OrganisationEntity organisation) {
		this.organisation = organisation;
	}

	public PersonEntity getPerson() {
		return person;
	}

	public void setPerson(PersonEntity person) {
		this.person = person;
	}

	public CodeWertEntity getFunktion() {
		return funktion;
	}

	public void setFunktion(CodeWertEntity funktion) {
		this.funktion = funktion;
	}

	public CodeWertEntity getHaftung() {
		return haftung;
	}

	public void setHaftung(CodeWertEntity haftung) {
		this.haftung = haftung;
	}

	public BigDecimal getHaftungCHF() {
		return haftungCHF;
	}

	public void setHaftungCHF(BigDecimal haftungCHF) {
		this.haftungCHF = haftungCHF;
	}

	public CodeWertEntity getZeichnung() {
		return zeichnung;
	}

	public void setZeichnung(CodeWertEntity zeichnung) {
		this.zeichnung = zeichnung;
	}

	public boolean isNurHauptsitz() {
		return nurHauptsitz;
	}

	public void setNurHauptsitz(boolean nurHauptsitz) {
		this.nurHauptsitz = nurHauptsitz;
	}

	public CodeWertEntity getEinlage() {
		return einlage;
	}

	public void setEinlage(CodeWertEntity einlage) {
		this.einlage = einlage;
	}

	public Integer getStammanteile() {
		return stammanteile;
	}

	public void setStammanteile(Integer stammanteile) {
		this.stammanteile = stammanteile;
	}

	public GeschaeftsrolleTypEnum getTyp() {
		return typ;
	}

	public void setTyp(GeschaeftsrolleTypEnum typ) {
		this.typ = typ;
	}

	public boolean isComplete() {
		return complete;
	}

	public void setComplete(boolean complete) {
		this.complete = complete;
	}

	public Integer getAnzInhaberaktien() {
		return anzInhaberaktien;
	}

	public void setAnzInhaberaktien(Integer anzInhaberaktien) {
		this.anzInhaberaktien = anzInhaberaktien;
	}

	public Integer getAnzNamensaktien() {
		return anzNamensaktien;
	}

	public void setAnzNamensaktien(Integer anzNamensaktien) {
		this.anzNamensaktien = anzNamensaktien;
	}

	public Integer getAnzStammanteile() {
		return anzStammanteile;
	}

	public void setAnzStammanteile(Integer anzStammanteile) {
		this.anzStammanteile = anzStammanteile;
	}

	public boolean isDelete() {
		return delete;
	}

	public void setDelete(boolean delete) {
		this.delete = delete;
	}
	
	public void copyFrom(GeschaftsrolleEntity entity) {
		setAnzInhaberaktien(entity.getAnzInhaberaktien());
		setAnzNamensaktien(entity.getAnzNamensaktien());
		setAnzStammanteile(entity.getAnzStammanteile());
		setComplete(entity.isComplete());
		setDelete(entity.isDelete());
		setEinlage(entity.getEinlage());
		setFunktion(entity.getFunktion());
		setHaftung(entity.getHaftung());
		setHaftungCHF(entity.getHaftungCHF());
		setNurHauptsitz(entity.isNurHauptsitz());
		setStammanteile(entity.getStammanteile());
		setTyp(entity.getTyp());
		setZeichnung(entity.getZeichnung());
		person.copyFrom(entity.getPerson());
	}
}
