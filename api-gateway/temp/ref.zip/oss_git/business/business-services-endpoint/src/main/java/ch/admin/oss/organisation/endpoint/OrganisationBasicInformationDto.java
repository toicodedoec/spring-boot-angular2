/*
 * OrganisationBasicInformationDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import java.util.List;

import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.OssNumberFormatUtil;
import ch.admin.oss.common.enums.RechtsformEnum;

/**
 * @author tdm
 */
public class OrganisationBasicInformationDto {

	private FirmennameDto defaultName;
	private AdresseDto domizil;
	private String uid;
	private RechtsformEnum rechtsform;

	List<ZugriffDto> zugrrifs;

	List<EinladungDto> einladungs;

	public OrganisationBasicInformationDto() {}

	public FirmennameDto getDefaultName() {
		return defaultName;
	}

	public void setDefaultName(FirmennameDto defaultName) {
		this.defaultName = defaultName;
	}

	public AdresseDto getDomizil() {
		return domizil;
	}

	public void setDomizil(AdresseDto domizil) {
		this.domizil = domizil;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}

	public List<ZugriffDto> getZugrrifs() {
		return zugrrifs;
	}

	public void setZugrrifs(List<ZugriffDto> zugrrifs) {
		this.zugrrifs = zugrrifs;
	}

	public List<EinladungDto> getEinladungs() {
		return einladungs;
	}

	public void setEinladungs(List<EinladungDto> einladungs) {
		this.einladungs = einladungs;
	}

	public String getUidFormatted() {
		return OssNumberFormatUtil.formatUid(uid);
	}
}
