/*
 * UserEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;
import org.hibernate.validator.constraints.NotBlank;

import ch.admin.oss.common.SupportedLanguage;

/**
 * 
 * @author coh
 */
@Audited
@Entity
@Table(name = "T_USER")
public class UserEntity extends AbstractOSSEntity {

	@NotBlank
	@Column(name = "EID", nullable = false)
	private String eid;

	@Column(name = "FAMILIENNAME")
	private String familienname;

	@Column(name = "VORNAME")
	private String vorname;

	@Column(name = "EMAIL")
	private String email;

	@NotNull
	@Column(name = "LANGUAGE", length = 2, nullable = false)
	@Enumerated(EnumType.STRING)
	private SupportedLanguage language;

	@OneToOne(fetch = FetchType.LAZY, mappedBy = "user")
	private PflichtenabklaerungenEntity pflichten;

	@Column(name = "CREATED_TS", nullable = false)
	private LocalDateTime createdTimeStamp;

	public UserEntity() {
		// Default constructor.
	}

	/**
	 * Use this constructor for setting entity reference.
	 * 
	 * @param userId
	 */
	public UserEntity(long userId) {
		this.setId(userId);
	}

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public String getFamilienname() {
		return familienname;
	}

	public void setFamilienname(String familienname) {
		this.familienname = familienname;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public SupportedLanguage getLanguage() {
		return language;
	}

	public void setLanguage(SupportedLanguage language) {
		this.language = language;
	}

	public PflichtenabklaerungenEntity getPflichten() {
		return pflichten;
	}

	public void setPflichten(PflichtenabklaerungenEntity pflichten) {
		this.pflichten = pflichten;
	}

	public LocalDateTime getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(LocalDateTime createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
}
