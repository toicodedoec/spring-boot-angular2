/*
 * ZipUtil
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import ch.admin.oss.common.OssTechnicalException;

/**
 * Provide utilities for Zip.
 * 
 * @author hha
 */
public class ZipUtil {

	public static void createZipFile(File zipFile, Map<String, byte[]> dataMap) {
		try {
			Files.createDirectories(zipFile.toPath().getParent());
			Files.createFile(zipFile.toPath());
		} catch (IOException e) {
			throw new OssTechnicalException("Cannot create new file " + zipFile, e);
		}
		try (FileOutputStream fos = new FileOutputStream(zipFile);
			 ZipOutputStream zos = new ZipOutputStream(fos)) {
			if (dataMap != null) {
				dataMap.forEach((fileName, data) -> {
					try {
						addFile(zos, fileName, data);
					} catch (IOException e) {
						throw new OssTechnicalException("Cannot add file " + fileName + " to zip file", e);
					}
				});
			}
		} catch (FileNotFoundException e) {
			throw new OssTechnicalException("Cannot create zip file " + zipFile, e);
		} catch (IOException e) {
			throw new OssTechnicalException("Cannot create zip file " + zipFile, e);
		}
	}

	private static void addFile(ZipOutputStream zos, String filename, byte[] input) throws IOException {
		// Create a new entry.
		ZipEntry entry = new ZipEntry(filename);
	    entry.setSize(input.length);

	    // Write to zip output.
	    zos.putNextEntry(entry);
	    zos.write(input);
	    zos.closeEntry();
	}

}
