package ch.admin.oss.ahv.endpoint;

import javax.validation.constraints.NotNull;

import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.enums.KontotypEnum;
import ch.admin.oss.common.enums.ZahlungszweckEnum;

public class KontoDto extends AbstractOSSDto {

	@NotNull
	private KontotypEnum typ;

	private Long orgId;
	private String inhaber;
	private String ort;
	private String kontonummer;
	private String bankname;
	private String plz;
	private String land;
	private String landText;
	private String bankleitzahl;
	private String pc;
	private ZahlungszweckEnum zweck;

	public String getInhaber() {
		return inhaber;
	}

	public void setInhaber(String inhaber) {
		this.inhaber = inhaber;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public ZahlungszweckEnum getZweck() {
		return zweck;
	}

	public void setZweck(ZahlungszweckEnum zweck) {
		this.zweck = zweck;
	}

	public String getKontonummer() {
		return kontonummer;
	}

	public void setKontonummer(String kontonummer) {
		this.kontonummer = kontonummer;
	}

	public String getBankname() {
		return bankname;
	}

	public void setBankname(String bankname) {
		this.bankname = bankname;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}

	public String getLand() {
		return land;
	}

	public void setLand(String land) {
		this.land = land;
	}

	public String getBankleitzahl() {
		return bankleitzahl;
	}

	public void setBankleitzahl(String bankleitzahl) {
		this.bankleitzahl = bankleitzahl;
	}

	public String getPc() {
		return pc;
	}

	public void setPc(String pc) {
		this.pc = pc;
	}

	public Long getOrgId() {
		return orgId;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public KontotypEnum getTyp() {
		return typ;
	}

	public void setTyp(KontotypEnum typ) {
		this.typ = typ;
	}

	public String getLandText() {
		return landText;
	}

	public void setLandText(String landText) {
		this.landText = landText;
	}
}
