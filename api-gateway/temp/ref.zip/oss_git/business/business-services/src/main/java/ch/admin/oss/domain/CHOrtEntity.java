/*
 * CHOrtEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *  
 * @author coh
 */
@Entity
@Table(name = "T_CH_ORT")
public class CHOrtEntity extends AbstractOSSEntity {
	
	public static final String CH_ALL_KANTON = "CH";

	@Column(name = "BFSNR")
	private int bfsnr;
	
	@Column(name = "ORT")
	private String ort;
	
	@Column(name = "POLGEMEINDE")
	private String polGemeinde;
	
	@Column(name = "KANTON")
	private String kanton;
	
	@Column(name = "PLZ")
	private String plz;

	public int getBfsnr() {
		return bfsnr;
	}

	public String getOrt() {
		return ort;
	}

	public String getPolGemeinde() {
		return polGemeinde;
	}

	public String getKanton() {
		return kanton;
	}

	public String getPlz() {
		return plz;
	}
}
