package ch.admin.oss.moa.endpoint;

public class MoaDataDto {
	private String uuid; // session/company identifier
	private String anmeldungPdfUrl; // url main pdf document
	private String pdf1Url; // url of additional pdf document 1
	private String pdf2Url; // url of additional pdf document 2
	private String pdf3Url; // url of additional pdf document 3
	private String pdf4Url; // url of additional pdf document 4
	private Object userData; // company data, which has previously been
									// sent to MOA from getUserData
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getAnmeldungPdfUrl() {
		return anmeldungPdfUrl;
	}
	public void setAnmeldungPdfUrl(String anmeldungPdfUrl) {
		this.anmeldungPdfUrl = anmeldungPdfUrl;
	}
	public String getPdf1Url() {
		return pdf1Url;
	}
	public void setPdf1Url(String pdf1Url) {
		this.pdf1Url = pdf1Url;
	}
	public String getPdf2Url() {
		return pdf2Url;
	}
	public void setPdf2Url(String pdf2Url) {
		this.pdf2Url = pdf2Url;
	}
	public String getPdf3Url() {
		return pdf3Url;
	}
	public void setPdf3Url(String pdf3Url) {
		this.pdf3Url = pdf3Url;
	}
	public String getPdf4Url() {
		return pdf4Url;
	}
	public void setPdf4Url(String pdf4Url) {
		this.pdf4Url = pdf4Url;
	}
	public Object getUserData() {
		return userData;
	}
	public void setUserData(Object userData) {
		this.userData = userData;
	}
}
