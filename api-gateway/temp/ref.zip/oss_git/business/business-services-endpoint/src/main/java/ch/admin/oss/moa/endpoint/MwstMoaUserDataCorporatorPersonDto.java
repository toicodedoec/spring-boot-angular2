package ch.admin.oss.moa.endpoint;

public class MwstMoaUserDataCorporatorPersonDto {

	private int title;

	private String nationality;

	private String lastName;

	private String firstName;

	private String birthday;

	private String socialSecurityNum;

	private String homeTown;

	private String placeOfBirth;

	public MwstMoaUserDataCorporatorPersonDto() {
		placeOfBirth = null;
	}
	
	public MwstMoaUserDataCorporatorPersonDto(int title, String nationality) {
		this.title = title;
		this.nationality = nationality;
		placeOfBirth = null;
	}

	public void setTitle(int title) {
		this.title = title;
	}

	public int getTitle() {
		return title;
	}

	public String getNationality() {
		return nationality;
	}

	public String getLastName() {
		return lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getBirthday() {
		return birthday;
	}

	public String getSocialSecurityNum() {
		return socialSecurityNum;
	}

	public String getHomeTown() {
		return homeTown;
	}

	public String getPlaceOfBirth() {
		return placeOfBirth;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public void setSocialSecurityNum(String socialSecurityNum) {
		this.socialSecurityNum = socialSecurityNum;
	}

	public void setHomeTown(String homeTown) {
		this.homeTown = homeTown;
	}

	public void setPlaceOfBirth(String placeOfBirth) {
		this.placeOfBirth = placeOfBirth;
	}

}
