/*
 * OrganisationServiceTest
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.service;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.querydsl.jpa.impl.JPAQuery;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.ahv.service.IAhvService;
import ch.admin.oss.business.AbstractOSSTest;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.common.enums.HrMutationPersonTypeOfChangeEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonEnum;
import ch.admin.oss.common.enums.ProzessStatusEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrMutationEntity;
import ch.admin.oss.domain.HrMutationPersonEntity;
import ch.admin.oss.domain.OrganisationEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.QProzessEntity;
import ch.admin.oss.hr.service.IHRService;
import ch.admin.oss.hrmutation.repository.IHrMutationPersonRepository;
import ch.admin.oss.hrmutation.repository.IHrMutationRepository;
import ch.admin.oss.mwst.service.IMWSTService;
import ch.admin.oss.organisation.repository.ICodeWertRepository;
import ch.admin.oss.organisation.repository.IFirmennameRepository;
import ch.admin.oss.organisation.repository.IGeschaftsrolleRepository;
import ch.admin.oss.organisation.repository.IOrganisationRepository;
import ch.admin.oss.organisation.repository.IPflichtenabklaerungenRepository;
import ch.admin.oss.organisation.repository.IZugriffRepository;
import ch.admin.oss.portal.repository.IProzessRepository;
import ch.admin.oss.portal.repository.IUserRepository;
import ch.admin.oss.uvg.service.IUVGService;

/**
 * @author xdg
 */
@ActiveProfiles(CommonConstants.PROFILE_TEST)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Transactional
public class OrganisationServiceTest extends AbstractOSSTest {
	@Autowired
	IOrganisationService orgService;

	@Autowired
	IOrganisationRepository orgRepo;

	@Autowired
	IUserRepository userRepo;

	@Autowired
	IFirmennameRepository firmenNameRepo;

	@Autowired
	IZugriffRepository zugriffRepo;

	@Autowired
	IPflichtenabklaerungenRepository pflichtenRepo;

	@Autowired
	ICodeWertRepository codeWertRepo;
	
	@Autowired
	private IAhvService ahvService;

	@Autowired
	private IHRService hrService;
	
	@Autowired
	private IMWSTService mwstService;
	
	@Autowired
	private IUVGService uvgService;
	
	@Autowired
	private IProzessRepository prozessRepo;
	
	@PersistenceContext
	private EntityManager em;
	
	@Test
	public void saveOrganisationFromCratch_connectToDuty() {
		// prepare test data
		PflichtenabklaerungenEntity pflichtenEnt = new PflichtenabklaerungenEntity();
		pflichtenEnt.setRechtsform(RechtsformEnum.EINZELFIRMA);
		pflichtenEnt.setUser(getCurrentLoginUser());
		long pflichtenId = pflichtenRepo.saveAndFlush(pflichtenEnt).getId();
		
		long initialOrgCount = orgRepo.count();
		long initialFirmenNameCount = firmenNameRepo.count();
		long initialZugriffCount = zugriffRepo.count();

		// execute
		OrganisationEntity org = orgService.createOrganisationFromScratch("TEST_ELCA_0001", true);

		// verify
		Assert.assertTrue(initialOrgCount + 1 == orgRepo.count());
		Assert.assertTrue(initialFirmenNameCount + 1 == firmenNameRepo.count());
		Assert.assertTrue(initialZugriffCount + 1 == zugriffRepo.count());
		
		// TODO: check with PHD about saveAndFlush
		// Assert.assertNotNull(pflichtenRepo.findOne(pflichtenId).getOrganisation());
		// Assert.assertNull(pflichtenRepo.findOne(pflichtenId).getUser());
	}

	@Test
	public void saveOrganisationFromCratch_notConnectToDuty() {
		long initialCount = orgRepo.count();
		
		PflichtenabklaerungenEntity pflichtenEnt = new PflichtenabklaerungenEntity();
		pflichtenEnt.setRechtsform(RechtsformEnum.EINZELFIRMA);
		pflichtenEnt = pflichtenRepo.saveAndFlush(pflichtenEnt);
		
		// execute
		OrganisationEntity org = orgService.createOrganisationFromScratch("TEST_ELCA_0001", false);
		// verify
		Assert.assertTrue(initialCount + 1 == orgRepo.count());
		
		// TODO: check with PHD about saveAndFlush
		// Assert.assertNull(orgRepo.findOne(zugriff.getOrganisation().getId()).getPflichtenabklaerungen());
		// Assert.assertNotNull(userRepo.findOne(userId).getPflichten());
	}
	
	@Test
	public void markProcessExternal() {
		//prepare data
		OrganisationEntity org = orgService.createOrganisationFromScratch("TestEFCompany", false);
		
		addUserAuthorizedCompany("TestEFCompany", org);
		
		PflichtenabklaerungenEntity pflichEnt = new PflichtenabklaerungenEntity();
		pflichEnt.setAnmeldungHR(true);
		pflichEnt.setCompleted(true);
		pflichEnt.setEroeffnungsdatum(LocalDate.now());
		pflichEnt.setRechtsform(RechtsformEnum.EINZELFIRMA);
		
		OrganisationEntity orgEnt = orgRepo.findOne(org.getId());
		orgEnt.setBaseDataComplete(true);
		orgEnt.setPflichtenabklaerungen(pflichEnt);
		
		orgEnt = orgService.updateOrganisation(orgEnt);
		
		hrService.createProcess(orgEnt).getProzess().getStatuswechsels().size();
		int ahvStatuswechsels = ahvService.createProcess(orgEnt).getProzess().getStatuswechsels().size();
		int mwstStatuswechsels = mwstService.createProcess(orgEnt).getProzess().getStatuswechsels().size();
		int uvgStatuswechsels = uvgService.createProcess(orgEnt).getProzess().getStatuswechsels().size();
		
		//update data
		orgEnt.getPflichtenabklaerungen().setAnmeldungAHV(true);
		orgEnt.getPflichtenabklaerungen().setAnmeldungMWST(true);
		orgEnt.getPflichtenabklaerungen().setAnmeldungUVG(false);
		
		orgService.markProcessExternal(orgEnt.getId(), orgEnt.getPflichtenabklaerungen());
		
		//verify
		List<ProzessEntity> prozesses = new JPAQuery<ProzessEntity>(em)
			.from(QProzessEntity.prozessEntity)
			.where(QProzessEntity.prozessEntity.organisation.id.eq(orgEnt.getId()))
			.fetch();
		
		prozesses.stream().forEach(prozess -> {
			switch (prozess.getTyp()) {
				case AHV:
					verifyProcessStatus(prozess, ProzessStatusEnum.EXTERN, ahvStatuswechsels + 1);
					break;
				case MWST:
					verifyProcessStatus(prozess, ProzessStatusEnum.EXTERN, mwstStatuswechsels + 1);
					break;
				case UVG:
					verifyProcessStatus(prozess, ProzessStatusEnum.INITIAL, uvgStatuswechsels);
					break;
				default:
					break;
			}
		});
	}
	
	private void verifyProcessStatus(ProzessEntity prozess, ProzessStatusEnum expectedStatus,
		int expectedAhvStatuswechsels) {
		Assert.assertTrue("Invalid process status : Expected: " + expectedStatus + " - Actual: " + prozess.getStatus()
			+ " for process type " + prozess.getTyp(), prozess.getStatus() == expectedStatus);
		Assert.assertTrue(
			"Invalid number of Statuswechsels : Expected: " + expectedAhvStatuswechsels + " - Actual: "
				+ prozess.getStatuswechsels().size() + " for process type " + prozess.getTyp(),
			expectedAhvStatuswechsels == prozess.getStatuswechsels().size());
	}
	
	@Autowired
	private IHrMutationRepository hrMutationRepo;

	@Autowired
	private IHrMutationPersonRepository hrMutationPersonRepo;

	@Autowired
	private IGeschaftsrolleRepository geschaftsrolleRepository;
	

	@Test
	public void test() {
		HrMutationPersonEntity newEntity = new HrMutationPersonEntity();

		GeschaftsrolleEntity newNaturalPerson = new GeschaftsrolleEntity();

		newEntity.setNewNaturalPerson(geschaftsrolleRepository.save(newNaturalPerson));

		HrMutationEntity mutationEnt = new HrMutationEntity();

		mutationEnt.setExcerptsNum(0);
		mutationEnt.setExcerptsNumPrelim(0);

		mutationEnt.setTaskAddress(true);
		mutationEnt.setTaskDissolution(true);
		mutationEnt.setTaskExcerpts(true);
		mutationEnt.setTaskName(true);
		mutationEnt.setTaskPersons(true);
		mutationEnt.setTaskPurpose(true);
		mutationEnt.setTaskRevision(true);

		newEntity.setHrMutation(hrMutationRepo.save(mutationEnt));

		newEntity.setTypeOfChange(HrMutationPersonTypeOfChangeEnum.ADD);

		newEntity.setTypeOfPerson(HrMutationTypeOfPersonEnum.NATURAL);

		Assert.assertNotNull(hrMutationPersonRepo.save(newEntity).getId());
	}
	
}
