/*
 * OSSEnumDeserializer
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.io.IOException;
import java.util.Collection;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.deser.ContextualDeserializer;

/**
 * @author hhg
 *
 */
public class OSSEnumDeserializer extends JsonDeserializer<Enum<?>> implements ContextualDeserializer {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property)
		throws JsonMappingException {
		return new JsonDeserializer<Enum<?>>() {

			@Override
			public Enum<?> deserialize(JsonParser p, DeserializationContext ctxt)
				throws IOException, JsonProcessingException {
				Integer ordinal = p.readValueAs(Integer.class);
				if (ordinal == null) {
					return null;
				}
				return (Enum<?>) getPropertyType(property).getEnumConstants()[ordinal];
			}
		};
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Enum<?> deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JsonProcessingException {
		throw new IllegalStateException("Contextual deserializer should be used");
	}
	
	private Class<?> getPropertyType(BeanProperty property) {
		Class<?> clazz = property.getType().getRawClass();
		if (Collection.class.isAssignableFrom(clazz)) {
			return property.getType().getContentType().getRawClass();
		}
		return (clazz.isArray()) ? clazz.getComponentType() : clazz;
	}

}
