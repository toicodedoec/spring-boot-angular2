/*
 * OrganisationDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import ch.admin.oss.ahv.endpoint.KontoDto;
import ch.admin.oss.common.AbstractOSSDto;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.CommonAddress;
import ch.admin.oss.common.FlowHistoryDto;
import ch.admin.oss.common.GeschaftsrolleDto;
import ch.admin.oss.common.OwnerInfoDto;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.OrganisationCreationTypeEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.externalinterfaces.outgoing.zefix.CompanyDetailedInfoDto;
import ch.admin.oss.portal.endpoint.BrancheDto;
import ch.admin.oss.portal.endpoint.PflichtenabklaerungenDto;

/**
 * @author hhg
 */
public class OrganisationDto extends AbstractOSSDto {

	private String uid;
	private String chNr;

	@NotNull
	private RechtsformEnum rechtsform;

	@Valid
	@NotNull(groups = {CommonAddress.class, OrganisationDomizilAddress.class})
	private AdresseDto domizil;

	private PflichtenabklaerungenDto pflichtenabklaerungen;
	private PflichtenabklaerungenDto userPflichtenabklaerungen;

	@Valid
	@NotNull
	private List<GeschaftsrolleDto> geschaeftsrollens = new ArrayList<GeschaftsrolleDto>();

	private List<GeschaeftsstellenDto> geschaeftsstellens = new ArrayList<GeschaeftsstellenDto>();
	private KommGesDto kommGes;
	private OwnerInfoDto<GeschaftsrolleDto> selectedOwner;
	private LegalPartnerInfoDto selectedLegalPartner;
	private GeschaeftsstellenDto selectedBranche;

	@Valid
	@NotNull
	private List<BrancheDto> branches;

	@NotNull
	private String zweck;

	@NotNull
	private Date eroeffnungsDatum;

	@NotNull
	private Date geschaeftsjahrEnd;

	private HRStatusEnum hrStatus;
	private boolean validName;
	private String shabNr;
	private String shabPage;
	private Date shabDatum;
	private String shabId;
	private CompanyDetailedInfoDto importData;

	@NotNull
	private List<FirmennameDto> namens;

	private FlowHistoryDto flowHistory = new FlowHistoryDto();
	private List<KontoDto> kontens;
	private boolean baseDataLocked;
	private boolean baseDataComplete;
	private Date zefixImportDate;
	private boolean accessFromHrZefixImportFlow;
	private boolean accessFromOutsideFlow;
	private OrganisationCreationTypeEnum creationType;

	public List<KontoDto> getKontens() {
		return kontens;
	}

	public void setKontens(List<KontoDto> kontens) {
		this.kontens = kontens;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getChNr() {
		return chNr;
	}

	public void setChNr(String chNr) {
		this.chNr = chNr;
	}

	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}

	public PflichtenabklaerungenDto getPflichtenabklaerungen() {
		return pflichtenabklaerungen;
	}

	public void setPflichtenabklaerungen(PflichtenabklaerungenDto pflichtenabklaerungen) {
		this.pflichtenabklaerungen = pflichtenabklaerungen;
	}

	public PflichtenabklaerungenDto getUserPflichtenabklaerungen() {
		return userPflichtenabklaerungen;
	}

	public void setUserPflichtenabklaerungen(PflichtenabklaerungenDto userPflichtenabklaerungen) {
		this.userPflichtenabklaerungen = userPflichtenabklaerungen;
	}

	public AdresseDto getDomizil() {
		return domizil;
	}

	public void setDomizil(AdresseDto domizil) {
		this.domizil = domizil;
	}

	public List<GeschaftsrolleDto> getGeschaeftsrollens() {
		return geschaeftsrollens;
	}

	public void setGeschaeftsrollens(List<GeschaftsrolleDto> geschaeftsrollens) {
		this.geschaeftsrollens = geschaeftsrollens;
	}

	public KommGesDto getKommGes() {
		return kommGes;
	}

	public void setKommGes(KommGesDto kommGes) {
		this.kommGes = kommGes;
	}

	public OwnerInfoDto<GeschaftsrolleDto> getSelectedOwner() {
		return selectedOwner;
	}

	public void setSelectedOwner(OwnerInfoDto<GeschaftsrolleDto> selectedOwner) {
		this.selectedOwner = selectedOwner;
	}

	public LegalPartnerInfoDto getSelectedLegalPartner() {
		return selectedLegalPartner;
	}

	public void setSelectedLegalPartner(LegalPartnerInfoDto selectedLegalPartner) {
		this.selectedLegalPartner = selectedLegalPartner;
	}

	public List<BrancheDto> getBranches() {
		return branches;
	}

	public void setBranches(List<BrancheDto> branches) {
		this.branches = branches;
	}

	public String getZweck() {
		return zweck;
	}

	public void setZweck(String zweck) {
		this.zweck = zweck;
	}

	public HRStatusEnum getHrStatus() {
		return hrStatus;
	}

	public boolean isValidName() {
		return validName;
	}

	public Date getEroeffnungsDatum() {
		return eroeffnungsDatum;
	}

	public void setEroeffnungsDatum(Date eroeffnungsDatum) {
		this.eroeffnungsDatum = eroeffnungsDatum;
	}

	public Date getGeschaeftsjahrEnd() {
		return geschaeftsjahrEnd;
	}

	public void setGeschaeftsjahrEnd(Date geschaeftsjahrEnd) {
		this.geschaeftsjahrEnd = geschaeftsjahrEnd;
	}

	public void setHrStatus(HRStatusEnum hrStatus) {
		this.hrStatus = hrStatus;
	}

	public void setValidName(boolean validName) {
		this.validName = validName;
	}

	public List<GeschaeftsstellenDto> getGeschaeftsstellens() {
		return geschaeftsstellens;
	}

	public void setGeschaeftsstellens(List<GeschaeftsstellenDto> geschaeftsstellens) {
		this.geschaeftsstellens = geschaeftsstellens;
	}

	public GeschaeftsstellenDto getSelectedBranche() {
		return selectedBranche;
	}

	public void setSelectedBranche(GeschaeftsstellenDto selectedBranche) {
		this.selectedBranche = selectedBranche;
	}

	public String getShabNr() {
		return shabNr;
	}

	public void setShabNr(String shabNr) {
		this.shabNr = shabNr;
	}

	public String getShabPage() {
		return shabPage;
	}

	public void setShabPage(String shabPage) {
		this.shabPage = shabPage;
	}

	public Date getShabDatum() {
		return shabDatum;
	}

	public void setShabDatum(Date shabDatum) {
		this.shabDatum = shabDatum;
	}

	public String getShabId() {
		return shabId;
	}

	public void setShabId(String shabId) {
		this.shabId = shabId;
	}

	public CompanyDetailedInfoDto getImportData() {
		return importData;
	}

	public void setImportData(CompanyDetailedInfoDto importData) {
		this.importData = importData;
	}

	public List<FirmennameDto> getNamens() {
		return namens;
	}

	public void setNamens(List<FirmennameDto> namens) {
		this.namens = namens;
	}

	public FlowHistoryDto getFlowHistory() {
		return flowHistory;
	}

	public void setFlowHistory(FlowHistoryDto flowHistory) {
		this.flowHistory = flowHistory;
	}

	public boolean isBaseDataLocked() {
		return baseDataLocked;
	}

	public void setBaseDataLocked(boolean baseDataLocked) {
		this.baseDataLocked = baseDataLocked;
	}

	public Date getZefixImportDate() {
		return zefixImportDate;
	}

	public void setZefixImportDate(Date zefixImportDate) {
		this.zefixImportDate = zefixImportDate;
	}

	public boolean isAccessFromHrZefixImportFlow() {
		return accessFromHrZefixImportFlow;
	}

	public void setAccessFromHrZefixImportFlow(boolean accessFromHrZefixImportFlow) {
		this.accessFromHrZefixImportFlow = accessFromHrZefixImportFlow;
	}

	public boolean isAccessFromOutsideFlow() {
		return accessFromOutsideFlow;
	}

	public void setAccessFromOutsideFlow(boolean accessFromOutsideFlow) {
		this.accessFromOutsideFlow = accessFromOutsideFlow;
	}

	public boolean isBaseDataComplete() {
		return baseDataComplete;
	}

	public void setBaseDataComplete(boolean baseDataComplete) {
		this.baseDataComplete = baseDataComplete;
	}

	public OrganisationCreationTypeEnum getCreationType() {
		return creationType;
	}

	public void setCreationType(OrganisationCreationTypeEnum creationType) {
		this.creationType = creationType;
	}
}
