/*
 * AutoCompletePersonResultDto
 * 
 * Project: OSS
 *
 * Copyright 2017 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common.dto;

import ch.admin.oss.common.enums.HrMutationTypeOfPersonRoleEnum;
import ch.admin.oss.util.OSSConstants;

/**
 * @author xdg
 */
public class AutoCompletePersonResultDto {

	private Long id;
	private int version;
	// Natural person
	private String familienname;
	private String vorname;
	private String function;
	private String zeichnung;
	private String personTypeForDisplaying;
	// Legal person
	private String legalName;
	private String ort;
	
	private HrMutationTypeOfPersonRoleEnum personType;

	@SuppressWarnings("unused")
	private String displayText;

	public AutoCompletePersonResultDto() {}

	public AutoCompletePersonResultDto(Long id, int version, String familienname, String vorname, String function,
		String zeichnung, String personTypeForDisplaying, HrMutationTypeOfPersonRoleEnum personType) {
		this.setId(id);
		this.setVersion(version);
		this.familienname = familienname;
		this.vorname = vorname;
		this.function = function;
		this.zeichnung = zeichnung;
		this.personTypeForDisplaying = personTypeForDisplaying;
		this.personType = personType;
	}
	
	public AutoCompletePersonResultDto(Long id, int version, String legalName, String ort, HrMutationTypeOfPersonRoleEnum personType) {
		this.setId(id);
		this.setVersion(version);
		this.legalName = legalName;
		this.ort = ort;
		this.personType = personType;
	}

	public String getDisplayText() {
		if (personType == HrMutationTypeOfPersonRoleEnum.LEGAL) {
			return this.getId().equals(-1L) ? familienname : legalName + OSSConstants.SPACE + ", " + ort;
		} else {
			return this.getId().equals(-1L) ? familienname
				: familienname + OSSConstants.SPACE + vorname + " (" + personTypeForDisplaying + OSSConstants.COMMA_DISPLAY
					+ function + OSSConstants.COMMA_DISPLAY + zeichnung + ")";
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	public int getVersion() {
		return version;
	}
	
	public void setVersion(int version) {
		this.version = version;
	}

	public String getFunction() {
		return function;
	}

	public void setFunction(String function) {
		this.function = function;
	}

	public String getZeichnung() {
		return zeichnung;
	}

	public void setZeichnung(String zeichnung) {
		this.zeichnung = zeichnung;
	}

	public HrMutationTypeOfPersonRoleEnum getPersonType() {
		return personType;
	}

	public void setPersonType(HrMutationTypeOfPersonRoleEnum personType) {
		this.personType = personType;
	}

	public void setDisplayText(String displayText) {
		this.displayText = displayText;
	}

	public String getFamilienname() {
		return familienname;
	}

	public void setFamilienname(String familienname) {
		this.familienname = familienname;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getHaftung() {
		return function;
	}

	public void setHaftung(String haftung) {
		this.function = haftung;
	}
}
