/*
 * OssAsposeContext
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */
package ch.admin.oss.generator.aspose;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ch.admin.oss.OssPdfGenerateTechnicalException;
import ch.admin.oss.generator.aspose.converter.OssAsposeAnnotationConverter;
import ch.admin.oss.generator.aspose.converter.OssAsposeConverter;

/**
 * @author hha
 */
public class OssAsposeContext {

	private final Map<Class<?>, OssAsposeConverter<?>> converterMap = new HashMap<>();
	private final Map<Class<? extends Annotation>, OssAsposeAnnotationConverter<?>> annotationConverterMap = new HashMap<>();
	private final List<Class<? extends Annotation>> orderedAnotationClasses = new ArrayList<>();

	public <T> OssAsposeContext register(Class<T> clazz, OssAsposeConverter<T> converter) {
		converterMap.put(clazz, converter);
		return this;
	}

	public OssAsposeConverter<?> getConverter(Class<?> clazz) {
		return converterMap.get(clazz);
	}

	public OssAsposeContext registerAnnotation(Class<? extends Annotation> clazz, OssAsposeAnnotationConverter<?> converter) {
		orderedAnotationClasses.add(clazz);
		annotationConverterMap.put(clazz, converter);
		return this;
	}

	public OssAsposeAnnotationConverter<?> getAnnotationConverter(Class<? extends Annotation> clazz) {
		return annotationConverterMap.get(clazz);
	}
	
	public Collection<Class<? extends Annotation>> getAnotationClasses() {
		return orderedAnotationClasses;
	}

	public Object formatValue(Object entity, String fieldName, Object originalValue) {
		if (originalValue == null) {
			return null;
		}

		Object value = originalValue;
		OssAsposeConverter<?> typeConverter = getConverter(originalValue.getClass());
		if (typeConverter != null) {
			value = typeConverter.convertObject(this, value);
		}

		for (Class<? extends Annotation> annotationType : getAnotationClasses()) {
			Annotation annotation = getField(entity.getClass(), fieldName).getDeclaredAnnotation(annotationType);
			if (annotation != null) {
				value = getAnnotationConverter(annotationType).convertObject(this, originalValue, value, annotation);
			}
		}

		return value;
	}
	
	public static Field getField(Class<?> inClazz, String fieldName) {
		if (inClazz == null) {
			throw new OssPdfGenerateTechnicalException("Cannot find field " + fieldName + " because of unknown class");
		}
		Field field = null;
		Class<?> clazz = inClazz;
		while (clazz != null && field == null) {
			try {
				field = clazz.getDeclaredField(fieldName);
			} catch (NoSuchFieldException e) {
				// The field doesn't exist in child class.
				// Look up in parent class.
			} catch (SecurityException e) {
				throw new OssPdfGenerateTechnicalException("Cannot access field " + fieldName + " in class " + inClazz.getName(), e);
			}
			clazz = clazz.getSuperclass();
		}
		if (field == null) {
			throw new OssPdfGenerateTechnicalException("Cannot find field " + fieldName + " in class " + inClazz.getName());
		}
		return field;
	}

}