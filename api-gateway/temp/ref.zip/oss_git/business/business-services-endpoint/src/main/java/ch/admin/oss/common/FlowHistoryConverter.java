/*
 * FlowHistoryConverter
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.common;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.dozer.DozerConverter;
import org.hibernate.Hibernate;

import ch.admin.oss.domain.FlowHistoryEntity;
import ch.admin.oss.domain.FlowHistoryItemDataEntity;
import ch.admin.oss.domain.FlowHistoryItemEntity;

/**
 * DOZER converter for translating {@link FlowHistoryEntity} to kind of a multi {@link Map} that is keyed respectively
 * by (1) the history item and (2) its item data's key.
 * 
 * @author phd
 */
public class FlowHistoryConverter extends DozerConverter<FlowHistoryEntity, FlowHistoryDto> {

	public FlowHistoryConverter() {
		super(FlowHistoryEntity.class, FlowHistoryDto.class);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public FlowHistoryDto convertTo(FlowHistoryEntity source, FlowHistoryDto destination) {
		if (source == null) {
			return null;
		}
		if (!Hibernate.isInitialized(source) || !Hibernate.isInitialized(source.getItems())) {
			return new FlowHistoryDto();
		}
		return new FlowHistoryDto(source.getId(), source.getCallbackURL(), source.getItems().stream()
			.map(item -> {
				if (!Hibernate.isInitialized(item.getData())) {
					return new FlowHistoryItemDto(item.getName(), new HashMap<String, String>());
				}
				return new FlowHistoryItemDto(item.getName(),
				item.getData().stream()
					.collect(Collectors.toMap(FlowHistoryItemDataEntity::getKey, FlowHistoryItemDataEntity::getValue)));
			}).collect(Collectors.toList()));
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public FlowHistoryEntity convertFrom(FlowHistoryDto source, FlowHistoryEntity destination) {
		if (source == null || source.getItems().isEmpty()) {
			return destination;
		}
		destination.setCallbackURL(source.getCallbackURL());
		return destination.replaceItems(source.getItems().stream()
			.map(item -> new FlowHistoryItemEntity(item.getName(),
				item.getData().entrySet().stream()
					.map(itemData -> new FlowHistoryItemDataEntity(itemData.getKey(), itemData.getValue()))
					.collect(Collectors.toSet())))
			.collect(Collectors.toList()));
	}
}
