/*
 * GeschaftslokaleDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

import java.math.BigDecimal;
import java.time.LocalDate;

import ch.admin.oss.OssCurrencyFormatter;

/**
 * @author hhg
 *
 */
public class GeschaftslokaleDto {
	
	private String street;
	private String houseNr;
	private String zip;
	private String city;
	@OssCurrencyFormatter
	private BigDecimal lohnSumme;
	private Long numMa;
	private LocalDate seit;
	
	public GeschaftslokaleDto(String street, String houseNr, String zip, String city, BigDecimal lohnSumme, Long angestellte, LocalDate seit) {
		this.street = street;
		this.houseNr = houseNr;
		this.zip = zip;
		this.city = city;
		this.lohnSumme = lohnSumme;
		this.numMa = angestellte;
		this.seit = seit;
	}
	
	public String getStreet() {
		return street;
	}
	
	public String getHouseNr() {
		return houseNr;
	}
	
	public String getZip() {
		return zip;
	}
	
	public String getCity() {
		return city;
	}
	
	public BigDecimal getLohnSumme() {
		return lohnSumme;
	}
	
	public Long getNumMa() {
		return numMa;
	}

	public LocalDate getSeit() {
		return seit;
	}
}
