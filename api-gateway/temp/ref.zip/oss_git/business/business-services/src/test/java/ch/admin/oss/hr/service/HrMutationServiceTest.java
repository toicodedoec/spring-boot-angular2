/*
 * HrMutationServiceTest
 * 
 * Project: OSS
 *
 * Copyright 2017 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hr.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import ch.admin.oss.BusinessServicesConfig;
import ch.admin.oss.business.AbstractOSSTest;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.common.enums.HrMutationPersonTypeOfChangeEnum;
import ch.admin.oss.common.enums.HrMutationTypeOfPersonEnum;
import ch.admin.oss.domain.GeschaftsrolleEntity;
import ch.admin.oss.domain.HrMutationEntity;
import ch.admin.oss.domain.HrMutationPersonEntity;
import ch.admin.oss.hrmutation.repository.IHrMutationPersonRepository;
import ch.admin.oss.hrmutation.repository.IHrMutationRepository;
import ch.admin.oss.organisation.repository.IGeschaftsrolleRepository;

/**
 * @author xdg
 */
@ActiveProfiles(CommonConstants.PROFILE_TEST)
@RunWith(SpringRunner.class)
@ContextConfiguration(classes = BusinessServicesConfig.class, initializers = ConfigFileApplicationContextInitializer.class)
@Transactional
public class HrMutationServiceTest extends AbstractOSSTest {

	@Autowired
	private IHrMutationRepository hrMutationRepo;

	@Autowired
	private IHrMutationPersonRepository hrMutationPersonRepo;

	@Autowired
	private IGeschaftsrolleRepository geschaftsrolleRepository;
	

	@Test
	public void test() {
		HrMutationPersonEntity newEntity = new HrMutationPersonEntity();

		GeschaftsrolleEntity newNaturalPerson = new GeschaftsrolleEntity();

		newEntity.setNewNaturalPerson(geschaftsrolleRepository.save(newNaturalPerson));

		HrMutationEntity mutationEnt = new HrMutationEntity();

		mutationEnt.setExcerptsNum(0);
		mutationEnt.setExcerptsNumPrelim(0);

		mutationEnt.setTaskAddress(true);
		mutationEnt.setTaskDissolution(true);
		mutationEnt.setTaskExcerpts(true);
		mutationEnt.setTaskName(true);
		mutationEnt.setTaskPersons(true);
		mutationEnt.setTaskPurpose(true);
		mutationEnt.setTaskRevision(true);

		newEntity.setHrMutation(hrMutationRepo.save(mutationEnt));

		newEntity.setTypeOfChange(HrMutationPersonTypeOfChangeEnum.ADD);

		newEntity.setTypeOfPerson(HrMutationTypeOfPersonEnum.NATURAL);

		hrMutationPersonRepo.save(newEntity);
	}

}
