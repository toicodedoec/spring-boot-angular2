/*
 * PrivatePortalServiceEndpoint
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.portal.endpoint;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Validate;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;

import ch.admin.oss.common.AbstractOSSEndpoint;
import ch.admin.oss.common.AdresseDto;
import ch.admin.oss.common.CommonConstants;
import ch.admin.oss.common.ExceptionHandlingController;
import ch.admin.oss.domain.AdresseEntity;
import ch.admin.oss.domain.EinladungEntity;
import ch.admin.oss.domain.PflichtenabklaerungenEntity;
import ch.admin.oss.domain.ProzessEntity;
import ch.admin.oss.domain.ZugriffEntity;
import ch.admin.oss.exception.EinladungNotFoundException;
import ch.admin.oss.exception.InvitationWasExpiredException;
import ch.admin.oss.exception.UserWasAlreadyLinkedToOrganizationException;
import ch.admin.oss.organisation.endpoint.EinladungDto;
import ch.admin.oss.organisation.endpoint.ZugriffDto;
import ch.admin.oss.organisation.service.IOrganisationService;
import ch.admin.oss.portal.service.IPortalService;
import ch.admin.oss.security.AuthorizedOrganisation;
import ch.admin.oss.security.AuthorizedPermission;
import ch.admin.oss.security.OssUser;
import ch.admin.oss.security.SecurityUtil;
import ch.admin.oss.util.OSSDateUtil;

/**
 * @author phd
 */
@CrossOrigin
@RestController
@RequestMapping("/private/ext/")
public class PrivatePortalServiceEndpoint extends AbstractOSSEndpoint {

	private static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(PrivatePortalServiceEndpoint.class);

	public static final String ACTIVITY_DTO_DOZER_MAPPER_ID = "ACTIVITY_DTO_DOZER_MAPPER_ID";
	public static final String PORTAL_PFLICHTENABKLAERUNGEN = "PFLICHTENABKLAERUNGEN";
	public static final String LOGIN_INVITATION_TARGET = "invitation";

	@Autowired
	private IPortalService portalService;
	
	@Autowired
	private IOrganisationService orgService;
		
	@Value("${oss.dashboard.pageSize.process}")
	private Long pageSizeProcess;
	
	@Value("${oss.dashboard.pageSize.company}")
	private Long pageSizeCompany;
	
	@RequestMapping(value = "login", method = RequestMethod.GET)
	public void login(HttpServletResponse httpServletResponse, @RequestParam(name="target", required = false) String target,
		@RequestParam(name="code", required = false) String code) throws IOException {
		// SECOOSS-514 - Link invite new user doesn't work
		switch (StringUtils.defaultIfBlank(target, StringUtils.EMPTY)) {
			case CommonConstants.LOGIN_INVITATION_TARGET:
				httpServletResponse.sendRedirect(getFrontendRootUrl() + "/#/invitation/" + code);
				break;
			default:
				httpServletResponse.sendRedirect(getFrontendRootUrl() + "/#/dashboard");
				break;
		}
	}
	
	@RequestMapping(value = "enterprise/{orgId}", method = RequestMethod.GET)
	public EnterpriseDashboardDto getEnterpriseData(@PathVariable Long orgId) {
		
		AuthorizedOrganisation authOrg = SecurityUtil.currentUser().getAuthorizedCompanies()
			.stream().filter(org -> org.getOrgId().equals(orgId)).findFirst().get();
		
		EnterpriseDashboardDto dto = new EnterpriseDashboardDto();
		dto.setDefaultName(authOrg.getDefaultOrgName());
		dto.setOrgId(orgId);
		dto.setZugrrifs(new ArrayList<>());
		dto.setEinladungs(new ArrayList<>());
		
		orgService.getZugriff(orgId).stream().forEach(z -> {
			dto.getZugrrifs().add(mapper.map(z, ZugriffDto.class));
		});
		orgService.getEinladung(orgId).stream().forEach(z -> {
			dto.getEinladungs().add(mapper.map(z, EinladungDto.class));
		});
		dto.setDomizil(mapper.map(portalService.getAdresses(Lists.newArrayList(authOrg.getDomizilId())).stream().findFirst().get(), 
			AdresseDto.class));
		
		dto.setFinishedProcesses(getFinishedProcesses(orgId, 1L));
		
		OrganisationProcessesDto openProcesses = getOpenedProcesses(Lists.newArrayList(orgId)).get(orgId);
		dto.setOpenProcesses(openProcesses == null ? new OrganisationProcessesDto() : openProcesses);
		
		return dto;
	}
	
	@RequestMapping(value = "getFinishedProcess/{orgId}/{pageNumber}", method = RequestMethod.GET)
	public OrganisationProcessesDto getFinishedProcess(@PathVariable("orgId") long orgId, @PathVariable("pageNumber") long pageNumber) {
		return getFinishedProcesses(orgId, pageNumber);
	}
	
	@RequestMapping(value = "dashboardData", method = RequestMethod.GET)
	public DashboardDto getUserDashboardData() {
		DashboardDto result = new DashboardDto();
		Set<AuthorizedOrganisation> authorOrgs = SecurityUtil.currentUser().getAuthorizedCompanies();
		
		List<Long> domizilIds = authorOrgs.stream().map(org -> org.getDomizilId()).collect(Collectors.toList());
		List<Long> orgIds = authorOrgs.stream().map(org -> org.getOrgId()).collect(Collectors.toList());
		
		result.setTotalCount(Long.valueOf(authorOrgs.size()));
		result.setPageSize(pageSizeCompany);
		
		Map<Long, AdresseEntity> domizilMap = new HashMap<Long, AdresseEntity>();
		if(domizilIds.size() > 0) {
			domizilMap = portalService.getAdresses(domizilIds).stream()
					.collect(Collectors.toMap(key -> key.getId(), value -> value));
		}
		 
		Map<Long, OrganisationProcessesDto> openedProcessesMap = new HashMap<Long, OrganisationProcessesDto>(); 
		if(orgIds.size() > 0) {
			openedProcessesMap = getOpenedProcesses(orgIds);
		}		
		
		for(AuthorizedOrganisation org : authorOrgs) {
			OrganisationShortInfoDto dto = new OrganisationShortInfoDto();			
			dto.setCompanyName(org.getDefaultOrgName());			
			dto.setPermission(org.getPermission());
			AdresseDto adresseDto = mapper.map(domizilMap.get(org.getDomizilId()), AdresseDto.class);
			dto.setDomizil(adresseDto);
			dto.setOrgId(org.getOrgId());
			dto.setFinishedProcesses(getFinishedProcesses(org.getOrgId(), 1L));
			OrganisationProcessesDto openProcesses = openedProcessesMap.get(org.getOrgId());
			dto.setOpenProcesses(openProcesses == null ? new OrganisationProcessesDto() : openProcesses);			
			result.getOrganisations().add(dto);
		}
		
		Collections.sort(result.getOrganisations(), (org1, org2) -> org1.getCompanyName().compareTo(org2.getCompanyName()));
		return result;
	}
	
	private OrganisationProcessesDto getFinishedProcesses(Long orgId, Long pageNumber) {
		OrganisationProcessesDto result = new OrganisationProcessesDto();
		result.setTotalCount(portalService.countProcesses(orgId, false));
		result.setPageNumber(pageNumber);
		result.setPageSize(pageSizeProcess);
		Long offset = (pageNumber - 1) * pageSizeProcess;
		List<ProzessEntity> finshed = portalService.getProcessesSummary(Lists.newArrayList(orgId), false, offset, pageSizeProcess);
		finshed.stream().forEach(p -> {
			result.getProcesses().add(mapActivityDto(p));				
		});
		return result;
	}
	
	private Map<Long, OrganisationProcessesDto> getOpenedProcesses(List<Long> orgIds) {
		List<ProzessEntity> openProcesses = portalService.getProcessesSummary(orgIds, true, 0L, 0L);
		
		Map<Long, List<ProzessEntity>> openProcessMap = openProcesses.stream().collect(Collectors.groupingBy(value 
			-> ((ProzessEntity) value).getOrganisation().getId()));
		
		Comparator<ProzessEntity> comparator = new Comparator<ProzessEntity>() {
			@Override
			public int compare(ProzessEntity o1, ProzessEntity o2) {
				return o2.getBearbdatum().compareTo(o1.getBearbdatum());
			}
		};
		
		Map<Long, OrganisationProcessesDto> result = new HashMap<>();
		for (Entry<Long, List<ProzessEntity>> entry : openProcessMap.entrySet()) {
			List<ProzessEntity> processes = entry.getValue().stream().sorted(comparator).collect(Collectors.toList());
			OrganisationProcessesDto value = new OrganisationProcessesDto();
			processes.stream().forEach(p -> {
				value.getProcesses().add(mapActivityDto(p));				
			});
			result.put(entry.getKey(), value);
		}
		return result;
	}
	
	private ActivityDto mapActivityDto(ProzessEntity prozess) {
		ActivityDto dto = mapper.map(prozess, ActivityDto.class, ACTIVITY_DTO_DOZER_MAPPER_ID);
		dto.setModifyDate(OSSDateUtil.toDate(prozess.getBearbdatum()));
		dto.setZefixImportDate(prozess.getOrganisation().getZefixImportDate());
		return dto;
	}

	@RequestMapping(value = "pflichtenabklaerungen", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	public PflichtenabklaerungenDto pflichtenabklaerungen(@RequestBody PflichtenabklaerungenDto dto) {
		return updatePflichtenabklaerungen(dto);
	}

	private PflichtenabklaerungenDto updatePflichtenabklaerungen(PflichtenabklaerungenDto dto) {
		PflichtenabklaerungenEntity entity = new PflichtenabklaerungenEntity();
		if (dto.getId() != null) {
			entity = portalService.getPflichtenabklaerungenById(dto.getId());
		} else {
			entity.setUser(portalService.findUserByName(SecurityUtil.currentUser().getUsername()));
		}
		mapper.map(dto, entity, PORTAL_PFLICHTENABKLAERUNGEN);
		if (dto.getBeruf() != null) {
			entity.setBeruf(applicationService.getBeruf(dto.getBeruf().getId()));
		} else {
			entity.setBeruf(null);
		}
		entity.getBranches().clear();
		if (CollectionUtils.isNotEmpty(dto.getBranches())) {
			List<Long> brancheIds = dto.getBranches().stream()
				.mapToLong(b -> b.getId())
				.boxed()
				.collect(Collectors.toList());
			entity.getBranches().addAll(applicationService.getBranches(brancheIds));
		}
		entity.setDatum(LocalDateTime.now());
		entity = portalService.save(entity);
		mapper.map(entity, dto, PORTAL_PFLICHTENABKLAERUNGEN);
		return dto;
	}
	
	@RequestMapping(value = "pflichtenabklaerungen/interrupt", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
	public PflichtenabklaerungenDto interruptPflichtenabklaerungen(@RequestBody PflichtenabklaerungenDto dto) {
		return updatePflichtenabklaerungen(dto);
	}

	@RequestMapping(value = "pflichtenabklaerungen/{username}", method = RequestMethod.GET)
	public PflichtenabklaerungenDto userPflichtenabklaerungen(@PathVariable String username) {
		Validate.isTrue(SecurityUtil.currentUser().getUsername().equals(username));
		PflichtenabklaerungenDto dto = new PflichtenabklaerungenDto();
		PflichtenabklaerungenEntity entity = portalService.findPflichtenabklaerungenByUsername(username);
		if (entity != null) {
			mapper.map(entity, dto,PORTAL_PFLICHTENABKLAERUNGEN);
			if (entity.getBeruf() != null) {
				dto.setBeruf(new BerufDto(entity.getBeruf(), SecurityUtil.currentUser().getLanguagePreference()));
			}
			if (CollectionUtils.isNotEmpty(entity.getBranches())) {
				dto.setBranches(entity.getBranches().stream()
					.map(b -> new BrancheDto(b, SecurityUtil.currentUser().getLanguagePreference()))
					.collect(Collectors.toList()));
			}
		}
		return dto;
	}
	
	@RequestMapping(value = "invitation/{einladungCode}", method = RequestMethod.GET)
	public ResponseEntity<?> getUserInvitation(@PathVariable("einladungCode") String einladungCode) {
		try {
			 EinladungEntity einladungEntity = portalService.getEinladungByEinladungCode(einladungCode);
			 return ResponseEntity.ok(mapper.map(einladungEntity, UserInvitationDto.class));
		} catch (EinladungNotFoundException enfe) {
			LOGGER.error("Can not find Einladung with einladungCode: " + einladungCode);
			LOGGER.error("Detail: ", enfe);
			return ResponseEntity.badRequest().body(ExceptionHandlingController.errorFor(EinladungNotFoundException.class.getSimpleName()));
		}
	}
	
	@RequestMapping(value = "invitation/{einladungId}", method = RequestMethod.PUT)
	public void deleteUserInvitation(@PathVariable("einladungId") long einladungId, @RequestParam("einladungVer") int einladungVer) {
		portalService.deleteEinladungById(einladungId, einladungVer);
	}
	
	@RequestMapping(value = "invitation", method = RequestMethod.POST)
	public ResponseEntity<String> createZugriffFromInvitation(@RequestBody UserInvitationDto userInvitation) {
		try {
			OssUser user = SecurityUtil.currentUser();

			ZugriffEntity zugriffEntity = portalService.createZugriffFromInvitation(userInvitation.getOrgId(), userInvitation.getId());

			if(zugriffEntity.getFromDate() == null || !zugriffEntity.getFromDate().isAfter(LocalDate.now())){
				user.addAuthorizedCompany(new AuthorizedOrganisation(
						zugriffEntity.getUser().getEid(),
						zugriffEntity.getOrganisation().getId(), 
						zugriffEntity.getOrganisation().getDomizil().getId(), 
						userInvitation.getOrgName(),
					new AuthorizedPermission(zugriffEntity.getAccessLevel(), zugriffEntity.getStatus(),
						OSSDateUtil.toDate(zugriffEntity.getFromDate()),
						OSSDateUtil.toDate(zugriffEntity.getToDate()))));
				SecurityUtil.updateCurrentUser(user);
			}
			return ResponseEntity.ok("{ \"message\": \"ok\"}");
		} catch (UserWasAlreadyLinkedToOrganizationException odare) {
			LOGGER.error("User [{}] is already linked to the company [{}]", userInvitation.getEid(),
				userInvitation.getOrgId());
			LOGGER.error("Detail: ", odare);
			return ResponseEntity.badRequest().body(ExceptionHandlingController
				.errorFor(UserWasAlreadyLinkedToOrganizationException.class.getSimpleName()));
		} catch (InvitationWasExpiredException ede) {
			LOGGER.error("Invitation was expired" + userInvitation.getId());
			LOGGER.error("Detail: ", ede);
			return ResponseEntity.badRequest()
				.body(ExceptionHandlingController.errorFor(InvitationWasExpiredException.class.getSimpleName()));
		}
	}
	
}
