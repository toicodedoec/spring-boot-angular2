/*
 * IWHOISWebservice
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.whois;

/**
 * A utility class in order to perform the domain check (through WHOIS system).
 *  
 * @author tdm
 */

public interface IWHOISWebservice {
	
	/**
	 * Perform the domain check operation for the input domain name.
	 * 
	 * @param domainName: input domain name to check. 
	 * @return
	 * 
	 */
	WHOISCheckResultEnum checkDomain(String domainName);
}
