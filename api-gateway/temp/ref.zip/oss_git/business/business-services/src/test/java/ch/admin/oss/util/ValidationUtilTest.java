package ch.admin.oss.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Assert;
import org.junit.Test;

public class ValidationUtilTest {
	@Test
	public void isValidAhvNumber() {
		LocalDate geburtsdatumObj = LocalDate.parse("04.11.2016",
			DateTimeFormatter.ofPattern(OSSConstants.DATE_FORMAT));
		LocalDate dummyGeburtsdatumObj = LocalDate.parse("05.11.2017",
			DateTimeFormatter.ofPattern(OSSConstants.DATE_FORMAT));
		
		Assert.assertFalse(ValidationUtil.isValidAhvNumber("", geburtsdatumObj, true));
		Assert.assertFalse(ValidationUtil.isValidAhvNumber(null, geburtsdatumObj, true));
		
		Assert.assertTrue(ValidationUtil.isValidAhvNumber("999.99.999.999", geburtsdatumObj, true));
		Assert.assertTrue(ValidationUtil.isValidAhvNumber("999.99.999.999", geburtsdatumObj, false));
		Assert.assertTrue(ValidationUtil.isValidAhvNumber("999.99.999.999", dummyGeburtsdatumObj, true));
		Assert.assertTrue(ValidationUtil.isValidAhvNumber("999.99.999.999", dummyGeburtsdatumObj, false));

		Assert.assertFalse(ValidationUtil.isValidAhvNumber("123.50.435.004", geburtsdatumObj, true));
		Assert.assertFalse(ValidationUtil.isValidAhvNumber("123.16.656.004", geburtsdatumObj, true));
		Assert.assertFalse(ValidationUtil.isValidAhvNumber("123.16.435.004", geburtsdatumObj, true));

		Assert.assertTrue(ValidationUtil.isValidAhvNumber("123.16.435.007", geburtsdatumObj, true));
		Assert.assertTrue(ValidationUtil.isValidAhvNumber("123.16.835.005", geburtsdatumObj, false));

		Assert.assertFalse(ValidationUtil.isValidAhvNumber("756.16.435.007", geburtsdatumObj, true));
		Assert.assertTrue(ValidationUtil.isValidAhvNumber("756.16.835.009", geburtsdatumObj, false));

		Assert.assertTrue(ValidationUtil.isValidAhvNumber("756.1234.5678.97", geburtsdatumObj, true));
		Assert.assertTrue(ValidationUtil.isValidAhvNumber("756.1234.5678.97", geburtsdatumObj, false));
	}
	
	@Test
	public void isValidStartBizPasswordTest() {
		String original = "intel!";
		String encodedPass1 = "3ae612063a581b7f44b06592fe6aaa302864935098697f7aa936c2e87630607f5719b8a57e97d0f09bea0a3d6404e304c6977c87cff9cbf9ac65d5686b820995";
		
		Assert.assertTrue(ValidationUtil.isValidStartBizPassword(original, encodedPass1, "em9ehGAh+F71yw=="));
	}
}
