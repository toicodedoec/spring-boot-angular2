/*
 * CheckTrademarkResultDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.organisation.endpoint;

import ch.admin.oss.externalinterfaces.outgoing.swissreg.TmtransDto;

/**
 * @author hhg
 *
 */
public class CheckTrademarkResultDto {

	private String error;
	private TmtransDto tmtrans;
	
	public CheckTrademarkResultDto() {
		// default constructor
	}
	
	public CheckTrademarkResultDto(String error) {
		this.error = error;
	}

	public CheckTrademarkResultDto(TmtransDto tmtrans) {
		this.tmtrans = tmtrans;
	}

	public String getError() {
		return error;
	}
	
	public TmtransDto getTmtrans() {
		return tmtrans;
	}
}
