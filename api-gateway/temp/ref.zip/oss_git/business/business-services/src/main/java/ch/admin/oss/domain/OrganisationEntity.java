/*
 * OrganisationEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.FetchProfile;
import org.hibernate.annotations.FetchProfile.FetchOverride;
import org.hibernate.annotations.FetchProfiles;
import org.hibernate.annotations.Type;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import ch.admin.oss.common.enums.GeschaeftsrolleTypEnum;
import ch.admin.oss.common.enums.HRStatusEnum;
import ch.admin.oss.common.enums.OrganisationCreationTypeEnum;
import ch.admin.oss.common.enums.RechtsformEnum;
import ch.admin.oss.common.enums.ZahlungszweckEnum;
import ch.admin.oss.validator.OSSSytemValidator;

/**
 *  
 * @author coh
 */
@FetchProfiles({@FetchProfile
	(
		fetchOverrides = {
			@FetchOverride(association = "geschaeftsrollens", entity = OrganisationEntity.class, mode = FetchMode.JOIN),
			@FetchOverride(association = "domizil", entity = OrganisationEntity.class, mode = FetchMode.JOIN)
		}, 
		name = "organisation-with-geschaeftsrollens-and-domizil"
	)
})
@Audited
@Entity
@Table(name = "T_ORGANISATION")
public class OrganisationEntity extends AbstractOSSEntity {
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "LN_DOMIZIL", foreignKey = @ForeignKey(name="FK_ORGANISATION_ADRESSE"))
	private AdresseEntity domizil;
	
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "organisation", cascade = CascadeType.ALL)
	private PflichtenabklaerungenEntity pflichtenabklaerungen;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "organisation", cascade = CascadeType.ALL)
	private KommGesEntity kommGes;
	
	@NotNull(groups = {OSSSytemValidator.class})
	@Column(name = "ZWECK", length = 4000)
	private String zweck;
	
	@Column(name = "BEMERKUNGEN")
	private String bemerkungen;
	
	@Column(name = "BESCHREIBUNG")
	private String beschreibung;
	
	@Column(name = "RECHTSFORM")
	@Enumerated(EnumType.STRING)
	private RechtsformEnum rechtsform;
	
	@NotNull(groups = {OSSSytemValidator.class})
	@Column(name = "EROEFFNUNGS_DATUM")
	private LocalDate eroeffnungsDatum;
	
	@Column(name = "ERSTRECHNUNGS_DATUM")
	private LocalDate erstrechnungsDatum;
	
	@Column(name = "ERSTAUFTRAGS_DATUM")
	private LocalDate erstauftragsDatum;
	
	@Column(name = "GESCHAEFTSJAHR_START")
	private LocalDate geschaeftsjahrStart;
	
	@NotNull(groups = {OSSSytemValidator.class})
	@Column(name = "GESCHAEFTSJAHR_END")
	private LocalDate geschaeftsjahrEnd;
	
	@Column(name = "CH_NR")
	private String chNr;
	
	@Column(name = "UID_NR")
	private String uid;
	
	@Column(name = "SHAB_NR")
	private String shabNr;
	
	@Column(name = "SHAB_PAGE")
	private String shabPage;
	
	@Column(name = "SHAB_DATUM")
	private LocalDate shabDatum;
	
	@Column(name = "SHAB_ID")
	private String shabId;
	
	@Column(name = "HR_STATUS")
	@Enumerated(EnumType.STRING)
	private HRStatusEnum hrStatus;
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "organisation", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<FirmennameEntity> namens = new HashSet<>();
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "organisation")
	private Set<KontoEntity> kontens = new HashSet<>();
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "organisation", cascade = CascadeType.MERGE)
	private Set<GeschaftsrolleEntity> geschaeftsrollens = new HashSet<>();
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "organisation", cascade = CascadeType.ALL)
	private Set<GeschaeftsstelleEntity> geschaeftsstellens = new HashSet<>();
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@NotNull(groups = {OSSSytemValidator.class})
	@Fetch(FetchMode.SUBSELECT)
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name="T_ORGANISATION_BRANCHE",
		joinColumns=
			@JoinColumn(name="LN_ORGANISATION", referencedColumnName="PK", foreignKey = @ForeignKey(name = "FK_ORG_BRANCHE_ORG")),
		inverseJoinColumns=
			@JoinColumn(name="LN_BRANCHE", referencedColumnName="PK", foreignKey = @ForeignKey(name = "FK_ORG_BRANCHE_BRANCHE")),
		uniqueConstraints={
			@UniqueConstraint(name="UK_ORG_BRANCHE", columnNames = {"LN_ORGANISATION", "LN_BRANCHE"})
		})
	private Set<BrancheEntity> branches = new HashSet<>();
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "organisation", cascade = CascadeType.ALL)
	private Set<ZugriffEntity> zugrrifs = new HashSet<>();
	
	@Fetch(FetchMode.SUBSELECT)
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "organisation")
	private Set<EinladungEntity> einladungs = new HashSet<>();
	
	@Column(name = "ZEFIX_IMPORT_DATE")
	private LocalDate zefixImportDate;
	
	@Column(name = "ZEFIX_IMPORT_HASH")
	private String zefixImportHash;

	// TODO [HHG / S9] To consider remove this column as it is not necessary now.
	@Column(name = "BASE_DATA_LOCKED", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean baseDataLocked;
	
	@Column(name = "BASE_DATA_COMPLETE", nullable = false, length = 1)
	@Type(type = "org.hibernate.type.TrueFalseType")
	private boolean baseDataComplete;
	
	@Column(name = "CREATION_TYPE", nullable = false)
	@Enumerated(EnumType.STRING)
	private OrganisationCreationTypeEnum creationType;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@OneToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "LN_FLOW_HISTORY", foreignKey = @ForeignKey(name = "FK_ORGANISATION_HISTORY"))
	private FlowHistoryEntity flowHistory;
	
	@Column(name = "CREATED_TS", nullable = false)
	private LocalDateTime createdTimeStamp;
	
	public OrganisationEntity() {
		setCreatedTimeStamp(LocalDateTime.now());
		setDomizil(new AdresseEntity());
	}
	
	public AdresseEntity getDomizil() {
		return domizil;
	}

	public void setDomizil(AdresseEntity domizil) {
		this.domizil = domizil;
	}

	public PflichtenabklaerungenEntity getPflichtenabklaerungen() {
		return pflichtenabklaerungen;
	}

	public void setPflichtenabklaerungen(PflichtenabklaerungenEntity pflichtenabklaerungen) {
		this.pflichtenabklaerungen = pflichtenabklaerungen;
	}

	public KommGesEntity getKommGes() {
		return kommGes;
	}

	public void setKommGes(KommGesEntity kommGes) {
		this.kommGes = kommGes;
	}

	public String getZweck() {
		return zweck;
	}

	public void setZweck(String zweck) {
		this.zweck = zweck;
	}

	public String getBemerkungen() {
		return bemerkungen;
	}

	public void setBemerkungen(String bemerkungen) {
		this.bemerkungen = bemerkungen;
	}

	public String getBeschreibung() {
		return beschreibung;
	}

	public void setBeschreibung(String beschreibung) {
		this.beschreibung = beschreibung;
	}

	public RechtsformEnum getRechtsform() {
		return rechtsform;
	}

	public void setRechtsform(RechtsformEnum rechtsform) {
		this.rechtsform = rechtsform;
	}

	public LocalDate getEroeffnungsDatum() {
		return eroeffnungsDatum;
	}

	public void setEroeffnungsDatum(LocalDate eroeffnungsDatum) {
		this.eroeffnungsDatum = eroeffnungsDatum;
	}

	public LocalDate getErstrechnungsDatum() {
		return erstrechnungsDatum;
	}

	public void setErstrechnungsDatum(LocalDate erstrechnungsDatum) {
		this.erstrechnungsDatum = erstrechnungsDatum;
	}

	public LocalDate getErstauftragsDatum() {
		return erstauftragsDatum;
	}

	public void setErstauftragsDatum(LocalDate erstauftragsDatum) {
		this.erstauftragsDatum = erstauftragsDatum;
	}

	public LocalDate getGeschaeftsjahrStart() {
		return geschaeftsjahrStart;
	}

	public void setGeschaeftsjahrStart(LocalDate geschaeftsjahrStart) {
		this.geschaeftsjahrStart = geschaeftsjahrStart;
	}

	public LocalDate getGeschaeftsjahrEnd() {
		return geschaeftsjahrEnd;
	}

	public void setGeschaeftsjahrEnd(LocalDate geschaeftsjahrEnd) {
		this.geschaeftsjahrEnd = geschaeftsjahrEnd;
	}

	public Set<FirmennameEntity> getNamens() {
		return namens;
	}

	public void setNamens(Set<FirmennameEntity> namens) {
		this.namens = namens;
	}

	public Set<KontoEntity> getKontens() {
		return kontens;
	}

	public void setKontens(Set<KontoEntity> kontens) {
		this.kontens = kontens;
	}

	/**
	 * This method is intended to be used by dozer map only. For business access please consider
	 * {@link #getGeschaeftsrollens(GeschaeftsrolleTypEnum)} instead.
	 * 
	 * @return
	 */
	@Deprecated
	public Set<GeschaftsrolleEntity> getGeschaeftsrollens() {
		return geschaeftsrollens;
	}

	public void setGeschaeftsrollens(Set<GeschaftsrolleEntity> geschaeftsrollens) {
		this.geschaeftsrollens = geschaeftsrollens;
	}

	public Set<GeschaeftsstelleEntity> getGeschaeftsstellens() {
		return geschaeftsstellens;
	}

	public void setGeschaeftsstellens(Set<GeschaeftsstelleEntity> geschaeftsstellens) {
		this.geschaeftsstellens = geschaeftsstellens;
	}

	public Set<BrancheEntity> getBranches() {
		return branches;
	}

	public void setBranches(Set<BrancheEntity> branches) {
		this.branches = branches;
	}

	public Set<ZugriffEntity> getZugrrifs() {
		return zugrrifs;
	}

	public void setZugrrifs(Set<ZugriffEntity> zugrrifs) {
		this.zugrrifs = zugrrifs;
	}

	public Set<EinladungEntity> getEinladungs() {
		return einladungs;
	}

	public void setEinladungs(Set<EinladungEntity> einladungs) {
		this.einladungs = einladungs;
	}
	
	public String getChNr() {
		return chNr;
	}

	public void setChNr(String chNr) {
		this.chNr = chNr;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getShabNr() {
		return shabNr;
	}

	public void setShabNr(String shabNr) {
		this.shabNr = shabNr;
	}

	public String getShabPage() {
		return shabPage;
	}

	public void setShabPage(String shabPage) {
		this.shabPage = shabPage;
	}

	public LocalDate getShabDatum() {
		return shabDatum;
	}

	public void setShabDatum(LocalDate shabDatum) {
		this.shabDatum = shabDatum;
	}

	public String getShabId() {
		return shabId;
	}

	public void setShabId(String shabId) {
		this.shabId = shabId;
	}

	public HRStatusEnum getHrStatus() {
		return hrStatus;
	}

	public void setHrStatus(HRStatusEnum hrStatus) {
		if (HRStatusEnum.REGISTERED == hrStatus && hrStatus != this.hrStatus) {
			this.zefixImportDate = LocalDate.now();
		}
		this.hrStatus = hrStatus;
	}

	public LocalDate getZefixImportDate() {
		return zefixImportDate;
	}

	public void setZefixImportDate(LocalDate zefixImportDate) {
		// does nothing
	}

	public String getZefixImportHash() {
		return zefixImportHash;
	}

	public void setZefixImportHash(String zefixImportHash) {
		this.zefixImportHash = zefixImportHash;
	}

	// TODO [HHG / S9] To be removed.
	@Deprecated
	public boolean isBaseDataLocked() {
		return baseDataLocked;
	}

	// TODO [HHG / S9] To be removed.
	@Deprecated
	public void setBaseDataLocked(boolean baseDataLocked) {
		this.baseDataLocked = baseDataLocked;
	}

	public boolean isBaseDataComplete() {
		return baseDataComplete;
	}

	public void setBaseDataComplete(boolean baseDataComplete) {
		this.baseDataComplete = baseDataComplete;
	}
	
	public OrganisationCreationTypeEnum getCreationType() {
		return creationType;
	}

	public void setCreationType(OrganisationCreationTypeEnum creationType) {
		this.creationType = creationType;
	}

	public FlowHistoryEntity getFlowHistory() {
		return flowHistory;
	}

	public void setFlowHistory(FlowHistoryEntity flowHistory) {
		this.flowHistory = flowHistory;
	}
	
	public LocalDateTime getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(LocalDateTime createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public void updateDefaultName(String nameToUpdate) {
		FirmennameEntity defaultName = getNamens().stream().filter(name -> name.isDefault()).findFirst().get();
		defaultName.setBezeichnung(nameToUpdate);
	}
	
	public String defaultName() {
		return getNamens().stream().filter(name -> name.isDefault()).findFirst().get().getBezeichnung();
	}

	public KontoEntity konto(ZahlungszweckEnum zweck) {
		return getKontens().stream().filter(k -> k.getZweck() == zweck).findFirst().get();
	}
	
	@Transient
	public Set<GeschaftsrolleEntity> getGeschaeftsrollens(GeschaeftsrolleTypEnum type) {
		return geschaeftsrollens.stream().filter(g -> g.getTyp() == type).collect(Collectors.toSet());
	}
}
