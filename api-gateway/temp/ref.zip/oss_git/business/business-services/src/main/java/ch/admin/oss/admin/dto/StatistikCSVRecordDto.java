/*
 * StatistikCSVRecordDto
 * 
 * Project: OSS
 *
 * Copyright 2015 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.admin.dto;

import java.util.ArrayList;
import java.util.List;


/**
 * @author coh
 */
public class StatistikCSVRecordDto {

	private String erstellDatum; 
	private String empfanger; 
	private String strasse; 
	private int nummer;
	private int plz;
	private String ort;
	private int bfsnr;
	private String kanton;
	private String firmenname;
	private String rechtsform;
	private String berufsbezeichnung;
	private int hr;
	private String hrDatum;
	private int hrDigital;
	private int ahv;
	private String ahvDatum;
	private int mwst;
	private String mwstDatum;
	private int uvg;
	private String uvgDatum;
	private int mindestens;
	private String mindestensDatum;
	private final List<Integer> branches = new ArrayList<>();
	
	public String getErstellDatum() {
		return erstellDatum;
	}
	public void setErstellDatum(String erstellDatum) {
		this.erstellDatum = erstellDatum;
	}
	public String getEmpfanger() {
		return empfanger;
	}
	public void setEmpfanger(String empfanger) {
		this.empfanger = empfanger;
	}
	public String getStrasse() {
		return strasse;
	}
	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}
	public int getNummer() {
		return nummer;
	}
	public void setNummer(int nummer) {
		this.nummer = nummer;
	}
	public int getPlz() {
		return plz;
	}
	public void setPlz(int plz) {
		this.plz = plz;
	}
	public String getOrt() {
		return ort;
	}
	public void setOrt(String ort) {
		this.ort = ort;
	}
	public int getBfsnr() {
		return bfsnr;
	}
	public void setBfsnr(int bfsnr) {
		this.bfsnr = bfsnr;
	}
	public String getKanton() {
		return kanton;
	}
	public void setKanton(String kanton) {
		this.kanton = kanton;
	}
	public String getFirmenname() {
		return firmenname;
	}
	public void setFirmenname(String firmenname) {
		this.firmenname = firmenname;
	}
	public String getRechtsform() {
		return rechtsform;
	}
	public void setRechtsform(String rechtsform) {
		this.rechtsform = rechtsform;
	}
	public String getBerufsbezeichnung() {
		return berufsbezeichnung;
	}
	public void setBerufsbezeichnung(String berufsbezeichnung) {
		this.berufsbezeichnung = berufsbezeichnung;
	}
	public int getHr() {
		return hr;
	}
	public void setHr(int hr) {
		this.hr = hr;
	}
	public String getHrDatum() {
		return hrDatum;
	}
	public void setHrDatum(String hrDatum) {
		this.hrDatum = hrDatum;
	}
	public int getHrDigital() {
		return hrDigital;
	}
	public void setHrDigital(int hrDigital) {
		this.hrDigital = hrDigital;
	}
	public int getAhv() {
		return ahv;
	}
	public void setAhv(int ahv) {
		this.ahv = ahv;
	}
	public String getAhvDatum() {
		return ahvDatum;
	}
	public void setAhvDatum(String ahvDatum) {
		this.ahvDatum = ahvDatum;
	}
	public int getMwst() {
		return mwst;
	}
	public void setMwst(int mwst) {
		this.mwst = mwst;
	}
	public String getMwstDatum() {
		return mwstDatum;
	}
	public void setMwstDatum(String mwstDatum) {
		this.mwstDatum = mwstDatum;
	}
	public int getUvg() {
		return uvg;
	}
	public void setUvg(int uvg) {
		this.uvg = uvg;
	}
	public String getUvgDatum() {
		return uvgDatum;
	}
	public void setUvgDatum(String uvgDatum) {
		this.uvgDatum = uvgDatum;
	}
	public int getMindestens() {
		return mindestens;
	}
	public void setMindestens(int mindestens) {
		this.mindestens = mindestens;
	}
	public String getMindestensDatum() {
		return mindestensDatum;
	}
	public void setMindestensDatum(String mindestensDatum) {
		this.mindestensDatum = mindestensDatum;
	}
	public List<Integer> getBranches() {
		return branches;
	}
}
