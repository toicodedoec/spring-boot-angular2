/*
 * HrMutationOrgInfoDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.hrmutation.endpoint;

import ch.admin.oss.common.AdresseDto;

public class HrMutationOrgInfoDto {
	private String companyName;
	private String uid;
	private String legalSeat;
	private AdresseDto domizil;
	private String companyPurpose;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getLegalSeat() {
		return legalSeat;
	}

	public void setLegalSeat(String legalSeat) {
		this.legalSeat = legalSeat;
	}

	public AdresseDto getDomizil() {
		return domizil;
	}

	public void setDomizil(AdresseDto domizil) {
		this.domizil = domizil;
	}

	public String getCompanyPurpose() {
		return companyPurpose;
	}

	public void setCompanyPurpose(String companyPurpose) {
		this.companyPurpose = companyPurpose;
	}

}
