/*
 * Gsgr
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.swissreg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author hhg
 *
 */
public class GsgrDto implements Serializable {
	
	private static final long serialVersionUID = -1883775364676683755L;
	
	private List<IntreggDto> intregg = new ArrayList<>();

	public List<IntreggDto> getIntregg() {
		return intregg;
	}

	public void setIntregg(List<IntreggDto> intregg) {
		this.intregg = intregg;
	}
}
