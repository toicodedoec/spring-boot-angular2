/*
 * NotaryOrganisationDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.externalinterfaces.outgoing.hr;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author hha
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class NotaryOrganisationDto implements Serializable {

	private static final long serialVersionUID = -6928216849173721306L;

	private String organizationContactEMail;
	private String organizationAddress;
	private String organizationContactPhone;
	private String organizationContactFax;

	public String getOrganizationContactEMail() {
		return organizationContactEMail;
	}

	public void setOrganizationContactEMail(String organizationContactEMail) {
		this.organizationContactEMail = organizationContactEMail;
	}

	public String getOrganizationAddress() {
		return organizationAddress;
	}

	public void setOrganizationAddress(String organizationAddress) {
		this.organizationAddress = organizationAddress;
	}

	public String getOrganizationContactPhone() {
		return organizationContactPhone;
	}

	public void setOrganizationContactPhone(String organizationContactPhone) {
		this.organizationContactPhone = organizationContactPhone;
	}

	public String getOrganizationContactFax() {
		return organizationContactFax;
	}

	public void setOrganizationContactFax(String organizationContactFax) {
		this.organizationContactFax = organizationContactFax;
	}

}
