/*
 * PersonHeimatortEntity
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.envers.Audited;

/**
 *  
 * @author coh
 */
@Audited
@Entity
@Table(name = "T_PERSON_HEIMATORT")
public class PersonHeimatortEntity extends AbstractOSSEntity {

	@NotNull
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "LN_PERSON", foreignKey = @ForeignKey(name="FK_PERSON_HEIMATORT_PERSON"))
	private PersonEntity person;
	
	@Column(name = "BFSNR")
	private int bfsnr;
	
	@Column(name = "ORT")
	private String ort;
	
	@Column(name = "POLGEMEINDE")
	private String polGemeinde;
	
	@Column(name = "KANTON")
	private String kanton;
	
	@Column(name = "PLZ")
	private String plz;

	public PersonEntity getPerson() {
		return person;
	}

	public void setPerson(PersonEntity person) {
		this.person = person;
	}

	public int getBfsnr() {
		return bfsnr;
	}

	public void setBfsnr(int bfsnr) {
		this.bfsnr = bfsnr;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}

	public String getPolGemeinde() {
		return polGemeinde;
	}

	public void setPolGemeinde(String polGemeinde) {
		this.polGemeinde = polGemeinde;
	}

	public String getKanton() {
		return kanton;
	}

	public void setKanton(String kanton) {
		this.kanton = kanton;
	}

	public String getPlz() {
		return plz;
	}

	public void setPlz(String plz) {
		this.plz = plz;
	}
}
