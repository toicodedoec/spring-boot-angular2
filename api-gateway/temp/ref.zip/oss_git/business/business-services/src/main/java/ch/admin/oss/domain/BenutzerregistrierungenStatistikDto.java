package ch.admin.oss.domain;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;

@Entity
@SqlResultSetMapping(name = "BenutzerregistrierungenStatistikDto", entities = @EntityResult(entityClass = BenutzerregistrierungenStatistikDto.class))
public class BenutzerregistrierungenStatistikDto {
	@Id
	private String month;
	private int userNumber;
	
	public BenutzerregistrierungenStatistikDto() {
	}
	
	public BenutzerregistrierungenStatistikDto(String month, int userNumber) {
		this.month = month;
		this.userNumber = userNumber;
	}

	public int getUserNumber() {
		return userNumber;
	}

	public void setUserNumber(int userNumber) {
		this.userNumber = userNumber;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((month == null) ? 0 : month.hashCode());
		result = prime * result + userNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BenutzerregistrierungenStatistikDto other = (BenutzerregistrierungenStatistikDto) obj;
		if (month == null) {
			if (other.month != null)
				return false;
		} else if (!month.equals(other.month))
			return false;
		if (userNumber != other.userNumber)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "BenutzerregistrierungenStatistikDto [month=" + month + ", userNumber=" + userNumber + "]";
	}
}
