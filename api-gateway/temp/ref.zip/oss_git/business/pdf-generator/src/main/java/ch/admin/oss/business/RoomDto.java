/*
 * RoomDto
 * 
 * Project: OSS
 *
 * Copyright 2016 by ELCA Informatik AG
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of ELCA Informatik AG ("Confidential Information"). You 
 * shall not disclose such "Confidential Information" and shall
 * use it only in accordance with the terms of the license
 * agreement you entered into with ELCA.
 */

package ch.admin.oss.business;

/**
 * @author hhg
 */
public class RoomDto {

	private String raumKeine;
	private String raumEigene;
	private String raumWohnung;
	private String raumKunde;

	public RoomDto(String raumEigene, String raumWohnung, String raumKunde, String raumKeine) {
		this.raumKeine = raumKeine;
		this.raumEigene = raumEigene;
		this.raumWohnung = raumWohnung;
		this.raumKunde = raumKunde;
	}

	public String getRaumKeine() {
		return raumKeine;
	}

	public String getRaumEigene() {
		return raumEigene;
	}

	public String getRaumWohnung() {
		return raumWohnung;
	}

	public String getRaumKunde() {
		return raumKunde;
	}
}
